# postgreshelm — Service Definition

PostgreSQL service deployed via Helm. The broker renders a `values.yaml` per instance; ArgoCD applies the Helm release to the target cluster.

## Directory structure

```
services/postgreshelm/v1/
├── chart/
│   ├── Chart.yaml
│   ├── values.yaml
│   └── templates/          # StatefulSet, Service, ConfigMap, etc.
├── template/
│   └── values.yaml.tmpl    # Jinja2 template rendered per instance
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json         # Instance parameter schema
│   └── metrics.json
└── argocd/
    └── applicationset-helm.yaml.tmpl
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `database_name` | ✓ | — | User database to create (`^[a-zA-Z][a-zA-Z0-9_]*$`, max 64) |
| `database_user` | | `appuser` | Database user with full access |
| `database_password` | | auto | User password (min 8, auto-generated if omitted) |
| `superuser_password` | | auto | PostgreSQL superuser password (min 12, auto-generated if omitted) |
| `cluster_url` | | broker default | ArgoCD-registered cluster URL |

## Key Helm values set per instance

| values.yaml path | Source |
|-----------------|--------|
| `image.registry` | `BYOP_REGISTRY` → runtime registry (substituted by `service-render --mapping`) |
| `image.repository` | `byop/postgres` |
| `image.tag` | `17.10` |
| `settings.superuserPassword` | `spec.superuser_password` |
| `userDatabase.name` | `spec.database_name` |
| `userDatabase.user` | `spec.database_user` |
| `userDatabase.password` | `spec.database_password` |
| `storage.requestedSize` | `storage_size` |

## ApplicationSet

Render `argocd/applicationset-helm.yaml.tmpl` with `service-render`, substituting the variables below, then apply the result to your ArgoCD namespace.

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | Service identifier (`postgreshelm`) |
| `SERVICE_VERSION` | Service version directory (`v1`) |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

The ApplicationSet watches `instances/postgreshelm/*/metadata.yaml` and creates one ArgoCD Application per instance directory.

## Instance directory layout (rendered by the broker)

```
instances/postgreshelm/<instance-name>/
├── metadata.yaml           # Picked up by the ApplicationSet generator
└── values.yaml             # Rendered Helm values
```
