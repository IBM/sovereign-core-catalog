# etcdhelm — Service Definition

etcd distributed key-value store deployed via Helm. The broker renders a `values.yaml` per instance; ArgoCD applies the Helm release to the target cluster.

## Directory structure

```
services/etcdhelm/v1/
├── chart/                  # Helm chart (appVersion v3.4.2)
│   ├── Chart.yaml
│   ├── values.yaml
│   └── templates/          # StatefulSet, Services, etcd config, NetworkPolicy, ServiceMonitor, etc.
├── template/
│   └── values.yaml.tmpl    # Jinja2 template rendered per instance
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json         # Instance parameter schema
│   └── metrics.json
├── imagesetconfiguration.yaml
└── argocd/
    └── applicationset-helm.yaml.tmpl
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `cluster_token` | | auto | Unique etcd cluster token (auto-generated if omitted) |
| `cluster_url` | | broker default | ArgoCD-registered cluster URL |

## Key Helm values set per instance

| values.yaml path | Source |
|-----------------|--------|
| `image.registry` | `BYOP_REGISTRY` → runtime registry (substituted by `service-render --mapping`) |
| `image.repository` | `byop/etcd` |
| `image.tag` | `v3.4.2` |
| `initImage.registry` | `BYOP_REGISTRY` |
| `initImage.repository` | `byop/busybox` |
| `replicas` | `replicas` |
| `settings.clusterToken` | `spec.cluster_token` |
| `storage.requestedSize` | `storage_size` |
| `storage.className` | `ceph-rbd-platform` |

## ApplicationSet

Render `argocd/applicationset-helm.yaml.tmpl` with `sed`, substituting the variables below, then apply the result to your ArgoCD namespace.

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | Service identifier (e.g. `etcd`) |
| `SERVICE_VERSION` | Service version directory (e.g. `v1`) |
| `SERVICE_TYPE` | Service type label (e.g. `etcd`) |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

The ApplicationSet watches `instances/SERVICE_NAME/*/metadata.yaml` and creates one ArgoCD Application per instance directory.

## Instance directory layout (rendered by the broker)

```
instances/etcd/<instance-name>/
├── metadata.yaml           # Picked up by the ApplicationSet generator
└── values.yaml             # Rendered Helm values
```
