# mysqldbhelm — Service Definition

MySQL service deployed via Helm. The broker renders a `values.yaml` per instance; ArgoCD applies the Helm release to the target cluster.

## Directory structure

```
services/mysqldbhelm/v1/
├── chart/                  
│   ├── Chart.yaml
│   ├── values.yaml
│   └── templates/          # StatefulSet, Service, ConfigMap, NetworkPolicy, etc.
├── template/
│   └── values.yaml.tmpl    # Jinja2 template rendered per instance
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json         # Instance parameter schema
│   └── metrics.json
└── argocd/
    └── applicationset-helm.yaml.tmpl
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `database_name` | ✓ | — | Database to create (`^[a-zA-Z][a-zA-Z0-9_]*$`, max 64) |
| `database_user` | | `appuser` | Database user |
| `database_password` | | auto | User password (min 8, auto-generated if omitted) |
| `root_password` | | auto | Root password (min 12, auto-generated if omitted) |
| `cluster_url` | | broker default | ArgoCD-registered cluster URL |

## Key Helm values set per instance

| values.yaml path | Source |
|-----------------|--------|
| `settings.rootPassword.value` | `spec.root_password` |
| `userDatabase.name.value` | `spec.database_name` |
| `userDatabase.user.value` | `spec.database_user` |
| `userDatabase.password.value` | `spec.database_password` |
| `storage.requestedSize` | `storage_size` |
| `storage.className` | `ceph-rbd-platform` |

## ApplicationSet

Render `argocd/applicationset-helm.yaml.tmpl` with `sed`, substituting the variables below, then apply the result to your ArgoCD namespace.

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | Service identifier (e.g. `mysql`) |
| `SERVICE_VERSION` | Service version directory (e.g. `v1`) |
| `SERVICE_TYPE` | Service type label (e.g. `mysql`) |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

The ApplicationSet watches `instances/SERVICE_NAME/*/metadata.yaml` and creates one ArgoCD Application per instance directory.

## Instance directory layout (rendered by the broker)

```
instances/mysql/<instance-name>/
├── metadata.yaml           # Picked up by the ApplicationSet generator
└── values.yaml             # Rendered Helm values
```
