# langflowrthelm — Service Definition

Langflow backend-only runtime service deployed via Helm. Serves pre-built flows as API endpoints — no IDE frontend. The broker renders a `values.yaml` per instance; ArgoCD applies the Helm release to the target cluster.

## Directory structure

```
services/langflowrthelm/v1/
├── chart/                  # langflow-ide chart v0.1.2 (frontend disabled, backend-only mode)
│   ├── Chart.yaml
│   ├── values.yaml
│   └── templates/          # backend StatefulSet, Services, Route (→ backend:7860), OpenShift RBAC
├── template/
│   └── values.yaml.tmpl    # Jinja2 template rendered per instance
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json         # Instance parameter schema
│   └── metrics.json
├── imagesetconfiguration.yaml
├── values-test.yaml
└── argocd/
    └── applicationset-helm.yaml.tmpl
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `api_key` | | auto | API key for authenticating runtime API requests (min 32, auto-generated) |
| `cluster_url` | | broker default | ArgoCD-registered cluster URL |

## Key Helm values set per instance

| values.yaml path | Source |
|-----------------|--------|
| `langflow.backend.image.repository` | `BYOP_REGISTRY/byop/langflow` |
| `langflow.backend.image.tag` | `1.10.2` |
| `langflow.backend.backendOnly` | `true` |
| `langflow.frontend.enabled` | `false` |
| `route.enabled` | `true` — Route points to `langflow-service-backend` on port 7860 |
| `langflow.backend.sqlite.volume.size` | `storage_size` |

## Difference from `langflowhelm` (IDE)

| Feature | `langflowhelm` (IDE) | `langflowrthelm` (Runtime) |
|---------|----------------------|----------------------------|
| Frontend UI | ✅ Enabled (port 8080) | ❌ Disabled |
| Route target | Frontend service :8080 | Backend service :7860 |
| Superuser/login | ✅ Configured | ❌ Not configured |
| Use case | Building flows | Serving flows via API |
| Images mirrored | `langflow` + `langflow-frontend` | `langflow` only |

## ApplicationSet

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | `langflowrt` |
| `SERVICE_VERSION` | `v1` |
| `SERVICE_TYPE` | `langflowrt` |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

## Instance directory layout

```
instances/langflowrt/<instance-name>/
├── metadata.yaml
└── values.yaml
```
