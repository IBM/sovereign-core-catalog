# mariadbkz — Service Definition

MariaDB service deployed via Kustomize. The broker renders credentials into a `Secret` committed alongside the instance manifests; ArgoCD applies everything to the target cluster.

## Directory structure

```
services/mariadbkz/v1/
├── manifests/              # Base Kubernetes resources (StatefulSet, Service, ConfigMap)
├── template/               # Jinja2 templates rendered per instance
│   ├── kustomization.yaml.tmpl
│   └── secret.yaml.tmpl
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json         # Instance parameter schema
│   └── metrics.json
└── argocd/
    └── applicationset-kustomize.yaml.tmpl
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `database_name` | ✓ | — | Database to create (`^[a-zA-Z][a-zA-Z0-9_]*$`, max 64) |
| `database_user` | | `appuser` | Database user (auto-generated if omitted) |
| `database_password` | | auto | User password (min 8, auto-generated if omitted) |
| `root_password` | | auto | Root password (min 12, auto-generated if omitted) |
| `character_set` | | `utf8mb4` | One of `utf8mb4`, `utf8`, `latin1`, `ascii` |
| `collation` | | `utf8mb4_unicode_ci` | Matching collation for the chosen character set |
| `cluster_url` | | broker default | ArgoCD-registered cluster URL |

## Secret produced per instance

The rendered `secret.yaml` creates a Secret named `mariadb-<instance_name>` containing:

| Key | Value |
|-----|-------|
| `root-password` | Root password |
| `user` | Database user |
| `password` | User password |
| `database` | Database name |
| `character-set` | Character set |
| `collation` | Collation |
| `connection-string` | `mariadb://<user>:<password>@mariadb-<instance>:3306/<db>` |
| `jdbc-url` | JDBC connection string |

## ApplicationSet

Render `argocd/applicationset-kustomize.yaml.tmpl` with `sed`, substituting the variables below, then apply the result to your ArgoCD namespace.

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | Service identifier (e.g. `mariadb`) |
| `SERVICE_TYPE` | Service type label (e.g. `mariadb`) |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

The ApplicationSet watches `instances/SERVICE_NAME/*/metadata.yaml` and creates one ArgoCD Application per instance directory.

## Instance directory layout (rendered by the broker)

```
instances/mariadb/<instance-name>/
├── metadata.yaml           # Picked up by the ApplicationSet generator
├── kustomization.yaml      # Points to services/mariadb/latest/manifests as base
└── secret.yaml             # Credentials committed to Git
```
