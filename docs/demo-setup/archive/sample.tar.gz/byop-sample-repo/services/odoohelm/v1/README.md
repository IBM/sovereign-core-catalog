# odoohelm — Service Definition

Odoo ERP service deployed via Helm. The broker renders a `values.yaml` per instance; ArgoCD applies the Helm release to the target cluster. PostgreSQL is provided as a bundled subchart (`postgres` v0.2.26).

## Directory structure

```
services/odoohelm/v1/
├── chart/                  # Helm chart (odoo v1.0.0-alpha, appVersion 18.0)
│   ├── Chart.yaml
│   ├── Chart.lock
│   ├── values.yaml
│   ├── charts/postgres/    # Bundled postgres subchart (v0.2.26, appVersion 13.12)
│   └── templates/          # Deployment, CronJob, Ingress, Route, PVC, HPA, Secrets, etc.
├── template/
│   └── values.yaml.tmpl    # Jinja2 template rendered per instance
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json         # Instance parameter schema
│   └── metrics.json
└── argocd/
    └── applicationset-helm.yaml.tmpl
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `admin_password` | | auto | Odoo master password (auto-generated if omitted) |
| `database_name` | | `odoo` | PostgreSQL database name |
| `database_user` | | `odoo` | PostgreSQL user |
| `database_password` | | auto | PostgreSQL user password (auto-generated if omitted) |
| `postgres_superuser_password` | | auto | PostgreSQL superuser password (auto-generated if omitted) |
| `postgres_storage_size` | | `8Gi` | PostgreSQL PVC size (e.g. `8Gi`, `20Gi`) |
| `storage_size` | | `10Gi` | Odoo filestore PVC size (e.g. `10Gi`, `50Gi`) |
| `workers` | | `2` | Number of Odoo worker processes (0–16) |
| `cluster_url` | | broker default | ArgoCD-registered cluster URL |

## Key Helm values set per instance

| values.yaml path | Source |
|-----------------|--------|
| `odoo.admin_passwd` | `spec.admin_password` |
| `odoo.db_name` | `spec.database_name` |
| `odoo.workers` | `spec.workers` |
| `externalDatabase.host` | `<instance_name>-postgres` |
| `externalDatabase.name` | `spec.database_name` |
| `externalDatabase.user` | `spec.database_user` |
| `externalDatabase.password` | `spec.database_password` |
| `persistence.size` | `spec.storage_size` |
| `persistence.storageClass` | `ceph-rbd-platform` |
| `postgres.settings.superuserPassword` | `spec.postgres_superuser_password` |
| `postgres.userDatabase.name/user/password` | `spec.database_*` |
| `postgres.storage.requestedSize` | `spec.postgres_storage_size` |
| `route.enabled` | `true` (OpenShift Route exposed by default) |

## ApplicationSet

Render `argocd/applicationset-helm.yaml.tmpl` with `sed`, substituting the variables below, then apply the result to your ArgoCD namespace.

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | Service identifier (e.g. `odoo`) |
| `SERVICE_VERSION` | Service version directory (e.g. `v1`) |
| `SERVICE_TYPE` | Service type label (e.g. `odoo`) |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

The ApplicationSet watches `instances/SERVICE_NAME/*/metadata.yaml` and creates one ArgoCD Application per instance directory.

## Instance directory layout (rendered by the broker)

```
instances/odoo/<instance-name>/
├── metadata.yaml           # Picked up by the ApplicationSet generator
└── values.yaml             # Rendered Helm values
```
