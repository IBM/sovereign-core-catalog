# mariadbhelm — Service Definition

MariaDB service deployed via Helm. The broker renders a `values.yaml` per instance; ArgoCD applies the Helm release to the target cluster.

## Directory structure

```
services/mariadbhelm/v1/
├── chart/                  # Helm chart (appVersion 12.3.2)
│   ├── Chart.yaml
│   ├── values.yaml
│   └── templates/          # StatefulSet, Service, ConfigMap, Secret
├── template/
│   └── values.yaml.tmpl    # Jinja2 template rendered per instance
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json         # Instance parameter schema
│   └── metrics.json
└── argocd/
    └── applicationset-helm.yaml.tmpl
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `database_name` | ✓ | — | Database to create (`^[a-zA-Z][a-zA-Z0-9_]*$`, max 64) |
| `database_user` | | `appuser` | Database user |
| `database_password` | | auto | User password (min 8, auto-generated if omitted) |
| `root_password` | | auto | Root password (min 12, auto-generated if omitted) |
| `character_set` | | `utf8mb4` | One of `utf8mb4`, `utf8`, `latin1`, `ascii` |
| `collation` | | `utf8mb4_unicode_ci` | Matching collation for the chosen character set |
| `cluster_url` | | broker default | ArgoCD-registered cluster URL |

## Secret produced per instance

The chart's `templates/secret.yaml` creates a Secret named `mariadb-<instance_name>` containing:

| Key | Value |
|-----|-------|
| `root-password` | Root password |
| `user` | Database user |
| `password` | User password |
| `database` | Database name |
| `character-set` | Character set |
| `collation` | Collation |
| `connection-string` | `mariadb://<user>:<password>@mariadb-<instance>:3306/<db>` |
| `jdbc-url` | JDBC connection string |

## Key Helm values set per instance

| values.yaml path | Source |
|-----------------|--------|
| `auth.rootPassword` | `spec.root_password` |
| `auth.database` | `spec.database_name` |
| `auth.username` | `spec.database_user` |
| `auth.password` | `spec.database_password` |
| `databaseConfig.character-set` | `spec.character_set` |
| `databaseConfig.collation` | `spec.collation` |
| `statefulset.replicas` | `replicas` |
| `persistence.size` | `storage_size` |
| `persistence.storageClass` | `ceph-rbd-platform` |

## ApplicationSet

Render `argocd/applicationset-helm.yaml.tmpl` with `sed`, substituting the variables below, then apply the result to your ArgoCD namespace.

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | Service identifier (e.g. `mariadb`) |
| `SERVICE_VERSION` | Service version directory (e.g. `v1`) |
| `SERVICE_TYPE` | Service type label (e.g. `mariadb`) |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

The ApplicationSet watches `instances/SERVICE_NAME/*/metadata.yaml` and creates one ArgoCD Application per instance directory.

## Instance directory layout (rendered by the broker)

```
instances/mariadb/<instance-name>/
├── metadata.yaml           # Picked up by the ApplicationSet generator
└── values.yaml             # Rendered Helm values
```
