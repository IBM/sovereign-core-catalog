# vaulthelm — Service Definition

HashiCorp Vault deployed via Helm in HA mode with integrated Raft storage. The broker renders a `values.yaml` per instance; ArgoCD applies the Helm release to the target cluster.

## Directory structure

```
services/vaulthelm/v1/
├── chart/                  # HashiCorp Vault Helm chart (v0.30.0, appVersion 1.17.2)
│   ├── Chart.yaml
│   ├── values.yaml
│   ├── values.openshift.yaml
│   └── templates/          # StatefulSet, Services, RBAC, Injector, CSI
├── template/
│   ├── values.yaml.tmpl    # Jinja2 template rendered per instance
│   └── ref.yaml            # Reference values for airgap / HA deployment
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json         # Instance parameter schema
│   └── metrics.json
├── argocd/
│   └── applicationset-helm.yaml.tmpl
└── values-test.yaml        # Local test overrides (standalone, dev mode)
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `cluster_url` | | broker default | ArgoCD-registered cluster URL |

Vault has no user-configurable instance parameters — credentials and storage are fully managed by the chart.

## Key Helm values set per instance

| values.yaml path | Value |
|-----------------|-------|
| `global.namespace` | `namespace` |
| `global.openshift` | `true` — activates built-in OpenShift SCC support |
| `injector.enabled` | `false` |
| `server.image.repository` | `BYOP_REGISTRY/hashicorp/vault` |
| `server.image.tag` | `1.17.2` |
| `server.ha.enabled` | `true` |
| `server.ha.replicas` | `3` |
| `server.ha.raft.enabled` | `true` |
| `server.ha.raft.setNodeId` | `true` |
| `ui.enabled` | `false` |

## ApplicationSet

Render `argocd/applicationset-helm.yaml.tmpl` with `sed`, substituting the variables below, then apply the result to your ArgoCD namespace.

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | Service identifier (e.g. `vaulthelm`) |
| `SERVICE_VERSION` | Service version directory (e.g. `v1`) |
| `SERVICE_TYPE` | Service type label (e.g. `vault`) |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

The ApplicationSet watches `instances/vaulthelm/*/metadata.yaml` and creates one ArgoCD Application per instance directory.

## Instance directory layout (rendered by the broker)

```
instances/vaulthelm/<instance-name>/
├── metadata.yaml           # Picked up by the ApplicationSet generator
└── values.yaml             # Rendered Helm values
```

## Local testing

```bash
helm upgrade --install vault-test services/vaulthelm/v1/chart \
  -f services/vaulthelm/v1/values-test.yaml \
  --create-namespace \
  --namespace vault-test
```

The `values-test.yaml` uses standalone mode and Vault dev mode (auto-unseals, no TLS) for local convenience. HA with Raft is enabled in the production template.
