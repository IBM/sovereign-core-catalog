# olgranitehelm — Service Definition

Ollama inference service pre-loaded with `granite4:latest`, deployed via Helm for CPU workloads. The model is baked into a custom image built from [`services/olgranitehelm/docker/Dockerfile`](../docker/Dockerfile) — no internet access required at runtime.

## Directory structure

```
services/olgranitehelm/v1/
├── chart/                  # otwld/ollama chart v1.68.0 (appVersion 0.32.2), patched
│   ├── Chart.yaml
│   ├── values.yaml         # Patched: registry split, SCC nulls, route block added
│   └── templates/          # Deployment, Service, PVC, Route, Ingress, etc.
├── template/
│   └── values.yaml.tmpl    # Jinja2 template rendered per instance
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json         # Instance parameter schema (cluster_url only)
│   └── metrics.json
├── imagesetconfiguration.yaml
├── values-test.yaml
└── argocd/
    └── applicationset-helm.yaml.tmpl
```

## Custom image

The image `byop/olgranitehelm:0.32.2` is **not** a standard mirror — it is a custom image built with the `granite4:latest` model weights baked in. Build it using the Dockerfile in [`services/olgranitehelm/docker/`](../docker/):

```bash
# Build (requires internet access)
podman build -t olgranitehelm:0.32.2 services/olgranitehelm/docker/

# Push to airgap registry
podman tag olgranitehelm:0.32.2 <airgap-registry>/byop/olgranitehelm:0.32.2
podman push <airgap-registry>/byop/olgranitehelm:0.32.2
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `cluster_url` | | broker default | ArgoCD-registered cluster URL |

## Key Helm values set per instance

| values.yaml path | Source |
|-----------------|--------|
| `image.registry` | `BYOP_REGISTRY` |
| `image.repository` | `byop/olgranitehelm` |
| `image.tag` | `0.32.2` |
| `ollama.gpu.enabled` | `false` (CPU only) |
| `ollama.models.run` | `[granite4:latest]` |
| `persistentVolume.size` | `storage_size` |
| `route.enabled` | `true` (OpenShift Route on port 11434) |

## Connecting from Langflow

Use the native **Ollama** component in Langflow with:

| Field | Value |
|-------|-------|
| Base URL | `http://<instance-name>.<namespace>.svc.cluster.local:11434` |
| Model | `granite4:latest` |

Or via the OpenAI-compatible endpoint:

| Field | Value |
|-------|-------|
| OpenAI API Base | `http://<instance-name>.<namespace>.svc.cluster.local:11434/v1` |
| Model Name | `granite4:latest` |
| API Key | `ollama` |

## ApplicationSet

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | `olgranite4` |
| `SERVICE_VERSION` | `v1` |
| `SERVICE_TYPE` | `olgranite4` |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

## Instance directory layout

```
instances/olgranite4/<instance-name>/
├── metadata.yaml
└── values.yaml
```
