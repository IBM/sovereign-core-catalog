# olgranitehelm — Custom Image Build

This directory contains the Dockerfile to build the `olgranitehelm` image — a
custom Ollama image with `granite4:latest` pre-baked into the model store. The
image is self-contained and does not require internet access at runtime, making
it suitable for airgapped clusters.

## Prerequisites

- Podman with internet access to reach `ollama.com`
- Access to the airgap registry to push the final image

## Build

```bash
podman build -t olgranitehelm:0.32.2 services/olgranitehelm/docker/
```

This takes several minutes — it downloads the granite4 model weights during
the build (roughly 2–5 GB depending on quantization).

## Push to airgap registry

```bash
# Replace <airgap-registry> with your actual registry hostname
# e.g. registry.example.com

REGISTRY=<airgap-registry>

podman tag olgranitehelm:0.32.2 ${REGISTRY}/byop/olgranitehelm:0.32.2
podman push ${REGISTRY}/byop/olgranitehelm:0.32.2
```

## Verify locally

```bash
# Run the image and confirm the model is served without any network calls
podman run --rm -p 11434:11434 olgranitehelm:0.32.2 &
sleep 5
curl http://localhost:11434/api/tags   # should list granite4:latest
curl http://localhost:11434/api/generate \
  -d '{"model":"granite4:latest","prompt":"Hello!","stream":false}'
```

## Connect Langflow

Once deployed, point Langflow at this service using the **OpenAI-compatible**
component with:

| Field | Value |
|-------|-------|
| OpenAI API Base | `http://<instance-name>.<namespace>.svc.cluster.local:11434/v1` |
| Model Name | `granite4:latest` |
| API Key | `ollama` (any non-empty string) |

Or use the native **Ollama** component in Langflow with:

| Field | Value |
|-------|-------|
| Base URL | `http://<instance-name>.<namespace>.svc.cluster.local:11434` |
| Model | `granite4:latest` |

## Notes

- The model store is at `/root/.ollama/models` inside the image.
- The base Ollama version is `0.32.2` — update both `FROM` lines in the
  Dockerfile when upgrading.
- To swap the model, change `granite4:latest` to any model available on
  `https://ollama.com/library`.
- To add multiple models, add more `ollama pull` lines before the `kill`.
