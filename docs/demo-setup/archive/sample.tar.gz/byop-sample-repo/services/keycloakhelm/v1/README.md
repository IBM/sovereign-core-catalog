# keycloakhelm — Service Definition

Keycloak identity and access management deployed via Helm with a bundled PostgreSQL subchart. The broker renders a `values.yaml` per instance; ArgoCD applies the Helm release to the target cluster.

## Directory structure

```
services/keycloakhelm/v1/
├── chart/                  # Keycloak Helm chart (v0.4.0, appVersion 26.6)
│   ├── Chart.yaml
│   ├── Chart.lock
│   ├── values.yaml
│   ├── values.schema.json
│   └── templates/          # StatefulSet, Services, ServiceAccount, Ingress, HTTPRoute
│   └── charts/
│       └── postgres/       # Bundled PostgreSQL subchart (v0.2.26, image postgres:17)
├── template/
│   └── values.yaml.tmpl    # Jinja2 template rendered per instance
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json         # Instance parameter schema
│   └── metrics.json
├── argocd/
│   └── applicationset-helm.yaml.tmpl
└── values-test.yaml        # Local test overrides
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `admin_user` | | `admin` | Keycloak admin username |
| `admin_password` | | auto | Admin password (min 12, auto-generated if omitted) |
| `replica_count` | | `1` | Number of Keycloak replicas |
| `database_name` | | `keycloak` | PostgreSQL database name |
| `database_user` | | `keycloak` | PostgreSQL database user |
| `database_password` | | auto | PostgreSQL user password (auto-generated if omitted) |
| `postgres_superuser_password` | | auto | PostgreSQL superuser password (auto-generated if omitted) |
| `postgres_storage_size` | | `1Gi` | PostgreSQL PVC size |
| `cluster_url` | | broker default | ArgoCD-registered cluster URL |

## Key Helm values set per instance

| values.yaml path | Source |
|-----------------|--------|
| `auth.adminUser` | `spec.admin_user` |
| `auth.adminPassword` | `spec.admin_password` |
| `replicaCount` | `spec.replica_count` |
| `database.vendor` | `postgres` (hardcoded) |
| `persistence.size` | `storage_size` |
| `postgres.enabled` | `true` |
| `postgres.image.repository` | `BYOP_REGISTRY/byop/postgres` |
| `postgres.image.tag` | `17` |
| `postgres.settings.superuserPassword` | `spec.postgres_superuser_password` |
| `postgres.userDatabase.name` | `spec.database_name` |
| `postgres.userDatabase.user` | `spec.database_user` |
| `postgres.userDatabase.password` | `spec.database_password` |
| `postgres.storage.requestedSize` | `spec.postgres_storage_size` |
| `postgres.storage.storageClass` | `ceph-rbd-platform` |

## OpenShift compatibility

Both the Keycloak and PostgreSQL containers use `null` for `fsGroup`, `runAsUser`, and `runAsGroup` so the namespace SCC assigns UIDs dynamically. The `values-test.yaml` pins UIDs to `1001` (Keycloak) and `999` (PostgreSQL) for local Kubernetes where SCC is not available.

## ApplicationSet

Render `argocd/applicationset-helm.yaml.tmpl` with `sed`, substituting the variables below, then apply the result to your ArgoCD namespace.

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | Service identifier (e.g. `keycloakhelm`) |
| `SERVICE_VERSION` | Service version directory (e.g. `v1`) |
| `SERVICE_TYPE` | Service type label (e.g. `keycloak`) |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

The ApplicationSet watches `instances/keycloakhelm/*/metadata.yaml` and creates one ArgoCD Application per instance directory.

## Instance directory layout (rendered by the broker)

```
instances/keycloakhelm/<instance-name>/
├── metadata.yaml           # Picked up by the ApplicationSet generator
└── values.yaml             # Rendered Helm values
```

## Local testing

```bash
helm upgrade --install keycloak-test services/keycloakhelm/v1/chart \
  -f services/keycloakhelm/v1/values-test.yaml \
  --create-namespace \
  --namespace keycloak-test
```
