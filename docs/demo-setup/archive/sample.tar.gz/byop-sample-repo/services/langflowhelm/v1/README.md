# langflowhelm — Service Definition

Langflow visual AI pipeline builder deployed via Helm (official langflow-ide chart). The broker renders a `values.yaml` per instance; ArgoCD applies the Helm release to the target cluster.

## Directory structure

```
services/langflowhelm/v1/
├── chart/                  # Official langflow-ide chart v0.1.2 (appVersion 1.10.2)
│   ├── Chart.yaml
│   ├── values.yaml         # Patched: runAsUser/runAsGroup/fsGroup set to null for OpenShift
│   └── templates/          # backend StatefulSet, frontend Deployment, OpenShift RBAC, Ingress, etc.
├── template/
│   └── values.yaml.tmpl    # Jinja2 template rendered per instance
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json         # Instance parameter schema
│   └── metrics.json
├── imagesetconfiguration.yaml
├── values-test.yaml
└── argocd/
    └── applicationset-helm.yaml.tmpl
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `superuser` | | `admin@langflow.io` | Langflow admin login email |
| `superuser_password` | | auto | Admin password (min 8, auto-generated if omitted) |
| `secret_key` | | auto | Encryption key for stored credentials (min 32, auto-generated) |
| `cluster_url` | | broker default | ArgoCD-registered cluster URL |

## Key Helm values set per instance

| values.yaml path | Source |
|-----------------|--------|
| `langflow.backend.image.repository` | `BYOP_REGISTRY/byop/langflow` (combined — no registry split in this chart) |
| `langflow.backend.image.tag` | `1.10.2` |
| `langflow.frontend.image.repository` | `BYOP_REGISTRY/byop/langflow-frontend` |
| `langflow.backend.superuser` | `spec.superuser` |
| `langflow.backend.superuserPassword` | `spec.superuser_password` |
| `langflow.backend.secretKey` | `spec.secret_key` |
| `langflow.backend.sqlite.volume.size` | `storage_size` |
| `route.enabled` | `true` (OpenShift Route) |

## ApplicationSet

Render `argocd/applicationset-helm.yaml.tmpl` with `sed`, substituting the variables below, then apply the result to your ArgoCD namespace.

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | Service identifier (e.g. `langflow`) |
| `SERVICE_VERSION` | Service version directory (e.g. `v1`) |
| `SERVICE_TYPE` | Service type label (e.g. `langflow`) |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

The ApplicationSet watches `instances/SERVICE_NAME/*/metadata.yaml` and creates one ArgoCD Application per instance directory.

## Instance directory layout (rendered by the broker)

```
instances/langflow/<instance-name>/
├── metadata.yaml           # Picked up by the ApplicationSet generator
└── values.yaml             # Rendered Helm values
```

## Notes

- **Image registry pattern:** This chart has no top-level `registry` field. The full registry+path is embedded in `repository` (e.g. `BYOP_REGISTRY/byop/langflow`), consistent with the `vaulthelm` service.
- **OpenShift SCC:** `runAsUser`, `runAsGroup`, and `fsGroup` are set to `null` in `chart/values.yaml` so OpenShift assigns IDs from the namespace's allowed range.
- **Storage:** SQLite mode by default (single PVC). To use external PostgreSQL, set `langflow.backend.sqlite.enabled: false` and configure `langflow.backend.externalDatabase`.
