# openldaphelm — Service Definition

OpenLDAP directory service deployed via Helm using the `osixia/openldap` v2 image. The broker renders a `values.yaml` per instance; ArgoCD applies the Helm release to the target cluster.

## Directory structure

```
services/openldaphelm/v1/
├── chart/                       # Helm chart (version 1.0.0, appVersion 2.6.15-alpha)
│   ├── Chart.yaml
│   ├── values.yaml
│   └── templates/               # StatefulSet, Service, Service (headless), Secret, ServiceAccount
├── template/
│   └── values.yaml.tmpl         # Jinja2 template rendered per instance
├── catalog/
│   ├── catalog.yaml
│   ├── schema.json              # Instance parameter schema
│   └── metrics.json
├── imagesetconfiguration.yaml
├── values-test.yaml             # Static test values for local helm template validation
└── argocd/
    └── applicationset-helm.yaml.tmpl
```

## Instance parameters (`catalog/schema.json`)

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `admin_password` | | auto-generated (24 chars) | Admin (`cn=admin`) password for the LDAP directory |
| `ldap_base_dn` | | `dc=example,dc=org` | Base DN for the directory (dc-style) |
| `ldap_organisation` | | `My Organisation` | Organisation name seeded as the root entry |
| `storage_size` | | `1Gi` | Persistent volume size for LDAP data |
| `cluster_url` | | broker default | ArgoCD-registered target cluster URL |

## Key Helm values set per instance

| values.yaml path | Source |
|-----------------|--------|
| `image.registry` | `BYOP_REGISTRY` → runtime registry (substituted by `service-render --mapping`) |
| `image.repository` | `byop/openldap` |
| `image.tag` | `2.6.15-alpha` |
| `ldap.baseDN` | `spec.ldap_base_dn` (default `dc=example,dc=org`) |
| `ldap.organisation` | `spec.ldap_organisation` (default `My Organisation`) |
| `auth.adminPassword` | `spec.admin_password` (auto-generated if empty) |
| `persistence.size` | `spec.storage_size` (default `1Gi`) |
| `persistence.storageClass` | `ceph-rbd-platform` |

## ApplicationSet

Render `argocd/applicationset-helm.yaml.tmpl` with `sed`, substituting the variables below, then apply the result to your ArgoCD namespace.

| Variable | Description |
|----------|-------------|
| `SERVICE_NAME` | Service identifier (e.g. `openldaphelm`) |
| `SERVICE_VERSION` | Service version directory (e.g. `v1`) |
| `SERVICE_TYPE` | Service type label (e.g. `openldap`) |
| `ARGOCD_NAMESPACE` | Namespace where ArgoCD is installed |
| `ARGOCD_PROJECT` | ArgoCD project name |
| `GITOPS_REPO_URL` | GitOps repository URL |
| `GITOPS_REPO_REVISION` | Branch or tag to track |
| `CLUSTER_SERVER` | Target cluster API server hostname |

The ApplicationSet watches `instances/SERVICE_NAME/*/metadata.yaml` and creates one ArgoCD Application per instance directory.

## Instance directory layout (rendered by the broker)

```
instances/openldap/<instance-name>/
├── metadata.yaml           # Picked up by the ApplicationSet generator
└── values.yaml             # Rendered Helm values
```

## SCC compliance notes

- Runs as non-root (`runAsNonRoot: true`); `runAsUser`/`runAsGroup`/`fsGroup` are `null` so OpenShift's `restricted-v2` SCC assigns UIDs automatically.
- `readOnlyRootFilesystem: false` — required because `osixia/openldap` writes to `/var/lib/ldap` and `/etc/ldap/slapd.d` at runtime.
- All capabilities dropped (`capabilities.drop: [ALL]`).
- `seccompProfile: RuntimeDefault` on both pod and container.
- LDAP listener runs on port `3890` (non-privileged) and LDAPS on `6360`; the ClusterIP Service maps them to the standard `389`/`636` ports for clients.
