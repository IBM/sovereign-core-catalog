# GitOps CSB Broker

A persistent broker process that combines the Common Service Broker (CSB) v2 API with GitOps-based provisioning. This broker receives provisioning requests via the CSB API and drives actual infrastructure deployment through the GitOps orchestrator.

## Overview

This broker merges two key components:

1. **CSB (Common Service Broker)**: Provides a standard API for service provisioning requests
2. **GitOps Orchestrator**: Implements actual provisioning by committing to Git and deploying via ArgoCD

### Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  Client (invoker_demo.py, curl, etc.)                       │
└────────────────────┬────────────────────────────────────────┘
                     │ CSB v2 API (HTTP/HTTPS)
                     ↓
┌─────────────────────────────────────────────────────────────┐
│  GitOps CSB Broker (Flask App)                              │
│  ├── CSBBroker (business logic)                             │
│  └── GitOpsStorage (implements StorageInterface)            │
└────────────────────┬────────────────────────────────────────┘
                     │ subprocess calls
                     ↓
┌─────────────────────────────────────────────────────────────┐
│  GitOps Orchestrator (provision.py, deprovision.py)         │
│  ├── Git Operations (commit, push)                          │
│  └── ArgoCD Application creation                            │
└────────────────────┬────────────────────────────────────────┘
                     │ Git push
                     ↓
┌─────────────────────────────────────────────────────────────┐
│  GitHub Enterprise Repository                                │
│  ├── services/mysql/v1/                                     │
│  ├── instances/<instance-id>/                               │
│  └── argocd-apps/<instance-id>.yaml                         │
└────────────────────┬────────────────────────────────────────┘
                     │ Git sync
                     ↓
┌─────────────────────────────────────────────────────────────┐
│  ArgoCD (on k3s-cluster-1)                                  │
│  └── Watches Git repo and deploys to clusters               │
└────────────────────┬────────────────────────────────────────┘
                     │ oc apply
                     ↓
┌─────────────────────────────────────────────────────────────┐
│  Kubernetes Clusters (k3s-cluster-1, k3s-cluster-2, etc.)   │
│  └── MySQL/MariaDB instances running                        │
└─────────────────────────────────────────────────────────────┘
```

## Docker Image

The broker is containerized using **Red Hat Universal Base Image (UBI) 9 Minimal** with Python 3.12 for enhanced security and enterprise support.

### Image Details

- **Base Image**: `registry.access.redhat.com/ubi9/ubi-minimal:latest`
- **Python Version**: 3.12.12
- **Image Size**: ~335MB
- **User**: Non-root user (UID 1001, GID 0) for OpenShift compatibility
- **Security**: Enterprise-grade security updates from Red Hat

### Why UBI?

1. **Enterprise Support**: Red Hat provides enterprise-grade support and security updates
2. **Security**: Regular CVE scanning and patching by Red Hat
3. **Compliance**: Better suited for regulated environments and enterprise deployments
4. **OpenShift Compatibility**: Native compatibility with OpenShift Container Platform
5. **Long-term Support**: Predictable lifecycle and support windows (UBI9 until ~2032)

### Building the Image

```bash
# Build locally
cd broker
docker build -t byop-broker:latest .

# Build multi-architecture (amd64 + arm64)
make docker-build-multiarch

# Build and push to registry
make docker-publish REGISTRY_URL=quay.io/your-org
```

### OpenShift Compatibility

The image is designed for OpenShift with:
- **UID 1001** with **GID 0** (root group) for proper file permissions
- **Group write permissions** (`chmod -R g=u`) for volume mounts
- **Security labels** for OpenShift metadata
- **Non-root execution** with `/sbin/nologin` shell

## Key Features

- ✅ **CSB v2 API Compliance**: Standard service broker interface
- ✅ **GitOps-Driven Provisioning**: All changes via Git commits
- ✅ **Persistent Broker Process**: Long-running Flask server
- ✅ **Multi-Cluster Support**: Deploy to any registered cluster
- ✅ **Async Operations**: Supports async provisioning workflow
- ✅ **State Tracking**: Monitors provisioning state (in_progress, succeeded, failed)
- ✅ **TLS/mTLS Support**: Secure communication options

## CLI Tool

The broker includes a standalone CLI tool for testing and managing service instances:

```bash
# Quick start
broker-cli config init
broker-cli provision my-db mariadb small --dry-run
broker-cli list --dry-run

# See full documentation
broker-cli --help
```

**Documentation:**
- [CLI Usage Guide](docs/cli-usage-guide.md) - Complete CLI reference and examples
- [CLI Configuration](docs/cli-configuration.md) - Configuration file reference

## Installation

### Prerequisites

1. **Python 3.10+** with virtual environment
2. **Git repository** configured for GitOps
3. **ArgoCD** installed on hub cluster (see `../argocd/README.md` for ArgoCD setup)

### Setup

```bash
# Create virtual environment
python3 -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your settings
```

## Configuration

The broker supports two configuration methods:

1. **JSON Configuration File** (recommended)
2. **Environment Variables** (for overrides)

### JSON Configuration File

Create a JSON configuration file (e.g., `config.gitops.json`):

```json
{
  "port": 7329,
  "host": "0.0.0.0",
  "storage": {
    "type": "gitops",
    "config": {
      "storage_dir": "./data",
      "cluster_name": "k3s-cluster-1",
      "orchestrator_path": "./orchestrator"
    }
  },
  "gitops": {
    "repo_url": "git@github.com:your-org/gitops-repo.git",
    "branch": "main",
    "git_backend": "remote",
    "git_auth_method": "ssh",
    "ssh_private_key_path": "~/.ssh/gitops_deploy_key"
  }
}
```

**Storage Types:**

The broker supports three storage backend types:

1. **`gitops`** - GitOps-based stateless storage (Production)
   - Uses Git repository as the single source of truth
   - Stateless operation - no local state persistence
   - Requires Git repository access (SSH or HTTPS)
   - Includes caching layer for performance (30s TTL)
   - **Use case:** Production deployments, multi-instance setups
   - **Class:** `GitopsStorage`

2. **`file`** - File-based stateful storage (Development)
   - Uses local JSON files for state persistence
   - No Git dependencies required
   - Simpler setup for local development
   - Supports async and sync operations
   - **Use case:** Local development, testing, single-instance setups
   - **Class:** `FileStorage`

3. **`dummy`** - In-memory storage (Testing)
   - Volatile storage for testing purposes
   - No persistence between restarts
   - **Use case:** Unit tests, integration tests
   - **Class:** `DummyStorage`

**Storage Selection Guide:**

| Scenario | Recommended Storage | Rationale |
|----------|-------------------|-----------|
| Production deployment | `gitops` | Stateless, scalable, Git-backed |
| Local development | `file` | Simple setup, no Git required |
| CI/CD testing | `dummy` or `file` | Fast, isolated |
| Multi-broker instances | `gitops` | Shared state via Git |

**GitOps Configuration:**
The `gitops` section declares all configuration requirements for the GitOps orchestrator:
- `repo_url` - GitHub Enterprise repository URL (SSH or HTTPS)
- `branch` - Git branch name (default: "main")
- `git_backend` - Backend type: "remote" or "local" (default: "remote")
- `git_auth_method` - Authentication method: "ssh" or "https" (default: "ssh")
- `ssh_private_key` - SSH private key content (base64 encoded, for CI/CD)
- `ssh_private_key_path` - Path to SSH private key file (for local development)
- `github_token` - GitHub Personal Access Token (for HTTPS authentication)

**Start with configuration file:**
```bash
python app.py --config config.gitops.json
```

### Environment Variables

Environment variables override JSON configuration:

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `PORT` | No | `7329` | HTTP server port |
| `HOST` | No | `0.0.0.0` | HTTP server host |
| `STORAGE_DIR` | No | `./data` | Directory for instance metadata |
| `DASHBOARD_URL` | No | `http://localhost:7329/dash/<instance-id>` | Dashboard URL template |
| `ASYNC_ENABLED` | No | `true` | Enable async operations |
| `GITOPS_ORCHESTRATOR_PATH` | No | `./orchestrator` | Path to the broker's bundled orchestrator code |
| `GITOPS_CLUSTER_NAME` | No | `k3s-cluster-1` | Default target cluster |
| `GITOPS_REPO_URL` | **Yes** | - | Git repository URL (inherited from GitOps) |
| `GITOPS_BRANCH` | No | `main` | Git branch (inherited from GitOps) |
| `SSH_PRIVATE_KEY_PATH` | No* | - | SSH key for Git auth |
| `TLS_ENABLED` | No | `false` | Enable TLS (HTTPS) |
| `MTLS_ENABLED` | No | `false` | Enable mutual TLS |

*Required for SSH Git URLs

**Configuration Priority:**
1. Environment variables (highest priority)
2. JSON configuration file
3. Built-in defaults (lowest priority)

### Storage Factory Pattern

The broker uses a factory pattern to instantiate storage backends based on type:

```python
from storage import create_storage

# Storage type maps to class name by convention:
# "gitops" → GitopsStorage
# "file" → FileStorage
# "dummy" → DummyStorage

storage = create_storage("gitops", {
    "storage_dir": "./data",
    "cluster_name": "k3s-cluster-1",
    "orchestrator_path": "./orchestrator"
})
```

**Naming Convention:**
- Storage type: lowercase (e.g., `gitops`)
- Class name: PascalCase with "Storage" suffix (e.g., `GitopsStorage`)
- The factory automatically converts type to class name

### Example Configurations

**Development (JSON file):**
```json
{
  "port": 7329,
  "host": "127.0.0.1",
  "storage": {
    "type": "gitops",
    "config": {
      "storage_dir": "./data",
      "cluster_name": "k3s-cluster-1",
      "orchestrator_path": "./orchestrator"
    }
  },
  "gitops": {
    "repo_url": "git@github.com:your-org/gitops-repo.git",
    "branch": "main",
    "git_backend": "remote",
    "git_auth_method": "ssh",
    "ssh_private_key_path": "~/.ssh/gitops_deploy_key"
  }
}
```

**Production (JSON + Environment Variables):**
```json
{
  "port": 8080,
  "host": "0.0.0.0",
  "tls_enabled": true,
  "server_cert_path": "/etc/certs/server.crt",
  "server_key_path": "/etc/certs/server.key",
  "mtls_enabled": true,
  "client_ca_path": "/etc/certs/client-ca.crt",
  "storage": {
    "type": "gitops",
    "config": {
      "storage_dir": "/var/gitops-csb/data",
      "cluster_name": "k3s-cluster-prod",
      "orchestrator_path": "/opt/broker/orchestrator"
    }
  },
  "gitops": {
    "repo_url": "git@github.com:your-org/gitops-prod-repo.git",
    "branch": "production",
    "git_backend": "remote",
    "git_auth_method": "ssh",
    "ssh_private_key_path": "/etc/broker/deploy_key"
  }
}
```

Override cluster and Git repository via environment variables:
```bash
export GITOPS_CLUSTER_NAME=k3s-cluster-prod-2
export GITOPS_REPO_URL=git@github.com:your-org/gitops-prod-repo-2.git
python app.py --config config.production.json
```

**Local Development (File Storage):**
```json
{
  "port": 7329,
  "host": "127.0.0.1",
  "async_enabled": true,
  "storage": {
    "type": "file",
    "config": {
      "storage_dir": "./data",
      "cluster_name": "k3s-cluster-1",
      "async_enabled": true,
      "gitops_path": "./orchestrator"
    }
  }
}
```

**Note:** FileStorage does not require Git configuration. It stores instance state in local JSON files and uses the GitOps library API for provisioning/deprovisioning operations.

**Testing (In-Memory Storage):**
```json
{
  "port": 7329,
  "storage": {
    "type": "dummy",
    "config": {}
  }
}
```

**Example .env (Environment Variables):**
```bash
# Server configuration
PORT=7329
HOST=0.0.0.0
STORAGE_DIR=./data

# GitOps configuration
GITOPS_ORCHESTRATOR_PATH=./orchestrator
GITOPS_CLUSTER_NAME=k3s-cluster-1

# Git repository configuration
GITOPS_REPO_URL=git@github.com:your-org/gitops-repo.git
GITOPS_BRANCH=main
SSH_PRIVATE_KEY_PATH=~/.ssh/gitops_deploy_key

# Optional: TLS configuration
TLS_ENABLED=false
MTLS_ENABLED=false
```

## Usage

### Start the Broker

**With JSON configuration file (recommended):**
```bash
# Activate virtual environment
source .venv/bin/activate

# Start with configuration file
python app.py --config config.gitops.json
```

**With environment variables only:**
```bash
# Activate virtual environment
source .venv/bin/activate

# Set required environment variables
export GITOPS_REPO_URL=git@github.com:your-org/gitops-repo.git
export SSH_PRIVATE_KEY_PATH=~/.ssh/gitops_deploy_key

# Start the broker
python app.py
```

**With both (environment variables override JSON):**
```bash
# Override cluster from config file
export GITOPS_CLUSTER_NAME=k3s-cluster-2

# Start with config file
python app.py --config config.gitops.json
```

The broker will start on `http://0.0.0.0:7329` by default.

### Provision a Service Instance

#### Important: Instance ID Consistency

**The instance ID used in the CSB API must be the same for all operations (provision, update, deprovision).**

The instance ID is used directly as the Kubernetes namespace name. The service type is NOT prepended to the instance ID.

**✅ Correct Usage:**
```bash
# Provision with instance ID "dev-001"
curl -X PUT "http://localhost:7329/v2/service_instances/dev-001" \
  -H "Content-Type: application/json" \
  -d '{"service_id": "mysql-service", "plan_id": "dev"}'

# Creates:
# - Kubernetes namespace: "dev-001" (NOT "mysql-dev-001")
# - ArgoCD Application: "mysql-dev-001" (service type IS included in app name)
# - Metadata file: "./data/dev-001.json"

# Deprovision with SAME instance ID "dev-001"
curl -X DELETE "http://localhost:7329/v2/service_instances/dev-001?accepts_incomplete=true&service_id=mysql-service&plan_id=dev"
```

**❌ Incorrect Usage:**
```bash
# Provision with instance ID "dev-001"
curl -X PUT "http://localhost:7329/v2/service_instances/dev-001" ...

# Deprovision with DIFFERENT ID "mysql-dev-001" (WRONG!)
curl -X DELETE "http://localhost:7329/v2/service_instances/mysql-dev-001?..." ...
# This will fail with "Instance not found" because the instance was created as "dev-001"
```

**Key Points:**
- Use the same instance ID for provision, update, and deprovision
- Instance ID becomes the Kubernetes namespace name directly
- ArgoCD Application name includes service type: `{service-type}-{instance-id}`
- Metadata file name matches instance ID: `{instance-id}.json`

#### Step 1: Check Available Services

First, check the catalog to see available services:

```bash
curl http://localhost:7329/v2/catalog | python3 -m json.tool
```

This returns services discovered from the **GitOps repository's `services/` directory**:
- `mysql-service` - MySQL database
- `mariadb-service` - MariaDB database

The catalog is dynamically generated by scanning the cloned GitOps repository. Each service directory must contain a `service.yaml` file with service metadata.

Each service has plans: `dev` (development) and `prod` (production).

#### Step 2: Provision Using CSB API

**Minimal request (uses plan defaults):**

```bash
curl -X PUT "http://localhost:7329/v2/service_instances/dev-mysql-001" \
  -H "Content-Type: application/json" \
  -d '{
    "service_id": "mysql-service",
    "plan_id": "dev"
  }'
```

**Complete request with all parameters:**

```bash
curl -X PUT "http://localhost:7329/v2/service_instances/prod-mysql-001" \
  -H "Content-Type: application/json" \
  -d '{
    "service_id": "mysql-service",
    "plan_id": "prod",
    "context": {
      "platform": "kubernetes",
      "organization_guid": "org-123",
      "space_guid": "space-456"
    },
    "parameters": {
      "replicas": 3,
      "storage_size": "100Gi",
      "environment": "production"
    }
  }'
```

**Provision MariaDB:**

```bash
curl -X PUT "http://localhost:7329/v2/service_instances/dev-mariadb-001" \
  -H "Content-Type: application/json" \
  -d '{
    "service_id": "mariadb-service",
    "plan_id": "dev",
    "parameters": {
      "replicas": 1,
      "storage_size": "20Gi",
      "environment": "dev"
    }
  }'
```

**Request Fields:**

| Field | Required | Description |
|-------|----------|-------------|
| `service_id` | **Yes** | Service from catalog (e.g., `mysql-service`, `mariadb-service`) |
| `plan_id` | **Yes** | Plan from catalog (e.g., `dev`, `prod`) |
| `context` | No | Platform context (organization, space, etc.) |
| `parameters` | No | Override plan defaults |
| `parameters.replicas` | No | Number of replicas (default from plan) |
| `parameters.storage_size` | No | Storage size (default from plan) |
| `parameters.environment` | No | Environment label (default: `dev`) |

**Plan Defaults:**

| Plan ID | Replicas | Storage Size |
|---------|----------|--------------|
| `dev` | 1 | 10Gi |
| `prod` | 3 | 100Gi |

**Target Cluster:**

The target cluster is configured at the broker level via:
- JSON config: `storage.config.cluster_name` (e.g., `"k3s-cluster-1"`)
- Environment variable: `GITOPS_CLUSTER_NAME`

To deploy to different clusters, configure multiple broker instances or change the environment variable.

**What happens internally:**
1. Broker receives request with `service_id: "mysql-service"` and `plan_id: "dev"`
2. GitOpsStorage maps service_id to service type: `mysql-service` → `mysql`
3. Extracts parameters (uses plan defaults if not specified)
4. Calls orchestrator: `provision.py --instance-name dev-mysql-001 --service-type mysql --cluster-name k3s-cluster-1 --replicas 1 --storage-size 10Gi --environment dev`
5. Orchestrator generates manifests from `orchestrator/service-templates/mysql/base/`
6. Orchestrator commits to Git and creates ArgoCD Application
7. ArgoCD detects changes and deploys MySQL to the configured cluster

### List All Instances

**Custom Extension Endpoint** (not part of standard CSB v2 API):

```bash
curl -X GET "http://localhost:7329/v2/service_instances"
```

Response:
```json
{
  "instances": [
    {
      "instance_id": "dev-001",
      "crn": "dev-001",
      "service_id": "mysql-service",
      "plan_id": "dev",
      "state": "succeeded",
      "description": "Service instance provisioned successfully",
      "created_at": "2026-03-31T15:00:00.000000",
      "updated_at": "2026-03-31T15:00:15.123456",
      "parameters": {
        "replicas": 1,
        "storage_size": "10Gi",
        "environment": "dev"
      }
    },
    {
      "instance_id": "prod-001",
      "crn": "prod-001",
      "service_id": "mariadb-service",
      "plan_id": "prod",
      "state": "in_progress",
      "description": "Provisioning in progress",
      "created_at": "2026-03-31T15:05:00.000000",
      "updated_at": "2026-03-31T15:05:00.000000",
      "parameters": {
        "replicas": 3,
        "storage_size": "100Gi",
        "environment": "prod"
      }
    }
  ],
  "count": 2
}
```

**Note**: This endpoint is a custom extension for management and monitoring. It is not part of the standard CSB v2 API specification.

### Check Status

```bash
curl -X GET "http://localhost:7329/v2/service_instances/dev-001/last_operation"
```

Response:
```json
{
  "state": "succeeded",
  "description": "Service instance provisioned successfully",
  "dashboard_url": "http://localhost:7329/dash/dev-001",
  "extensions": {
    "instanceID": "dev-001",
    "crn": "dev-001",
    "serviceID": "mysql-service"
  }
}
```

### Deprovision Instance

```bash
curl -X DELETE "http://localhost:7329/v2/service_instances/dev-001?accepts_incomplete=true&service_id=mysql-service&plan_id=standard"
```

## How It Works

### Provisioning Flow

1. **Client sends CSB provision request** to broker
2. **Broker validates request** (service_id, plan_id required)
3. **GitOpsStorage.create()** is called:
   - Saves instance metadata (state: in_progress)
   - Calls `provision.py` from GitOps orchestrator
   - Orchestrator generates Kubernetes manifests
   - Orchestrator commits and pushes to Git
   - Orchestrator creates ArgoCD Application
   - Updates metadata (state: succeeded or failed)
4. **Broker returns response** with dashboard URL
5. **ArgoCD detects changes** and deploys to cluster

### Deprovisioning Flow

1. **Client sends CSB deprovision request** to broker
2. **Broker validates instance exists**
3. **GitOpsStorage.delete()** is called:
   - Reads instance metadata
   - Calls `deprovision.py` from GitOps orchestrator
   - Orchestrator removes manifests from Git
   - Orchestrator deletes ArgoCD Application
   - Deletes instance metadata file
4. **Broker returns success response**
5. **ArgoCD removes resources** from cluster

## Service Mapping

The broker maps CSB service IDs to GitOps service types:

| CSB Service ID | GitOps Service Type | Description |
|----------------|---------------------|-------------|
| `mysql-service` | `mysql` | MySQL database |
| `mariadb-service` | `mariadb` | MariaDB database |
| `postgres-service` | `mysql` | PostgreSQL (demo: maps to MySQL) |
| `rabbitmq-service` | `mysql` | RabbitMQ (demo: maps to MySQL) |
| `redis-service` | `mysql` | Redis (demo: maps to MySQL) |

## Plan Mapping

CSB plans are mapped to GitOps parameters:

| Plan ID | Replicas | Storage Size |
|---------|----------|--------------|
| `basic` | 1 | 5Gi |
| `standard` | 1 | 10Gi |
| `premium` | 3 | 50Gi |
| `enterprise` | 3 | 100Gi |

## State Management

Instance states:

- `in_progress`: Provisioning is running
- `succeeded`: Provisioning completed successfully
- `failed`: Provisioning failed (check logs)

## Cleanup

Use standard development cleanup targets from the `Makefile` instead of broker-specific shell scripts.

```bash
# Remove build artifacts, caches, coverage output, and test artifacts
make clean

# Remove the virtual environment as well
make distclean
```

**What gets removed by `make clean`:**
- ✓ Build artifacts (`build/`, `dist/`, `*.egg-info`)
- ✓ Coverage reports (`.coverage`, `htmlcov/`)
- ✓ Test/cache artifacts (`.pytest_cache/`, `__pycache__/`, `*.pyc`)

**What `make distclean` adds:**
- ✓ Virtual environments (`venv/`, `.venv/`)

**Note:** The broker's Git working directory is runtime-managed inside the container and is not treated as a host-side local setup artifact.

**Example usage:**

```bash
# Clean everything and start fresh
make distclean
python app.py --config config.gitops.json
```

**When to use:**
- After testing to clean up test instances
- Before switching to a different Git repository
- To reset the broker to a clean state
- When troubleshooting persistent issues

**Note:** The teardown script does NOT:
- Remove the broker source code
- Delete configuration files (`.env`, `config.gitops.json`)
- Uninstall Python packages
- Remove certificates (`certs/`)
- Delete resources from Kubernetes clusters (use ArgoCD or oc for that)

## Troubleshooting

### Broker won't start

**Check broker orchestrator path:**
```bash
ls -la ./orchestrator/provision.py
```

**Check Git configuration:**
```bash
python3 -c "from orchestrator.git_config import GitConfig; GitConfig.print_config()"
```

### Provisioning fails

**Check broker logs** (stderr output):
```json
{"timestamp": "...", "level": "ERROR", "message": "GitOps provision failed", ...}
```

**Check orchestrator directly:**
```bash
python3 -m orchestrator.provision --instance-name test-001 --service-type mysql --cluster-name k3s-cluster-1
```

### Instance stuck in "in_progress"

The provisioning subprocess may have failed. Check:

1. Instance metadata file: `./data/<instance-id>.json`
2. GitOps orchestrator logs
3. ArgoCD Application status:
   ```bash
   oc --context k3s-cluster-1 get application mysql-<instance-id> -n argocd
   ```

## Integration with Existing Components

## Project Structure

```
gitops-csb/
├── app.py              # Flask application entry point
├── broker.py           # CSB v2 API business logic
├── storage.py          # Storage interface and factory
├── gitops_storage.py   # GitOps storage implementation
├── config.py           # Configuration management
├── logger.py           # Structured logging module
├── config.gitops.json  # Example configuration file
├── requirements.txt    # Python dependencies
├── requirements-dev.txt # Development dependencies
├── README.md           # This file
├── data/              # Instance metadata storage
├── orchestrator/      # GitOps provisioning orchestrator
│   ├── provision.py   # Provisioning script
│   ├── deprovision.py # Deprovisioning script
│   ├── git_operations.py # Git operations
│   ├── git_config.py  # Git configuration
│   ├── ssh_key_manager.py # SSH key management
│   ├── sbom_generator.py # SBOM generation
│   ├── templates.py   # Template rendering
│   ├── requirements.txt # Orchestrator dependencies
│   └── service-templates/ # Service templates (MySQL, MariaDB)
└── tests/             # Test suite
```

### Components

**CSB Broker:**
- `broker.py`: CSB v2 API business logic
- `logger.py`: Structured JSON logging
- `config.py`: Configuration management
- `storage.py`: Storage interface and factory pattern
- `gitops_storage.py`: GitOps storage implementation

**GitOps Orchestrator (Integrated):**
- `orchestrator/provision.py`: Provisioning script
- `orchestrator/deprovision.py`: Deprovisioning script
- `orchestrator/git_operations.py`: Git operations
- `orchestrator/git_config.py`: Git configuration
- `orchestrator/ssh_key_manager.py`: SSH key management
- `orchestrator/sbom_generator.py`: SBOM generation
### Asynchronous Operations

The broker supports asynchronous provisioning and deprovisioning operations (enabled by default):

**How it works:**
1. Client sends provision/deprovision request with `accepts_incomplete=true`
2. Broker returns `202 Accepted` immediately
3. Provisioning runs in background thread
4. Client polls `/last_operation` to check status

**Configuration:**
```json
{
  "storage": {
    "config": {
      "async_enabled": true
    }
  }
}
```

Or via environment variable:
```bash
export ASYNC_ENABLED=true
```

**Example workflow:**
```bash
# 1. Provision (returns immediately with 202)
curl -X PUT "http://localhost:7329/v2/service_instances/dev-001?accepts_incomplete=true" \
  -H "Content-Type: application/json" \
  -d '{"service_id": "mysql-service", "plan_id": "dev"}'

# Response: 202 Accepted
# {"dashboard_url": "http://localhost:7329/dash/dev-001"}

# 2. Poll status (repeat until state is "succeeded" or "failed")
curl "http://localhost:7329/v2/service_instances/dev-001/last_operation"

# Response while in progress:
# {"state": "in_progress", "description": "Provisioning in progress", ...}

# Response when complete:
# {"state": "succeeded", "description": "Service instance provisioned successfully", ...}

# 3. Deprovision (also async)
curl -X DELETE "http://localhost:7329/v2/service_instances/dev-001?accepts_incomplete=true&service_id=mysql-service&plan_id=dev"

# Response: 202 Accepted
```

**Benefits:**
- ✅ API responds immediately (< 100ms)
- ✅ No timeout issues for long-running operations
- ✅ Client can poll at their own pace
- ✅ Standard CSB v2 async pattern

**Synchronous mode:**
Set `async_enabled: false` to wait for provisioning to complete before returning (original behavior).


## Limitations

### Error Handling in Async Mode

When an async operation fails, error details are captured in the instance state and accessible via `/last_operation`:

**Failed Provision Example:**
```bash
# 1. Provision request (returns 202 immediately)
curl -X PUT "http://localhost:7329/v2/service_instances/bad-001?accepts_incomplete=true" \
  -H "Content-Type: application/json" \
  -d '{"service_id": "mysql-service", "plan_id": "dev"}'

# Response: 202 Accepted

# 2. Poll status - operation failed
curl "http://localhost:7329/v2/service_instances/bad-001/last_operation"

# Response when failed:
{
  "state": "failed",
  "description": "Provisioning failed: Cluster 'k3s-cluster-1' not found in ArgoCD. Available clusters: cluster-k3s-cluster-2, cluster-k3s-cluster-3",
  "dashboard_url": "http://localhost:7329/dash/bad-001",
  "extensions": {
    "instanceID": "bad-001",
    "crn": "bad-001",
    "serviceID": "mysql-service"
  }
}
```

**Error Information Sources:**

1. **`/last_operation` endpoint** - Returns current state and error description
   - `state`: `"failed"` indicates operation failed
   - `description`: Contains the error message from the provisioning subprocess

2. **Instance metadata file** - Stored in `./data/<instance-id>.json`
   ```json
   {
     "instance_id": "bad-001",
     "service_id": "mysql-service",
     "plan_id": "dev",
     "state": "failed",
     "description": "Provisioning failed: Cluster 'k3s-cluster-1' not found...",
     "created_at": "2026-03-31T15:00:00.000000",
     "updated_at": "2026-03-31T15:00:15.123456"
   }
   ```

3. **Broker logs** - JSON-formatted logs to stderr
   ```json
   {
     "timestamp": "2026-03-31T15:00:15.123456",
     "level": "ERROR",
     "message": "Async provision failed",
     "instance_id": "bad-001",
     "error": "Provisioning failed: Cluster 'k3s-cluster-1' not found..."
   }
   ```

4. **Orchestrator logs** - Detailed subprocess output
   - Captured in broker logs with `stderr` and `stdout` fields
   - Shows exact command that failed and full error output

**Checking for Errors:**

```bash
# Check if operation succeeded or failed
STATE=$(curl -s "http://localhost:7329/v2/service_instances/bad-001/last_operation" | jq -r '.state')

if [ "$STATE" = "failed" ]; then
  # Get error description
  ERROR=$(curl -s "http://localhost:7329/v2/service_instances/bad-001/last_operation" | jq -r '.description')
  echo "Provisioning failed: $ERROR"
fi
```

**Common Error Scenarios:**

| Error | Description Field Contains | Solution |
|-------|---------------------------|----------|
| Cluster not found | `Cluster 'X' not found in ArgoCD` | Update `cluster_name` in config or register cluster |
| Git auth failure | `Authentication failed` or `Permission denied` | Check SSH key or GitHub token |
| Invalid service type | `Service template not found` | Verify service type exists in `orchestrator/service-templates/` |
| ArgoCD unavailable | `Connection refused` or `timeout` | Check ArgoCD is running on hub cluster |

**Best Practices:**

1. **Poll with timeout** - Don't poll indefinitely
   ```bash
   # Poll for up to 5 minutes
   for i in {1..60}; do
     STATE=$(curl -s "http://localhost:7329/v2/service_instances/dev-001/last_operation" | jq -r '.state')
     if [ "$STATE" = "succeeded" ]; then
       echo "✓ Provisioning succeeded"
       break
     elif [ "$STATE" = "failed" ]; then
       ERROR=$(curl -s "http://localhost:7329/v2/service_instances/dev-001/last_operation" | jq -r '.description')
       echo "✗ Provisioning failed: $ERROR"
       exit 1
     fi
     sleep 5
   done
   ```

2. **Check broker logs** - For detailed error context
   ```bash
   # Broker logs go to stderr
   python app.py --config config.gitops.json 2>&1 | grep ERROR
   ```

3. **Inspect metadata file** - For persistent error state
   ```bash
   cat ./data/bad-001.json | jq '.state, .description'
   ```


- **Synchronous API**: CSB API calls wait for provisioning to complete
- **Single Broker Instance**: Not designed for horizontal scaling
- **Basic Error Handling**: Limited retry logic
- **Demo Service Mapping**: Some services map to MySQL for demonstration
## Architecture Documentation

For detailed architecture information, see:

- **[Architecture Overview](docs/architecture/README.md)** - Complete architecture documentation
- **[System Context](docs/architecture/system-overview.md)** - C4 Context diagram showing system landscape
- **[Container Diagram](docs/architecture/container-diagram.md)** - C4 Container diagram showing major components
- **[Component Design](docs/architecture/component-design.md)** - C4 Component diagram showing internal structure

## Security

For security information, see:

- **[Security Policy](docs/security/SECURITY.md)** - Security policy and vulnerability reporting
- **[Threat Model](docs/security/threat-model.md)** - STRIDE threat analysis and mitigations

**Security Features:**
- TLS/mTLS support for secure communication
- API key authentication (configurable)
- Input validation on all endpoints
- Secure credential storage (environment variables, not hardcoded)
- Regular security scanning (bandit, pip-audit, detect-secrets)

## Development Setup

### Prerequisites

- Python 3.12+ (matches Docker image)
- Git
- Virtual environment tool (venv or uv)
- Docker (for building container images)

### Quick Start

```bash
# Clone repository
git clone <repository-url>
cd broker

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# Install dependencies
make install-dev

# Run tests
make test

# Run linting
make lint

# Run all checks
make ci
```

### Development Workflow

**Before committing:**
```bash
make all  # Runs format, lint, complexity, and tests
```

**Code quality checks:**
```bash
make lint              # Ruff + mypy
make format            # Auto-format code
make complexity        # Radon complexity analysis
make security          # Security scanning
```

**Testing:**
```bash
make test              # All tests
make test-unit         # Unit tests only
make test-integration  # Integration tests only
make coverage          # Coverage report
```

### Code Standards

This project follows the Bob development standards:

- **Python 3.12+** with modern type hints (`dict`, `list`, `X | None`)
- **Ruff** for linting and formatting (line length: 120)
- **Mypy** for static type checking
- **Pytest** for testing (target: 80%+ coverage)
- **Radon** for complexity analysis (target: grade B or better, complexity < 10)
- **Bandit** for security scanning
- **detect-secrets** for secret detection (IBM fork)

### Pre-commit Hooks

Pre-commit hooks are configured at the project root level (not duplicated in subprojects).

## Contributing

### How to Contribute

1. **Fork the repository**
2. **Create a feature branch**: `git checkout -b feature/my-feature`
3. **Make your changes** following the code standards
4. **Run all checks**: `make ci`
5. **Commit your changes**: `git commit -m "feat: add new feature"`
6. **Push to your fork**: `git push origin feature/my-feature`
7. **Create a Pull Request**

### Commit Message Format

Follow conventional commits:
- `feat:` New feature
- `fix:` Bug fix
- `docs:` Documentation changes
- `refactor:` Code refactoring
- `test:` Test changes
- `chore:` Build/tooling changes

### Pull Request Checklist

- [ ] Code follows project standards
- [ ] All tests pass (`make test`)
- [ ] Linting passes (`make lint`)
- [ ] Complexity is acceptable (`make complexity`)
- [ ] Security checks pass (`make security`)
- [ ] Documentation updated
- [ ] Commit messages follow convention


## Future Enhancements

- Async provisioning with polling
- Webhook notifications for completion
- Multiple broker instances with shared state
- Enhanced error recovery
- Support for more service types
- Binding operations support

## License

Apache 2.0

---

**Status**: ✅ Functional prototype combining CSB API with GitOps provisioning

*Last Updated: 2026-03-31*