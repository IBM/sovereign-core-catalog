#!/bin/bash
# OpenShift-compatible entrypoint script
# Adds current UID to /etc/passwd if it doesn't exist
# Required for Git/SSH operations which need a valid user entry

set -e

# Check if current UID exists in /etc/passwd
if ! whoami &> /dev/null; then
  # Current UID doesn't exist in /etc/passwd, add it
  # This happens when OpenShift assigns an arbitrary UID
  if [ -w /etc/passwd ]; then
    echo "broker:x:$(id -u):0:Broker User:/app:/sbin/nologin" >> /etc/passwd
    echo "Added UID $(id -u) to /etc/passwd for OpenShift compatibility"
  else
    echo "Warning: Cannot write to /etc/passwd, Git/SSH operations may fail"
  fi
fi

# Execute the main command
exec "$@"

# Made with Bob
