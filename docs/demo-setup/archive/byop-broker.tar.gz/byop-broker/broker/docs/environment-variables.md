# Environment Variables Reference

This document provides a comprehensive reference of all environment variables used by the BYOP broker and broker-cli.

## Table of Contents

- [Server Configuration](#server-configuration)
- [Storage Configuration](#storage-configuration)
- [GitOps Configuration](#gitops-configuration)
- [Logging Configuration](#logging-configuration)
- [Security Configuration](#security-configuration)
- [JWT Authentication](#jwt-authentication)
- [Debug and Development](#debug-and-development)
- [Gunicorn Configuration](#gunicorn-configuration)

---

## Server Configuration

### `HOST`
- **Default:** `0.0.0.0`
- **Description:** Server bind address. Binds to all interfaces for container deployment.
- **Example:** `HOST=127.0.0.1`

### `PORT`
- **Default:** `7329` (broker), `8080` (gunicorn)
- **Description:** Server port number.
- **Example:** `PORT=8080`

### `DASHBOARD_URL`
- **Default:** `https://example.com`
- **Description:** Dashboard URL template for service instances. Use `{instance_id}` placeholder.
- **Example:** `DASHBOARD_URL=https://dashboard.example.com/instances/{instance_id}`

### `ASYNC_ENABLED`
- **Default:** `true`
- **Description:** Enable asynchronous operations support.
- **Values:** `true`, `false`
- **Example:** `ASYNC_ENABLED=true`

---

## Storage Configuration

### `STORAGE_TYPE`
- **Default:** `gitops`
- **Description:** Storage backend type.
- **Values:** `gitops`, `file`
- **Example:** `STORAGE_TYPE=gitops`

### `STORAGE_DIR`
- **Default:** `./data`
- **Description:** Directory for file-based storage.
- **Example:** `STORAGE_DIR=/var/lib/broker/data`

### `GITOPS_CLUSTER_NAME`
- **Default:** `k3s-cluster-1`
- **Description:** Target cluster name for GitOps deployments.
- **Example:** `GITOPS_CLUSTER_NAME=prod-cluster-1`

### `GITOPS_ORCHESTRATOR_PATH`
- **Default:** None
- **Description:** Path to GitOps orchestrator directory within the repository.
- **Example:** `GITOPS_ORCHESTRATOR_PATH=clusters/hub/orchestrator`

### `AVAILABLE_CLUSTERS`
- **Default:** `[]`
- **Description:** JSON array of available clusters for multi-cluster deployments.
- **Example:** `AVAILABLE_CLUSTERS='[{"name":"k3s-cluster-1","server":"https://kubernetes.default.svc"}]'`

---

## GitOps Configuration

### `GITOPS_REPO_URL`
- **Default:** None (required for GitOps)
- **Description:** GitOps repository URL.
- **Example:** `GITOPS_REPO_URL=git@github.com:org/gitops-repo.git`

### `GITOPS_BRANCH`
- **Default:** `main`
- **Description:** GitOps repository branch.
- **Example:** `GITOPS_BRANCH=develop`

### `GIT_BACKEND`
- **Default:** `remote`
- **Description:** Git backend type.
- **Values:** `remote`, `local`
- **Example:** `GIT_BACKEND=remote`

### `GIT_AUTH_METHOD`
- **Default:** `ssh`
- **Description:** Git authentication method.
- **Values:** `ssh`, `https`, `token`
- **Example:** `GIT_AUTH_METHOD=ssh`

### `SSH_PRIVATE_KEY`
- **Default:** None
- **Description:** SSH private key content for GitOps authentication (inline).
- **Example:** `SSH_PRIVATE_KEY="-----BEGIN RSA PRIVATE KEY-----\n..."`
- **Security:** Never commit this value. Use secrets management.

### `SSH_PRIVATE_KEY_PATH`
- **Default:** None
- **Description:** Path to SSH private key file for GitOps authentication.
- **Example:** `SSH_PRIVATE_KEY_PATH=/app/secrets/ssh-key`

### `GITHUB_TOKEN`
- **Default:** None
- **Description:** GitHub personal access token for HTTPS authentication.
- **Example:** `GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxx`
- **Security:** Never commit this value. Use secrets management.

### `GITOPS_REPO_DIR`
- **Default:** None
- **Description:** Local directory path for GitOps repository (for local backend).
- **Example:** `GITOPS_REPO_DIR=/var/lib/gitops/repo`

### `GITOPS_WORK_DIR`
- **Default:** `.gitops-work`
- **Description:** Working directory for GitOps operations.
- **Example:** `GITOPS_WORK_DIR=/tmp/gitops-work`

---

## Logging Configuration

### `LOG_LEVEL`
- **Default:** `INFO`
- **Description:** Logging level.
- **Values:** `DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`
- **Example:** `LOG_LEVEL=DEBUG`

### `LOG_FORMAT`
- **Default:** `json`
- **Description:** Log output format.
- **Values:** `json`, `text`
- **Example:** `LOG_FORMAT=json`

### `LOG_RESPONSE_PAYLOADS`
- **Default:** `false`
- **Description:** Log full response payloads (useful for debugging, verbose).
- **Values:** `true`, `false`
- **Example:** `LOG_RESPONSE_PAYLOADS=true`

---

## Security Configuration

### TLS/SSL

#### `TLS_ENABLED`
- **Default:** `false`
- **Description:** Enable TLS/SSL for server.
- **Values:** `true`, `false`
- **Example:** `TLS_ENABLED=true`

#### `SERVER_CERT_PATH`
- **Default:** `./certs/server.crt`
- **Description:** Path to TLS server certificate.
- **Example:** `SERVER_CERT_PATH=/app/certs/server.crt`

#### `SERVER_KEY_PATH`
- **Default:** `./certs/server.key`
- **Description:** Path to TLS server private key.
- **Example:** `SERVER_KEY_PATH=/app/certs/server.key`

### Mutual TLS (mTLS)

#### `MTLS_ENABLED`
- **Default:** `false`
- **Description:** Enable mutual TLS (client certificate verification).
- **Values:** `true`, `false`
- **Example:** `MTLS_ENABLED=true`

#### `CLIENT_CA_PATH`
- **Default:** `./certs/client-ca.crt`
- **Description:** Path to client CA certificate for mTLS.
- **Example:** `CLIENT_CA_PATH=/app/certs/ca.crt`

---

## JWT Authentication

### `JWT_AUTH_ENABLED`
- **Default:** `false`
- **Description:** Enable JWT authentication.
- **Values:** `true`, `false`, `1`, `0`, `yes`, `no`
- **Example:** `JWT_AUTH_ENABLED=true`

### `JWT_JWKS_URL`
- **Default:** None
- **Description:** JWKS (JSON Web Key Set) URL for JWT validation.
- **Example:** `JWT_JWKS_URL=https://auth.example.com/.well-known/jwks.json`

### `JWT_ISSUER`
- **Default:** None
- **Description:** Expected JWT issuer (iss claim).
- **Example:** `JWT_ISSUER=https://auth.example.com`

### `JWT_AUDIENCE`
- **Default:** None
- **Description:** Expected JWT audience (aud claim).
- **Example:** `JWT_AUDIENCE=broker-api`

### `JWT_ALGORITHMS`
- **Default:** `RS256`
- **Description:** Comma-separated list of allowed JWT algorithms.
- **Example:** `JWT_ALGORITHMS=RS256,ES256`

### `JWT_CACHE_TTL`
- **Default:** `3600`
- **Description:** JWKS cache TTL in seconds.
- **Example:** `JWT_CACHE_TTL=7200`

### `JWT_EXEMPT_PATHS`
- **Default:** `/health,/v2/catalog`
- **Description:** Comma-separated list of paths exempt from JWT authentication.
- **Example:** `JWT_EXEMPT_PATHS=/health,/v2/catalog,/metrics`

### `JWT_VERIFY_SSL`
- **Default:** `true`
- **Description:** Verify SSL certificates when fetching JWKS.
- **Values:** `true`, `false`, `1`, `0`, `yes`, `no`
- **Example:** `JWT_VERIFY_SSL=true`

---

## Debug and Development

### `DEBUG_RETAIN_FAILED_FILES`
- **Default:** `false`
- **Description:** Retain failed provisioning files for debugging. When enabled, skips cleanup of instance files when provisioning fails.
- **Values:** `true`, `false`
- **Example:** `DEBUG_RETAIN_FAILED_FILES=true`
- **Use Case:** Debugging service definitions and troubleshooting provisioning issues.

### `DUMP_PROVISION_VARIABLES`
- **Default:** `false`
- **Description:** Dump provision variables to file for debugging.
- **Values:** `true`, `false`
- **Example:** `DUMP_PROVISION_VARIABLES=true`

### `CREATE_ARGOCD_APP`
- **Default:** `true` (server), `false` (CLI)
- **Description:** Create ArgoCD Application YAML files during provisioning.
- **Values:** `true`, `false`
- **Example:** `CREATE_ARGOCD_APP=false`
- **Note:** CLI sets this to `false` by default. Override if needed.

---

## Gunicorn Configuration

These variables configure the Gunicorn WSGI server when running in production mode.

### Worker Configuration

#### `GUNICORN_WORKERS`
- **Default:** `2`
- **Description:** Number of worker processes. Use `auto` for `(CPU_COUNT * 2) + 1`.
- **Example:** `GUNICORN_WORKERS=4` or `GUNICORN_WORKERS=auto`

#### `GUNICORN_WORKER_CLASS`
- **Default:** `sync`
- **Description:** Worker class type.
- **Values:** `sync`, `gevent`, `eventlet`
- **Example:** `GUNICORN_WORKER_CLASS=sync`

#### `GUNICORN_WORKER_CONNECTIONS`
- **Default:** `1000`
- **Description:** Maximum simultaneous clients per worker (for async workers).
- **Example:** `GUNICORN_WORKER_CONNECTIONS=2000`

### Request Handling

#### `GUNICORN_MAX_REQUESTS`
- **Default:** `5000`
- **Description:** Maximum requests per worker before restart (prevents memory leaks).
- **Example:** `GUNICORN_MAX_REQUESTS=10000`

#### `GUNICORN_MAX_REQUESTS_JITTER`
- **Default:** `500`
- **Description:** Randomize max_requests to prevent simultaneous worker restarts.
- **Example:** `GUNICORN_MAX_REQUESTS_JITTER=1000`

#### `GUNICORN_TIMEOUT`
- **Default:** `60`
- **Description:** Worker timeout in seconds before killing unresponsive worker.
- **Example:** `GUNICORN_TIMEOUT=120`

#### `GUNICORN_GRACEFUL_TIMEOUT`
- **Default:** `30`
- **Description:** Graceful shutdown timeout in seconds.
- **Example:** `GUNICORN_GRACEFUL_TIMEOUT=60`

#### `GUNICORN_KEEPALIVE`
- **Default:** `5`
- **Description:** Keep-alive timeout in seconds for persistent connections.
- **Example:** `GUNICORN_KEEPALIVE=10`

### Network Configuration

#### `GUNICORN_BACKLOG`
- **Default:** `2048`
- **Description:** Maximum number of pending connections.
- **Example:** `GUNICORN_BACKLOG=4096`

### Security Limits

#### `GUNICORN_LIMIT_REQUEST_LINE`
- **Default:** `4096`
- **Description:** Maximum size of HTTP request line (prevents DoS).
- **Example:** `GUNICORN_LIMIT_REQUEST_LINE=8192`

#### `GUNICORN_LIMIT_REQUEST_FIELDS`
- **Default:** `100`
- **Description:** Maximum number of HTTP request header fields.
- **Example:** `GUNICORN_LIMIT_REQUEST_FIELDS=200`

#### `GUNICORN_LIMIT_REQUEST_FIELD_SIZE`
- **Default:** `8190`
- **Description:** Maximum size of HTTP request header field.
- **Example:** `GUNICORN_LIMIT_REQUEST_FIELD_SIZE=16380`

### Logging

#### `GUNICORN_ACCESS_LOG`
- **Default:** `None` (disabled)
- **Description:** Access log file path. Use `-` for stdout, `None` to disable.
- **Example:** `GUNICORN_ACCESS_LOG=-`

#### `GUNICORN_ERROR_LOG`
- **Default:** `-` (stderr)
- **Description:** Error log file path. Use `-` for stderr.
- **Example:** `GUNICORN_ERROR_LOG=/var/log/gunicorn-error.log`

#### `GUNICORN_LOG_LEVEL`
- **Default:** `info`
- **Description:** Gunicorn log level.
- **Values:** `debug`, `info`, `warning`, `error`, `critical`
- **Example:** `GUNICORN_LOG_LEVEL=warning`

---

## Usage Examples

### Development (broker-cli)

```bash
# Enable debug mode with verbose logging
DEBUG_RETAIN_FAILED_FILES=true \
LOG_LEVEL=DEBUG \
broker-cli instance provision --service mysql --instance test-001

# Use specific GitOps configuration
GITOPS_REPO_URL=git@github.com:org/repo.git \
GITOPS_BRANCH=develop \
SSH_PRIVATE_KEY_PATH=~/.ssh/id_rsa \
broker-cli instance provision --service mysql --instance dev-001
```

### Production (Docker/Kubernetes)

```yaml
# Kubernetes Deployment example
env:
  - name: PORT
    value: "8080"
  - name: LOG_LEVEL
    value: "INFO"
  - name: LOG_FORMAT
    value: "json"
  - name: STORAGE_TYPE
    value: "gitops"
  - name: GITOPS_REPO_URL
    value: "git@github.com:org/gitops-repo.git"
  - name: GITOPS_BRANCH
    value: "main"
  - name: SSH_PRIVATE_KEY
    valueFrom:
      secretKeyRef:
        name: gitops-ssh-key
        key: private-key
  - name: JWT_AUTH_ENABLED
    value: "true"
  - name: JWT_JWKS_URL
    value: "https://auth.example.com/.well-known/jwks.json"
  - name: TLS_ENABLED
    value: "true"
  - name: GUNICORN_WORKERS
    value: "4"
  - name: GUNICORN_TIMEOUT
    value: "120"
```

### Docker Compose

```yaml
services:
  broker:
    image: quay.io/your-org/byop-broker:latest
    environment:
      - PORT=8080
      - LOG_LEVEL=INFO
      - STORAGE_TYPE=gitops
      - GITOPS_REPO_URL=git@github.com:org/repo.git
      - GITOPS_BRANCH=main
      - SSH_PRIVATE_KEY_PATH=/run/secrets/ssh-key
      - DEBUG_RETAIN_FAILED_FILES=false
      - GUNICORN_WORKERS=2
    secrets:
      - ssh-key
```

---

## Configuration Precedence

Environment variables take precedence over configuration file values:

1. **Environment variables** (highest priority)
2. **Configuration file** (`config.gitops.json`)
3. **Default values** (lowest priority)

This allows flexible configuration management across different deployment environments.

---

## Security Best Practices

1. **Never commit secrets** to version control
2. **Use Kubernetes Secrets** or similar for sensitive values
3. **Enable TLS/mTLS** in production
4. **Enable JWT authentication** for API access control
5. **Use SSH keys** for GitOps authentication
6. **Rotate credentials** regularly
7. **Set appropriate log levels** (avoid DEBUG in production)
8. **Disable debug features** in production (`DEBUG_RETAIN_FAILED_FILES=false`)

---

## Related Documentation

- [CLI Usage Guide](cli-usage-guide.md) - Comprehensive CLI documentation
- [Configuration Guide](CLI-CONFIGURATION.md) - Detailed configuration reference
- [Architecture Documentation](architecture/README.md) - System architecture

---

*Last Updated: 2026-04-30*