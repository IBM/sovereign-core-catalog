# Broker CLI Usage Guide

Complete guide for using the `broker-cli` command-line tool for service provisioning and management.

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [Environment Variables](#environment-variables)
- [Command Groups](#command-groups)
- [Common Workflows](#common-workflows)
- [Examples](#examples)
- [Troubleshooting](#troubleshooting)

## Installation

### From Source

```bash
cd broker
pip install -e .
```

### Verify Installation

```bash
broker-cli --version
broker-cli --help
```

## Quick Start

### 1. Initialize Configuration

```bash
# Create default configuration profile
broker-cli config init

# Edit configuration
vim ~/.broker-cli/default.json
```

### 2. Discover Available Services

```bash
# List all available services
broker-cli catalog list

# Show details of a specific service
broker-cli catalog show mariadb
```

### 3. Provision a Service (Dry-Run)

```bash
# Test provisioning without GitOps
broker-cli instance provision --service mariadb --instance my-database --plan small --dry-run
```

### 4. List Instances

```bash
broker-cli instance list --dry-run
```

### 5. Get Instance Details

```bash
broker-cli instance get --instance my-database --dry-run
```

### 6. Clean Up

```bash
broker-cli instance clean --instance my-database
```

## Configuration

### Configuration File Locations

The CLI searches for configuration in this order:

1. **Explicit path** (highest priority):
   ```bash
   broker-cli --config /path/to/config.json instance list
   ```

2. **Project-specific config**:
   ```
   ./config.gitops.json
   ```

3. **User config directory** (default):
   ```
   ~/.broker-cli/config
   ```

### Configuration File Format

The CLI configuration file has two main sections: `storage` and `gitops`.

**Basic Structure:**
```json
{
  "storage": {
    "type": "gitops",
    "config": {
      "storage_dir": "./data",
      "cluster_name": "k3s-cluster-2",
      "orchestrator_path": "./orchestrator"
    }
  },
  "gitops": {
    "repo_url": "git@github.com:your-org/gitops-repo.git",
    "branch": "main",
    "git_backend": "remote",
    "git_auth_method": "ssh",
    "ssh_private_key_path": ".ssh/gitops_deploy_key"
  }
}
```

**Configuration Fields:**

| Section | Field | Type | Required | Description |
|---------|-------|------|----------|-------------|
| `storage` | `type` | string | Yes | Storage type. Must be `"gitops"` |
| `storage.config` | `storage_dir` | string | Yes | Local directory for instance metadata |
| `storage.config` | `cluster_name` | string | Yes | Target cluster name |
| `storage.config` | `orchestrator_path` | string | Yes | Path to orchestrator directory |
| `gitops` | `repo_url` | string | Yes | Git repository URL (SSH or HTTPS) |
| `gitops` | `branch` | string | Yes | Git branch to use |
| `gitops` | `git_backend` | string | Yes | Git backend: `"remote"` or `"local"` |
| `gitops` | `git_auth_method` | string | Yes | Auth method: `"ssh"` or `"https"` |
| `gitops` | `ssh_private_key_path` | string | Conditional | SSH private key path (required if using SSH) |

**SSH Authentication (Recommended):**
```json
{
  "gitops": {
    "repo_url": "git@github.com:org/repo.git",
    "git_auth_method": "ssh",
    "ssh_private_key_path": "~/.ssh/gitops_deploy_key"
  }
}
```

**Environment Variables in Config (New Feature):**

You can now define environment variables directly in the config file using an `env` section. These variables will be automatically set when the CLI runs:

```json
{
  "cluster_name": "k3s-1",
  "gitops": {
    "repo_url": "git@github.com:org/repo.git",
    "branch": "main",
    "git_backend": "remote",
    "git_auth_method": "ssh",
    "ssh_private_key_path": "~/git/org/repo/ssh/gitops"
  },
  "env": {
    "GITOPS_REPO_URL": "git@github.com:org/repo.git",
    "SSH_PRIVATE_KEY_PATH": "~/git/org/repo/ssh/gitops",
    "CLUSTER_NAME": "k3s-1",
    "LOG_LEVEL": "INFO"
  },
  "default_output": "text"
}
```

**Configuration Options:**
- `env`: Dictionary of environment variables to set automatically
- `default_output`: Default output format for commands ("table", "json", or "text")
  - Can be overridden with `--output` flag on individual commands
  - If not specified, defaults to "table"

**Benefits of using the `env` section:**
- No need to export environment variables in your shell
- Configuration is self-contained in one file
- Easier to switch between different environments
- Path expansion (e.g., `~`) is automatically handled

**View current environment configuration:**
```bash
# Display all environment variables and config (table format, default)
broker-cli config env

# Display in JSON format
broker-cli config env --output json

# Display in plain text format (no colors, no tables)
broker-cli config env --output text
```

**HTTPS Authentication:**
```json
{
  "gitops": {
    "repo_url": "https://github.com/org/repo.git",
    "git_auth_method": "https"
  }
}
```

**SSH Key Setup:**

```bash
# Generate dedicated SSH key for GitOps
ssh-keygen -t ed25519 -C "gitops-deploy-key" -f ~/.ssh/gitops_deploy_key

# Add public key to GitHub/GitLab
cat ~/.ssh/gitops_deploy_key.pub
# Copy and add to repository deploy keys

# Test SSH connection
ssh -T git@github.com -i ~/.ssh/gitops_deploy_key
```

**Security Best Practices:**
- Never commit SSH private keys to version control
- Use dedicated deploy keys for GitOps repositories
- Restrict deploy key permissions to read/write only the GitOps repository
- Use restrictive file permissions on SSH keys: `chmod 600 ~/.ssh/gitops_deploy_key`
- Add config files to `.gitignore` if they contain sensitive paths

### Profile Management

#### Create Profiles

```bash
# Create profiles for different environments
broker-cli config init --profile k3s
broker-cli config init --profile prod
broker-cli config init --profile dev
```

#### List Profiles

```bash
broker-cli config list
```

Output:
```
┏━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Profile ┃ Status   ┃ Path                                       ┃
┡━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ k3s     │ → active │ /Users/user/.broker-cli/k3s.json           │
│ prod    │          │ /Users/user/.broker-cli/prod.json          │
│ dev     │          │ /Users/user/.broker-cli/dev.json           │
└─────────┴──────────┴────────────────────────────────────────────┘
```

#### Switch Profiles

```bash
broker-cli config use prod
```
## Environment Variables

The broker-cli respects environment variables for configuration, which take precedence over configuration file values. This is useful for:

- **Debugging**: Enable verbose logging and retain failed files
- **CI/CD**: Override configuration without modifying files
- **Secrets**: Provide credentials without storing in config files
- **Testing**: Temporarily change behavior for specific runs

### Common Environment Variables

#### Debug and Development

```bash
# Retain failed provisioning files for debugging
DEBUG_RETAIN_FAILED_FILES=true broker-cli instance provision --service mysql --instance test-001

# Enable verbose logging
LOG_LEVEL=DEBUG broker-cli instance provision --service mysql --instance test-001

# Dump provision variables to file
DUMP_PROVISION_VARIABLES=true broker-cli instance provision --service mysql --instance test-001
```

#### GitOps Configuration

```bash
# Override GitOps repository
GITOPS_REPO_URL=git@github.com:org/repo.git \
GITOPS_BRANCH=develop \
broker-cli instance provision --service mysql --instance dev-001

# Provide SSH key inline (for CI/CD)
SSH_PRIVATE_KEY="$(cat ~/.ssh/gitops_key)" \
broker-cli instance provision --service mysql --instance test-001
```

#### ArgoCD Control

```bash
# Disable ArgoCD Application file creation (default for CLI)
CREATE_ARGOCD_APP=false broker-cli instance provision --service mysql --instance test-001

# Enable ArgoCD Application file creation
CREATE_ARGOCD_APP=true broker-cli instance provision --service mysql --instance test-001
```

### Complete Reference

For a comprehensive list of all available environment variables, see:

**[Environment Variables Reference](environment-variables.md)**

This document includes:
- Server configuration variables
- Storage and GitOps settings
- Logging configuration
- Security settings (TLS, mTLS, JWT)
- Debug and development options
- Gunicorn configuration (for server mode)

### Configuration Precedence

Environment variables take precedence over configuration file values:

1. **Environment variables** (highest priority)
2. **Configuration file** (`config.gitops.json` or profile)
3. **Default values** (lowest priority)

**Example:**
```bash
# Config file has: "branch": "main"
# Environment variable overrides it:
GITOPS_BRANCH=develop broker-cli instance provision --service mysql --instance test-001
# Result: Uses "develop" branch
```


## Command Groups

The CLI is organized into three main command groups:

### 1. config - Configuration Management

Manage configuration profiles and settings.

```bash
broker-cli config init      # Initialize config directory
broker-cli config list      # List profiles
broker-cli config use       # Switch profiles
```

### 2. catalog - Service Discovery

Discover and view available services from the GitOps repository.

```bash
broker-cli catalog list     # List available services
broker-cli catalog show     # Show service details
```

### 3. instance - Instance Management

Provision, update, and manage service instances.

```bash
broker-cli instance provision    # Provision new instance
broker-cli instance deprovision  # Deprovision instance
broker-cli instance update       # Update instance
broker-cli instance get          # Get instance details
broker-cli instance list         # List instances
broker-cli instance clean        # Clean dry-run artifacts
```

### Global Options

All commands support these global options:

```bash
--config, -c PATH    # Path to configuration file
--verbose, -v        # Enable verbose output (DEBUG logging)
--quiet, -q          # Suppress all output except errors
--help, -h           # Show help message
```

## Commands Reference

### config

Manage configuration profiles.

#### config init

Initialize user configuration directory.

```bash
broker-cli config init [OPTIONS]
```

**Options:**
- `--profile, -p TEXT` - Profile name (default: default)

**Examples:**
```bash
broker-cli config init
broker-cli config init --profile k3s
broker-cli config init -p prod
```

#### config list

List available configuration profiles.

```bash
broker-cli config list
```

#### config use

Switch to a different configuration profile.

```bash
broker-cli config use PROFILE
```

**Arguments:**
- `PROFILE` - Profile name to activate

**Examples:**
```bash
broker-cli config use k3s
broker-cli config use prod
```

---

### catalog

Discover and view available services.

#### catalog list

List all available services from the GitOps repository.

```bash
broker-cli catalog list [OPTIONS]
```

**Options:**
- `--output, -o FORMAT` - Output format: table, json, yaml (default: table)

**Examples:**
```bash
# List services (table format)
broker-cli catalog list

# JSON output
broker-cli catalog list --output json

# YAML output
broker-cli catalog list --output yaml
```

**Output (table format):**
```
┏━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━┓
┃ Service           ┃ Name         ┃ Description              ┃ Plans              ┃
┡━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━┩
│ mariadb-service   │ MariaDB      │ MariaDB database service │ small, medium, ... │
│ postgresql-service│ PostgreSQL   │ PostgreSQL database      │ small, medium, ... │
└───────────────────┴──────────────┴──────────────────────────┴────────────────────┘
```

#### catalog show

Show detailed information about a specific service.

```bash
broker-cli catalog show SERVICE [OPTIONS]
```

**Arguments:**
- `SERVICE` - Service name or ID
  - Short name: `mariadb`, `postgresql`, `mariadb-helm`
  - Full service ID: `mariadb-service`, `postgresql-service`, `mariadb-helm-service`
  - Both formats are accepted

**Options:**
- `--output, -o FORMAT` - Output format: table, json, yaml (default: table)

**Examples:**
```bash
# Show service details using short name (table format)
broker-cli catalog show mariadb

# Show service details using full service ID
broker-cli catalog show mariadb-service

# JSON output
broker-cli catalog show mariadb --output json

# YAML output
broker-cli catalog show postgresql-service --output yaml
```

**Output (table format):**
```
╭─────────────────── Service Details ────────────────────╮
│ Name: MariaDB                                          │
│ ID: mariadb-service                                    │
│ Description: MariaDB database service                  │
│ Bindable: False                                        │
╰────────────────────────────────────────────────────────╯

┏━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Plan ID  ┃ Name         ┃ Description                        ┃
┡━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ small    │ Small        │ Small MariaDB instance (1 CPU)     │
│ medium   │ Medium       │ Medium MariaDB instance (2 CPU)    │
│ large    │ Large        │ Large MariaDB instance (4 CPU)     │
└──────────┴──────────────┴────────────────────────────────────┘
```

---

### instance

Manage service instances.

#### instance provision

Provision a new service instance.

```bash
broker-cli instance provision [OPTIONS]
```

**Options:**
- `--service, -s TEXT` - Service type (required)
- `--instance, -i TEXT` - Instance name (required)
- `--plan, -p TEXT` - Service plan (default: default)
- `--cluster, -c TEXT` - Target cluster name
- `--environment, -e TEXT` - Environment: dev, staging, prod (default: dev)
- `--param KEY=VALUE` - Service parameters (repeatable)
- `--dry-run` - Test without GitOps (uses FileStorage)
- `--output-dir PATH` - Output directory for dry-run (default: ./dry-run-output)

**Examples:**
```bash
# Basic provisioning (dry-run)
broker-cli instance provision --service mariadb --instance my-db --plan small --dry-run

# With parameters
broker-cli instance provision --service mariadb --instance my-db --plan small \
  --param db_name=myapp \
  --param db_user=admin \
  --dry-run

# With GitOps (requires config)
broker-cli instance provision --service mariadb --instance my-db --plan small \
  --param db_name=myapp

# Production environment
broker-cli instance provision --service mariadb --instance prod-db --plan large \
  --environment prod \
  --param db_name=production
```

#### instance deprovision

Deprovision (delete) a service instance.

```bash
broker-cli instance deprovision [OPTIONS]
```

**Options:**
- `--instance, -i TEXT` - Instance name (required)
- `--dry-run` - Test without GitOps
- `--output-dir PATH` - Output directory for dry-run
- `--confirm` - Skip confirmation prompt

**Examples:**
```bash
# Deprovision instance (dry-run)
broker-cli instance deprovision --instance my-db --dry-run

# With GitOps (prompts for confirmation)
broker-cli instance deprovision --instance my-db

# Skip confirmation
broker-cli instance deprovision --instance my-db --confirm
```

#### instance update

Update an existing service instance.

```bash
broker-cli instance update [OPTIONS]
```

**Options:**
- `--instance, -i TEXT` - Instance name (required)
- `--param KEY=VALUE` - Updated parameters (repeatable)
- `--dry-run` - Test without GitOps
- `--output-dir PATH` - Output directory for dry-run

**Examples:**
```bash
# Update parameters
broker-cli instance update --instance my-db \
  --param db_name=newdb \
  --param db_user=newuser \
  --dry-run

# With GitOps
broker-cli instance update --instance my-db --param db_name=newdb
```

**Output shows visual diff:**
```
Parameter Changes:
  db_name: myapp → newdb
  db_user: admin → newuser

File Changes (instances/my-db/instance.yaml):
  - db_name: myapp
  + db_name: newdb
```

#### instance get

Get details of a service instance.

```bash
broker-cli instance get [OPTIONS]
```

**Options:**
- `--instance, -i TEXT` - Instance name (required)
- `--dry-run` - Use FileStorage instead of GitOps
- `--output-dir PATH` - Output directory for dry-run
- `--output, -o FORMAT` - Output format: table, json, yaml (default: table)

**Examples:**
```bash
# Get instance details (table format)
broker-cli instance get --instance my-db --dry-run

# JSON output
broker-cli instance get --instance my-db --dry-run --output json

# YAML output
broker-cli instance get --instance my-db --dry-run --output yaml
```

#### instance list

List all service instances.

```bash
broker-cli instance list [OPTIONS]
```

**Options:**
- `--dry-run` - Use FileStorage instead of GitOps
- `--output-dir PATH` - Output directory for dry-run
- `--output, -o FORMAT` - Output format: table, json, yaml (default: table)

**Examples:**
```bash
# List all instances (table format)
broker-cli instance list --dry-run

# JSON output
broker-cli instance list --dry-run --output json

# With GitOps
broker-cli instance list
```

**Output (table format):**
```
┏━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┓
┃ Instance   ┃ Service      ┃ Plan   ┃ Environment ┃ Cluster       ┃
┡━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━┩
│ my-db      │ mariadb      │ small  │ dev         │ k3s-cluster-1 │
│ prod-db    │ postgresql   │ large  │ prod        │ k3s-cluster-1 │
└────────────┴──────────────┴────────┴─────────────┴───────────────┘
```

#### instance clean

Clean up dry-run artifacts.

```bash
broker-cli instance clean [OPTIONS]
```

**Options:**
- `--instance, -i TEXT` - Specific instance to clean
- `--all` - Clean all dry-run instances
- `--output-dir PATH` - Dry-run output directory (default: ./dry-run-output)
- `--confirm` - Skip confirmation prompt

**Examples:**
```bash
# Clean specific instance
broker-cli instance clean --instance my-db

# Clean all instances (prompts for confirmation)
broker-cli instance clean --all

# Skip confirmation
broker-cli instance clean --all --confirm
```

## Common Workflows

### Workflow 1: Discover and Provision Service

Discover available services and provision one:

```bash
# 1. List available services
broker-cli catalog list

# 2. Show service details
broker-cli catalog show mariadb

# 3. Provision instance (dry-run)
broker-cli instance provision --service mariadb --instance test-db --plan small \
  --param db_name=testdb \
  --dry-run

# 4. Verify instance
broker-cli instance get --instance test-db --dry-run

# 5. Clean up
broker-cli instance clean --instance test-db
```

### Workflow 2: Local Testing (Dry-Run)

Test service provisioning without GitOps:

```bash
# 1. Provision instance
broker-cli instance provision --service mariadb --instance test-db --plan small \
  --param db_name=testdb \
  --dry-run

# 2. Verify instance
broker-cli instance get --instance test-db --dry-run

# 3. List all instances
broker-cli instance list --dry-run

# 4. Update instance
broker-cli instance update --instance test-db \
  --param db_name=newdb \
  --dry-run

# 5. Clean up
broker-cli instance clean --instance test-db
```

### Workflow 3: GitOps Deployment

Deploy to GitOps repository:

```bash
# 1. Configure GitOps
broker-cli config init --profile prod
vim ~/.broker-cli/prod.json  # Edit with GitOps settings

# 2. Activate profile
broker-cli config use prod

# 3. Check available services
broker-cli catalog list

# 4. Provision instance
broker-cli instance provision --service mariadb --instance prod-db --plan medium \
  --param db_name=production \
  --param db_user=app

# 5. Verify deployment
broker-cli instance get --instance prod-db

# 6. Update if needed
broker-cli instance update --instance prod-db \
  --param db_name=production_v2

# 7. Deprovision when done
broker-cli instance deprovision --instance prod-db
```

### Workflow 4: Multi-Environment Management

Manage multiple environments with profiles:

```bash
# Setup profiles
broker-cli config init --profile dev
broker-cli config init --profile staging
broker-cli config init --profile prod

# Edit each profile
vim ~/.broker-cli/dev.json
vim ~/.broker-cli/staging.json
vim ~/.broker-cli/prod.json

# Deploy to dev
broker-cli config use dev
broker-cli instance provision --service mariadb --instance app-db --plan small \
  --param db_name=dev_db

# Promote to staging
broker-cli config use staging
broker-cli instance provision --service mariadb --instance app-db --plan medium \
  --param db_name=staging_db

# Promote to prod
broker-cli config use prod
broker-cli instance provision --service mariadb --instance app-db --plan large \
  --param db_name=prod_db

# List instances in each environment
broker-cli config use dev && broker-cli instance list
broker-cli config use staging && broker-cli instance list
broker-cli config use prod && broker-cli instance list
```

## Examples

### Example 1: Service Discovery

```bash
# List all available services
broker-cli catalog list

# Show MariaDB service details
broker-cli catalog show mariadb

# Show PostgreSQL service details with JSON output
broker-cli catalog show postgresql --output json
```

### Example 2: MariaDB Provisioning

```bash
# Provision MariaDB with custom parameters
broker-cli instance provision --service mariadb --instance my-mariadb --plan small \
  --param db_name=myapp \
  --param db_user=appuser \
  --param db_password=secure123 \
  --param storage_size=10Gi \
  --dry-run

# Verify
broker-cli instance get --instance my-mariadb --dry-run --output yaml
```

### Example 3: Update with Diff

```bash
# Update instance and see changes
broker-cli instance update --instance my-mariadb \
  --param db_name=myapp_v2 \
  --param storage_size=20Gi \
  --dry-run
```

Output shows color-coded diff:
```
Parameter Changes:
  db_name: myapp → myapp_v2
  storage_size: 10Gi → 20Gi

File Changes (instances/my-mariadb/instance.yaml):
  - db_name: myapp
  + db_name: myapp_v2
  - storage_size: 10Gi
  + storage_size: 20Gi
```

### Example 4: JSON Output for Automation

```bash
# Get instance details as JSON
broker-cli instance get --instance my-db --dry-run --output json | jq '.parameters'

# List instances as JSON
broker-cli instance list --dry-run --output json | jq '.[] | {id, service, plan}'

# List services as JSON
broker-cli catalog list --output json | jq '.[] | {id, name, plans}'
```

### Example 5: Batch Operations

```bash
# Provision multiple instances
for env in dev staging prod; do
  broker-cli instance provision --service mariadb --instance "app-db-$env" --plan small \
    --param db_name="${env}_database" \
    --dry-run
done

# List all
broker-cli instance list --dry-run

# Clean all
broker-cli instance clean --all --confirm
```

## Troubleshooting

### Issue: "Config file not found"

**Problem:** CLI cannot find configuration file.

**Solution:**
```bash
# Check config search order
broker-cli --help  # Shows config search order

# Create config
broker-cli config init

# Or specify explicit path
broker-cli --config /path/to/config.json instance list
```

### Issue: "Profile not found"

**Problem:** Trying to use non-existent profile.

**Solution:**
```bash
# List available profiles
broker-cli config list

# Create missing profile
broker-cli config init --profile missing-profile
```

### Issue: "Service not found"

**Problem:** Service type not available in GitOps repository.

**Solution:**
```bash
# List available services
broker-cli catalog list

# Check if service exists
broker-cli catalog show mariadb

# Use dry-run to test without GitOps
broker-cli instance provision --service mariadb --instance test-db --plan small --dry-run
```

### Issue: "SSH key not found"

**Problem:** GitOps SSH key path incorrect.

**Solution:**
```bash
# Check SSH key exists
ls -la ~/.ssh/gitops_deploy_key

# Update config with correct path
vim ~/.broker-cli/config
# Set: "ssh_private_key_path": "~/.ssh/correct_key"

# Test SSH connection
ssh -i ~/.ssh/gitops_deploy_key git@github.com
```

### Issue: "Permission denied"

**Problem:** SSH key permissions too open.

**Solution:**
```bash
# Fix SSH key permissions
chmod 600 ~/.ssh/gitops_deploy_key
chmod 700 ~/.ssh
```

### Issue: "Git operation failed"

**Problem:** Git authentication or network issues.

**Solution:**
```bash
# Test Git access
git clone git@github.com:your-org/gitops-repo.git /tmp/test

# Check SSH agent
ssh-add -l

# Add key to agent
ssh-add ~/.ssh/gitops_deploy_key

# Enable verbose logging
broker-cli --verbose instance provision --service mariadb --instance test-db --plan small
```

### Issue: "Instance already exists"

**Problem:** Trying to provision duplicate instance.

**Solution:**
```bash
# Check existing instances
broker-cli instance list --dry-run

# Use different instance ID
broker-cli instance provision --service mariadb --instance my-db-2 --plan small --dry-run

# Or deprovision existing
broker-cli instance deprovision --instance my-db --dry-run
```

### Debug Mode

Enable verbose logging for troubleshooting:

```bash
# Verbose output (DEBUG level)
broker-cli --verbose instance provision --service mariadb --instance my-db --plan small --dry-run

# Quiet mode (errors only)
broker-cli --quiet instance provision --service mariadb --instance my-db --plan small --dry-run
```

## Advanced Usage

### Output Formatting

Use different output formats for automation:

```bash
# Text (default) - human-readable tables
broker-cli instance list --dry-run

# JSON - for scripting
broker-cli instance list --dry-run --output json | jq

# YAML - for configuration
broker-cli instance get --instance my-db --dry-run --output yaml
```

### Pipeline Integration

Use in CI/CD pipelines:

```bash
#!/bin/bash
set -e

# Discover services
broker-cli catalog list --output json > available-services.json

# Provision
broker-cli instance provision --service mariadb --instance ci-db --plan small \
  --param db_name=ci_test \
  --dry-run \
  --output json > provision-result.json

# Verify
if broker-cli instance get --instance ci-db --dry-run --output json | jq -e '.instance_id == "ci-db"'; then
  echo "Provisioning successful"
else
  echo "Provisioning failed"
  exit 1
fi

# Clean up
broker-cli instance clean --instance ci-db --confirm
```

## Best Practices

### 1. Discover Services Before Provisioning

```bash
# Always check available services first
broker-cli catalog list

# Review service details
broker-cli catalog show mariadb
```

### 2. Use Profiles for Environments

```bash
# Separate profiles for each environment
broker-cli config init --profile dev
broker-cli config init --profile prod

# Never mix environments
broker-cli config use dev
broker-cli instance provision --service mariadb --instance dev-db --plan small
```

### 3. Test with Dry-Run First

```bash
# Always test locally first
broker-cli instance provision --service mariadb --instance test-db --plan small --dry-run

# Then deploy to GitOps
broker-cli instance provision --service mariadb --instance prod-db --plan small
```

### 4. Use Meaningful Instance IDs

```bash
# Good: descriptive, environment-specific
broker-cli instance provision --service mariadb --instance prod-app-mariadb --plan large

# Bad: generic, unclear
broker-cli instance provision --service mariadb --instance db1 --plan large
```

### 5. Document Parameters

```bash
# Keep parameter documentation
cat > instance-params.txt <<EOF
Instance: prod-app-db
Service: mariadb
Plan: large
Parameters:
  - db_name: production_app
  - db_user: app_user
  - storage_size: 100Gi
EOF

# Use documented parameters
broker-cli instance provision --service mariadb --instance prod-app-db --plan large \
  --param db_name=production_app \
  --param db_user=app_user \
  --param storage_size=100Gi
```

### 6. Version Control Configurations

```bash
# Store configs in version control (without secrets)
git add ~/.broker-cli/*.json
git commit -m "Add broker CLI configurations"

# Use environment variables for secrets
export GITOPS_SSH_KEY_PATH=~/.ssh/gitops_key
```

## Migration from v1.0.0

If you're upgrading from v1.0.0, note these breaking changes:

### Command Structure Changes

All instance management commands now require the `instance` prefix:

| Old Command (v1.0.0) | New Command (v1.1.0) |
|----------------------|----------------------|
| `broker-cli provision ...` | `broker-cli instance provision ...` |
| `broker-cli deprovision ...` | `broker-cli instance deprovision ...` |
| `broker-cli update ...` | `broker-cli instance update ...` |
| `broker-cli get ...` | `broker-cli instance get ...` |
| `broker-cli list` | `broker-cli instance list` |
| `broker-cli clean ...` | `broker-cli instance clean ...` |

**Config commands unchanged:**
- `broker-cli config init` ✅
- `broker-cli config list` ✅
- `broker-cli config use` ✅

### New Features in v1.1.0

- **Service Discovery:** New `catalog` command group
  - `broker-cli catalog list` - List available services
  - `broker-cli catalog show <service>` - Show service details

- **Better Organization:** Commands grouped by functionality
  - `config` - Configuration management
  - `catalog` - Service discovery
  - `instance` - Instance management

## See Also

- [Configuration Guide](CLI-CONFIGURATION.md) - Detailed configuration reference
- [Architecture Documentation](architecture/README.md) - System architecture
- [Security Policy](security/SECURITY.md) - Security best practices

---

*Last Updated: 2026-04-28*  
*Version: 1.1.0*  
*Breaking Changes: Instance commands moved under `instance` subcommand*