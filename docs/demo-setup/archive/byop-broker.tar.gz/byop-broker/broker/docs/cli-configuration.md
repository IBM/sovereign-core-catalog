# CLI Configuration Guide

This guide explains how to configure the CLI for GitOps operations.

## Configuration File Location

The CLI looks for configuration in the following order:

1. **Command-line specified**: `--config /path/to/config.json`
2. **Default location**: `config.gitops.json` in the current directory
3. **Dry-run mode**: No configuration needed (uses `--dry-run` flag)

## Configuration File Structure

### For CLI Usage (Recommended)

The CLI expects a configuration file with two main sections: `storage` and `gitops`.

**File: `config.gitops.json`**

```json
{
  "storage": {
    "type": "gitops",
    "config": {
      "storage_dir": "./data",
      "cluster_name": "k3s-cluster-2",
      "orchestrator_path": "./orchestrator"
    }
  },
  "gitops": {
    "repo_url": "git@github.com:your-org/gitops-repo.git",
    "branch": "main",
    "git_backend": "remote",
    "git_auth_method": "ssh",
    "ssh_private_key_path": ".ssh/gitops_deploy_key"
  }
}
```

### Configuration Sections

#### 1. Storage Configuration (`storage`)

Controls the storage backend behavior.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `type` | string | Yes | Storage type. Must be `"gitops"` for GitOps operations |
| `config.storage_dir` | string | Yes | Local directory for instance metadata (default: `"./data"`) |
| `config.cluster_name` | string | Yes | Target cluster name (e.g., `"k3s-cluster-1"`) |
| `config.orchestrator_path` | string | Yes | Path to orchestrator directory (default: `"./orchestrator"`) |

#### 2. GitOps Configuration (`gitops`)

Controls Git repository access and authentication.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `repo_url` | string | Yes | Git repository URL (SSH or HTTPS) |
| `branch` | string | Yes | Git branch to use (default: `"main"`) |
| `git_backend` | string | Yes | Git backend type: `"remote"` or `"local"` |
| `git_auth_method` | string | Yes | Authentication method: `"ssh"` or `"https"` |
| `ssh_private_key_path` | string | Conditional | Path to SSH private key (required if `git_auth_method` is `"ssh"`) |

### Git Repository URL Formats

**SSH (Recommended):**
```json
{
  "gitops": {
    "repo_url": "git@github.com:org/repo.git",
    "git_auth_method": "ssh",
    "ssh_private_key_path": "~/.ssh/gitops_deploy_key"
  }
}
```

**HTTPS:**
```json
{
  "gitops": {
    "repo_url": "https://github.com/org/repo.git",
    "git_auth_method": "https"
  }
}
```

## Example Configurations

### Example 1: Local Development with SSH

```json
{
  "storage": {
    "type": "gitops",
    "config": {
      "storage_dir": "./data",
      "cluster_name": "k3s-local",
      "orchestrator_path": "./orchestrator"
    }
  },
  "gitops": {
    "repo_url": "git@github.com:myorg/gitops-repo.git",
    "branch": "main",
    "git_backend": "remote",
    "git_auth_method": "ssh",
    "ssh_private_key_path": "~/.ssh/id_rsa"
  }
}
```

### Example 2: Production with Dedicated SSH Key

```json
{
  "storage": {
    "type": "gitops",
    "config": {
      "storage_dir": "/var/lib/broker/data",
      "cluster_name": "prod-cluster-1",
      "orchestrator_path": "/opt/broker/orchestrator"
    }
  },
  "gitops": {
    "repo_url": "git@github.com:myorg/prod-gitops.git",
    "branch": "production",
    "git_backend": "remote",
    "git_auth_method": "ssh",
    "ssh_private_key_path": "/etc/broker/keys/gitops_deploy_key"
  }
}
```

### Example 3: Multiple Environments

**Development (`config.dev.json`):**
```json
{
  "storage": {
    "type": "gitops",
    "config": {
      "storage_dir": "./data",
      "cluster_name": "k3s-dev",
      "orchestrator_path": "./orchestrator"
    }
  },
  "gitops": {
    "repo_url": "git@github.com:myorg/gitops-dev.git",
    "branch": "develop",
    "git_backend": "remote",
    "git_auth_method": "ssh",
    "ssh_private_key_path": "~/.ssh/gitops_dev_key"
  }
}
```

**Production (`config.prod.json`):**
```json
{
  "storage": {
    "type": "gitops",
    "config": {
      "storage_dir": "./data",
      "cluster_name": "prod-cluster-1",
      "orchestrator_path": "./orchestrator"
    }
  },
  "gitops": {
    "repo_url": "git@github.com:myorg/gitops-prod.git",
    "branch": "main",
    "git_backend": "remote",
    "git_auth_method": "ssh",
    "ssh_private_key_path": "~/.ssh/gitops_prod_key"
  }
}
```

## Usage Examples

### Using Default Configuration

```bash
# Uses config.gitops.json in current directory
python -m broker.cli list
python -m broker.cli provision my-db mariadb small
```

### Using Custom Configuration

```bash
# Specify config file
python -m broker.cli list --config config.prod.json
python -m broker.cli provision my-db mariadb small --config config.dev.json
```

### Dry-Run Mode (No Configuration Needed)

```bash
# No GitOps config required for dry-run
python -m broker.cli list --dry-run
python -m broker.cli provision test-db mariadb small --dry-run --output-dir ./test-output
```

## SSH Key Setup

### Generate SSH Key for GitOps

```bash
# Generate dedicated SSH key for GitOps
ssh-keygen -t ed25519 -C "gitops-deploy-key" -f ~/.ssh/gitops_deploy_key

# Add public key to GitHub/GitLab
cat ~/.ssh/gitops_deploy_key.pub
# Copy and add to repository deploy keys
```

### Configure SSH Key in Config File

```json
{
  "gitops": {
    "ssh_private_key_path": "~/.ssh/gitops_deploy_key"
  }
}
```

### Test SSH Connection

```bash
# Test SSH connection to GitHub Enterprise
ssh -T git@github.com -i ~/.ssh/gitops_deploy_key
```

## Troubleshooting

### Error: "GITOPS_REPO_URL must be set"

**Cause:** Configuration file not found or missing `gitops` section.

**Solution:**
1. Verify config file exists: `ls -la config.gitops.json`
2. Check config file has `gitops` section with `repo_url`
3. Use `--config` flag to specify path explicitly

### Error: "Configuration file must contain 'storage' and 'gitops' sections"

**Cause:** Config file is missing required sections.

**Solution:**
Ensure your config file has both `storage` and `gitops` sections:
```json
{
  "storage": { ... },
  "gitops": { ... }
}
```

### Error: "Permission denied (publickey)"

**Cause:** SSH key not configured or not added to repository.

**Solution:**
1. Verify SSH key path in config file
2. Check SSH key permissions: `chmod 600 ~/.ssh/gitops_deploy_key`
3. Add public key to repository deploy keys
4. Test SSH connection: `ssh -T git@github.com -i ~/.ssh/gitops_deploy_key`

### Error: "Config file not found"

**Cause:** Config file doesn't exist at specified path.

**Solution:**
1. Create config file from example: `cp config.gitops.example.json config.gitops.json`
2. Edit with your repository details
3. Or use `--config` to specify correct path

## Configuration Validation

The CLI validates configuration on startup and provides clear error messages:

```bash
# Valid configuration
$ python -m broker.cli list
✓ Configuration loaded successfully

# Missing config file
$ python -m broker.cli list --config missing.json
✗ Error: Config file not found: missing.json

# Invalid config structure
$ python -m broker.cli list
✗ Error: Configuration file must contain 'storage' and 'gitops' sections
```

## Security Best Practices

1. **Never commit SSH private keys** to version control
2. **Use dedicated deploy keys** for GitOps repositories
3. **Restrict deploy key permissions** to read/write only the GitOps repository
4. **Use restrictive file permissions** on SSH keys: `chmod 600 ~/.ssh/gitops_deploy_key`
5. **Add config files to .gitignore** if they contain sensitive paths
6. **Use example config files** for documentation: `config.gitops.example.json`

## Environment Variables (Advanced)

For backward compatibility with web server deployment, the CLI also supports environment variables:

```bash
export GITOPS_REPO_URL="git@github.com:org/repo.git"
export GITOPS_BRANCH="main"
export GIT_BACKEND="remote"
export GIT_AUTH_METHOD="ssh"
export SSH_PRIVATE_KEY_PATH="~/.ssh/gitops_deploy_key"

# Config file values take precedence over environment variables
python -m broker.cli list
```

**Note:** Config file values always take precedence over environment variables.

## Related Documentation

- **CLI Usage Guide**: See `broker/README.md` for command reference
- **GitOps Setup**: See `docs/` for GitOps repository setup
- **Web Server Config**: See `config.gitops.example.json` for web server configuration format

---

*Last Updated: 2026-04-28*
*For CLI Feature Implementation: Phase 4*