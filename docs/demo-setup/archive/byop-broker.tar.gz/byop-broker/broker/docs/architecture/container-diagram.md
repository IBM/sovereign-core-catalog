# Container Diagram - GitOps CSB Broker

## C4 Container Diagram

This diagram shows the major containers (applications/services) that make up the GitOps CSB Broker system.

```mermaid
C4Container
    title Container Diagram - GitOps CSB Broker
    
    Person(client, "Client", "API consumer")
    
    Container_Boundary(broker_system, "GitOps CSB Broker") {
        Container(api, "Broker API", "Flask/Python", "CSB API endpoints")
        Container(catalog, "Catalog Discovery", "Python", "Service catalog management")
        Container(orchestrator, "Provisioning Orchestrator", "Python", "GitOps provisioning logic")
        Container(git_manager, "Git State Manager", "Python", "Git operations and state")
        Container(storage, "GitOps Storage", "Python", "Manifest generation and storage")
    }
    
    System_Ext(git, "GitHub Enterprise", "Git repository")
    System_Ext(argocd, "ArgoCD", "GitOps engine")
    
    Rel(client, api, "Provisions services", "HTTPS/JSON")
    Rel(api, catalog, "Gets catalog", "Function calls")
    Rel(api, orchestrator, "Triggers provisioning", "Function calls")
    Rel(orchestrator, git_manager, "Manages Git state", "Function calls")
    Rel(orchestrator, storage, "Generates manifests", "Function calls")
    Rel(git_manager, git, "Commits/pulls", "Git/SSH")
    Rel(orchestrator, argocd, "Creates apps", "HTTPS/REST")
    Rel(catalog, git, "Reads catalog", "Git/SSH")
```

## Container Descriptions

### Broker API (`app.py`)
**Technology**: Flask (Python)  
**Purpose**: Expose Open Service Broker API endpoints

**Responsibilities**:
- Handle HTTP requests for catalog, provisioning, binding, deprovisioning
- Request validation and authentication
- Route requests to appropriate handlers
- Return standardized CSB API responses

**Key Endpoints**:
- `GET /v2/catalog` - Return service catalog
- `PUT /v2/service_instances/:id` - Provision service
- `DELETE /v2/service_instances/:id` - Deprovision service
- `PUT /v2/service_instances/:id/service_bindings/:binding_id` - Create binding
- `DELETE /v2/service_instances/:id/service_bindings/:binding_id` - Delete binding

### Catalog Discovery (`catalog_discovery.py`)
**Technology**: Python  
**Purpose**: Discover and manage service catalog from Git repository

**Responsibilities**:
- Clone/pull catalog repository from Git
- Parse service definitions (YAML/JSON)
- Build CSB-compliant catalog structure
- Cache catalog for performance
- Handle catalog updates

**Key Functions**:
- `discover_catalog()` - Scan Git repo for service definitions
- `parse_service_definition()` - Parse service YAML/JSON
- `build_catalog_response()` - Format for CSB API

### Provisioning Orchestrator (`orchestrator/`)
**Technology**: Python  
**Purpose**: Orchestrate the GitOps provisioning workflow

**Responsibilities**:
- Coordinate provisioning steps
- Generate service-specific manifests
- Commit manifests to Git
- Create ArgoCD applications
- Monitor deployment status
- Handle errors and rollbacks

**Key Modules**:
- `provision.py` - Provisioning workflow
- `deprovision.py` - Deprovisioning workflow
- `api.py` - ArgoCD API client
- `git_operations.py` - Git operations

### Git State Manager (`git_state_manager.py`)
**Technology**: Python  
**Purpose**: Manage Git repository state and operations

**Responsibilities**:
- Initialize and configure Git repositories
- Handle SSH key management
- Perform Git operations (clone, pull, commit, push)
- Manage working directory state
- Handle Git conflicts and errors

**Key Functions**:
- `setup_git_repo()` - Initialize repository
- `commit_and_push()` - Commit changes to Git
- `pull_latest()` - Sync with remote
- `cleanup()` - Clean working directory

### GitOps Storage (`gitops_storage.py`)
**Technology**: Python  
**Purpose**: Generate and store Kubernetes manifests

**Responsibilities**:
- Generate Kubernetes manifests from templates
- Render service-specific configurations
- Organize manifests in Git repository structure
- Validate manifest syntax
- Handle manifest versioning

**Key Functions**:
- `generate_manifests()` - Create K8s manifests
- `render_template()` - Apply service parameters
- `store_manifests()` - Write to Git repository
- `validate_manifests()` - Check syntax

## Data Flow

### Provisioning Request Flow
```
1. Client → Broker API (PUT /v2/service_instances/:id)
2. Broker API → Orchestrator (provision_service())
3. Orchestrator → Storage (generate_manifests())
4. Orchestrator → Git Manager (commit_and_push())
5. Git Manager → GitHub (git push)
6. Orchestrator → ArgoCD API (create_application())
7. Orchestrator → Broker API (return operation status)
8. Broker API → Client (202 Accepted)
```

### Catalog Request Flow
```
1. Client → Broker API (GET /v2/catalog)
2. Broker API → Catalog Discovery (get_catalog())
3. Catalog Discovery → Git Manager (pull_latest())
4. Git Manager → GitHub (git pull)
5. Catalog Discovery → Parse service definitions
6. Catalog Discovery → Broker API (return catalog)
7. Broker API → Client (200 OK with catalog)
```

## Configuration

### Environment Variables
- `GIT_REPO_URL` - Git repository URL
- `GIT_SSH_KEY_PATH` - Path to SSH private key
- `ARGOCD_SERVER` - ArgoCD server URL
- `ARGOCD_TOKEN` - ArgoCD authentication token
- `CATALOG_PATH` - Path to catalog definitions in Git

### Configuration Files
- `config.py` - Application configuration
- `logger.py` - Logging configuration

## Deployment

### Container Requirements
- Python 3.10+
- Git client
- SSH client
- Network access to GitHub and ArgoCD

### Resource Requirements
- CPU: 0.5-1 core
- Memory: 512MB-1GB
- Storage: 1GB (for Git repositories)

### Scaling Considerations
- Stateless design allows horizontal scaling
- Git operations may require locking for concurrent access
- Consider using Git LFS for large manifests

## Security

### Authentication
- API key authentication for broker endpoints
- SSH key authentication for Git
- Token authentication for ArgoCD

### Secrets Management
- SSH keys stored in Kubernetes secrets
- ArgoCD tokens stored in Kubernetes secrets
- No secrets in code or logs

### Network Security
- TLS for all external communications
- Network policies to restrict access
- Firewall rules for Git and ArgoCD access

---

*Last Updated: 2026-04-14*