# Architecture Documentation - GitOps CSB Broker

This directory contains architecture documentation for the GitOps CSB Broker, following the C4 model for visualizing software architecture.

## Documentation Structure

### [System Overview](system-overview.md)
**C4 Level 1: System Context**

Shows the GitOps CSB Broker in the context of its users and external systems. This is the highest level view, showing:
- Who uses the system (clients, users)
- What external systems it interacts with (GitHub, ArgoCD, Kubernetes)
- The key relationships and data flows

**Read this first** to understand the broker's role in the overall ecosystem.

### [Container Diagram](container-diagram.md)
**C4 Level 2: Container**

Shows the major containers (applications/services) that make up the broker system. This includes:
- Broker API (Flask application)
- Catalog Discovery (service catalog management)
- Provisioning Orchestrator (GitOps workflow)
- Git State Manager (Git operations)
- GitOps Storage (manifest generation)

**Read this second** to understand the major components and their responsibilities.

### [Component Design](component-design.md)
**C4 Level 3: Component**

Zooms into the Provisioning Orchestrator to show its internal components:
- Provision Handler
- Deprovision Handler
- ArgoCD Client
- Git Operations
- SSH Key Manager
- Config Manager

**Read this third** to understand the detailed design of the provisioning workflow.

## Architecture Principles

### GitOps-First
All service definitions and manifests are stored in Git, making Git the single source of truth for infrastructure state.

### Stateless Design
The broker maintains no local state. All state is stored in Git, allowing for horizontal scaling and high availability.

### Separation of Concerns
Clear boundaries between API handling, catalog management, provisioning orchestration, and Git operations.

### Dependency Injection
Components receive dependencies through constructor injection, enabling testability and flexibility.

### Asynchronous Operations
Provisioning operations are asynchronous, allowing the broker to handle multiple requests concurrently.

## Key Design Decisions

### Why GitOps?
- **Audit Trail**: Every change is tracked in Git history
- **Declarative**: Desired state is declared, not imperative commands
- **Rollback**: Easy to revert to previous states
- **Multi-Cluster**: Single source of truth for multiple clusters
- **Collaboration**: Teams can review and approve changes via pull requests

### Why ArgoCD?
- **Continuous Sync**: Automatically syncs Git state to Kubernetes
- **Health Monitoring**: Tracks application health and sync status
- **Multi-Cluster**: Native support for multiple Kubernetes clusters
- **Declarative**: Aligns with GitOps principles
- **Mature**: Production-ready with active community

### Why Flask?
- **Lightweight**: Minimal overhead for API endpoints
- **Flexible**: Easy to extend and customize
- **Python Ecosystem**: Leverage rich Python libraries
- **CSB Compatibility**: Simple to implement Open Service Broker API

## Architecture Patterns

### Repository Pattern
Git repositories serve as the data store for service definitions and manifests.

### Factory Pattern
Service-specific manifest generation uses factory pattern for different service types.

### Strategy Pattern
Different provisioning strategies for different service types (databases, middleware, etc.).

### Observer Pattern
ArgoCD monitors Git repository and reacts to changes.

## Data Flow Patterns

### Provisioning Flow
```
Request → Validate → Generate → Commit → Create App → Monitor
```

### Catalog Discovery Flow
```
Git → Parse → Cache → Serve
```

### Deprovisioning Flow
```
Request → Delete App → Remove Manifests → Cleanup
```

## Security Architecture

### Authentication Layers
1. **API Layer**: API key authentication for broker endpoints
2. **Git Layer**: SSH key authentication for Git operations
3. **ArgoCD Layer**: Token authentication for ArgoCD API

### Secrets Management
- SSH keys stored in Kubernetes secrets
- ArgoCD tokens stored in Kubernetes secrets
- No secrets in code, logs, or Git

### Network Security
- TLS for all external communications
- Network policies to restrict access
- Firewall rules for Git and ArgoCD

## Scalability Considerations

### Horizontal Scaling
- Stateless design allows multiple broker instances
- Load balancer distributes requests
- Shared Git repository for state

### Performance Optimization
- Catalog caching to reduce Git operations
- Asynchronous provisioning to avoid blocking
- Connection pooling for ArgoCD API

### Resource Management
- CPU: 0.5-1 core per instance
- Memory: 512MB-1GB per instance
- Storage: 1GB for Git repositories

## High Availability

### Redundancy
- Multiple broker instances for failover
- GitHub Enterprise provides Git HA
- ArgoCD can be deployed in HA mode

### Failure Handling
- Retry logic for transient failures
- Graceful degradation (catalog available even if provisioning fails)
- Health checks for liveness and readiness

## Monitoring and Observability

### Metrics
- Request rate and latency
- Provisioning success/failure rate
- Git operation duration
- ArgoCD API response time

### Logging
- Structured JSON logging
- Correlation IDs for request tracing
- Log levels: DEBUG, INFO, WARNING, ERROR, CRITICAL
- No sensitive data in logs

### Health Checks
- Liveness: Broker process is running
- Readiness: Can connect to Git and ArgoCD
- Startup: Initial catalog discovery complete

## Future Enhancements

### Planned Improvements
- [ ] Support for Helm charts in addition to raw manifests
- [ ] Multi-tenancy with namespace isolation
- [ ] Service binding with credential injection
- [ ] Backup and restore for service instances
- [ ] Cost tracking and metering integration

### Under Consideration
- [ ] Support for other GitOps engines (Flux)
- [ ] Support for other Git providers (GitLab, Bitbucket)
- [ ] GraphQL API in addition to REST
- [ ] Service mesh integration

## Related Documentation

- [System Overview](system-overview.md) - C4 Context diagram
- [Container Diagram](container-diagram.md) - C4 Container diagram
- [Component Design](component-design.md) - C4 Component diagram
- [Security Documentation](../security/threat-model.md) - Threat model and security policy
- [API Reference](../api-reference.md) - API documentation
- [Configuration Guide](../configuration-guide.md) - Configuration reference

---

*Last Updated: 2026-04-14*