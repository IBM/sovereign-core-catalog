# System Overview - GitOps CSB Broker

## C4 Context Diagram

This diagram shows the GitOps CSB Broker in the context of its external dependencies and users.

```mermaid
C4Context
    title System Context - GitOps CSB Broker
    Person(client, "Client", "API consumer (e.g., Catalog UI, CLI)")
    System(broker, "GitOps CSB Broker", "Service broker with GitOps provisioning")
    System_Ext(git, "GitHub Enterprise", "Git repository for manifests")
    System_Ext(argocd, "ArgoCD", "GitOps deployment engine")
    System_Ext(k8s, "Kubernetes Clusters", "Target deployment clusters")
    
    Rel(client, broker, "Provisions services", "HTTPS/CSB API")
    Rel(broker, git, "Commits manifests", "Git/SSH")
    Rel(broker, argocd, "Creates applications", "HTTPS")
    Rel(argocd, git, "Syncs from", "Git")
    Rel(argocd, k8s, "Deploys to", "Kubernetes API")
```

## System Purpose

The GitOps CSB Broker is a Cloud Service Broker (CSB) implementation that uses GitOps principles for service provisioning. Instead of directly deploying services to Kubernetes clusters, it:

1. **Accepts provisioning requests** via the Open Service Broker API
2. **Generates Kubernetes manifests** for the requested service
3. **Commits manifests to Git** repository
4. **Creates ArgoCD applications** that sync from Git
5. **Monitors deployment status** through ArgoCD

## Key Characteristics

### GitOps-First Design
- All service definitions stored in Git
- Git as the single source of truth
- Declarative infrastructure management
- Audit trail through Git history

### Multi-Cluster Support
- Provisions services across multiple Kubernetes clusters
- Cluster selection based on service requirements
- Centralized management of distributed deployments

### Service Catalog Discovery
- Automatic discovery of available services from Git repository
- Dynamic catalog updates without broker restart
- Support for multiple service types (databases, middleware, etc.)

## External Dependencies

### GitHub Enterprise
- **Purpose**: Store service manifests and ArgoCD application definitions
- **Protocol**: Git over SSH
- **Authentication**: SSH keys
- **Usage**: Commit manifests, read catalog definitions

### ArgoCD
- **Purpose**: Continuous deployment of services to Kubernetes
- **Protocol**: HTTPS REST API
- **Authentication**: API tokens
- **Usage**: Create/update/delete applications, monitor sync status

### Kubernetes Clusters
- **Purpose**: Target infrastructure for service deployment
- **Protocol**: Kubernetes API (via ArgoCD)
- **Authentication**: Managed by ArgoCD
- **Usage**: Service deployment and management

## Trust Boundaries

1. **External API Boundary**: Client → Broker (HTTPS)
2. **Git Boundary**: Broker → GitHub (SSH)
3. **ArgoCD Boundary**: Broker → ArgoCD (HTTPS)
4. **Kubernetes Boundary**: ArgoCD → Clusters (Kubernetes API)

## Data Flow

### Provisioning Flow
```
Client Request → Broker API → Generate Manifests → Commit to Git → 
Create ArgoCD App → ArgoCD Syncs → Deploy to Kubernetes
```

### Catalog Discovery Flow
```
Git Repository → Broker Reads Catalog → Parse Service Definitions → 
Expose via CSB API
```

## Security Considerations

- **Authentication**: API key-based authentication for broker API
- **Authorization**: Role-based access control for service provisioning
- **Secrets Management**: Sensitive data stored in Kubernetes secrets
- **Audit Logging**: All operations logged with structured logging
- **Network Security**: TLS for all external communications

## Scalability

- **Stateless Design**: Broker can be horizontally scaled
- **Git as State Store**: No local state persistence required
- **Asynchronous Operations**: Non-blocking provisioning workflow
- **Multi-Cluster**: Distributes load across multiple clusters

## High Availability

- **Multiple Broker Instances**: Run multiple replicas for redundancy
- **Git Redundancy**: GitHub Enterprise provides HA
- **ArgoCD HA**: ArgoCD can be deployed in HA mode
- **Graceful Degradation**: Continues to serve catalog even if provisioning is unavailable

---

*Last Updated: 2026-04-14*