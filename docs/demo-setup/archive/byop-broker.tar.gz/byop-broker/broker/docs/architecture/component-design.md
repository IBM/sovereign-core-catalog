# Component Design - GitOps CSB Broker

## C4 Component Diagram

This diagram shows the internal components of the Provisioning Orchestrator, which is the most complex container in the system.

```mermaid
C4Component
    title Component Diagram - Provisioning Orchestrator
    
    Container_Boundary(orchestrator, "Provisioning Orchestrator") {
        Component(provision, "Provision Handler", "Python", "Handles service provisioning")
        Component(deprovision, "Deprovision Handler", "Python", "Handles service deprovisioning")
        Component(argocd_client, "ArgoCD Client", "Python", "ArgoCD API interactions")
        Component(git_ops, "Git Operations", "Python", "Git commands wrapper")
        Component(ssh_manager, "SSH Key Manager", "Python", "SSH key lifecycle")
        Component(config_mgr, "Config Manager", "Python", "Configuration management")
    }
    
    Container_Ext(storage, "GitOps Storage", "Manifest generation")
    Container_Ext(git_mgr, "Git State Manager", "Git state management")
    System_Ext(argocd, "ArgoCD", "GitOps engine")
    System_Ext(git, "GitHub", "Git repository")
    
    Rel(provision, config_mgr, "Gets config", "Function calls")
    Rel(provision, git_ops, "Commits manifests", "Function calls")
    Rel(provision, argocd_client, "Creates app", "Function calls")
    Rel(deprovision, argocd_client, "Deletes app", "Function calls")
    Rel(deprovision, git_ops, "Removes manifests", "Function calls")
    Rel(git_ops, ssh_manager, "Gets SSH keys", "Function calls")
    Rel(git_ops, git, "Git operations", "Git/SSH")
    Rel(argocd_client, argocd, "API calls", "HTTPS/REST")
```

## Component Descriptions

### Provision Handler (`orchestrator/provision.py`)
**Purpose**: Orchestrate the service provisioning workflow

**Key Responsibilities**:
- Validate provisioning request
- Generate unique service identifiers
- Coordinate manifest generation
- Commit manifests to Git
- Create ArgoCD application
- Monitor initial deployment status
- Handle provisioning errors

**Key Functions**:
```python
def provision_service(
    service_id: str,
    plan_id: str,
    parameters: dict[str, Any]
) -> dict[str, Any]:
    """Provision a new service instance."""
    
def validate_parameters(
    service_id: str,
    parameters: dict[str, Any]
) -> bool:
    """Validate provisioning parameters."""
    
def create_argocd_application(
    instance_id: str,
    manifest_path: str,
    cluster: str
) -> dict[str, Any]:
    """Create ArgoCD application for service."""
```

**Error Handling**:
- Rollback on Git commit failure
- Cleanup ArgoCD app on deployment failure
- Retry logic for transient failures
- Detailed error logging

### Deprovision Handler (`orchestrator/deprovision.py`)
**Purpose**: Orchestrate the service deprovisioning workflow

**Key Responsibilities**:
- Validate deprovision request
- Delete ArgoCD application
- Remove manifests from Git
- Clean up service resources
- Handle deprovisioning errors

**Key Functions**:
```python
def deprovision_service(
    instance_id: str,
    service_id: str
) -> dict[str, Any]:
    """Deprovision an existing service instance."""
    
def delete_argocd_application(
    instance_id: str
) -> bool:
    """Delete ArgoCD application."""
    
def cleanup_manifests(
    instance_id: str
) -> bool:
    """Remove manifests from Git repository."""
```

**Cleanup Strategy**:
- Delete ArgoCD app first (stops sync)
- Remove manifests from Git
- Verify resource cleanup
- Log all cleanup operations

### ArgoCD Client (`orchestrator/api.py`)
**Purpose**: Interact with ArgoCD REST API

**Key Responsibilities**:
- Authenticate with ArgoCD
- Create/update/delete applications
- Query application status
- Handle API errors and retries
- Manage API rate limiting

**Key Functions**:
```python
def create_application(
    name: str,
    repo_url: str,
    path: str,
    cluster: str,
    namespace: str
) -> dict[str, Any]:
    """Create ArgoCD application."""
    
def delete_application(
    name: str,
    cascade: bool = True
) -> bool:
    """Delete ArgoCD application."""
    
def get_application_status(
    name: str
) -> dict[str, Any]:
    """Get application sync and health status."""
    
def sync_application(
    name: str
) -> dict[str, Any]:
    """Trigger application sync."""
```

**API Features**:
- Automatic token refresh
- Retry with exponential backoff
- Request/response logging
- Error classification

### Git Operations (`orchestrator/git_operations.py`)
**Purpose**: Perform Git operations for manifest management

**Key Responsibilities**:
- Clone/pull repositories
- Commit and push changes
- Manage branches
- Handle merge conflicts
- SSH authentication

**Key Functions**:
```python
def clone_repository(
    repo_url: str,
    local_path: str,
    ssh_key_path: str
) -> bool:
    """Clone Git repository."""
    
def commit_changes(
    repo_path: str,
    files: list[str],
    message: str
) -> str:
    """Commit changes to repository."""
    
def push_changes(
    repo_path: str,
    branch: str = "main"
) -> bool:
    """Push commits to remote."""
    
def pull_latest(
    repo_path: str,
    branch: str = "main"
) -> bool:
    """Pull latest changes from remote."""
```

**Git Configuration**:
- User name and email from config
- SSH key-based authentication
- Commit signing (optional)
- Branch protection handling

### SSH Key Manager (`orchestrator/ssh_key_manager.py`)
**Purpose**: Manage SSH keys for Git authentication

**Key Responsibilities**:
- Load SSH keys from secrets
- Configure SSH for Git operations
- Handle key permissions
- Validate key format
- Secure key storage

**Key Functions**:
```python
def load_ssh_key(
    key_path: str
) -> str:
    """Load SSH private key from file."""
    
def configure_ssh_for_git(
    key_path: str,
    known_hosts_path: str
) -> bool:
    """Configure SSH for Git operations."""
    
def validate_ssh_key(
    key_path: str
) -> bool:
    """Validate SSH key format and permissions."""
```

**Security Considerations**:
- Keys stored in Kubernetes secrets
- File permissions set to 600
- Keys never logged
- Temporary key files cleaned up

### Config Manager (`orchestrator/config.py`)
**Purpose**: Manage orchestrator configuration

**Key Responsibilities**:
- Load configuration from environment
- Validate configuration values
- Provide configuration to components
- Handle configuration updates
- Default value management

**Key Functions**:
```python
def load_config() -> dict[str, Any]:
    """Load configuration from environment."""
    
def validate_config(
    config: dict[str, Any]
) -> bool:
    """Validate configuration values."""
    
def get_git_config() -> dict[str, str]:
    """Get Git-specific configuration."""
    
def get_argocd_config() -> dict[str, str]:
    """Get ArgoCD-specific configuration."""
```

**Configuration Sources**:
1. Environment variables (highest priority)
2. Configuration files
3. Default values (lowest priority)

## Component Interactions

### Provisioning Flow
```
1. Provision Handler receives request
2. Provision Handler → Config Manager (get configuration)
3. Provision Handler → Storage (generate manifests)
4. Provision Handler → Git Operations (commit manifests)
5. Git Operations → SSH Manager (get SSH key)
6. Git Operations → GitHub (push commits)
7. Provision Handler → ArgoCD Client (create application)
8. ArgoCD Client → ArgoCD (POST /api/v1/applications)
9. Provision Handler returns success
```

### Deprovisioning Flow
```
1. Deprovision Handler receives request
2. Deprovision Handler → ArgoCD Client (delete application)
3. ArgoCD Client → ArgoCD (DELETE /api/v1/applications/:name)
4. Deprovision Handler → Git Operations (remove manifests)
5. Git Operations → SSH Manager (get SSH key)
6. Git Operations → GitHub (push deletion)
7. Deprovision Handler returns success
```

## Design Patterns

### Dependency Injection
All components receive dependencies through constructor injection:
```python
class ProvisionHandler:
    def __init__(
        self,
        config_manager: ConfigManager,
        git_operations: GitOperations,
        argocd_client: ArgoCDClient,
        storage: GitOpsStorage
    ):
        self.config = config_manager
        self.git = git_operations
        self.argocd = argocd_client
        self.storage = storage
```

### Error Handling Strategy
- Use specific exception types
- Provide context in error messages
- Log errors with structured logging
- Return error details to caller
- Implement retry logic for transient failures

### Logging Strategy
- Structured JSON logging
- Log levels: DEBUG, INFO, WARNING, ERROR, CRITICAL
- Include correlation IDs for request tracing
- No sensitive data in logs
- Performance metrics logging

## Testing Strategy

### Unit Tests
- Mock external dependencies (Git, ArgoCD)
- Test each component in isolation
- Test error handling paths
- Test configuration validation

### Integration Tests
- Test component interactions
- Use test Git repository
- Mock ArgoCD API responses
- Test end-to-end workflows

### Test Coverage Goals
- Overall: > 80%
- Critical paths: > 90%
- Error handling: > 85%

---

*Last Updated: 2026-04-14*