# GitOps CSB Broker Documentation

Welcome to the GitOps CSB Broker documentation. This directory contains comprehensive documentation for understanding, deploying, and maintaining the broker.

## Documentation Structure

### Architecture Documentation
Detailed architecture documentation following the C4 model:

- **[Architecture Overview](architecture/README.md)** - Introduction to architecture documentation
- **[System Overview](architecture/system-overview.md)** - C4 Context diagram showing the broker in its ecosystem
- **[Container Diagram](architecture/container-diagram.md)** - Major components and their responsibilities
- **[Component Design](architecture/component-design.md)** - Detailed design of the provisioning orchestrator

### Security Documentation
Comprehensive security documentation and policies:

- **[Threat Model](security/threat-model.md)** - STRIDE threat analysis and attack scenarios
- **[Security Policy](security/SECURITY.md)** - Security best practices and vulnerability reporting

## Quick Links

### Getting Started
- [Installation Guide](#installation) - How to deploy the broker
- [Configuration Guide](#configuration) - Configuration options and examples
- [Quick Start](#quick-start) - Get up and running quickly

### Development
- [Development Setup](#development-setup) - Set up development environment
- [Testing Guide](#testing) - How to run tests
- [Contributing](#contributing) - How to contribute to the project

### Operations
- [Deployment Guide](#deployment) - Production deployment guidelines
- [Monitoring](#monitoring) - Monitoring and observability
- [Troubleshooting](#troubleshooting) - Common issues and solutions

## What is the GitOps CSB Broker?

The GitOps CSB Broker is a Cloud Service Broker (CSB) implementation that uses GitOps principles for service provisioning. It provides:

- **Open Service Broker API**: Standard CSB API for service provisioning
- **GitOps Workflow**: All service definitions stored in Git
- **ArgoCD Integration**: Continuous deployment via ArgoCD
- **Multi-Cluster Support**: Provision services across multiple Kubernetes clusters
- **Service Catalog Discovery**: Automatic discovery of available services from Git

### Key Features

- ✅ **GitOps-First**: Git as single source of truth
- ✅ **Declarative**: Desired state declared in Git
- ✅ **Auditable**: Complete audit trail via Git history
- ✅ **Scalable**: Stateless design for horizontal scaling
- ✅ **Secure**: SSH key authentication, TLS, RBAC
- ✅ **Extensible**: Easy to add new service types

## Installation

### Prerequisites

- Kubernetes cluster (1.20+)
- GitHub Enterprise or GitHub.com account
- ArgoCD installed and configured
- SSH key for Git access
- ArgoCD API token

### Quick Install

```bash
# Clone the repository
git clone https://github.com/example/broker.git
cd broker

# Create namespace
kubectl create namespace broker

# Create secrets
kubectl create secret generic broker-git-ssh-key \
  --from-file=ssh-privatekey=/path/to/ssh-key \
  -n broker

kubectl create secret generic broker-argocd-token \
  --from-literal=token=your-argocd-token \
  -n broker

# Deploy broker
kubectl apply -f kubernetes/deployment.yaml -n broker
```

### Helm Install

```bash
# Add Helm repository
helm repo add broker https://charts.example.com/broker
helm repo update

# Install broker
helm install broker broker/broker \
  --namespace broker \
  --create-namespace \
  --set git.repoUrl=git@github.com:org/repo.git \
  --set git.sshKeySecret=broker-git-ssh-key \
  --set argocd.server=https://argocd.example.com \
  --set argocd.tokenSecret=broker-argocd-token
```

## Configuration

### Environment Variables

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| `GIT_REPO_URL` | Git repository URL | Yes | - |
| `GIT_SSH_KEY_PATH` | Path to SSH private key | Yes | `/secrets/ssh-key` |
| `ARGOCD_SERVER` | ArgoCD server URL | Yes | - |
| `ARGOCD_TOKEN_PATH` | Path to ArgoCD token | Yes | `/secrets/argocd-token` |
| `BROKER_API_KEY` | API key for broker authentication | Yes | - |
| `CATALOG_PATH` | Path to catalog in Git repo | No | `catalog/` |
| `LOG_LEVEL` | Logging level | No | `INFO` |
| `PORT` | Server port | No | `5000` |

### Configuration File

Create a `config.yaml` file:

```yaml
git:
  repo_url: git@github.com:org/repo.git
  ssh_key_path: /secrets/ssh-key
  branch: main
  
argocd:
  server: https://argocd.example.com
  token_path: /secrets/argocd-token
  
broker:
  api_key: your-secure-api-key
  port: 5000
  
catalog:
  path: catalog/
  refresh_interval: 300  # seconds
  
logging:
  level: INFO
  format: json
```

## Quick Start

### 1. Verify Installation

```bash
# Check broker pod is running
kubectl get pods -n broker

# Check broker logs
kubectl logs -n broker deployment/broker

# Test broker health
curl http://broker.example.com/health
```

### 2. Get Service Catalog

```bash
# Get catalog
curl -H "X-Broker-API-Version: 2.16" \
     -H "Authorization: Bearer your-api-key" \
     http://broker.example.com/v2/catalog
```

### 3. Provision a Service

```bash
# Provision MySQL service
curl -X PUT \
     -H "X-Broker-API-Version: 2.16" \
     -H "Authorization: Bearer your-api-key" \
     -H "Content-Type: application/json" \
     -d '{
       "service_id": "mysql-service-id",
       "plan_id": "standard-plan-id",
       "parameters": {
         "database_name": "mydb",
         "storage_size": "10Gi"
       }
     }' \
     http://broker.example.com/v2/service_instances/my-mysql-instance
```

### 4. Check Provisioning Status

```bash
# Check ArgoCD application
kubectl get application my-mysql-instance -n argocd

# Check service deployment
kubectl get pods -n my-mysql-instance
```

## Development Setup

### Prerequisites

- Python 3.10+
- Git
- Docker (for containerized testing)

### Local Development

```bash
# Clone repository
git clone https://github.com/example/broker.git
cd broker

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt

# Install pre-commit hooks (configured at project root)
cd ..
pre-commit install

# Run tests
cd broker
make test

# Run linting
make lint

# Run security checks
make security

# Run broker locally
export GIT_REPO_URL=git@github.com:org/repo.git
export GIT_SSH_KEY_PATH=/path/to/ssh-key
export ARGOCD_SERVER=https://argocd.example.com
export ARGOCD_TOKEN=your-token
export BROKER_API_KEY=dev-api-key

python app.py
```

## Testing

### Run All Tests

```bash
make test
```

### Run Specific Test Types

```bash
# Unit tests only
make test-unit

# Integration tests only
make test-integration

# With coverage
make coverage
```

### Test Coverage

```bash
# Generate coverage report
make coverage

# View HTML coverage report
make coverage-report
```

## Deployment

### Production Deployment

See [Deployment Guide](deployment-guide.md) for detailed production deployment instructions.

Key considerations:
- Use Kubernetes secrets for credentials
- Enable TLS for all communications
- Configure network policies
- Set resource limits
- Enable monitoring and logging
- Configure backup and disaster recovery

### High Availability

For HA deployment:
- Run multiple broker replicas (3+)
- Use load balancer for traffic distribution
- Configure pod disruption budgets
- Use anti-affinity rules
- Monitor health checks

## Monitoring

### Metrics

The broker exposes Prometheus metrics at `/metrics`:

- `broker_requests_total` - Total API requests
- `broker_request_duration_seconds` - Request duration
- `broker_provision_total` - Total provisioning operations
- `broker_provision_failures_total` - Failed provisioning operations
- `broker_git_operations_total` - Git operations count
- `broker_argocd_api_calls_total` - ArgoCD API calls

### Logging

Structured JSON logging includes:
- Request ID for correlation
- Timestamp
- Log level
- Component name
- Message
- Context data

### Health Checks

- **Liveness**: `GET /health/live` - Broker process is running
- **Readiness**: `GET /health/ready` - Can connect to Git and ArgoCD
- **Startup**: `GET /health/startup` - Initial catalog discovery complete

## Troubleshooting

### Common Issues

#### Broker Pod Not Starting

```bash
# Check pod status
kubectl describe pod -n broker -l app=broker

# Check logs
kubectl logs -n broker -l app=broker

# Common causes:
# - Missing secrets
# - Invalid SSH key
# - Network connectivity issues
```

#### Git Operations Failing

```bash
# Verify SSH key
kubectl exec -n broker deployment/broker -- ssh -T git@github.com

# Check Git repository access
kubectl exec -n broker deployment/broker -- git ls-remote $GIT_REPO_URL

# Common causes:
# - Invalid SSH key
# - SSH key not added to GitHub
# - Repository doesn't exist
# - Network connectivity issues
```

#### ArgoCD Integration Issues

```bash
# Test ArgoCD connectivity
kubectl exec -n broker deployment/broker -- \
  curl -k https://argocd.example.com/api/version

# Verify ArgoCD token
kubectl get secret broker-argocd-token -n broker -o yaml

# Common causes:
# - Invalid token
# - Token expired
# - ArgoCD server unreachable
# - Network policies blocking access
```

## Contributing

We welcome contributions! Please see our [Contributing Guide](../CONTRIBUTING.md) for details.

### Development Workflow

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests and linting
5. Commit with clear messages
6. Push to your fork
7. Create a pull request

### Code Standards

- Follow PEP 8 style guide
- Use type hints (Python 3.10+ style)
- Write tests for new features
- Update documentation
- Run `make lint` before committing
- Ensure `make ci` passes

## Support

### Getting Help

- **Documentation**: Start here!
- **GitHub Issues**: Report bugs and request features
- **Discussions**: Ask questions and share ideas
- **Email**: support@example.com

### Reporting Issues

When reporting issues, please include:
- Broker version
- Kubernetes version
- Error messages and logs
- Steps to reproduce
- Expected vs actual behavior

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](../LICENSE) file for details.

## Related Projects

- [Catalog UI](../../catalog-app/docs/README.md) - Web interface for the broker
- [ArgoCD](https://argoproj.github.io/cd/) - GitOps continuous delivery
- [Open Service Broker API](https://www.openservicebrokerapi.org/) - Service broker specification

---

*Last Updated: 2026-04-14*