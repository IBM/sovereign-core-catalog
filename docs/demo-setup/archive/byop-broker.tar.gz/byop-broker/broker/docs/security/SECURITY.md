# Security Policy - GitOps CSB Broker

## Supported Versions

We release patches for security vulnerabilities in the following versions:

| Version | Supported          |
| ------- | ------------------ |
| 1.x.x   | :white_check_mark: |
| < 1.0   | :x:                |

## Reporting a Vulnerability

We take the security of the GitOps CSB Broker seriously. If you believe you have found a security vulnerability, please report it to us as described below.

### Where to Report

**Please do NOT report security vulnerabilities through public GitHub issues.**

Instead, please report them via email to:
- **Security Team**: security@example.com
- **Project Maintainer**: maintainer@example.com

### What to Include

Please include the following information in your report:

1. **Description**: A clear description of the vulnerability
2. **Impact**: The potential impact of the vulnerability
3. **Steps to Reproduce**: Detailed steps to reproduce the issue
4. **Proof of Concept**: Code or commands demonstrating the vulnerability (if applicable)
5. **Affected Versions**: Which versions are affected
6. **Suggested Fix**: Any suggestions for fixing the vulnerability (optional)
7. **Your Contact Information**: How we can reach you for follow-up

### Response Timeline

- **Initial Response**: Within 48 hours of receiving your report
- **Status Updates**: Weekly updates on the progress of addressing the vulnerability
- **Resolution**: We aim to resolve critical vulnerabilities within 30 days
- **Disclosure**: Coordinated disclosure after a fix is available

### What to Expect

1. **Acknowledgment**: We will acknowledge receipt of your vulnerability report
2. **Investigation**: We will investigate and validate the vulnerability
3. **Fix Development**: We will develop and test a fix
4. **Disclosure**: We will coordinate disclosure with you
5. **Credit**: We will credit you in the security advisory (unless you prefer to remain anonymous)

## Security Best Practices for Users

### Deployment Security

#### 1. Secure Credential Storage
- **Never hardcode credentials** in configuration files or code
- Store SSH keys in Kubernetes secrets with encryption at rest
- Store ArgoCD tokens in Kubernetes secrets
- Use secret management solutions (Vault, Sealed Secrets)
- Rotate credentials regularly

```yaml
# Example: Kubernetes secret for SSH key
apiVersion: v1
kind: Secret
metadata:
  name: broker-git-ssh-key
type: Opaque
data:
  ssh-privatekey: <base64-encoded-key>
```

#### 2. Network Security
- Deploy broker in a private network segment
- Use network policies to restrict traffic
- Enable TLS for all external communications
- Use mutual TLS where supported
- Implement firewall rules for Git and ArgoCD access

```yaml
# Example: Network policy
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: broker-network-policy
spec:
  podSelector:
    matchLabels:
      app: broker
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: catalog-ui
    ports:
    - protocol: TCP
      port: 5000
  egress:
  - to:
    - namespaceSelector: {}
    ports:
    - protocol: TCP
      port: 443  # HTTPS
    - protocol: TCP
      port: 22   # SSH
```

#### 3. Container Security
- Run as non-root user
- Use read-only root filesystem
- Drop all capabilities
- Apply pod security policies/standards
- Scan container images regularly

```yaml
# Example: Security context
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop:
    - ALL
```

#### 4. RBAC Configuration
- Use minimal RBAC permissions
- Create dedicated service account
- Never use cluster-admin role
- Audit RBAC regularly

```yaml
# Example: Minimal RBAC
apiVersion: v1
kind: ServiceAccount
metadata:
  name: broker-sa
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: broker-role
rules:
- apiGroups: [""]
  resources: ["secrets"]
  verbs: ["get", "list"]
  resourceNames: ["broker-git-ssh-key", "broker-argocd-token"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: broker-rolebinding
subjects:
- kind: ServiceAccount
  name: broker-sa
roleRef:
  kind: Role
  name: broker-role
  apiGroup: rbac.authorization.k8s.io
```

### Configuration Security

#### 1. Environment Variables
Use environment variables for configuration, never hardcode:

```bash
# Required environment variables
export GIT_REPO_URL="git@github.com:org/repo.git"
export GIT_SSH_KEY_PATH="/secrets/ssh-key"
export ARGOCD_SERVER="https://argocd.example.com"
export ARGOCD_TOKEN_PATH="/secrets/argocd-token"
export BROKER_API_KEY="<secure-random-key>"
```

#### 2. API Key Management
- Generate strong API keys (minimum 32 characters, cryptographically random)
- Rotate API keys regularly (every 90 days)
- Use different keys for different environments
- Monitor API key usage
- Revoke compromised keys immediately

```python
# Generate secure API key
import secrets
api_key = secrets.token_urlsafe(32)
```

#### 3. SSH Key Management
- Use dedicated SSH keys for broker (not personal keys)
- Use SSH keys with passphrase protection
- Rotate SSH keys regularly (every 180 days)
- Use separate keys per environment
- Monitor Git access logs

```bash
# Generate SSH key with passphrase
ssh-keygen -t ed25519 -C "broker@example.com" -f broker-key
```

### Monitoring and Logging

#### 1. Enable Comprehensive Logging
- Log all API requests
- Log all Git operations
- Log all ArgoCD API calls
- Log authentication attempts
- Log errors and exceptions

#### 2. Security Event Monitoring
Monitor for:
- Failed authentication attempts
- Unusual API usage patterns
- Git push failures
- ArgoCD sync failures
- Resource exhaustion
- Unexpected errors

#### 3. Log Security
- Forward logs to centralized logging system
- Ensure logs are immutable
- Retain logs for compliance requirements
- Never log sensitive data (keys, tokens, passwords)
- Implement log integrity verification

### Incident Response

#### 1. Preparation
- Document incident response procedures
- Identify incident response team
- Maintain contact information
- Test incident response plan

#### 2. Detection and Analysis
- Monitor security alerts
- Investigate suspicious activity
- Determine scope and impact
- Preserve evidence

#### 3. Containment and Recovery
- Isolate affected systems
- Rotate compromised credentials
- Apply security patches
- Restore from known good state
- Verify system integrity

#### 4. Post-Incident
- Document lessons learned
- Update security controls
- Update threat model
- Communicate with stakeholders

## Security Features

### Authentication and Authorization
- API key authentication for broker API
- SSH key authentication for Git
- Token authentication for ArgoCD
- RBAC for Kubernetes resources

### Data Protection
- TLS for all external communications
- SSH for Git operations
- Secrets stored in Kubernetes secrets
- Secret encryption at rest
- No secrets in logs or code

### Input Validation
- Schema validation for all API requests
- Parameter sanitization
- Path traversal prevention
- Command injection prevention
- SQL injection prevention (if applicable)

### Audit Logging
- Structured JSON logging
- Request correlation IDs
- Timestamp for all events
- User/API key identification
- Operation details

### Security Scanning
- Static analysis with Bandit
- Dependency scanning with pip-audit
- Secret scanning with detect-secrets
- Container image scanning
- Regular security audits

## Compliance

### Standards and Frameworks
- OWASP Top 10 compliance
- CIS Kubernetes Benchmark
- NIST Cybersecurity Framework
- SOC 2 Type II (if applicable)

### Data Privacy
- GDPR compliance (if applicable)
- Data minimization
- Right to erasure
- Data portability

## Security Updates

### Update Policy
- Security patches released as soon as possible
- Critical vulnerabilities patched within 7 days
- High severity vulnerabilities patched within 30 days
- Medium/Low severity vulnerabilities in next release

### Notification
- Security advisories published on GitHub
- Email notification to registered users
- CVE assignment for significant vulnerabilities

### Upgrade Recommendations
- Always use the latest stable version
- Subscribe to security advisories
- Test updates in non-production first
- Have rollback plan ready

## Security Checklist

### Pre-Deployment
- [ ] Review and update threat model
- [ ] Configure secrets management
- [ ] Set up network policies
- [ ] Configure RBAC with minimal permissions
- [ ] Enable audit logging
- [ ] Configure monitoring and alerting
- [ ] Test incident response procedures

### Post-Deployment
- [ ] Verify TLS configuration
- [ ] Verify secret encryption
- [ ] Test authentication and authorization
- [ ] Review audit logs
- [ ] Scan for vulnerabilities
- [ ] Verify network policies
- [ ] Test backup and restore

### Ongoing
- [ ] Monitor security alerts
- [ ] Review audit logs regularly
- [ ] Rotate credentials quarterly
- [ ] Update dependencies monthly
- [ ] Scan for vulnerabilities weekly
- [ ] Review RBAC permissions quarterly
- [ ] Test incident response annually

## Resources

### Documentation
- [Threat Model](threat-model.md) - Detailed threat analysis
- [Architecture Documentation](../architecture/README.md) - System architecture
- [Configuration Guide](../configuration-guide.md) - Configuration reference

### External Resources
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [CIS Kubernetes Benchmark](https://www.cisecurity.org/benchmark/kubernetes)
- [Kubernetes Security Best Practices](https://kubernetes.io/docs/concepts/security/)
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework)

## Contact

For security-related questions or concerns:
- **Security Team**: security@example.com
- **Project Maintainer**: maintainer@example.com
- **GitHub Issues**: For non-security bugs only

---

*Last Updated: 2026-04-14*  
*Next Review: 2026-07-14*