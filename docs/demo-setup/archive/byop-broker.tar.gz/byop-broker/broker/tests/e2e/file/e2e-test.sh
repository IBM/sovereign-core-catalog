#!/bin/bash
# E2E test for file storage backend
# Tests implemented endpoints only (catalog and provision)
#
# Prerequisites:
#   - Deploy file storage broker to byop-file namespace:
#     helm upgrade --install byop-file chart/ \
#       --namespace byop-file --create-namespace \
#       -f data/local/values.yaml \
#       -f data/local/values-file-storage.yaml
#
# Usage:
#   ./e2e-test.sh

set -e

echo "=== File Storage E2E Test ==="
echo "Testing implemented endpoints (catalog and provision)"
echo "Namespace: byop-file"
echo ""

# Start port-forward to byop-file namespace
echo "Starting port-forward..."
kubectl port-forward -n byop-file service/byop-file-broker 8085:8080 > /dev/null 2>&1 &
PF_PID=$!
sleep 3

cleanup() {
    echo "Cleaning up..."
    if [ -n "$PF_PID" ]; then
        kill $PF_PID 2>/dev/null || true
        wait $PF_PID 2>/dev/null || true
    fi
}
trap cleanup EXIT

# Test 1: Health check
echo "Test 1: Health check..."
HEALTH_RESPONSE=$(curl -s -w "\n%{http_code}" \
  "http://localhost:8085/health")

HTTP_CODE=$(echo "$HEALTH_RESPONSE" | tail -n1)
BODY=$(echo "$HEALTH_RESPONSE" | sed '$d')

if [ "$HTTP_CODE" = "200" ]; then
    echo "✓ Health check passed (HTTP $HTTP_CODE)"
    echo "  Response: $BODY"
else
    echo "✗ Health check failed (HTTP $HTTP_CODE)"
    exit 1
fi
echo ""

# Test 2: Get catalog
echo "Test 2: Getting service catalog..."
CATALOG_RESPONSE=$(curl -s -w "\n%{http_code}" \
  "http://localhost:8085/v2/catalog")

HTTP_CODE=$(echo "$CATALOG_RESPONSE" | tail -n1)
BODY=$(echo "$CATALOG_RESPONSE" | sed '$d')

if [ "$HTTP_CODE" = "200" ]; then
    echo "✓ Catalog retrieved (HTTP $HTTP_CODE)"
    SERVICE_COUNT=$(echo "$BODY" | grep -o '"id"' | wc -l)
    echo "  Found $SERVICE_COUNT service(s)"
else
    echo "✗ Catalog retrieval failed (HTTP $HTTP_CODE)"
    exit 1
fi
echo ""

# Generate unique instance ID
INSTANCE_ID="file-e2e-$(date +%s)"

# Test 3: Provision (synchronous, metadata-only)
echo "Test 3: Provisioning instance (metadata-only)..."
PROVISION_RESPONSE=$(curl -s -w "\n%{http_code}" -X PUT \
  "http://localhost:8085/v2/service_instances/${INSTANCE_ID}?accepts_incomplete=false" \
  -H "Content-Type: application/json" \
  -d '{
    "service_id": "mysql-service",
    "plan_id": "small",
    "parameters": {
      "db_name": "testdb"
    }
  }')

HTTP_CODE=$(echo "$PROVISION_RESPONSE" | tail -n1)
BODY=$(echo "$PROVISION_RESPONSE" | sed '$d')

if [ "$HTTP_CODE" = "201" ]; then
    echo "✓ Provision completed synchronously (HTTP $HTTP_CODE)"
    echo "  Response: $BODY"
    echo "  ✓ File storage returns 201 (synchronous completion)"
else
    echo "✗ Provision failed (HTTP $HTTP_CODE)"
    echo "  Response: $BODY"
    exit 1
fi
echo ""

# Test 4: Get instance details
echo "Test 4: Getting instance details..."
GET_RESPONSE=$(curl -s -w "\n%{http_code}" \
  "http://localhost:8085/v2/service_instances/${INSTANCE_ID}")

HTTP_CODE=$(echo "$GET_RESPONSE" | tail -n1)
BODY=$(echo "$GET_RESPONSE" | sed '$d')

if [ "$HTTP_CODE" = "200" ]; then
    echo "✓ Instance details retrieved (HTTP $HTTP_CODE)"
    echo "  Response: $BODY"
    # Verify instance data
    if echo "$BODY" | grep -q "mysql-service"; then
        echo "  ✓ Instance contains correct service_id"
    fi
    if echo "$BODY" | grep -q "succeeded"; then
        echo "  ✓ Instance state is 'succeeded'"
    fi
else
    echo "✗ Get instance failed (HTTP $HTTP_CODE)"
    echo "  Response: $BODY"
    exit 1
fi
echo ""

# Test 5: Duplicate provision (idempotency)
echo "Test 5: Testing idempotency (duplicate provision)..."
DUPLICATE_RESPONSE=$(curl -s -w "\n%{http_code}" -X PUT \
  "http://localhost:8085/v2/service_instances/${INSTANCE_ID}?accepts_incomplete=false" \
  -H "Content-Type: application/json" \
  -d '{
    "service_id": "mysql-service",
    "plan_id": "small",
    "parameters": {
      "db_name": "testdb"
    }
  }')

HTTP_CODE=$(echo "$DUPLICATE_RESPONSE" | tail -n1)

if [ "$HTTP_CODE" = "200" ]; then
    echo "✓ Duplicate provision handled correctly (HTTP $HTTP_CODE)"
    echo "  ✓ Returns 200 for existing instance with same config"
else
    echo "⚠ Unexpected response for duplicate provision (HTTP $HTTP_CODE)"
fi
echo ""

echo "=== File Storage E2E Test Complete ==="
echo ""
echo "Summary:"
echo "  ✓ Health check"
echo "  ✓ Service catalog retrieval"
echo "  ✓ Synchronous provision (metadata-only, HTTP 201)"
echo "  ✓ Get instance details (HTTP 200)"
echo "  ✓ Idempotent provision (HTTP 200)"
echo ""
echo "File storage backend validated successfully!"
echo ""
echo "Note: File storage provides metadata-only tracking with synchronous responses."
echo "      PATCH, DELETE, and LIST endpoints are available but not tested in this E2E script."

# Made with Bob
