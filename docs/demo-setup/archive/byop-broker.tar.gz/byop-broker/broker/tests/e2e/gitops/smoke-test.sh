#!/bin/bash
# Smoke test for broker - validates core endpoints are responding
# This is a lightweight test that does NOT create real instances
# For full workflow testing, use e2e-test.sh instead
#
# Usage:
#   ./smoke-test.sh                                    # Use port-forward (local)
#   ./smoke-test.sh --broker-url http://broker.example.com  # Direct connection (production)
#   ./smoke-test.sh --broker-url https://broker.example.com --insecure  # Skip SSL verification

set -e

BROKER_URL=""
USE_PORT_FORWARD=true
CURL_OPTS=""

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --broker-url)
            BROKER_URL="$2"
            USE_PORT_FORWARD=false
            shift 2
            ;;
        --insecure|-k)
            CURL_OPTS="-k"
            shift
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage: $0 [--broker-url URL] [--insecure]"
            exit 1
            ;;
    esac
done

echo "=== Smoke Test (Endpoint Validation) ==="
echo ""

PF_PID=""

if [ "$USE_PORT_FORWARD" = true ]; then
    # Start port-forward in background
    echo "Starting port-forward..."
    kubectl port-forward -n byop service/byop-broker 8083:8080 > /dev/null 2>&1 &
    PF_PID=$!
    sleep 3
    BROKER_URL="http://localhost:8083"
    echo "Using port-forward: $BROKER_URL"
else
    echo "Using direct connection: $BROKER_URL"
fi
echo ""

# Cleanup function
cleanup() {
    if [ -n "$PF_PID" ]; then
        kill $PF_PID 2>/dev/null || true
        wait $PF_PID 2>/dev/null || true
    fi
}
trap cleanup EXIT

# Test 1: Health check
echo "Test 1: Health Check"
HEALTH_RESPONSE=$(curl -s -w "\n%{http_code}" ${CURL_OPTS} ${BROKER_URL}/health)
HTTP_CODE=$(echo "$HEALTH_RESPONSE" | tail -n1)
BODY=$(echo "$HEALTH_RESPONSE" | sed '$d')

if [ "$HTTP_CODE" = "200" ] && echo "$BODY" | grep -q "healthy"; then
    echo "✓ Health check passed (HTTP $HTTP_CODE)"
else
    echo "✗ Health check failed (HTTP $HTTP_CODE)"
    echo "  Response: $BODY"
    exit 1
fi
echo ""

# Test 2: Catalog discovery
echo "Test 2: Catalog Discovery"
CATALOG_RESPONSE=$(curl -s -w "\n%{http_code}" ${CURL_OPTS} ${BROKER_URL}/v2/catalog)
HTTP_CODE=$(echo "$CATALOG_RESPONSE" | tail -n1)
BODY=$(echo "$CATALOG_RESPONSE" | sed '$d')

if [ "$HTTP_CODE" = "200" ]; then
    echo "✓ Catalog discovery passed (HTTP $HTTP_CODE)"
    SERVICE_COUNT=$(echo "$BODY" | grep -o '"name"' | wc -l)
    if [ "$SERVICE_COUNT" -gt 0 ]; then
        echo "  Found $SERVICE_COUNT service(s)"
    else
        echo "  Catalog is empty (no service templates published yet)"
    fi
else
    echo "✗ Catalog discovery failed (HTTP $HTTP_CODE)"
    echo "  Response: $BODY"
    exit 1
fi
echo ""

# Test 3: List instances endpoint
echo "Test 3: List Instances Endpoint"
LIST_RESPONSE=$(curl -s -w "\n%{http_code}" ${CURL_OPTS} ${BROKER_URL}/service_instances)
HTTP_CODE=$(echo "$LIST_RESPONSE" | tail -n1)

if [ "$HTTP_CODE" = "200" ]; then
    echo "✓ List instances endpoint working (HTTP $HTTP_CODE)"
else
    echo "✗ List instances endpoint failed (HTTP $HTTP_CODE)"
    exit 1
fi
echo ""

echo "=== Smoke Test Passed! ==="
echo ""
echo "Summary:"
echo "  ✓ Health endpoint responding"
echo "  ✓ Catalog endpoint responding"
echo "  ✓ List instances endpoint responding"
echo ""
echo "All core endpoints validated successfully!"
echo ""
echo "Note: This smoke test only validates endpoint availability."
echo "For full workflow testing (provision/deprovision), run: make test-e2e"

# Made with Bob
