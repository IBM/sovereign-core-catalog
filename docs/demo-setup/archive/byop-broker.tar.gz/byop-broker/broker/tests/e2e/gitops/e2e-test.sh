#!/bin/bash
# Full end-to-end test that waits for async operations to complete
#
# Usage:
#   ./e2e-test.sh                                      # Use port-forward (local)
#   ./e2e-test.sh --pause                              # Pause for 60s (default)
#   ./e2e-test.sh --pause 120                          # Pause for 120s
#   ./e2e-test.sh --broker-url http://broker.example.com  # Direct connection (production)
#   ./e2e-test.sh --broker-url https://broker.example.com --insecure  # Skip SSL verification
#   ./e2e-test.sh --broker-url http://broker.example.com --pause 120  # Production with pause

set -e

PAUSE_FOR_VERIFICATION=false
PAUSE_SECONDS=60
BROKER_URL=""
USE_PORT_FORWARD=true
CURL_OPTS=""

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --pause|-p)
            PAUSE_FOR_VERIFICATION=true
            if [ -n "$2" ] && [[ "$2" =~ ^[0-9]+$ ]]; then
                PAUSE_SECONDS=$2
                shift 2
            else
                shift
            fi
            ;;
        --broker-url)
            BROKER_URL="$2"
            USE_PORT_FORWARD=false
            shift 2
            ;;
        --insecure|-k)
            CURL_OPTS="-k"
            shift
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage: $0 [--pause [SECONDS]] [--broker-url URL] [--insecure]"
            exit 1
            ;;
    esac
done

echo "=== End-to-End Test ==="
if [ "$PAUSE_FOR_VERIFICATION" = true ]; then
    echo "Pause interval: ${PAUSE_SECONDS}s"
fi
echo ""

PF_PID=""

if [ "$USE_PORT_FORWARD" = true ]; then
    # Start port-forward
    echo "Starting port-forward..."
    kubectl port-forward -n byop service/byop-broker 8084:8080 > /dev/null 2>&1 &
    PF_PID=$!
    sleep 3
    BROKER_URL="http://localhost:8084"
    echo "Using port-forward: $BROKER_URL"
else
    echo "Using direct connection: $BROKER_URL"
fi
echo ""

cleanup() {
    echo "Cleaning up..."
    if [ -n "$INSTANCE_ID" ]; then
        echo "Deprovisioning instance $INSTANCE_ID..."
        curl -s ${CURL_OPTS} -X DELETE \
          "${BROKER_URL}/v2/service_instances/${INSTANCE_ID}?service_id=mariadb-service&plan_id=v11&accepts_incomplete=true" \
          > /dev/null 2>&1 || true
    fi
    if [ -n "$PF_PID" ]; then
        kill $PF_PID 2>/dev/null || true
        wait $PF_PID 2>/dev/null || true
    fi
}
trap cleanup EXIT

# Test 1: Provision
echo "Test 1: Provisioning instance..."
INSTANCE_ID="e2e-$(date +%s)"
PROV_RESPONSE=$(curl -s -w "\n%{http_code}" ${CURL_OPTS} -X PUT \
  "${BROKER_URL}/v2/service_instances/${INSTANCE_ID}?accepts_incomplete=true" \
  -H "Content-Type: application/json" \
  -d '{
    "service_id": "mariadb-service",
    "plan_id": "v11",
    "organization_guid": "test-org",
    "space_guid": "test-space",
    "parameters": {
      "cluster_name": "k3s-cluster-1",
      "replicas": 1,
      "storage_size": "10Gi",
      "environment": "dev"
    }
  }')

HTTP_CODE=$(echo "$PROV_RESPONSE" | tail -n1)
if [ "$HTTP_CODE" != "202" ] && [ "$HTTP_CODE" != "201" ]; then
    echo "✗ Provision request failed (HTTP $HTTP_CODE)"
    exit 1
fi
echo "✓ Provision request accepted (HTTP $HTTP_CODE)"
echo ""

# Test 2: Poll for completion
echo "Test 2: Polling for provision completion..."
MAX_ATTEMPTS=30
ATTEMPT=0
while [ $ATTEMPT -lt $MAX_ATTEMPTS ]; do
    ATTEMPT=$((ATTEMPT + 1))
    
    LAST_OP=$(curl -s ${CURL_OPTS} "${BROKER_URL}/v2/service_instances/${INSTANCE_ID}/last_operation")
    STATE=$(echo "$LAST_OP" | grep -o '"state":"[^"]*"' | cut -d'"' -f4)
    
    echo "  Attempt $ATTEMPT/$MAX_ATTEMPTS: state=$STATE"
    
    if [ "$STATE" = "succeeded" ]; then
        echo "✓ Provision completed successfully!"
        break
    elif [ "$STATE" = "failed" ]; then
        echo "✗ Provision failed!"
        echo "  Response: $LAST_OP"
        exit 1
    elif [ "$STATE" = "in progress" ]; then
        sleep 2
        continue
    else
        # Unknown state or 410 (operation completed and removed)
        if echo "$LAST_OP" | grep -q "410"; then
            echo "✓ Operation completed (410 - already removed)"
            break
        fi
        sleep 2
    fi
done

if [ $ATTEMPT -eq $MAX_ATTEMPTS ]; then
    echo "⚠ Timeout waiting for provision to complete"
fi
echo ""

# Test 3: Verify instance exists
echo "Test 3: Verifying instance exists..."
INSTANCES=$(curl -s ${CURL_OPTS} "${BROKER_URL}/service_instances")
if echo "$INSTANCES" | grep -q "$INSTANCE_ID"; then
    echo "✓ Instance found in list"
else
    echo "⚠ Instance not found in list (may have been cleaned up)"
fi
echo ""

# Optional pause for manual verification
if [ "$PAUSE_FOR_VERIFICATION" = true ]; then
    echo "=========================================="
    echo "PAUSED FOR MANUAL VERIFICATION ($PAUSE_SECONDS seconds)"
    echo "=========================================="
    echo ""
    echo "Instance ID: $INSTANCE_ID"
    echo ""
    echo "What to verify:"
    echo ""
    echo "1. GitHub Repository:"
    echo "   - Check instances/$INSTANCE_ID/ directory exists"
    echo "   - Verify files: kustomization.yaml, secret.yaml, metadata.yaml"
    echo "   - Check argocd-apps/$INSTANCE_ID.yaml exists"
    echo ""
    echo "2. ArgoCD:"
    echo "   kubectl get applications -n argocd | grep $INSTANCE_ID"
    echo "   kubectl get application $INSTANCE_ID -n argocd -o yaml"
    echo ""
    echo "3. Kubernetes Resources:"
    echo "   kubectl get namespace $INSTANCE_ID"
    echo "   kubectl get all -n $INSTANCE_ID"
    echo ""
    echo "4. Broker State:"
    echo "   curl -s ${BROKER_URL}/service_instances | jq '.instances[] | select(.id==\"$INSTANCE_ID\")'"
    echo ""
    echo "=========================================="
    echo "Waiting $PAUSE_SECONDS seconds before continuing..."
    echo "Press Ctrl+C to abort if needed"
    echo ""
    
    # Countdown timer
    for ((i=$PAUSE_SECONDS; i>0; i--)); do
        printf "\rContinuing in %3d seconds..." $i
        sleep 1
    done
    printf "\rContinuing now...                    \n"
    echo ""
fi

# Test 4: Deprovision
echo "Test 4: Deprovisioning instance..."
DEPROV_RESPONSE=$(curl -s -w "\n%{http_code}" ${CURL_OPTS} -X DELETE \
  "${BROKER_URL}/v2/service_instances/${INSTANCE_ID}?service_id=mariadb-service&plan_id=v11&accepts_incomplete=true")

DEPROV_CODE=$(echo "$DEPROV_RESPONSE" | tail -n1)
if [ "$DEPROV_CODE" = "200" ] || [ "$DEPROV_CODE" = "202" ] || [ "$DEPROV_CODE" = "410" ]; then
    echo "✓ Deprovision accepted (HTTP $DEPROV_CODE)"
else
    echo "⚠ Deprovision returned HTTP $DEPROV_CODE"
fi
echo ""

# Test 5: Poll for deprovision completion
echo "Test 5: Polling for deprovision completion..."
ATTEMPT=0
while [ $ATTEMPT -lt $MAX_ATTEMPTS ]; do
    ATTEMPT=$((ATTEMPT + 1))
    
    LAST_OP=$(curl -s -w "\n%{http_code}" ${CURL_OPTS} \
      "${BROKER_URL}/v2/service_instances/${INSTANCE_ID}/last_operation")
    
    HTTP_CODE=$(echo "$LAST_OP" | tail -n1)
    
    # 410 = operation completed and removed (OSB spec)
    # 404 = instance fully removed from storage (deprovision complete)
    if [ "$HTTP_CODE" = "410" ]; then
        echo "✓ Deprovision completed (410 - operation removed)"
        break
    elif [ "$HTTP_CODE" = "404" ]; then
        echo "✓ Deprovision completed (404 - instance fully removed)"
        break
    fi
    
    BODY=$(echo "$LAST_OP" | sed '$d')
    STATE=$(echo "$BODY" | grep -o '"state":"[^"]*"' | cut -d'"' -f4)
    
    echo "  Attempt $ATTEMPT/$MAX_ATTEMPTS: state=$STATE (HTTP $HTTP_CODE)"
    
    if [ "$STATE" = "succeeded" ]; then
        echo "✓ Deprovision completed successfully!"
        break
    elif [ "$STATE" = "failed" ]; then
        echo "✗ Deprovision failed!"
        exit 1
    fi
    
    sleep 2
done
echo ""

echo "=== Full E2E Test Complete ==="
echo ""
echo "Summary:"
echo "  ✓ Provision request accepted"
echo "  ✓ Async provision completed"
echo "  ✓ Instance verified"
echo "  ✓ Deprovision request accepted"
echo "  ✓ Async deprovision completed"

# Made with Bob
