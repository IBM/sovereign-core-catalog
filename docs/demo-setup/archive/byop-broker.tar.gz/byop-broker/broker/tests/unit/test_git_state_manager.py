"""Unit tests for GitStateManager."""

from unittest.mock import Mock

import yaml

from broker.gitops.git_state_manager import GitStateManager


class TestFindMetadataFile:
    """Tests for _find_metadata_file method."""

    def test_finds_metadata_in_subdirectory_structure(self, tmp_path):
        """Test finding metadata.yaml in main/ subdirectory (new structure)."""
        # Create subdirectory structure
        instance_dir = tmp_path / "instances" / "qradar" / "qradar-test-01"
        main_dir = instance_dir / "main"
        main_dir.mkdir(parents=True)

        # Create metadata in subdirectory
        metadata_file = main_dir / "metadata.yaml"
        metadata_file.write_text("instance_id: qradar-test-01\n")

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test finding metadata
        result = manager._find_metadata_file(instance_dir)

        assert result is not None
        assert result == metadata_file
        assert result.exists()

    def test_finds_metadata_in_flat_structure(self, tmp_path):
        """Test finding metadata.yaml at root (old structure)."""
        # Create flat structure
        instance_dir = tmp_path / "instances" / "mysql" / "mysql-test-01"
        instance_dir.mkdir(parents=True)

        # Create metadata at root
        metadata_file = instance_dir / "metadata.yaml"
        metadata_file.write_text("instance_id: mysql-test-01\n")

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test finding metadata
        result = manager._find_metadata_file(instance_dir)

        assert result is not None
        assert result == metadata_file
        assert result.exists()

    def test_prefers_subdirectory_over_flat(self, tmp_path):
        """Test that subdirectory structure takes precedence over flat."""
        # Create both structures
        instance_dir = tmp_path / "instances" / "qradar" / "qradar-test-01"
        main_dir = instance_dir / "main"
        main_dir.mkdir(parents=True)

        # Create metadata in both locations
        subdirectory_metadata = main_dir / "metadata.yaml"
        subdirectory_metadata.write_text("instance_id: qradar-test-01\nlocation: subdirectory\n")

        root_metadata = instance_dir / "metadata.yaml"
        root_metadata.write_text("instance_id: qradar-test-01\nlocation: root\n")

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test finding metadata - should prefer subdirectory
        result = manager._find_metadata_file(instance_dir)

        assert result is not None
        assert result == subdirectory_metadata
        assert "subdirectory" in result.read_text()

    def test_returns_none_when_no_metadata_found(self, tmp_path):
        """Test returns None when metadata.yaml doesn't exist."""
        # Create instance directory without metadata
        instance_dir = tmp_path / "instances" / "mysql" / "mysql-test-01"
        instance_dir.mkdir(parents=True)

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test finding metadata
        result = manager._find_metadata_file(instance_dir)

        assert result is None

    def test_returns_none_when_instance_dir_not_exists(self, tmp_path):
        """Test returns None when instance directory doesn't exist."""
        # Don't create instance directory
        instance_dir = tmp_path / "instances" / "mysql" / "mysql-test-01"

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test finding metadata
        result = manager._find_metadata_file(instance_dir)

        assert result is None


class TestReadInstanceFromGit:
    """Tests for _read_instance_from_git method."""

    def test_reads_instance_with_subdirectory_structure(self, tmp_path):
        """Test reading instance with subdirectory structure (main/metadata.yaml)."""
        # Create subdirectory structure
        instance_dir = tmp_path / "instances" / "qradar" / "qradar-test-01"
        main_dir = instance_dir / "main"
        main_dir.mkdir(parents=True)

        # Create metadata in subdirectory
        metadata = {
            "instance_id": "qradar-test-01",
            "service_type": "qradar",
            "service_version": "v1",
            "plan_id": "standard",
            "cluster_name": "hub",
            "namespace": "qradar-qradar-test-01",
        }
        metadata_file = main_dir / "metadata.yaml"
        with open(metadata_file, "w") as f:
            yaml.dump(metadata, f)

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test reading instance
        result = manager._read_instance_from_git("qradar-test-01")

        assert result is not None
        assert result["instance_id"] == "qradar-test-01"
        assert result["service_id"] == "qradar"
        assert result["plan_id"] == "standard"
        assert result["state"] == "succeeded"

    def test_reads_instance_with_flat_structure(self, tmp_path):
        """Test reading instance with flat structure (metadata.yaml at root)."""
        # Create flat structure
        instance_dir = tmp_path / "instances" / "mysql" / "mysql-test-01"
        instance_dir.mkdir(parents=True)

        # Create metadata at root
        metadata = {
            "instance_id": "mysql-test-01",
            "service_type": "mysql",
            "service_version": "v1",
            "plan_id": "dev",
            "cluster_name": "spoke1",
        }
        metadata_file = instance_dir / "metadata.yaml"
        with open(metadata_file, "w") as f:
            yaml.dump(metadata, f)

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test reading instance
        result = manager._read_instance_from_git("mysql-test-01")

        assert result is not None
        assert result["instance_id"] == "mysql-test-01"
        assert result["service_id"] == "mysql"
        assert result["plan_id"] == "dev"
        assert result["state"] == "succeeded"

    def test_returns_none_when_instance_not_found(self, tmp_path):
        """Test returns None when instance doesn't exist."""
        # Create empty instances directory
        instances_dir = tmp_path / "instances"
        instances_dir.mkdir(parents=True)

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test reading non-existent instance
        result = manager._read_instance_from_git("nonexistent-instance")

        assert result is None

    def test_returns_none_when_instances_dir_not_exists(self, tmp_path):
        """Test returns None when instances directory doesn't exist."""
        # Don't create instances directory

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test reading instance
        result = manager._read_instance_from_git("test-instance")

        assert result is None

    def test_searches_across_multiple_service_directories(self, tmp_path):
        """Test searching for instance across multiple service type directories."""
        # Create multiple service directories
        instances_dir = tmp_path / "instances"
        mysql_dir = instances_dir / "mysql"
        qradar_dir = instances_dir / "qradar"
        mysql_dir.mkdir(parents=True)
        qradar_dir.mkdir(parents=True)

        # Create instance in qradar directory
        instance_dir = qradar_dir / "qradar-test-01"
        main_dir = instance_dir / "main"
        main_dir.mkdir(parents=True)

        metadata = {
            "instance_id": "qradar-test-01",
            "service_type": "qradar",
            "plan_id": "standard",
        }
        metadata_file = main_dir / "metadata.yaml"
        with open(metadata_file, "w") as f:
            yaml.dump(metadata, f)

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test reading instance - should find it in qradar directory
        result = manager._read_instance_from_git("qradar-test-01")

        assert result is not None
        assert result["instance_id"] == "qradar-test-01"
        assert result["service_id"] == "qradar"

    def test_handles_missing_service_id_gracefully(self, tmp_path):
        """Test handles missing service_id by using service_type."""
        # Create instance with metadata missing service_id
        instance_dir = tmp_path / "instances" / "mysql" / "mysql-test-01"
        instance_dir.mkdir(parents=True)

        metadata = {
            "instance_id": "mysql-test-01",
            "service_type": "mysql",  # No service_id
            "plan_id": "dev",
        }
        metadata_file = instance_dir / "metadata.yaml"
        with open(metadata_file, "w") as f:
            yaml.dump(metadata, f)

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test reading instance
        result = manager._read_instance_from_git("mysql-test-01")

        assert result is not None
        assert result["service_id"] == "mysql"  # Should use service_type

    def test_handles_missing_plan_id_gracefully(self, tmp_path):
        """Test handles missing plan_id by using default."""
        # Create instance with metadata missing plan_id
        instance_dir = tmp_path / "instances" / "mysql" / "mysql-test-01"
        instance_dir.mkdir(parents=True)

        metadata = {
            "instance_id": "mysql-test-01",
            "service_type": "mysql",
            # No plan_id
        }
        metadata_file = instance_dir / "metadata.yaml"
        with open(metadata_file, "w") as f:
            yaml.dump(metadata, f)

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test reading instance
        result = manager._read_instance_from_git("mysql-test-01")

        assert result is not None
        assert result["plan_id"] == "dev"  # Should use default

    def test_backward_compatibility_with_existing_flat_instances(self, tmp_path):
        """Test backward compatibility with existing flat structure instances."""
        # Create multiple flat structure instances (old pattern)
        instances_dir = tmp_path / "instances"

        # MySQL instance (flat)
        mysql_dir = instances_dir / "mysql" / "mysql-prod-01"
        mysql_dir.mkdir(parents=True)
        mysql_metadata = {
            "instance_id": "mysql-prod-01",
            "service_type": "mysql",
            "plan_id": "production",
        }
        with open(mysql_dir / "metadata.yaml", "w") as f:
            yaml.dump(mysql_metadata, f)

        # MariaDB instance (flat)
        mariadb_dir = instances_dir / "mariadb" / "mariadb-dev-01"
        mariadb_dir.mkdir(parents=True)
        mariadb_metadata = {
            "instance_id": "mariadb-dev-01",
            "service_type": "mariadb",
            "plan_id": "dev",
        }
        with open(mariadb_dir / "metadata.yaml", "w") as f:
            yaml.dump(mariadb_metadata, f)

        # Create GitStateManager with mocked git_ops
        mock_git_ops = Mock()
        mock_git_ops.repo_dir = tmp_path
        manager = GitStateManager(mock_git_ops)

        # Test reading both instances
        mysql_result = manager._read_instance_from_git("mysql-prod-01")
        mariadb_result = manager._read_instance_from_git("mariadb-dev-01")

        assert mysql_result is not None
        assert mysql_result["instance_id"] == "mysql-prod-01"
        assert mysql_result["service_id"] == "mysql"

        assert mariadb_result is not None
        assert mariadb_result["instance_id"] == "mariadb-dev-01"
        assert mariadb_result["service_id"] == "mariadb"


# Made with Bob
