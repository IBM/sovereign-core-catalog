"""Unit tests for provision_templates module."""

from typing import Any

from broker.gitops.provision_templates import _merge_plan_metadata


class TestMergePlanMetadata:
    """Test plan metadata merging functionality."""

    def test_merge_vm_fields(self) -> None:
        """Test merging VM-related fields (cpu, memory, storage, template)."""
        user_params: dict[str, Any] = {
            "vm": {"name": "qradar-01"},
            "qradar": {"hostname": "qradar.local"},
        }
        plan_metadata = {
            "cpu": 8,
            "memory": 32,
            "storage": 256,
            "template": "all-in-one",
        }

        result = _merge_plan_metadata(user_params, plan_metadata)

        assert result["vm"]["name"] == "qradar-01"
        assert result["vm"]["cpu"] == 8
        assert result["vm"]["memory"] == 32
        assert result["vm"]["storage"] == 256
        assert result["vm"]["template"] == "all-in-one"
        assert result["qradar"]["hostname"] == "qradar.local"

    def test_merge_version_field(self) -> None:
        """Test merging version field to first service object."""
        user_params: dict[str, Any] = {
            "vm": {"name": "qradar-01"},
            "qradar": {"hostname": "qradar.local"},
        }
        plan_metadata = {"version": "7.5.0"}

        result = _merge_plan_metadata(user_params, plan_metadata)

        assert result["qradar"]["version"] == "7.5.0"
        assert result["qradar"]["hostname"] == "qradar.local"

    def test_user_precedence(self) -> None:
        """Test that user parameters take precedence over plan metadata."""
        user_params: dict[str, Any] = {
            "vm": {"name": "qradar-01", "cpu": 16},
            "qradar": {"hostname": "qradar.local", "version": "7.6.0"},
        }
        plan_metadata = {
            "cpu": 8,
            "memory": 32,
            "version": "7.5.0",
        }

        result = _merge_plan_metadata(user_params, plan_metadata)

        # User values should be preserved
        assert result["vm"]["cpu"] == 16
        assert result["qradar"]["version"] == "7.6.0"
        # Plan metadata should fill in missing values
        assert result["vm"]["memory"] == 32

    def test_empty_user_params(self) -> None:
        """Test merging with empty user parameters."""
        user_params: dict[str, Any] = {}
        plan_metadata = {
            "cpu": 8,
            "memory": 32,
            "version": "7.5.0",
        }

        result = _merge_plan_metadata(user_params, plan_metadata)

        # Should create vm object with plan metadata
        assert result["vm"]["cpu"] == 8
        assert result["vm"]["memory"] == 32
        # Version needs a service object, but none exists
        assert "version" not in result

    def test_empty_plan_metadata(self) -> None:
        """Test merging with empty plan metadata."""
        user_params: dict[str, Any] = {
            "vm": {"name": "qradar-01"},
            "qradar": {"hostname": "qradar.local"},
        }
        plan_metadata: dict[str, Any] = {}

        result = _merge_plan_metadata(user_params, plan_metadata)

        # Should return unchanged user params
        assert result == user_params
        assert result is not user_params  # Should be a copy

    def test_missing_vm_object(self) -> None:
        """Test merging when user params don't have vm object."""
        user_params: dict[str, Any] = {
            "qradar": {"hostname": "qradar.local"},
        }
        plan_metadata = {
            "cpu": 8,
            "memory": 32,
        }

        result = _merge_plan_metadata(user_params, plan_metadata)

        # Should create vm object
        assert "vm" in result
        assert result["vm"]["cpu"] == 8
        assert result["vm"]["memory"] == 32

    def test_missing_service_object_for_version(self) -> None:
        """Test merging version when no service object exists."""
        user_params: dict[str, Any] = {
            "vm": {"name": "qradar-01"},
        }
        plan_metadata = {"version": "7.5.0"}

        result = _merge_plan_metadata(user_params, plan_metadata)

        # Version should not be added if no service object exists
        assert "version" not in result
        assert "version" not in result.get("vm", {})

    def test_complex_nested_structure(self) -> None:
        """Test merging with complex nested structures."""
        user_params: dict[str, Any] = {
            "vm": {
                "name": "qradar-01",
                "network": {"interface": "eth0"},
            },
            "qradar": {
                "hostname": "qradar.local",
                "config": {"debug": True},
            },
            "other": {"value": "test"},
        }
        plan_metadata = {
            "cpu": 8,
            "memory": 32,
            "version": "7.5.0",
        }

        result = _merge_plan_metadata(user_params, plan_metadata)

        # VM fields should be added
        assert result["vm"]["cpu"] == 8
        assert result["vm"]["memory"] == 32
        # Nested structures should be preserved
        assert result["vm"]["network"]["interface"] == "eth0"
        assert result["qradar"]["config"]["debug"] is True
        # Version should be added to first service object (qradar)
        assert result["qradar"]["version"] == "7.5.0"
        # Other objects should be preserved
        assert result["other"]["value"] == "test"

    def test_all_metadata_fields(self) -> None:
        """Test merging all possible metadata fields."""
        user_params: dict[str, Any] = {
            "vm": {"name": "qradar-01"},
            "qradar": {"hostname": "qradar.local"},
        }
        plan_metadata = {
            "version": "7.5.0",
            "cpu": 8,
            "memory": 32,
            "storage": 256,
            "template": "all-in-one",
            "other_field": "ignored",  # Should be ignored
        }

        result = _merge_plan_metadata(user_params, plan_metadata)

        assert result["vm"]["cpu"] == 8
        assert result["vm"]["memory"] == 32
        assert result["vm"]["storage"] == 256
        assert result["vm"]["template"] == "all-in-one"
        assert result["qradar"]["version"] == "7.5.0"
        # Other fields should not be added
        assert "other_field" not in result
        assert "other_field" not in result["vm"]
        assert "other_field" not in result["qradar"]

    def test_no_mutation_of_inputs(self) -> None:
        """Test that input dictionaries are not mutated."""
        user_params: dict[str, Any] = {
            "vm": {"name": "qradar-01"},
            "qradar": {"hostname": "qradar.local"},
        }
        plan_metadata = {
            "cpu": 8,
            "version": "7.5.0",
        }

        # Keep references to originals
        original_user_params = user_params.copy()
        original_plan_metadata = plan_metadata.copy()

        result = _merge_plan_metadata(user_params, plan_metadata)

        # Inputs should not be mutated
        assert user_params == original_user_params
        assert plan_metadata == original_plan_metadata
        # Result should be different
        assert result != user_params
        assert "cpu" in result["vm"]
        assert "cpu" not in user_params["vm"]

    def test_multiple_service_objects(self) -> None:
        """Test version merging with multiple service objects."""
        user_params: dict[str, Any] = {
            "vm": {"name": "qradar-01"},
            "qradar": {"hostname": "qradar.local"},
            "database": {"type": "postgres"},
        }
        plan_metadata = {"version": "7.5.0"}

        result = _merge_plan_metadata(user_params, plan_metadata)

        # Version should go to first service object (qradar, alphabetically)
        assert result["qradar"]["version"] == "7.5.0"
        # Should not be added to other service objects
        assert "version" not in result.get("database", {})

    def test_partial_vm_fields(self) -> None:
        """Test merging with only some VM fields in plan metadata."""
        user_params: dict[str, Any] = {
            "vm": {"name": "qradar-01", "cpu": 16},
            "qradar": {"hostname": "qradar.local"},
        }
        plan_metadata = {
            "cpu": 8,  # Should be ignored (user has it)
            "memory": 32,  # Should be added
        }

        result = _merge_plan_metadata(user_params, plan_metadata)

        assert result["vm"]["cpu"] == 16  # User value preserved
        assert result["vm"]["memory"] == 32  # Plan value added
        assert "storage" not in result["vm"]  # Not in plan metadata


# Made with Bob
