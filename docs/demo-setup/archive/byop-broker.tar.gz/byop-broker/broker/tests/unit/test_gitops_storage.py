"""
Unit tests for GitopsStorage implementation.

Tests the GitOps-based storage backend with mocked Git dependencies.
"""

import tempfile
from collections.abc import Generator
from pathlib import Path
from typing import Any
from unittest.mock import Mock, patch

import pytest

from broker.gitops_storage import GitopsStorage


@pytest.fixture
def temp_storage_dir() -> Generator[Path, None, None]:
    """Create a temporary directory for storage tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def mock_state_manager() -> Mock:
    """Create a mock GitStateManager."""
    mock = Mock()
    mock.get_instance = Mock(return_value=None)
    mock.update_instance = Mock()
    mock.exists = Mock(return_value=False)
    mock.list_instances = Mock(return_value=[])
    return mock


@pytest.fixture
def gitops_storage(temp_storage_dir: Path, mock_state_manager: Mock) -> GitopsStorage:
    """Create a GitopsStorage instance for testing with mocked dependencies."""
    storage = GitopsStorage()

    # Mock GitOperations and GitStateManager initialization
    # GitOperations is imported inside _init_state_manager, so patch at import location
    with patch("broker.gitops.git_operations.GitOperations") as mock_git_ops_class:
        mock_git_ops = Mock()
        mock_git_ops.ensure_repo_cloned = Mock()
        mock_git_ops_class.return_value = mock_git_ops

        config: dict[str, Any] = {
            "storage_dir": str(temp_storage_dir),
            "cluster_name": "test-cluster",
            "async_enabled": False,  # Use sync mode for simpler testing
            "gitops_config": {
                "repo_url": "https://github.com/test/repo.git",
                "branch": "main",
            },
        }

        # Patch GitStateManager to return our mock
        with patch(
            "broker.gitops.git_state_manager.GitStateManager", return_value=mock_state_manager
        ):
            storage.init(config)

    # Replace the state_manager with our mock after initialization
    storage.state_manager = mock_state_manager

    return storage


class TestGitopsStorageInit:
    """Test GitopsStorage initialization."""

    def test_init_with_defaults(self, temp_storage_dir: Path, mock_state_manager: Mock) -> None:
        """Test initialization with default configuration."""
        storage = GitopsStorage()

        with patch("broker.gitops.git_operations.GitOperations") as mock_git_ops_class:
            mock_git_ops = Mock()
            mock_git_ops.ensure_repo_cloned = Mock()
            mock_git_ops_class.return_value = mock_git_ops

            with patch(
                "broker.gitops.git_state_manager.GitStateManager", return_value=mock_state_manager
            ):
                config: dict[str, Any] = {
                    "storage_dir": str(temp_storage_dir),
                    "gitops_config": {"repo_url": "https://github.com/test/repo.git"},
                }
                storage.init(config)

        assert storage.storage_dir == temp_storage_dir
        assert storage.cluster_name == "k3s-cluster-1"  # Default
        assert storage.async_enabled is True  # Default

    def test_init_with_custom_cluster(
        self, temp_storage_dir: Path, mock_state_manager: Mock
    ) -> None:
        """Test initialization with custom cluster name."""
        storage = GitopsStorage()

        with patch("broker.gitops.git_operations.GitOperations") as mock_git_ops_class:
            mock_git_ops = Mock()
            mock_git_ops.ensure_repo_cloned = Mock()
            mock_git_ops_class.return_value = mock_git_ops

            with patch(
                "broker.gitops.git_state_manager.GitStateManager", return_value=mock_state_manager
            ):
                config: dict[str, Any] = {
                    "storage_dir": str(temp_storage_dir),
                    "cluster_name": "custom-cluster",
                    "gitops_config": {"repo_url": "https://github.com/test/repo.git"},
                }
                storage.init(config)

        assert storage.cluster_name == "custom-cluster"

    def test_storage_dir_created(self, temp_storage_dir: Path, mock_state_manager: Mock) -> None:
        """Test that storage directory is created if it doesn't exist."""
        storage_path = temp_storage_dir / "nested" / "storage"
        storage = GitopsStorage()

        with patch("broker.gitops.git_operations.GitOperations") as mock_git_ops_class:
            mock_git_ops = Mock()
            mock_git_ops.ensure_repo_cloned = Mock()
            mock_git_ops_class.return_value = mock_git_ops

            with patch(
                "broker.gitops.git_state_manager.GitStateManager", return_value=mock_state_manager
            ):
                config: dict[str, Any] = {
                    "storage_dir": str(storage_path),
                    "gitops_config": {"repo_url": "https://github.com/test/repo.git"},
                }
                storage.init(config)

        assert storage_path.exists()
        assert storage_path.is_dir()


class TestGitopsStorageCRUD:
    """Test CRUD operations."""

    def test_create_instance(self, gitops_storage: GitopsStorage, mock_state_manager: Mock) -> None:
        """Test creating a new instance."""
        instance_id = "test-instance-1"
        data = {
            "service_id": "mysql-service",
            "plan_id": "small",
            "parameters": {
                "db_name": "testdb",
                "cluster_name": "test-cluster",
            },
        }

        # Mock provisioning to succeed
        with patch.object(gitops_storage, "_run_provision"):
            gitops_storage.create(instance_id, data)

        # Verify instance file was created
        instance_path = gitops_storage._get_instance_path(instance_id)
        assert instance_path.exists()

    def test_create_duplicate_instance(self, gitops_storage: GitopsStorage) -> None:
        """Test that creating a duplicate instance raises an error."""
        instance_id = "test-instance-1"
        data = {
            "service_id": "mysql-service",
            "plan_id": "small",
            "parameters": {"cluster_name": "test-cluster"},
        }

        with patch.object(gitops_storage, "_run_provision"):
            gitops_storage.create(instance_id, data)

        # Mock state_manager.exists() to return True for duplicate check
        with (
            patch.object(gitops_storage.state_manager, "exists", return_value=True),
            pytest.raises(ValueError, match="already exists"),
        ):
            gitops_storage.create(instance_id, data)

    def test_get_existing_instance(
        self, gitops_storage: GitopsStorage, mock_state_manager: Mock
    ) -> None:
        """Test retrieving an existing instance."""
        instance_id = "test-instance-1"
        expected_data = {
            "instance_id": instance_id,
            "service_id": "mysql-service",
            "plan_id": "small",
        }

        # Mock state manager to return instance data
        mock_state_manager.get_instance.return_value = expected_data

        retrieved = gitops_storage.get(instance_id)

        assert retrieved is not None
        assert retrieved["service_id"] == "mysql-service"
        mock_state_manager.get_instance.assert_called_once_with(instance_id)

    def test_get_nonexistent_instance(
        self, gitops_storage: GitopsStorage, mock_state_manager: Mock
    ) -> None:
        """Test retrieving a non-existent instance returns None."""
        mock_state_manager.get_instance.return_value = None

        result = gitops_storage.get("nonexistent-instance")
        assert result is None

    def test_update_instance(self, gitops_storage: GitopsStorage, mock_state_manager: Mock) -> None:
        """Test updating an existing instance."""
        instance_id = "test-instance-1"
        update_data = {"plan_id": "large", "parameters": {"db_name": "newdb"}}

        gitops_storage.update(instance_id, update_data)

        # Verify state manager was called
        mock_state_manager.update_instance.assert_called_once_with(instance_id, update_data)

    def test_update_nonexistent_instance(
        self, gitops_storage: GitopsStorage, mock_state_manager: Mock
    ) -> None:
        """Test that updating a non-existent instance raises an error."""
        # Mock state manager to raise ValueError
        mock_state_manager.update_instance.side_effect = ValueError("Instance not found")

        with pytest.raises(ValueError, match="not found"):
            gitops_storage.update("nonexistent-instance", {"plan_id": "large"})

    def test_delete_existing_instance(
        self, gitops_storage: GitopsStorage, mock_state_manager: Mock
    ) -> None:
        """Test deleting an existing instance."""
        instance_id = "test-instance-1"
        instance_data = {
            "instance_id": instance_id,
            "service_id": "mysql-service",
            "plan_id": "small",
        }

        # Mock instance exists and can be retrieved
        mock_state_manager.exists.return_value = True
        mock_state_manager.get_instance.return_value = instance_data

        # Mock deprovisioning to succeed
        with patch.object(gitops_storage, "_run_deprovision"):
            result = gitops_storage.delete(instance_id)

        assert result is True

    def test_delete_nonexistent_instance(
        self, gitops_storage: GitopsStorage, mock_state_manager: Mock
    ) -> None:
        """Test deleting a non-existent instance returns False."""
        mock_state_manager.exists.return_value = False

        result = gitops_storage.delete("nonexistent-instance")
        assert result is False

    def test_exists_for_existing_instance(
        self, gitops_storage: GitopsStorage, mock_state_manager: Mock
    ) -> None:
        """Test exists() returns True for existing instance."""
        instance_id = "test-instance-1"
        mock_state_manager.exists.return_value = True

        assert gitops_storage.exists(instance_id) is True
        mock_state_manager.exists.assert_called_once_with(instance_id)

    def test_exists_for_nonexistent_instance(
        self, gitops_storage: GitopsStorage, mock_state_manager: Mock
    ) -> None:
        """Test exists() returns False for non-existent instance."""
        mock_state_manager.exists.return_value = False

        assert gitops_storage.exists("nonexistent-instance") is False

    def test_list_all_empty(self, gitops_storage: GitopsStorage, mock_state_manager: Mock) -> None:
        """Test listing instances when storage is empty."""
        mock_state_manager.list_instances.return_value = []

        instances = gitops_storage.list_all()
        assert instances == []

    def test_list_all_with_instances(
        self, gitops_storage: GitopsStorage, mock_state_manager: Mock
    ) -> None:
        """Test listing all instances."""
        expected_instances = [
            {"instance_id": "instance-1", "service_id": "mysql-service"},
            {"instance_id": "instance-2", "service_id": "postgres-service"},
            {"instance_id": "instance-3", "service_id": "redis-service"},
        ]
        mock_state_manager.list_instances.return_value = expected_instances

        instances = gitops_storage.list_all()
        assert len(instances) == 3

        # Verify all instances are present
        instance_ids = {inst.get("instance_id") for inst in instances}
        assert "instance-1" in instance_ids
        assert "instance-2" in instance_ids
        assert "instance-3" in instance_ids


class TestGitopsStorageHelpers:
    """Test helper methods."""

    def test_get_instance_path(self, gitops_storage: GitopsStorage) -> None:
        """Test instance path generation."""
        path = gitops_storage._get_instance_path("test-instance")
        assert path.name == "test-instance.json"
        assert path.parent == gitops_storage.storage_dir

    def test_get_instance_path_with_special_chars(self, gitops_storage: GitopsStorage) -> None:
        """Test instance path generation with special characters."""
        # Special characters should be sanitized
        path = gitops_storage._get_instance_path("test/instance:with:special")
        assert "/" not in path.name
        assert ":" not in path.name
        assert path.name == "test_instance_with_special.json"


class TestGitopsStorageEdgeCases:
    """Test edge cases and error handling."""

    def test_operations_before_init(self) -> None:
        """Test that operations before init() raise appropriate errors."""
        storage = GitopsStorage()

        with pytest.raises(RuntimeError, match="not initialized"):
            storage._get_instance_path("test")

    def test_async_mode_enabled(self, temp_storage_dir: Path, mock_state_manager: Mock) -> None:
        """Test that async mode can be enabled."""
        storage = GitopsStorage()

        with patch("broker.gitops.git_operations.GitOperations") as mock_git_ops_class:
            mock_git_ops = Mock()
            mock_git_ops.ensure_repo_cloned = Mock()
            mock_git_ops_class.return_value = mock_git_ops

            with patch(
                "broker.gitops.git_state_manager.GitStateManager", return_value=mock_state_manager
            ):
                config: dict[str, Any] = {
                    "storage_dir": str(temp_storage_dir),
                    "async_enabled": True,
                    "gitops_config": {"repo_url": "https://github.com/test/repo.git"},
                }
                storage.init(config)

        assert storage.async_enabled is True

    def test_create_with_async_mode(self, temp_storage_dir: Path, mock_state_manager: Mock) -> None:
        """Test creating instance in async mode starts background thread."""
        storage = GitopsStorage()

        with patch("broker.gitops.git_operations.GitOperations") as mock_git_ops_class:
            mock_git_ops = Mock()
            mock_git_ops.ensure_repo_cloned = Mock()
            mock_git_ops.pull_latest = Mock()  # Mock pull_latest
            mock_git_ops.repo_dir = temp_storage_dir  # Mock repo_dir as Path
            mock_git_ops_class.return_value = mock_git_ops

            with patch(
                "broker.gitops.git_state_manager.GitStateManager", return_value=mock_state_manager
            ):
                config: dict[str, Any] = {
                    "storage_dir": str(temp_storage_dir),
                    "async_enabled": True,
                    "gitops_config": {"repo_url": "https://github.com/test/repo.git"},
                }
                storage.init(config)

        # Ensure state_manager has git_ops attribute with pull_latest and repo_dir
        storage.state_manager.git_ops = Mock()
        storage.state_manager.git_ops.pull_latest = Mock()
        storage.state_manager.git_ops.repo_dir = temp_storage_dir

        instance_id = "test-instance"
        data = {
            "service_id": "mysql-service",
            "plan_id": "small",
            "parameters": {"cluster_name": "test-cluster"},
        }

        # Mock threading.Thread to verify it's called
        with patch("broker.gitops_storage.threading.Thread") as mock_thread_class:
            mock_thread = Mock()
            mock_thread.name = "provision-test-instance"  # Provide name attribute for logging
            mock_thread_class.return_value = mock_thread

            storage.create(instance_id, data)

            # Verify thread was created and started
            mock_thread_class.assert_called_once()
            mock_thread.start.assert_called_once()

    def test_provision_deprovision_reprovision_cycle(
        self, gitops_storage: GitopsStorage, mock_state_manager: Mock
    ) -> None:
        """Test that instance name can be reused after deletion (regression test for git state sync bug).

        This test reproduces the original bug where:
        1. Instance is provisioned
        2. Instance is deprovisioned
        3. Attempting to provision with same name fails with "already exists"

        The bug was caused by checking local file existence instead of Git state.
        """
        instance_id = "test-reuse-001"
        data = {
            "service_id": "mysql-service",
            "plan_id": "small",
            "parameters": {"cluster_name": "test-cluster"},
        }

        # Mock provisioning and deprovisioning operations
        with (
            patch.object(gitops_storage, "_run_provision"),
            patch.object(gitops_storage, "_run_deprovision"),
        ):
            # Step 1: Create instance
            gitops_storage.create(instance_id, data)

            # Simulate that instance now exists in Git
            mock_state_manager.exists.return_value = True
            mock_state_manager.get_instance.return_value = data

            # Verify instance exists
            assert gitops_storage.exists(instance_id)

            # Step 2: Delete instance
            gitops_storage.delete(instance_id)

            # Simulate that instance is now gone from Git
            mock_state_manager.exists.return_value = False
            mock_state_manager.get_instance.return_value = None

            # Verify instance is gone
            assert not gitops_storage.exists(instance_id)

            # Step 3: Recreate with same name (should succeed, not fail with "already exists")
            # This is the key test - before the fix, this would fail because it checked
            # local file existence instead of Git state
            gitops_storage.create(instance_id, data)

            # Verify instance was created again
            instance_path = gitops_storage._get_instance_path(instance_id)
            assert instance_path.exists()


# Made with Bob
