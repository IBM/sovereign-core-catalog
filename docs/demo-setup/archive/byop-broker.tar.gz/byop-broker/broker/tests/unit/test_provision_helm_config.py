"""Unit tests for helm_config detection in provision.py."""

import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from broker.gitops.provision import _create_instance_files


class TestHelmConfigDetection:
    """Test helm_config detection and routing in _create_instance_files."""

    @pytest.fixture
    def temp_repo(self):
        """Create a temporary repository structure."""
        with tempfile.TemporaryDirectory() as tmpdir:
            repo_dir = Path(tmpdir)

            # Create service directory structure
            service_dir = repo_dir / "services" / "mariadb" / "v2"
            catalog_dir = service_dir / "catalog"
            template_dir = service_dir / "template"

            catalog_dir.mkdir(parents=True)
            template_dir.mkdir(parents=True)

            # Create a dummy template file to pass template check
            (template_dir / "values.yaml.tmpl").write_text("# template")

            yield repo_dir

    def test_uses_kustomize_when_helm_config_present(self, temp_repo):
        """Test that Kustomize provisioning is used when helm_config is present."""
        # Create catalog.yaml with helm_config
        catalog_file = temp_repo / "services" / "mariadb" / "v2" / "catalog" / "catalog.yaml"
        catalog_data = {
            "helm_config": {
                "chart_url": "https://charts.bitnami.com/bitnami",
                "chart_version": "11.0.0",
                "container_name": "mariadb",
                "requires_patch": True,
            }
        }
        catalog_file.write_text(yaml.dump(catalog_data))

        with patch("broker.gitops.provision.GitConfig") as mock_git_config:
            mock_git_config.get_repo_dir.return_value = temp_repo

            with patch("broker.gitops.provision_templates.check_template_support") as mock_check:
                mock_check.return_value = True

                with patch(
                    "broker.gitops.provision_templates.create_instance_files_with_kustomize"
                ) as mock_kustomize:
                    mock_kustomize.return_value = (temp_repo / "instances" / "test", {})

                    with patch(
                        "broker.gitops.provision_templates.create_instance_files_from_templates"
                    ) as mock_templates:
                        _create_instance_files(
                            instance_name="test-instance",
                            namespace="test-ns",
                            replicas=1,
                            storage_size="1Gi",
                            service_type="mariadb",
                            service_version="v2",
                        )

                        # Verify Kustomize function was called
                        assert mock_kustomize.called
                        assert not mock_templates.called

                        # Verify helm_config was passed
                        call_kwargs = mock_kustomize.call_args[1]
                        assert "helm_config" in call_kwargs
                        assert (
                            call_kwargs["helm_config"]["chart_url"]
                            == "https://charts.bitnami.com/bitnami"
                        )

    def test_uses_templates_when_helm_config_absent(self, temp_repo):
        """Test that template provisioning is used when helm_config is absent."""
        # Create catalog.yaml without helm_config
        catalog_file = temp_repo / "services" / "mariadb" / "v2" / "catalog" / "catalog.yaml"
        catalog_data = {"plans": [{"id": "small", "name": "Small"}]}
        catalog_file.write_text(yaml.dump(catalog_data))

        with (
            patch("broker.gitops.provision.GitConfig") as mock_git_config,
            patch("broker.gitops.provision_templates.check_template_support") as mock_check,
            patch(
                "broker.gitops.provision_templates.create_instance_files_with_kustomize"
            ) as mock_kustomize,
            patch(
                "broker.gitops.provision_templates.create_instance_files_from_templates"
            ) as mock_templates,
        ):
            mock_git_config.get_repo_dir.return_value = temp_repo
            mock_check.return_value = True
            mock_templates.return_value = (temp_repo / "instances" / "test", {})

            _create_instance_files(
                instance_name="test-instance",
                namespace="test-ns",
                replicas=1,
                storage_size="1Gi",
                service_type="mariadb",
                service_version="v2",
            )

            # Verify template function was called
            assert mock_templates.called
            assert not mock_kustomize.called

    def test_uses_templates_when_catalog_missing(self, temp_repo):
        """Test that template provisioning is used when catalog.yaml is missing."""
        # Don't create catalog.yaml

        with (
            patch("broker.gitops.provision.GitConfig") as mock_git_config,
            patch("broker.gitops.provision_templates.check_template_support") as mock_check,
            patch(
                "broker.gitops.provision_templates.create_instance_files_with_kustomize"
            ) as mock_kustomize,
            patch(
                "broker.gitops.provision_templates.create_instance_files_from_templates"
            ) as mock_templates,
        ):
            mock_git_config.get_repo_dir.return_value = temp_repo
            mock_check.return_value = True
            mock_templates.return_value = (temp_repo / "instances" / "test", {})

            _create_instance_files(
                instance_name="test-instance",
                namespace="test-ns",
                replicas=1,
                storage_size="1Gi",
                service_type="mariadb",
                service_version="v2",
            )

            # Verify template function was called
            assert mock_templates.called
            assert not mock_kustomize.called

    def test_uses_templates_when_catalog_invalid(self, temp_repo):
        """Test that template provisioning is used when catalog.yaml is invalid."""
        # Create invalid catalog.yaml
        catalog_file = temp_repo / "services" / "mariadb" / "v2" / "catalog" / "catalog.yaml"
        catalog_file.write_text("invalid: yaml: content: [")

        with (
            patch("broker.gitops.provision.GitConfig") as mock_git_config,
            patch("broker.gitops.provision_templates.check_template_support") as mock_check,
            patch(
                "broker.gitops.provision_templates.create_instance_files_with_kustomize"
            ) as mock_kustomize,
            patch(
                "broker.gitops.provision_templates.create_instance_files_from_templates"
            ) as mock_templates,
        ):
            mock_git_config.get_repo_dir.return_value = temp_repo
            mock_check.return_value = True
            mock_templates.return_value = (temp_repo / "instances" / "test", {})

            _create_instance_files(
                instance_name="test-instance",
                namespace="test-ns",
                replicas=1,
                storage_size="1Gi",
                service_type="mariadb",
                service_version="v2",
            )

            # Verify template function was called (fallback)
            assert mock_templates.called
            assert not mock_kustomize.called

    def test_passes_all_parameters_to_kustomize(self, temp_repo):
        """Test that all parameters are correctly passed to Kustomize function."""
        # Create catalog.yaml with helm_config
        catalog_file = temp_repo / "services" / "mariadb" / "v2" / "catalog" / "catalog.yaml"
        catalog_data = {
            "helm_config": {
                "chart_url": "https://charts.bitnami.com/bitnami",
                "chart_version": "11.0.0",
                "container_name": "mariadb",
                "requires_patch": True,
            }
        }
        catalog_file.write_text(yaml.dump(catalog_data))

        with patch("broker.gitops.provision.GitConfig") as mock_git_config:
            mock_git_config.get_repo_dir.return_value = temp_repo

            with patch("broker.gitops.provision_templates.check_template_support") as mock_check:
                mock_check.return_value = True

                with patch(
                    "broker.gitops.provision_templates.create_instance_files_with_kustomize"
                ) as mock_kustomize:
                    mock_kustomize.return_value = (temp_repo / "instances" / "test", {})

                    _create_instance_files(
                        instance_name="test-instance",
                        namespace="test-ns",
                        replicas=3,
                        storage_size="10Gi",
                        service_type="mariadb",
                        service_version="v2",
                        image_pull_secret_name="my-secret",
                        instance_id="inst-123",
                        cluster_name="prod-cluster",
                        cluster_url="https://prod.example.com",
                        environment="production",
                        deployment_registry="quay.io/myorg",
                        parameters_spec={"custom": "param"},
                        context={"org_id": "org-123"},
                        broker_plan_id="plan-456",
                    )

                    # Verify all parameters were passed
                    call_kwargs = mock_kustomize.call_args[1]
                    assert call_kwargs["instance_name"] == "test-instance"
                    assert call_kwargs["namespace"] == "test-ns"
                    assert call_kwargs["replicas"] == 3
                    assert call_kwargs["storage_size"] == "10Gi"
                    assert call_kwargs["service_type"] == "mariadb"
                    assert call_kwargs["service_version"] == "v2"
                    assert call_kwargs["image_pull_secret_name"] == "my-secret"
                    assert call_kwargs["instance_id"] == "inst-123"
                    assert call_kwargs["cluster_name"] == "prod-cluster"
                    assert call_kwargs["cluster_url"] == "https://prod.example.com"
                    assert call_kwargs["environment"] == "production"
                    assert call_kwargs["deployment_registry"] == "quay.io/myorg"
                    assert call_kwargs["parameters_spec"] == {"custom": "param"}
                    assert call_kwargs["context"] == {"org_id": "org-123"}
                    assert call_kwargs["broker_plan_id"] == "plan-456"
                    assert "helm_config" in call_kwargs


# Made with Bob
