"""Unit tests for template_renderer module."""

from pathlib import Path

import pytest

from broker.gitops.template_renderer import RenderError, TemplateRenderer


class TestTemplateRendererInit:
    """Test TemplateRenderer initialization."""

    def test_init_with_valid_directory(self, tmp_path: Path) -> None:
        """Test initialization with valid repository directory."""
        renderer = TemplateRenderer(tmp_path)
        assert renderer.template_loader.repo_dir == tmp_path
        assert renderer.jinja_env is not None


class TestRenderTemplates:
    """Test rendering all templates for a service."""

    def test_render_templates_success(self, tmp_path: Path) -> None:
        """Test successful template rendering."""
        # Create templates
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        (template_dir / "secret.yaml.tmpl").write_text(
            "name: {{ instance_name }}\nnamespace: {{ namespace }}"
        )

        # Render templates
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "my-instance", "namespace": "mysql-ns"}
        rendered = renderer.render_templates("mysql", context)

        # Verify
        assert "secret.yaml.tmpl" in rendered
        assert "my-instance" in rendered["secret.yaml.tmpl"]
        assert "mysql-ns" in rendered["secret.yaml.tmpl"]
        assert "schema.json" not in rendered  # Schema not rendered

    def test_render_templates_with_spec(self, tmp_path: Path) -> None:
        """Test rendering with spec parameters."""
        # Create template
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        (template_dir / "secret.yaml.tmpl").write_text(
            "database: {{ spec.database_name }}\nuser: {{ spec.database_user }}"
        )

        # Render with spec
        renderer = TemplateRenderer(tmp_path)
        context = {
            "instance_name": "my-instance",
            "spec": {"database_name": "myapp", "database_user": "appuser"},
        }
        rendered = renderer.render_templates("mysql", context)

        assert "myapp" in rendered["secret.yaml.tmpl"]
        assert "appuser" in rendered["secret.yaml.tmpl"]

    def test_render_templates_auto_generate_passwords(self, tmp_path: Path) -> None:
        """Test auto-generation of passwords."""
        # Create template
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        (template_dir / "secret.yaml.tmpl").write_text("password: {{ spec.password }}")

        # Render with empty password (should auto-generate)
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "my-instance", "spec": {"password": ""}}
        rendered = renderer.render_templates("mysql", context, auto_generate_secrets=True)

        # Password should be generated
        assert "password:" in rendered["secret.yaml.tmpl"]
        assert rendered["secret.yaml.tmpl"] != "password: "

    def test_render_templates_no_auto_generate(self, tmp_path: Path) -> None:
        """Test rendering without auto-generation."""
        # Create template
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        (template_dir / "secret.yaml.tmpl").write_text("password: {{ spec.password }}")

        # Render with empty password and auto-generate disabled
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "my-instance", "spec": {"password": ""}}
        rendered = renderer.render_templates("mysql", context, auto_generate_secrets=False)

        # Password should remain empty
        assert rendered["secret.yaml.tmpl"] == "password: "

    def test_render_templates_undefined_variable(self, tmp_path: Path) -> None:
        """Test rendering fails with undefined variable."""
        # Create template with undefined variable
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        (template_dir / "secret.yaml.tmpl").write_text("value: {{ undefined_var }}")

        # Render should fail
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "my-instance"}
        with pytest.raises(RenderError):
            renderer.render_templates("mysql", context)

    def test_render_templates_syntax_error(self, tmp_path: Path) -> None:
        """Test rendering fails with template syntax error."""
        # Create template with syntax error
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        (template_dir / "secret.yaml.tmpl").write_text("value: {{ unclosed")

        # Render should fail
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "my-instance"}
        with pytest.raises(RenderError, match="Template syntax error"):
            renderer.render_templates("mysql", context)


class TestRenderTemplate:
    """Test rendering a specific template."""

    def test_render_template_success(self, tmp_path: Path) -> None:
        """Test rendering a specific template."""
        # Create template
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "secret.yaml.tmpl").write_text("name: {{ instance_name }}")

        # Render specific template
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "my-instance"}
        rendered = renderer.render_template("mysql", "secret.yaml.tmpl", context)

        assert rendered == "name: my-instance"

    def test_render_template_not_found(self, tmp_path: Path) -> None:
        """Test rendering non-existent template."""
        # Create template directory
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')

        # Render non-existent template
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "my-instance"}
        with pytest.raises(RenderError, match="Failed to load template"):
            renderer.render_template("mysql", "nonexistent.yaml", context)


class TestGeneratePassword:
    """Test password generation."""

    def test_generate_password_default_length(self) -> None:
        """Test password generation with default length."""
        password = TemplateRenderer.generate_password()
        assert len(password) == 20
        assert any(c.islower() for c in password)
        assert any(c.isupper() for c in password)
        assert any(c.isdigit() for c in password)

    def test_generate_password_custom_length(self) -> None:
        """Test password generation with custom length."""
        password = TemplateRenderer.generate_password(16)
        assert len(password) == 16

    def test_generate_password_no_special_chars(self) -> None:
        """Test password generation without special characters."""
        password = TemplateRenderer.generate_password(20, include_special=False)
        assert len(password) == 20
        assert all(c.isalnum() for c in password)

    def test_generate_password_minimum_length(self) -> None:
        """Test password generation enforces minimum length."""
        with pytest.raises(ValueError, match="at least 8 characters"):
            TemplateRenderer.generate_password(7)

    def test_generate_password_uniqueness(self) -> None:
        """Test that generated passwords are unique."""
        passwords = [TemplateRenderer.generate_password() for _ in range(10)]
        assert len(set(passwords)) == 10  # All unique


class TestGenerateSecret:
    """Test secret generation."""

    def test_generate_secret_default_length(self) -> None:
        """Test secret generation with default length."""
        secret = TemplateRenderer.generate_secret()
        assert len(secret) == 64  # 32 bytes = 64 hex chars
        assert all(c in "0123456789abcdef" for c in secret)

    def test_generate_secret_custom_length(self) -> None:
        """Test secret generation with custom length."""
        secret = TemplateRenderer.generate_secret(16)
        assert len(secret) == 32  # 16 bytes = 32 hex chars

    def test_generate_secret_uniqueness(self) -> None:
        """Test that generated secrets are unique."""
        secrets = [TemplateRenderer.generate_secret() for _ in range(10)]
        assert len(set(secrets)) == 10  # All unique


class TestValidateContext:
    """Test context validation."""

    def test_validate_context_success(self, tmp_path: Path) -> None:
        """Test successful context validation."""
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "my-instance", "namespace": "mysql-ns"}
        # Should not raise
        renderer.validate_context(context, ["instance_name", "namespace"])

    def test_validate_context_missing_field(self, tmp_path: Path) -> None:
        """Test context validation with missing field."""
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "my-instance"}
        with pytest.raises(RenderError, match="Missing required context fields"):
            renderer.validate_context(context, ["instance_name", "namespace"])

    def test_validate_context_multiple_missing(self, tmp_path: Path) -> None:
        """Test context validation with multiple missing fields."""
        renderer = TemplateRenderer(tmp_path)
        context = {}
        with pytest.raises(RenderError) as exc_info:
            renderer.validate_context(context, ["instance_name", "namespace", "cluster"])

        error_message = str(exc_info.value)
        assert "instance_name" in error_message
        assert "namespace" in error_message
        assert "cluster" in error_message


class TestGetTemplateVariables:
    """Test extracting template variables."""

    def test_get_template_variables(self, tmp_path: Path) -> None:
        """Test extracting variables from template."""
        # Create template
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "secret.yaml.tmpl").write_text(
            "name: {{ instance_name }}\ndb: {{ spec.database_name }}"
        )

        # Get variables
        renderer = TemplateRenderer(tmp_path)
        variables = renderer.get_template_variables("mysql", "secret.yaml.tmpl")

        assert "instance_name" in variables
        assert "spec" in variables
        assert len(variables) == 2

    def test_get_template_variables_syntax_error(self, tmp_path: Path) -> None:
        """Test getting variables from template with syntax error."""
        # Create template with syntax error
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "secret.yaml.tmpl").write_text("value: {{ unclosed")

        # Should raise error
        renderer = TemplateRenderer(tmp_path)
        with pytest.raises(RenderError, match="Template syntax error"):
            renderer.get_template_variables("mysql", "secret.yaml.tmpl")


class TestAutoGenerationBehavior:
    """Test auto-generation behavior for various password fields."""

    def test_auto_generate_common_password_fields(self, tmp_path: Path) -> None:
        """Test auto-generation for common password field names."""
        # Create template
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        (template_dir / "secret.yaml.tmpl").write_text(
            "password: {{ spec.password }}\n"
            "root_password: {{ spec.root_password }}\n"
            "database_password: {{ spec.database_password }}"
        )

        # Render with empty passwords
        renderer = TemplateRenderer(tmp_path)
        context = {
            "instance_name": "my-instance",
            "spec": {
                "password": "",
                "root_password": "",
                "database_password": "",
            },
        }
        rendered = renderer.render_templates("mysql", context, auto_generate_secrets=True)

        # All passwords should be generated
        lines = rendered["secret.yaml.tmpl"].split("\n")
        for line in lines:
            if ":" in line:
                key, value = line.split(":", 1)
                value = value.strip()
                assert value != "", f"Password field {key} was not generated"
                assert len(value) >= 20, f"Generated password for {key} is too short"

    def test_preserve_provided_passwords(self, tmp_path: Path) -> None:
        """Test that provided passwords are not overridden."""
        # Create template
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        (template_dir / "secret.yaml.tmpl").write_text("password: {{ spec.password }}")

        # Render with provided password
        renderer = TemplateRenderer(tmp_path)
        context = {
            "instance_name": "my-instance",
            "spec": {"password": "my-custom-password"},
        }
        rendered = renderer.render_templates("mysql", context, auto_generate_secrets=True)

        assert "my-custom-password" in rendered["secret.yaml.tmpl"]


class TestIncludeDirective:
    """Test {% include %} directive support with FileSystemLoader."""

    def test_include_file_success(self, tmp_path: Path) -> None:
        """Test successful file inclusion using {% include %}."""
        # Create service structure with script to include
        service_dir = tmp_path / "services" / "test-service" / "v1"
        template_dir = service_dir / "template"
        scripts_dir = service_dir / "manifests" / "scripts"
        
        template_dir.mkdir(parents=True)
        scripts_dir.mkdir(parents=True)
        
        # Create a script file to be included
        script_content = """#!/bin/bash
echo "Hello from included script"
echo "Instance: $1"
"""
        (scripts_dir / "test-script.sh").write_text(script_content)
        
        # Create template that includes the script
        template_content = """apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ instance_name }}-scripts
data:
  test-script.sh: |
    {% include 'manifests/scripts/test-script.sh' %}
"""
        (template_dir / "configmap.yaml.tmpl").write_text(template_content)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        
        # Render template
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "my-instance"}
        rendered = renderer.render_templates("test-service", context)
        
        # Verify script was included
        assert "configmap.yaml.tmpl" in rendered
        assert "#!/bin/bash" in rendered["configmap.yaml.tmpl"]
        assert "Hello from included script" in rendered["configmap.yaml.tmpl"]
        assert "my-instance-scripts" in rendered["configmap.yaml.tmpl"]

    def test_include_with_relative_path(self, tmp_path: Path) -> None:
        """Test file inclusion with relative path from template subdirectory."""
        # Create service structure
        service_dir = tmp_path / "services" / "test-service" / "v1"
        template_main_dir = service_dir / "template" / "main"
        scripts_dir = service_dir / "manifests" / "scripts"
        
        template_main_dir.mkdir(parents=True)
        scripts_dir.mkdir(parents=True)
        
        # Create script
        (scripts_dir / "installer.sh").write_text("#!/bin/bash\necho 'Installing...'")
        
        # Create template in subdirectory with relative include
        # Note: FileSystemLoader base is service_dir, so path is relative to that
        template_content = """apiVersion: v1
kind: Secret
metadata:
  name: {{ instance_name }}-config
stringData:
  installer.sh: |
    {% include 'manifests/scripts/installer.sh' %}
"""
        (template_main_dir / "secret.yaml.tmpl").write_text(template_content)
        (service_dir / "template" / "schema.json").write_text('{"type": "object"}')
        
        # Render template
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "test-instance"}
        rendered = renderer.render_templates("test-service", context)
        
        # Verify
        assert "main/secret.yaml.tmpl" in rendered
        assert "Installing..." in rendered["main/secret.yaml.tmpl"]

    def test_include_multiple_files(self, tmp_path: Path) -> None:
        """Test including multiple files in a single template."""
        # Create service structure
        service_dir = tmp_path / "services" / "test-service" / "v1"
        template_dir = service_dir / "template"
        scripts_dir = service_dir / "manifests" / "scripts"
        
        template_dir.mkdir(parents=True)
        scripts_dir.mkdir(parents=True)
        
        # Create multiple scripts
        (scripts_dir / "script1.sh").write_text("#!/bin/bash\necho 'Script 1'")
        (scripts_dir / "script2.sh").write_text("#!/bin/bash\necho 'Script 2'")
        (scripts_dir / "script3.sh").write_text("#!/bin/bash\necho 'Script 3'")
        
        # Create template including all scripts
        template_content = """apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ instance_name }}-scripts
data:
  script1.sh: |
    {% include 'manifests/scripts/script1.sh' %}
  script2.sh: |
    {% include 'manifests/scripts/script2.sh' %}
  script3.sh: |
    {% include 'manifests/scripts/script3.sh' %}
"""
        (template_dir / "configmap.yaml.tmpl").write_text(template_content)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        
        # Render
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "multi-script"}
        rendered = renderer.render_templates("test-service", context)
        
        # Verify all scripts included
        result = rendered["configmap.yaml.tmpl"]
        assert "Script 1" in result
        assert "Script 2" in result
        assert "Script 3" in result

    def test_include_nonexistent_file_fails(self, tmp_path: Path) -> None:
        """Test that including a non-existent file raises an error."""
        # Create service structure
        service_dir = tmp_path / "services" / "test-service" / "v1"
        template_dir = service_dir / "template"
        template_dir.mkdir(parents=True)
        
        # Create template with non-existent include
        template_content = """data:
  script.sh: |
    {% include 'manifests/scripts/nonexistent.sh' %}
"""
        (template_dir / "configmap.yaml.tmpl").write_text(template_content)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        
        # Render should fail
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "test"}
        with pytest.raises(RenderError):
            renderer.render_templates("test-service", context)

    def test_include_with_jinja_variables(self, tmp_path: Path) -> None:
        """Test that included files can contain Jinja2 variables."""
        # Create service structure
        service_dir = tmp_path / "services" / "test-service" / "v1"
        template_dir = service_dir / "template"
        scripts_dir = service_dir / "manifests" / "scripts"
        
        template_dir.mkdir(parents=True)
        scripts_dir.mkdir(parents=True)
        
        # Create script with Jinja2 variables
        script_with_vars = """#!/bin/bash
INSTANCE_NAME="{{ instance_name }}"
NAMESPACE="{{ namespace }}"
echo "Deploying $INSTANCE_NAME in $NAMESPACE"
"""
        (scripts_dir / "deploy.sh").write_text(script_with_vars)
        
        # Create template
        template_content = """apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ instance_name }}-deploy
  namespace: {{ namespace }}
data:
  deploy.sh: |
    {% include 'manifests/scripts/deploy.sh' %}
"""
        (template_dir / "configmap.yaml.tmpl").write_text(template_content)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        
        # Render
        renderer = TemplateRenderer(tmp_path)
        context = {"instance_name": "my-app", "namespace": "production"}
        rendered = renderer.render_templates("test-service", context)
        
        # Verify variables were rendered in included file
        result = rendered["configmap.yaml.tmpl"]
        assert 'INSTANCE_NAME="my-app"' in result
        assert 'NAMESPACE="production"' in result
        assert "Deploying $INSTANCE_NAME in $NAMESPACE" in result


# Made with Bob
