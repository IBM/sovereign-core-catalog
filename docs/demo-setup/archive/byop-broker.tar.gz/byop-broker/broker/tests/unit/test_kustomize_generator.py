"""Unit tests for Kustomize infrastructure file generation module.

This test file has been deprecated because all Kustomize file generation
functionality has been moved to service templates following the template-first
architecture principle.

Historical Context:
    This module previously tested generate_kustomization_yaml() and
    generate_ksops_generator() functions. Both have been removed because:

    1. All Kustomize files (kustomization.yaml, ksops-generator.yaml, patches)
       now come from service templates, not programmatic generation

    2. This follows the separation of concerns principle:
       - Service templates define WHAT (files, patches, configuration)
       - Broker defines HOW (rendering, encryption, orchestration)

    3. Programmatic generation violated this principle and caused maintenance
       issues (see docs/dev/feat-sops/lessons-learned-double-implementation.md)

Note:
    This file is retained as a placeholder to document why the tests were removed.
    It can be deleted in a future cleanup if desired.
"""


# Made with Bob
