"""Unit tests for provision module."""

from pathlib import Path
from unittest.mock import patch

import yaml

from broker.gitops.provision import _create_metadata, _has_subdirectory_structure


class TestHasSubdirectoryStructure:
    """Test subdirectory structure detection."""

    def test_detects_subdirectory_structure(self, tmp_path: Path) -> None:
        """Test detection of subdirectory structure with main/ directory."""
        instance_dir = tmp_path / "qradar-1"
        main_dir = instance_dir / "main"
        main_dir.mkdir(parents=True)
        (main_dir / "kustomization.yaml").write_text("content")

        assert _has_subdirectory_structure(instance_dir) is True

    def test_detects_flat_structure(self, tmp_path: Path) -> None:
        """Test detection of flat structure (no main/ directory)."""
        instance_dir = tmp_path / "mysql-1"
        instance_dir.mkdir(parents=True)
        (instance_dir / "deployment.yaml").write_text("content")

        assert _has_subdirectory_structure(instance_dir) is False

    def test_empty_main_directory_is_flat(self, tmp_path: Path) -> None:
        """Test that empty main/ directory is treated as flat structure."""
        instance_dir = tmp_path / "test-1"
        main_dir = instance_dir / "main"
        main_dir.mkdir(parents=True)
        # main/ exists but is empty

        assert _has_subdirectory_structure(instance_dir) is False

    def test_nonexistent_directory(self, tmp_path: Path) -> None:
        """Test with non-existent directory."""
        instance_dir = tmp_path / "nonexistent"

        assert _has_subdirectory_structure(instance_dir) is False


class TestCreateMetadata:
    """Test metadata file creation."""

    def test_create_metadata_with_subdirectories(self, tmp_path: Path) -> None:
        """Test metadata creation in subdirectory structure."""
        instance_dir = tmp_path / "qradar-1"

        # Create subdirectories with files
        main_dir = instance_dir / "main"
        main_dir.mkdir(parents=True)
        (main_dir / "kustomization.yaml").write_text("main content")

        auth_dir = instance_dir / "auth"
        auth_dir.mkdir(parents=True)
        (auth_dir / "rolebinding.yaml").write_text("auth content")

        # Create metadata
        _create_metadata(
            instance_dir=instance_dir,
            instance_name="qradar-1",
            namespace="qradar-1-ns",
            environment="dev",
            replicas=1,
            storage_size="10Gi",
            cluster_url="https://cluster:6443",
            cluster_name="test-cluster",
            service_type="qradar",
            image="qradar:7.5.0",
        )

        # Verify metadata in subdirectories
        assert (main_dir / "metadata.yaml").exists()
        assert (auth_dir / "metadata.yaml").exists()
        assert not (instance_dir / "metadata.yaml").exists()  # Not at root

        # Verify metadata content
        with open(main_dir / "metadata.yaml") as f:
            metadata = yaml.safe_load(f)
            assert metadata["instance_name"] == "qradar-1"
            assert metadata["namespace"] == "qradar-1-ns"
            assert metadata["service_type"] == "qradar"
            assert metadata["environment"] == "dev"
            assert metadata["status"] == "provisioned"

    def test_create_metadata_flat_structure(self, tmp_path: Path) -> None:
        """Test metadata creation in flat structure (backward compatibility)."""
        instance_dir = tmp_path / "mysql-1"
        instance_dir.mkdir(parents=True)
        (instance_dir / "deployment.yaml").write_text("content")

        # Create metadata
        _create_metadata(
            instance_dir=instance_dir,
            instance_name="mysql-1",
            namespace="mysql-1-ns",
            environment="prod",
            replicas=3,
            storage_size="50Gi",
            cluster_url="https://cluster:6443",
            cluster_name="prod-cluster",
            service_type="mysql",
            image="mysql:8.0",
        )

        # Verify metadata at root
        assert (instance_dir / "metadata.yaml").exists()

        # Verify metadata content
        with open(instance_dir / "metadata.yaml") as f:
            metadata = yaml.safe_load(f)
            assert metadata["instance_name"] == "mysql-1"
            assert metadata["namespace"] == "mysql-1-ns"
            assert metadata["service_type"] == "mysql"
            assert metadata["replicas"] == 3

    def test_create_metadata_with_optional_fields(self, tmp_path: Path) -> None:
        """Test metadata creation with optional fields."""
        instance_dir = tmp_path / "test-1"
        instance_dir.mkdir(parents=True)

        _create_metadata(
            instance_dir=instance_dir,
            instance_name="test-1",
            namespace="test-ns",
            environment="dev",
            replicas=1,
            storage_size="10Gi",
            cluster_url="https://cluster:6443",
            cluster_name="test-cluster",
            service_type="test",
            image="test:1.0",
            image_pull_secret_name="my-secret",
            registry_server="quay.io",
            deployment_registry="quay.io/myorg",
            broker_service_id="service-123",
            broker_plan_id="plan-456",
        )

        with open(instance_dir / "metadata.yaml") as f:
            metadata = yaml.safe_load(f)
            assert metadata["image_pull_secret_name"] == "my-secret"
            assert metadata["registry_server"] == "quay.io"
            assert metadata["deployment_registry"] == "quay.io/myorg"
            assert metadata["service_id"] == "service-123"
            assert metadata["plan_id"] == "plan-456"

    def test_create_metadata_skips_hidden_directories(self, tmp_path: Path) -> None:
        """Test that hidden directories are skipped."""
        instance_dir = tmp_path / "test-1"

        # Create main/ and .git/ directories
        main_dir = instance_dir / "main"
        main_dir.mkdir(parents=True)
        (main_dir / "kustomization.yaml").write_text("content")

        git_dir = instance_dir / ".git"
        git_dir.mkdir(parents=True)
        (git_dir / "config").write_text("git config")

        _create_metadata(
            instance_dir=instance_dir,
            instance_name="test-1",
            namespace="test-ns",
            environment="dev",
            replicas=1,
            storage_size="10Gi",
            cluster_url=None,
            cluster_name=None,
            service_type="test",
            image="test:1.0",
        )

        # Verify metadata in main/ but not in .git/
        assert (main_dir / "metadata.yaml").exists()
        assert not (git_dir / "metadata.yaml").exists()

    def test_create_metadata_handles_errors_gracefully(self, tmp_path: Path) -> None:
        """Test that metadata creation errors don't fail provisioning."""
        instance_dir = tmp_path / "test-1"
        instance_dir.mkdir(parents=True)

        # Mock write_yaml_file to raise an exception
        with patch("broker.gitops.provision.write_yaml_file") as mock_write:
            mock_write.side_effect = Exception("Write failed")

            # Should not raise exception
            _create_metadata(
                instance_dir=instance_dir,
                instance_name="test-1",
                namespace="test-ns",
                environment="dev",
                replicas=1,
                storage_size="10Gi",
                cluster_url=None,
                cluster_name=None,
                service_type="test",
                image="test:1.0",
            )

    def test_create_metadata_multiple_subdirectories(self, tmp_path: Path) -> None:
        """Test metadata creation with multiple subdirectories."""
        instance_dir = tmp_path / "qradar-1"

        # Create multiple subdirectories
        subdirs = ["main", "auth", "cdi-clone", "monitoring"]
        for subdir_name in subdirs:
            subdir = instance_dir / subdir_name
            subdir.mkdir(parents=True)
            (subdir / "kustomization.yaml").write_text(f"{subdir_name} content")

        _create_metadata(
            instance_dir=instance_dir,
            instance_name="qradar-1",
            namespace="qradar-1-ns",
            environment="dev",
            replicas=1,
            storage_size="10Gi",
            cluster_url=None,
            cluster_name=None,
            service_type="qradar",
            image="qradar:7.5.0",
        )

        # Verify metadata in all subdirectories
        for subdir_name in subdirs:
            metadata_file = instance_dir / subdir_name / "metadata.yaml"
            assert metadata_file.exists(), f"metadata.yaml missing in {subdir_name}/"

    def test_create_metadata_creates_instance_dir_if_missing(self, tmp_path: Path) -> None:
        """Test that instance directory is created if it doesn't exist."""
        instance_dir = tmp_path / "nonexistent" / "test-1"

        _create_metadata(
            instance_dir=instance_dir,
            instance_name="test-1",
            namespace="test-ns",
            environment="dev",
            replicas=1,
            storage_size="10Gi",
            cluster_url=None,
            cluster_name=None,
            service_type="test",
            image="test:1.0",
        )

        # Verify directory was created
        assert instance_dir.exists()
        assert (instance_dir / "metadata.yaml").exists()


# Made with Bob
