"""
Unit tests for FileStorage implementation.

Tests the file-based storage backend without Git dependencies.
"""

import tempfile
from collections.abc import Generator
from pathlib import Path
from typing import Any

import pytest

from broker.file_storage import FileStorage


@pytest.fixture
def temp_storage_dir() -> Generator[Path, None, None]:
    """Create a temporary directory for storage tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def file_storage(temp_storage_dir: Path) -> FileStorage:
    """Create a FileStorage instance for testing."""
    storage = FileStorage()
    config: dict[str, Any] = {
        "storage_dir": str(temp_storage_dir),
    }
    storage.init(config)
    return storage


class TestFileStorageInit:
    """Test FileStorage initialization."""

    def test_init_with_defaults(self, temp_storage_dir: Path) -> None:
        """Test initialization with default configuration."""
        storage = FileStorage()
        config: dict[str, Any] = {"storage_dir": str(temp_storage_dir)}
        storage.init(config)

        assert storage.storage_dir == temp_storage_dir
        assert storage.storage_dir.exists()

    def test_init_with_custom_storage_dir(self, temp_storage_dir: Path) -> None:
        """Test initialization with custom storage directory."""
        custom_dir = temp_storage_dir / "custom"
        storage = FileStorage()
        config: dict[str, Any] = {
            "storage_dir": str(custom_dir),
        }
        storage.init(config)

        assert storage.storage_dir == custom_dir
        assert storage.storage_dir.exists()

    def test_storage_dir_created(self, temp_storage_dir: Path) -> None:
        """Test that storage directory is created if it doesn't exist."""
        storage_path = temp_storage_dir / "nested" / "storage"
        storage = FileStorage()
        config: dict[str, Any] = {"storage_dir": str(storage_path)}
        storage.init(config)

        assert storage_path.exists()
        assert storage_path.is_dir()


class TestFileStorageCRUD:
    """Test CRUD operations."""

    def test_create_instance(self, file_storage: FileStorage) -> None:
        """Test creating a new instance."""
        instance_id = "test-instance-1"
        data = {
            "service_id": "mysql-service",
            "plan_id": "small",
            "parameters": {"db_name": "testdb"},
        }

        file_storage.create(instance_id, data)

        # Verify instance was created
        assert file_storage.exists(instance_id)
        retrieved = file_storage.get(instance_id)
        assert retrieved is not None
        assert retrieved["service_id"] == "mysql-service"
        assert retrieved["plan_id"] == "small"
        assert retrieved["state"] == "succeeded"
        assert "created_at" in retrieved
        assert "updated_at" in retrieved

    def test_create_duplicate_instance(self, file_storage: FileStorage) -> None:
        """Test that creating a duplicate instance raises an error."""
        instance_id = "test-instance-1"
        data = {"service_id": "mysql-service", "plan_id": "small"}

        file_storage.create(instance_id, data)

        with pytest.raises(ValueError, match="already exists"):
            file_storage.create(instance_id, data)

    def test_get_existing_instance(self, file_storage: FileStorage) -> None:
        """Test retrieving an existing instance."""
        instance_id = "test-instance-1"
        data = {"service_id": "mysql-service", "plan_id": "small"}

        file_storage.create(instance_id, data)
        retrieved = file_storage.get(instance_id)

        assert retrieved is not None
        assert retrieved["service_id"] == "mysql-service"

    def test_get_nonexistent_instance(self, file_storage: FileStorage) -> None:
        """Test retrieving a non-existent instance returns None."""
        result = file_storage.get("nonexistent-instance")
        assert result is None

    def test_update_instance(self, file_storage: FileStorage) -> None:
        """Test updating an existing instance."""
        instance_id = "test-instance-1"
        data = {"service_id": "mysql-service", "plan_id": "small"}

        file_storage.create(instance_id, data)

        # Update the instance
        update_data = {"plan_id": "large", "parameters": {"db_name": "newdb"}}
        file_storage.update(instance_id, update_data)

        # Verify update
        retrieved = file_storage.get(instance_id)
        assert retrieved is not None
        assert retrieved["plan_id"] == "large"
        assert retrieved["parameters"]["db_name"] == "newdb"
        assert retrieved["service_id"] == "mysql-service"  # Original field preserved

    def test_update_nonexistent_instance(self, file_storage: FileStorage) -> None:
        """Test that updating a non-existent instance raises an error."""
        with pytest.raises(ValueError, match="not found"):
            file_storage.update("nonexistent-instance", {"plan_id": "large"})

    def test_delete_existing_instance(self, file_storage: FileStorage) -> None:
        """Test deleting an existing instance."""
        instance_id = "test-instance-1"
        data = {"service_id": "mysql-service", "plan_id": "small"}

        file_storage.create(instance_id, data)
        assert file_storage.exists(instance_id)

        # Delete the instance
        result = file_storage.delete(instance_id)
        assert result is True
        assert not file_storage.exists(instance_id)

    def test_delete_nonexistent_instance(self, file_storage: FileStorage) -> None:
        """Test deleting a non-existent instance returns False."""
        result = file_storage.delete("nonexistent-instance")
        assert result is False

    def test_exists_for_existing_instance(self, file_storage: FileStorage) -> None:
        """Test exists() returns True for existing instance."""
        instance_id = "test-instance-1"
        data = {"service_id": "mysql-service", "plan_id": "small"}

        file_storage.create(instance_id, data)
        assert file_storage.exists(instance_id) is True

    def test_exists_for_nonexistent_instance(self, file_storage: FileStorage) -> None:
        """Test exists() returns False for non-existent instance."""
        assert file_storage.exists("nonexistent-instance") is False

    def test_list_all_empty(self, file_storage: FileStorage) -> None:
        """Test listing instances when storage is empty."""
        instances = file_storage.list_all()
        assert instances == []

    def test_list_all_with_instances(self, file_storage: FileStorage) -> None:
        """Test listing all instances."""
        # Create multiple instances
        file_storage.create("instance-1", {"service_id": "mysql-service", "plan_id": "small"})
        file_storage.create("instance-2", {"service_id": "postgres-service", "plan_id": "medium"})
        file_storage.create("instance-3", {"service_id": "redis-service", "plan_id": "large"})

        instances = file_storage.list_all()
        assert len(instances) == 3

        # Verify all instances are present
        instance_ids = {inst.get("instance_id") for inst in instances}
        assert "instance-1" in instance_ids
        assert "instance-2" in instance_ids
        assert "instance-3" in instance_ids


class TestFileStorageHelpers:
    """Test helper methods."""

    def test_get_instance_path(self, file_storage: FileStorage) -> None:
        """Test instance path generation."""
        path = file_storage._get_instance_path("test-instance")
        assert path.name == "test-instance.json"
        assert path.parent == file_storage.storage_dir

    def test_get_instance_path_with_special_chars(self, file_storage: FileStorage) -> None:
        """Test instance path generation with special characters."""
        # Special characters should be sanitized
        path = file_storage._get_instance_path("test/instance:with:special")
        assert "/" not in path.name
        assert ":" not in path.name
        assert path.name == "test_instance_with_special.json"


class TestFileStorageEdgeCases:
    """Test edge cases and error handling."""

    def test_operations_before_init(self) -> None:
        """Test that operations before init() raise appropriate errors."""
        storage = FileStorage()

        with pytest.raises(RuntimeError, match="not initialized"):
            storage._get_instance_path("test")

        with pytest.raises(RuntimeError, match="not initialized"):
            storage.list_all()

    def test_invalid_json_in_storage(
        self, file_storage: FileStorage, temp_storage_dir: Path
    ) -> None:
        """Test handling of invalid JSON files in storage."""
        # Create an invalid JSON file
        invalid_file = temp_storage_dir / "invalid.json"
        invalid_file.write_text("{ invalid json }")

        # list_all should skip invalid files and continue
        instances = file_storage.list_all()
        assert instances == []

    def test_concurrent_access(self, file_storage: FileStorage) -> None:
        """Test that concurrent operations don't corrupt data."""
        instance_id = "test-instance"
        data = {"service_id": "mysql-service", "plan_id": "small"}

        # Create instance
        file_storage.create(instance_id, data)

        # Multiple updates
        for i in range(10):
            file_storage.update(instance_id, {"counter": i})

        # Verify final state
        retrieved = file_storage.get(instance_id)
        assert retrieved is not None
        assert retrieved["counter"] == 9


# Made with Bob
