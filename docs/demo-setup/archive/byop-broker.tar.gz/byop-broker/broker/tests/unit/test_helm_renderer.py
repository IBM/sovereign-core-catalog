"""Unit tests for Helm chart rendering module."""

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from broker.gitops.helm_renderer import (
    HelmRenderError,
    is_helm_available,
    render_helm_chart_to_yaml,
    validate_helm_chart,
)


class TestIsHelmAvailable:
    """Tests for is_helm_available function."""

    @patch("broker.gitops.helm_renderer.shutil.which")
    def test_helm_available(self, mock_which: MagicMock) -> None:
        """Test when Helm is available."""
        mock_which.return_value = "/usr/local/bin/helm"
        assert is_helm_available() is True
        mock_which.assert_called_once_with("helm")

    @patch("broker.gitops.helm_renderer.shutil.which")
    def test_helm_not_available(self, mock_which: MagicMock) -> None:
        """Test when Helm is not available."""
        mock_which.return_value = None
        assert is_helm_available() is False
        mock_which.assert_called_once_with("helm")


class TestRenderHelmChartToYaml:
    """Tests for render_helm_chart_to_yaml function."""

    @patch("broker.gitops.helm_renderer.is_helm_available")
    @patch("broker.gitops.helm_renderer.subprocess.run")
    def test_successful_render(
        self,
        mock_run: MagicMock,
        mock_helm_available: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Test successful Helm chart rendering."""
        # Setup
        mock_helm_available.return_value = True
        mock_run.return_value = MagicMock(
            stdout="apiVersion: v1\nkind: Service\nmetadata:\n  name: test\n"
        )

        values_file = tmp_path / "values.yaml"
        values_file.write_text("key: value\n")

        output_file = tmp_path / "manifests" / "all.yaml"

        # Execute
        render_helm_chart_to_yaml(
            chart_url="https://example.com/charts/test",
            chart_version="1.0.0",
            release_name="test-release",
            namespace="test-ns",
            values_file=values_file,
            output_file=output_file,
        )

        # Verify
        assert output_file.exists()
        assert "apiVersion: v1" in output_file.read_text()
        mock_run.assert_called_once()

    @patch("broker.gitops.helm_renderer.is_helm_available")
    def test_values_file_not_found(
        self,
        mock_helm_available: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Test error when values file doesn't exist."""
        mock_helm_available.return_value = True

        values_file = tmp_path / "nonexistent.yaml"
        output_file = tmp_path / "output.yaml"

        with pytest.raises(FileNotFoundError):
            render_helm_chart_to_yaml(
                chart_url="https://example.com/charts/test",
                chart_version="1.0.0",
                release_name="test-release",
                namespace="test-ns",
                values_file=values_file,
                output_file=output_file,
            )

    @patch("broker.gitops.helm_renderer.is_helm_available")
    def test_helm_not_available(
        self,
        mock_helm_available: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Test error when Helm is not available."""
        mock_helm_available.return_value = False

        values_file = tmp_path / "values.yaml"
        values_file.write_text("key: value\n")
        output_file = tmp_path / "output.yaml"

        with pytest.raises(HelmRenderError, match="Helm binary not found"):
            render_helm_chart_to_yaml(
                chart_url="https://example.com/charts/test",
                chart_version="1.0.0",
                release_name="test-release",
                namespace="test-ns",
                values_file=values_file,
                output_file=output_file,
            )

    @patch("broker.gitops.helm_renderer.is_helm_available")
    @patch("broker.gitops.helm_renderer.subprocess.run")
    def test_helm_command_timeout(
        self,
        mock_run: MagicMock,
        mock_helm_available: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Test timeout during Helm command execution."""
        mock_helm_available.return_value = True
        mock_run.side_effect = subprocess.TimeoutExpired(cmd=["helm"], timeout=300)

        values_file = tmp_path / "values.yaml"
        values_file.write_text("key: value\n")
        output_file = tmp_path / "output.yaml"

        with pytest.raises(HelmRenderError, match="timed out"):
            render_helm_chart_to_yaml(
                chart_url="https://example.com/charts/test",
                chart_version="1.0.0",
                release_name="test-release",
                namespace="test-ns",
                values_file=values_file,
                output_file=output_file,
            )

    @patch("broker.gitops.helm_renderer.is_helm_available")
    @patch("broker.gitops.helm_renderer.subprocess.run")
    def test_helm_command_failure(
        self,
        mock_run: MagicMock,
        mock_helm_available: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Test failure during Helm command execution."""
        mock_helm_available.return_value = True
        mock_run.side_effect = subprocess.CalledProcessError(
            returncode=1,
            cmd=["helm"],
            stderr="Error: chart not found",
        )

        values_file = tmp_path / "values.yaml"
        values_file.write_text("key: value\n")
        output_file = tmp_path / "output.yaml"

        with pytest.raises(HelmRenderError, match="Helm template command failed"):
            render_helm_chart_to_yaml(
                chart_url="https://example.com/charts/test",
                chart_version="1.0.0",
                release_name="test-release",
                namespace="test-ns",
                values_file=values_file,
                output_file=output_file,
            )


class TestValidateHelmChart:
    """Tests for validate_helm_chart function."""

    @patch("broker.gitops.helm_renderer.is_helm_available")
    @patch("broker.gitops.helm_renderer.subprocess.run")
    def test_valid_chart(
        self,
        mock_run: MagicMock,
        mock_helm_available: MagicMock,
    ) -> None:
        """Test validation of valid Helm chart."""
        mock_helm_available.return_value = True
        mock_run.return_value = MagicMock(stdout="name: test\nversion: 1.0.0\n")

        result = validate_helm_chart(
            chart_url="https://example.com/charts/test",
            chart_version="1.0.0",
        )

        assert result is True
        mock_run.assert_called_once()

    @patch("broker.gitops.helm_renderer.is_helm_available")
    def test_helm_not_available(
        self,
        mock_helm_available: MagicMock,
    ) -> None:
        """Test validation when Helm is not available."""
        mock_helm_available.return_value = False

        result = validate_helm_chart(
            chart_url="https://example.com/charts/test",
            chart_version="1.0.0",
        )

        assert result is False

    @patch("broker.gitops.helm_renderer.is_helm_available")
    @patch("broker.gitops.helm_renderer.subprocess.run")
    def test_invalid_chart(
        self,
        mock_run: MagicMock,
        mock_helm_available: MagicMock,
    ) -> None:
        """Test validation of invalid Helm chart."""
        mock_helm_available.return_value = True
        mock_run.side_effect = subprocess.CalledProcessError(
            returncode=1,
            cmd=["helm"],
            stderr="Error: chart not found",
        )

        result = validate_helm_chart(
            chart_url="https://example.com/charts/test",
            chart_version="1.0.0",
        )

        assert result is False


# Made with Bob
