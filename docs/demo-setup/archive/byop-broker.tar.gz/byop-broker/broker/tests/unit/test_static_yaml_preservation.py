"""Test that static YAML content is preserved during template rendering.

This test reproduces the issue where image overrides (static YAML without Jinja2
variables) are being stripped from rendered templates.
"""

from pathlib import Path

from broker.gitops.template_renderer import TemplateRenderer


def test_static_yaml_content_preserved(tmp_path):
    """Test that static YAML sections without Jinja2 variables are preserved."""

    # Create a mock GitOps repo structure
    repo_dir = tmp_path / "gitops-repo"
    service_dir = repo_dir / "services" / "mariadb" / "latest" / "template"
    service_dir.mkdir(parents=True)

    # Create a values.yaml.tmpl with static image overrides (like from service-render.sh)
    template_content = """# KubeLauncher MariaDB Helm Chart Values Override

{%- if spec.plan == "small" -%}
{%- set storage = "2Gi" -%}
{%- set mem_request = "128Mi" -%}
{%- elif spec.plan == "standard" -%}
{%- set storage = "8Gi" -%}
{%- set mem_request = "256Mi" -%}
{%- else -%}
{%- set storage = spec.storage_size -%}
{%- set mem_request = spec.resources_memory_request -%}
{%- endif -%}

# Image overrides for air-gapped/mirrored environments (auto-generated)
image:
  registry: registry.example.com/your-org
  repository: mariadb
  tag: "12.2.2"

metrics:
  image:
    registry: registry.example.com/your-org
    repository: mysqld-exporter
    tag: "0.18.0"

# Common labels applied to all resources
commonLabels:
  app: mariadb
  service-type: mariadb-kubelauncher
  instance: {{ instance_name }}
  instance-id: "{{ instance_id }}"

# MariaDB authentication configuration
auth:
  database: {{ spec.database_name | yaml_safe }}
  username: {{ spec.database_user | yaml_safe }}
  password: {{ spec.database_password | yaml_safe }}

# Persistence configuration
persistence:
  enabled: true
  size: {{ storage }}
  storageClass: ''

# Resource configuration
resources:
  requests:
    memory: {{ mem_request }}
"""

    # Write template file
    template_file = service_dir / "values.yaml.tmpl"
    template_file.write_text(template_content)

    # Create schema.json (required by template loader)
    schema_file = service_dir.parent.parent / "catalog" / "schema.json"
    schema_file.parent.mkdir(parents=True, exist_ok=True)
    schema_file.write_text('{"type": "object", "properties": {}}')

    # Initialize template renderer
    renderer = TemplateRenderer(repo_dir)

    # Render template with context
    context = {
        "instance_name": "test-instance",
        "instance_id": "test-123",
        "spec": {
            "plan": "standard",
            "database_name": "myapp",
            "database_user": "appuser",
            "database_password": "secret123",
        },
    }

    # Render the template
    rendered = renderer.render_templates("mariadb", context, service_version="latest")

    # Get rendered values.yaml
    rendered_values = rendered.get("values.yaml.tmpl", "")

    # Assert that static image overrides are preserved
    assert "image:" in rendered_values, "Image section missing from rendered output"
    assert (
        "registry: registry.example.com/your-org"
        in rendered_values
    ), "Image registry override missing"
    assert "repository: mariadb" in rendered_values, "Image repository missing"
    assert 'tag: "12.2.2"' in rendered_values, "Image tag missing"

    # Assert metrics image overrides are preserved
    assert "metrics:" in rendered_values, "Metrics section missing"
    assert "repository: mysqld-exporter" in rendered_values, "Metrics exporter repository missing"
    assert 'tag: "0.18.0"' in rendered_values, "Metrics exporter tag missing"

    # Assert dynamic content is rendered correctly
    assert "instance: test-instance" in rendered_values, "Instance name not rendered"
    assert "database: myapp" in rendered_values, "Database name not rendered"
    assert "size: 8Gi" in rendered_values, (
        "Storage size not rendered (should be 8Gi for standard plan)"
    )
    assert "memory: 256Mi" in rendered_values, "Memory request not rendered"

    # Print rendered output for debugging
    print("\n=== RENDERED VALUES.YAML ===")
    print(rendered_values)
    print("=== END ===")


if __name__ == "__main__":
    # Run test directly
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        test_static_yaml_content_preserved(Path(tmpdir))
        print("\n✅ Test passed! Static YAML content is preserved.")

# Made with Bob
