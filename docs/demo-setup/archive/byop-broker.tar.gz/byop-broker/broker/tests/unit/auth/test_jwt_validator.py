"""Unit tests for JWT validator module."""

import time
from datetime import datetime, timedelta, timezone
from unittest.mock import Mock, patch

import jwt
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from broker.auth.config import AuthConfig
from broker.auth.exceptions import (
    InvalidClaimError,
    InvalidSignatureError,
    InvalidTokenError,
    JWKSError,
    MissingClaimError,
    TokenExpiredError,
)
from broker.auth.jwt_validator import JWKSClient, JWTValidator


class TestJWKSClient:
    """Test JWKS client functionality."""

    def test_init(self):
        """Test JWKS client initialization."""
        client = JWKSClient("https://example.com/.well-known/jwks.json", cache_ttl=7200)

        assert client.jwks_url == "https://example.com/.well-known/jwks.json"
        assert client.cache_ttl == 7200
        assert client._jwks_cache is None
        assert client._cache_timestamp == 0.0

    def test_fetch_jwks_success(self):
        """Test successful JWKS fetching."""
        jwks_data = {"keys": [{"kty": "RSA", "kid": "test-key"}]}

        with patch("requests.get") as mock_get:
            mock_response = Mock()
            mock_response.json.return_value = jwks_data
            mock_response.raise_for_status = Mock()
            mock_get.return_value = mock_response

            client = JWKSClient("https://example.com/.well-known/jwks.json")
            result = client.fetch_jwks()

            assert result == jwks_data
            assert client._jwks_cache == jwks_data
            mock_get.assert_called_once()

    def test_fetch_jwks_http_error(self):
        """Test JWKS fetching with HTTP error."""
        import requests

        with patch("requests.get") as mock_get:
            mock_get.side_effect = requests.RequestException("HTTP 404")

            client = JWKSClient("https://example.com/.well-known/jwks.json")

            with pytest.raises(JWKSError, match="Failed to fetch JWKS"):
                client.fetch_jwks()

    def test_fetch_jwks_invalid_json(self):
        """Test JWKS fetching with invalid JSON response."""
        with patch("requests.get") as mock_get:
            mock_response = Mock()
            mock_response.json.side_effect = ValueError("Invalid JSON")
            mock_response.raise_for_status = Mock()
            mock_get.return_value = mock_response

            client = JWKSClient("https://example.com/.well-known/jwks.json")

            with pytest.raises(JWKSError, match="Invalid JWKS response"):
                client.fetch_jwks()

    def test_jwks_caching(self):
        """Test JWKS caching mechanism."""
        jwks_data = {"keys": [{"kty": "RSA", "kid": "test-key"}]}

        with patch("requests.get") as mock_get:
            mock_response = Mock()
            mock_response.json.return_value = jwks_data
            mock_response.raise_for_status = Mock()
            mock_get.return_value = mock_response

            client = JWKSClient("https://example.com/.well-known/jwks.json", cache_ttl=3600)

            # First call should fetch
            result1 = client.fetch_jwks()
            assert mock_get.call_count == 1

            # Second call should use cache
            result2 = client.fetch_jwks()
            assert mock_get.call_count == 1  # Still 1, not 2
            assert result1 == result2

    def test_jwks_cache_expiration(self):
        """Test JWKS cache expiration."""
        jwks_data = {"keys": [{"kty": "RSA", "kid": "test-key"}]}

        with patch("requests.get") as mock_get:
            mock_response = Mock()
            mock_response.json.return_value = jwks_data
            mock_response.raise_for_status = Mock()
            mock_get.return_value = mock_response

            # Use very short TTL for testing
            client = JWKSClient("https://example.com/.well-known/jwks.json", cache_ttl=1)

            # First call
            client.fetch_jwks()
            assert mock_get.call_count == 1

            # Wait for cache to expire
            time.sleep(1.1)

            # Second call should fetch again
            client.fetch_jwks()
            assert mock_get.call_count == 2

    def test_refresh_cache(self):
        """Test forcing cache refresh."""
        jwks_data = {"keys": [{"kty": "RSA", "kid": "test-key"}]}

        with patch("requests.get") as mock_get:
            mock_response = Mock()
            mock_response.json.return_value = jwks_data
            mock_response.raise_for_status = Mock()
            mock_get.return_value = mock_response

            client = JWKSClient("https://example.com/.well-known/jwks.json")

            # Fetch and cache
            client.fetch_jwks()
            assert client._jwks_cache is not None

            # Force refresh
            client.refresh_cache()
            assert mock_get.call_count == 2


class TestJWTValidator:
    """Test JWT validator functionality."""

    @pytest.fixture
    def rsa_keys(self):
        """Generate RSA key pair for testing."""
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )

        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )

        public_key = private_key.public_key()
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

        return private_pem, public_pem

    @pytest.fixture
    def auth_config(self):
        """Create test auth configuration."""
        return AuthConfig(
            enabled=True,
            jwks_url="https://example.com/.well-known/jwks.json",
            issuer="https://example.com",
            audience="test-audience",
            algorithms=["RS256"],
        )

    @pytest.fixture
    def validator(self, auth_config):
        """Create JWT validator instance."""
        return JWTValidator(auth_config)

    def create_token(
        self,
        private_key: bytes,
        issuer: str = "https://example.com",
        audience: str = "test-audience",
        subject: str = "test-user",
        kid: str = "test-key-id",
        exp_delta: timedelta = timedelta(hours=1),
        **extra_claims,
    ) -> str:
        """Create a test JWT token."""
        now = datetime.now(timezone.utc)

        payload = {
            "iss": issuer,
            "aud": audience,
            "sub": subject,
            "iat": now,
            "exp": now + exp_delta,
            **extra_claims,
        }

        return jwt.encode(payload, private_key, algorithm="RS256", headers={"kid": kid})

    def test_init(self, auth_config):
        """Test validator initialization."""
        validator = JWTValidator(auth_config)

        assert validator.config == auth_config
        assert validator.jwks_client is not None
        assert validator.jwks_client.jwks_url == auth_config.jwks_url

    def test_validate_token_success(self, validator, rsa_keys):
        """Test successful token validation."""
        private_key, public_key = rsa_keys
        token = self.create_token(private_key)

        with patch.object(validator.jwks_client, "get_signing_key") as mock_get_key:
            mock_get_key.return_value = public_key

            claims = validator.validate_token(token)

            assert claims["iss"] == "https://example.com"
            assert claims["aud"] == "test-audience"
            assert claims["sub"] == "test-user"

    def test_validate_token_expired(self, validator, rsa_keys):
        """Test validation of expired token."""
        private_key, public_key = rsa_keys
        # Create token that expired 1 hour ago
        token = self.create_token(private_key, exp_delta=timedelta(hours=-1))

        with patch.object(validator.jwks_client, "get_signing_key") as mock_get_key:
            mock_get_key.return_value = public_key

            with pytest.raises(TokenExpiredError, match="Token has expired"):
                validator.validate_token(token)

    def test_validate_token_invalid_issuer(self, validator, rsa_keys):
        """Test validation with invalid issuer."""
        private_key, public_key = rsa_keys
        token = self.create_token(private_key, issuer="https://wrong-issuer.com")

        with patch.object(validator.jwks_client, "get_signing_key") as mock_get_key:
            mock_get_key.return_value = public_key

            with pytest.raises(InvalidClaimError, match="Invalid issuer"):
                validator.validate_token(token)

    def test_validate_token_invalid_audience(self, validator, rsa_keys):
        """Test validation with invalid audience."""
        private_key, public_key = rsa_keys
        token = self.create_token(private_key, audience="wrong-audience")

        with patch.object(validator.jwks_client, "get_signing_key") as mock_get_key:
            mock_get_key.return_value = public_key

            with pytest.raises(InvalidClaimError, match="Invalid audience"):
                validator.validate_token(token)

    def test_validate_token_invalid_signature(self, validator, rsa_keys):
        """Test validation with invalid signature."""
        private_key, _ = rsa_keys

        # Create token with one key
        token = self.create_token(private_key)

        # Try to validate with different key
        different_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
        different_public = different_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

        with patch.object(validator.jwks_client, "get_signing_key") as mock_get_key:
            mock_get_key.return_value = different_public

            with pytest.raises(InvalidSignatureError, match="Invalid token signature"):
                validator.validate_token(token)

    def test_validate_token_malformed(self, validator):
        """Test validation with malformed token."""
        with pytest.raises(InvalidTokenError):
            validator.validate_token("not.a.valid.jwt.token")

    def test_validate_token_with_custom_claims(self, validator, rsa_keys):
        """Test validation preserves custom claims."""
        private_key, public_key = rsa_keys
        token = self.create_token(private_key, custom_claim="custom_value", roles=["admin", "user"])

        with patch.object(validator.jwks_client, "get_signing_key") as mock_get_key:
            mock_get_key.return_value = public_key

            claims = validator.validate_token(token)

            assert claims["custom_claim"] == "custom_value"
            assert claims["roles"] == ["admin", "user"]

    def test_decode_token_without_validation(self, validator, rsa_keys):
        """Test decoding token without validation."""
        private_key, _ = rsa_keys
        token = self.create_token(private_key, custom_field="test_value")

        payload = validator.decode_token(token)

        assert payload["iss"] == "https://example.com"
        assert payload["aud"] == "test-audience"
        assert payload["custom_field"] == "test_value"

    def test_verify_claims_success(self, validator):
        """Test successful claims verification."""
        payload = {
            "iss": "https://example.com",
            "aud": "test-audience",
            "exp": datetime.now(timezone.utc) + timedelta(hours=1),
            "sub": "test-user",
        }

        assert validator.verify_claims(payload) is True

    def test_verify_claims_missing_claim(self, validator):
        """Test claims verification with missing required claim."""
        payload = {
            "iss": "https://example.com",
            "aud": "test-audience",
            # Missing 'exp'
        }

        with pytest.raises(MissingClaimError, match="Missing required claim: exp"):
            validator.verify_claims(payload)

    def test_verify_claims_invalid_issuer(self, validator):
        """Test claims verification with invalid issuer."""
        payload = {
            "iss": "https://wrong-issuer.com",
            "aud": "test-audience",
            "exp": datetime.now(timezone.utc) + timedelta(hours=1),
        }

        with pytest.raises(InvalidClaimError, match="Invalid issuer"):
            validator.verify_claims(payload)

    def test_verify_claims_invalid_audience(self, validator):
        """Test claims verification with invalid audience."""
        payload = {
            "iss": "https://example.com",
            "aud": "wrong-audience",
            "exp": datetime.now(timezone.utc) + timedelta(hours=1),
        }

        with pytest.raises(InvalidClaimError, match="Invalid audience"):
            validator.verify_claims(payload)

    def test_verify_claims_audience_list(self, validator):
        """Test claims verification with audience as list."""
        payload = {
            "iss": "https://example.com",
            "aud": ["test-audience", "other-audience"],
            "exp": datetime.now(timezone.utc) + timedelta(hours=1),
        }

        assert validator.verify_claims(payload) is True


# Made with Bob
