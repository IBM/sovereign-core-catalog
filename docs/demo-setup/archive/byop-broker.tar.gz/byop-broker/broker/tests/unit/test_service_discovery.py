"""Unit tests for service discovery module."""

from pathlib import Path

from broker.gitops.service_discovery import (
    discover_available_services,
    get_service_directory,
    is_service_available,
    validate_service_type,
)


def test_discover_available_services_success(mock_gitops_repo: Path):
    """Test discovering services from a valid repository."""
    services = discover_available_services(mock_gitops_repo)

    assert services == ["mariadb", "mysql", "postgres"]
    assert len(services) == 3


def test_discover_available_services_empty_directory(tmp_path: Path):
    """Test discovering services from an empty services directory."""
    repo_dir = tmp_path / "empty-repo"
    services_dir = repo_dir / "services"
    services_dir.mkdir(parents=True)

    services = discover_available_services(repo_dir)

    assert services == []


def test_discover_available_services_no_services_directory(tmp_path: Path):
    """Test discovering services when services directory doesn't exist."""
    repo_dir = tmp_path / "no-services-repo"
    repo_dir.mkdir()

    services = discover_available_services(repo_dir)

    assert services == []


def test_discover_available_services_services_is_file(tmp_path: Path):
    """Test discovering services when 'services' is a file, not a directory."""
    repo_dir = tmp_path / "invalid-repo"
    repo_dir.mkdir()
    (repo_dir / "services").write_text("not a directory")

    services = discover_available_services(repo_dir)

    assert services == []


def test_is_service_available_valid_service(mock_gitops_repo: Path):
    """Test checking if a valid service is available."""
    assert is_service_available(mock_gitops_repo, "mysql") is True
    assert is_service_available(mock_gitops_repo, "mariadb") is True
    assert is_service_available(mock_gitops_repo, "postgres") is True


def test_is_service_available_invalid_service(mock_gitops_repo: Path):
    """Test checking if an invalid service is available."""
    assert is_service_available(mock_gitops_repo, "redis") is False
    assert is_service_available(mock_gitops_repo, "rabbitmq") is False


def test_is_service_available_empty_string(mock_gitops_repo: Path):
    """Test checking availability with empty service name."""
    assert is_service_available(mock_gitops_repo, "") is False


def test_get_service_directory_valid_service(mock_gitops_repo: Path):
    """Test getting directory for a valid service."""
    mysql_dir = get_service_directory(mock_gitops_repo, "mysql")

    assert mysql_dir is not None
    assert mysql_dir.exists()
    assert mysql_dir.is_dir()
    assert mysql_dir.name == "mysql"
    assert (mysql_dir / "latest" / "catalog" / "catalog.yaml").exists()


def test_get_service_directory_invalid_service(mock_gitops_repo: Path):
    """Test getting directory for an invalid service."""
    redis_dir = get_service_directory(mock_gitops_repo, "redis")

    assert redis_dir is None


def test_validate_service_type_valid(mock_gitops_repo: Path):
    """Test validating a valid service type."""
    is_valid, error = validate_service_type(mock_gitops_repo, "mysql")

    assert is_valid is True
    assert error == ""


def test_validate_service_type_invalid(mock_gitops_repo: Path):
    """Test validating an invalid service type."""
    is_valid, error = validate_service_type(mock_gitops_repo, "redis")

    assert is_valid is False
    assert "redis" in error
    assert "Available services:" in error
    assert "mysql" in error


def test_validate_service_type_empty_string(mock_gitops_repo: Path):
    """Test validating an empty service type."""
    is_valid, error = validate_service_type(mock_gitops_repo, "")

    assert is_valid is False
    assert "cannot be empty" in error


def test_validate_service_type_no_services(tmp_path: Path):
    """Test validating when no services are available."""
    repo_dir = tmp_path / "empty-repo"
    services_dir = repo_dir / "services"
    services_dir.mkdir(parents=True)

    is_valid, error = validate_service_type(repo_dir, "mysql")

    assert is_valid is False
    assert "No services are available" in error


def test_discover_services_sorted_order(tmp_path: Path):
    """Test that discovered services are returned in sorted order."""
    repo_dir = tmp_path / "sorted-repo"
    services_dir = repo_dir / "services"
    services_dir.mkdir(parents=True)

    # Create services in non-alphabetical order
    for service in ["zebra", "alpha", "mysql", "beta"]:
        service_latest = services_dir / service / "latest"
        catalog_dir = service_latest / "catalog"
        catalog_dir.mkdir(parents=True)
        (catalog_dir / "catalog.yaml").write_text(f"name: {service}\n")

    services = discover_available_services(repo_dir)

    assert services == ["alpha", "beta", "mysql", "zebra"]


def test_discover_services_with_files_in_services_dir(tmp_path: Path):
    """Test that files in services directory are skipped."""
    repo_dir = tmp_path / "files-repo"
    services_dir = repo_dir / "services"
    services_dir.mkdir(parents=True)

    # Create a valid service
    mysql_latest = services_dir / "mysql" / "latest"
    catalog_dir = mysql_latest / "catalog"
    catalog_dir.mkdir(parents=True)
    (catalog_dir / "catalog.yaml").write_text("name: mysql\n")

    # Create a file in services directory (should be skipped)
    (services_dir / "README.md").write_text("# Services\n")
    (services_dir / "config.json").write_text("{}\n")

    services = discover_available_services(repo_dir)

    assert services == ["mysql"]
    assert "README.md" not in services
    assert "config.json" not in services


def test_is_service_available_case_sensitive(mock_gitops_repo: Path):
    """Test that service name matching is case-sensitive on case-sensitive filesystems."""
    assert is_service_available(mock_gitops_repo, "mysql") is True
    # Note: Case sensitivity tests removed - filesystem behavior varies by OS
    # On macOS (case-insensitive by default), MySQL would match mysql
    # On Linux (case-sensitive), MySQL would not match mysql


def test_get_service_directory_returns_correct_path(mock_gitops_repo: Path):
    """Test that get_service_directory returns the correct path."""
    mysql_dir = get_service_directory(mock_gitops_repo, "mysql")

    assert mysql_dir is not None
    expected_path = mock_gitops_repo / "services" / "mysql"
    assert mysql_dir == expected_path


# Made with Bob
