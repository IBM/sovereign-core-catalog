"""Unit tests for schema_validator module."""

import json
from pathlib import Path

import pytest

from broker.gitops.schema_validator import SchemaValidator, ValidationError
from broker.gitops.template_loader import TemplateLoadError


class TestSchemaValidatorInit:
    """Test SchemaValidator initialization."""

    def test_init_with_valid_directory(self, tmp_path: Path) -> None:
        """Test initialization with valid repository directory."""
        validator = SchemaValidator(tmp_path)
        assert validator.template_loader.repo_dir == tmp_path

    def test_init_with_nonexistent_directory(self, tmp_path: Path) -> None:
        """Test initialization with non-existent directory."""
        nonexistent = tmp_path / "nonexistent"
        with pytest.raises(TemplateLoadError, match="Repository directory not found"):
            SchemaValidator(nonexistent)


class TestValidate:
    """Test parameter validation."""

    def test_validate_success(self, mock_gitops_repo: Path) -> None:
        """Test successful validation."""
        # Validate parameters
        validator = SchemaValidator(mock_gitops_repo)
        parameters = {"database_name": "myapp", "database_user": "appuser"}
        validator.validate("mysql", parameters)  # Should not raise

    def test_validate_missing_required_field(self, mock_gitops_repo: Path) -> None:
        """Test validation fails when required field is missing."""
        # Validate with missing field
        validator = SchemaValidator(mock_gitops_repo)
        with pytest.raises(ValidationError, match="Parameter validation failed"):
            validator.validate("mysql", {})

    def test_validate_wrong_type(self, tmp_path: Path) -> None:
        """Test validation fails when field has wrong type."""
        # Create schema
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {"port": {"type": "integer"}},
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Validate with wrong type
        validator = SchemaValidator(tmp_path)
        with pytest.raises(ValidationError, match="Must be of type integer"):
            validator.validate("mysql", {"port": "not-a-number"})

    def test_validate_pattern_mismatch(self, tmp_path: Path) -> None:
        """Test validation fails when pattern doesn't match."""
        # Create schema with pattern
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {
                "database_name": {"type": "string", "pattern": "^[a-zA-Z][a-zA-Z0-9_]*$"}
            },
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Validate with invalid pattern
        validator = SchemaValidator(tmp_path)
        with pytest.raises(ValidationError, match="Must match pattern"):
            validator.validate("mysql", {"database_name": "123invalid"})

    def test_validate_min_length(self, tmp_path: Path) -> None:
        """Test validation fails when string is too short."""
        # Create schema with minLength
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {"password": {"type": "string", "minLength": 8}},
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Validate with too short string
        validator = SchemaValidator(tmp_path)
        with pytest.raises(ValidationError, match="Must be at least 8 characters"):
            validator.validate("mysql", {"password": "short"})

    def test_validate_max_length(self, tmp_path: Path) -> None:
        """Test validation fails when string is too long."""
        # Create schema with maxLength
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {"username": {"type": "string", "maxLength": 10}},
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Validate with too long string
        validator = SchemaValidator(tmp_path)
        with pytest.raises(ValidationError, match="Must be at most 10 characters"):
            validator.validate("mysql", {"username": "verylongusername"})

    def test_validate_enum(self, tmp_path: Path) -> None:
        """Test validation with enum constraint."""
        # Create schema with enum
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {"size": {"type": "string", "enum": ["small", "medium", "large"]}},
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Validate with invalid enum value
        validator = SchemaValidator(tmp_path)
        with pytest.raises(ValidationError, match="Must be one of"):
            validator.validate("mysql", {"size": "xlarge"})

    def test_validate_error_includes_field_path(self, mock_gitops_repo: Path) -> None:
        """Test validation error includes field path."""
        # Validate and check error
        validator = SchemaValidator(mock_gitops_repo)
        with pytest.raises(ValidationError) as exc_info:
            validator.validate("mysql", {})

        assert exc_info.value.errors
        assert exc_info.value.errors[0]["field"] == "root"
        assert "database_name" in exc_info.value.errors[0]["message"]


class TestValidateWithDefaults:
    """Test validation with default value application."""

    def test_validate_with_defaults_applies_defaults(self, tmp_path: Path) -> None:
        """Test that default values are applied."""
        # Create schema with defaults
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {
                "database_name": {"type": "string"},
                "database_user": {"type": "string", "default": "appuser"},
                "port": {"type": "integer", "default": 3306},
            },
            "required": ["database_name"],
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Validate with defaults
        validator = SchemaValidator(tmp_path)
        parameters = {"database_name": "myapp"}
        result = validator.validate_with_defaults("mysql", parameters)

        assert result["database_name"] == "myapp"
        assert result["database_user"] == "appuser"  # Default applied
        assert result["port"] == 3306  # Default applied

    def test_validate_with_defaults_preserves_provided_values(self, tmp_path: Path) -> None:
        """Test that provided values are not overridden by defaults."""
        # Create schema with defaults
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {
                "database_user": {"type": "string", "default": "appuser"},
            },
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Validate with provided value
        validator = SchemaValidator(tmp_path)
        parameters = {"database_user": "customuser"}
        result = validator.validate_with_defaults("mysql", parameters)

        assert result["database_user"] == "customuser"  # Not overridden

    def test_validate_with_defaults_validates_after_applying(self, tmp_path: Path) -> None:
        """Test that validation occurs after applying defaults."""
        # Create schema with defaults and validation
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {
                "database_name": {"type": "string"},
            },
            "required": ["database_name"],
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Validate without required field (no default)
        validator = SchemaValidator(tmp_path)
        with pytest.raises(ValidationError):
            validator.validate_with_defaults("mysql", {})


class TestGetRequiredFields:
    """Test getting required fields from schema."""

    def test_get_required_fields(self, tmp_path: Path) -> None:
        """Test getting list of required fields."""
        # Create schema
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {
                "database_name": {"type": "string"},
                "database_user": {"type": "string"},
            },
            "required": ["database_name", "database_user"],
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Get required fields
        validator = SchemaValidator(tmp_path)
        required = validator.get_required_fields("mysql")

        assert required == ["database_name", "database_user"]

    def test_get_required_fields_empty(self, tmp_path: Path) -> None:
        """Test getting required fields when none are required."""
        # Create schema without required fields
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {"database_name": {"type": "string"}},
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Get required fields
        validator = SchemaValidator(tmp_path)
        required = validator.get_required_fields("mysql")

        assert required == []


class TestGetSchemaProperties:
    """Test getting schema properties."""

    def test_get_schema_properties(self, tmp_path: Path) -> None:
        """Test getting schema property definitions."""
        # Create schema
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {
                "database_name": {
                    "type": "string",
                    "description": "Database name",
                    "minLength": 1,
                },
                "port": {"type": "integer", "default": 3306},
            },
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Get properties
        validator = SchemaValidator(tmp_path)
        properties = validator.get_schema_properties("mysql")

        assert "database_name" in properties
        assert properties["database_name"]["type"] == "string"
        assert properties["database_name"]["description"] == "Database name"
        assert "port" in properties
        assert properties["port"]["default"] == 3306


class TestErrorFormatting:
    """Test error message formatting."""

    def test_error_formatting_required_field(self, tmp_path: Path) -> None:
        """Test error message for required field."""
        # Create schema
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {"database_name": {"type": "string"}},
            "required": ["database_name"],
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Validate and check error message
        validator = SchemaValidator(tmp_path)
        with pytest.raises(ValidationError) as exc_info:
            validator.validate("mysql", {})

        assert "database_name" in str(exc_info.value)
        assert "required" in str(exc_info.value).lower()

    def test_error_formatting_multiple_errors(self, tmp_path: Path) -> None:
        """Test error message with multiple validation errors."""
        # Create schema
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        schema = {
            "type": "object",
            "properties": {
                "database_name": {"type": "string"},
                "database_user": {"type": "string"},
            },
            "required": ["database_name", "database_user"],
        }
        (template_dir / "schema.json").write_text(json.dumps(schema))

        # Validate and check multiple errors
        validator = SchemaValidator(tmp_path)
        with pytest.raises(ValidationError) as exc_info:
            validator.validate("mysql", {})

        assert len(exc_info.value.errors) >= 1
        error_message = str(exc_info.value)
        # Should mention both fields or indicate multiple errors
        assert "database_name" in error_message or "database_user" in error_message


class TestSchemaLoadingErrors:
    """Test error handling for schema loading."""

    def test_validate_with_missing_schema(self, tmp_path: Path) -> None:
        """Test validation when schema doesn't exist."""
        # Create template directory without schema
        template_dir = tmp_path / "services" / "mysql" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "secret.yaml.tmpl").write_text("content")

        validator = SchemaValidator(tmp_path)
        with pytest.raises(ValidationError, match="Failed to load schema"):
            validator.validate("mysql", {})

    def test_validate_with_invalid_schema(self, tmp_path: Path) -> None:
        """Test validation with invalid JSON schema."""
        # Create invalid schema (missing type)
        template_dir = tmp_path / "services" / "mysql" / "template"
        template_dir.mkdir(parents=True)
        schema = {"properties": {}}  # Invalid - no type
        (template_dir / "schema.json").write_text(json.dumps(schema))

        import contextlib

        validator = SchemaValidator(tmp_path)
        # Should handle gracefully (jsonschema may or may not raise)
        with contextlib.suppress(ValidationError, Exception):
            validator.validate("mysql", {})


# Made with Bob
