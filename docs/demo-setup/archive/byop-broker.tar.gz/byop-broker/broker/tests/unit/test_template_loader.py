"""Unit tests for template_loader module."""

from pathlib import Path

import pytest

from broker.gitops.template_loader import TemplateLoader, TemplateLoadError


class TestTemplateLoaderInit:
    """Test TemplateLoader initialization."""

    def test_init_with_valid_directory(self, tmp_path: Path) -> None:
        """Test initialization with valid repository directory."""
        loader = TemplateLoader(tmp_path)
        assert loader.repo_dir == tmp_path
        assert loader._cache == {}

    def test_init_with_nonexistent_directory(self, tmp_path: Path) -> None:
        """Test initialization with non-existent directory."""
        nonexistent = tmp_path / "nonexistent"
        with pytest.raises(TemplateLoadError, match="Repository directory not found"):
            TemplateLoader(nonexistent)

    def test_init_with_file_instead_of_directory(self, tmp_path: Path) -> None:
        """Test initialization with file instead of directory."""
        file_path = tmp_path / "file.txt"
        file_path.write_text("content")
        with pytest.raises(TemplateLoadError, match="not a directory"):
            TemplateLoader(file_path)


class TestLoadTemplates:
    """Test template loading functionality."""

    def test_load_templates_success(self, mock_gitops_repo: Path) -> None:
        """Test successful template loading."""
        # Load templates
        loader = TemplateLoader(mock_gitops_repo)
        templates = loader.load_templates("mysql")

        # Verify
        assert len(templates) >= 3
        assert "schema.json" in templates
        assert "secret.yaml.tmpl" in templates
        assert "kustomization.yaml.tmpl" in templates

    def test_load_templates_with_version(self, tmp_path: Path) -> None:
        """Test loading templates with specific version."""
        # Create template directory with specific version
        template_dir = tmp_path / "services" / "postgres" / "v2" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')

        # Load with version
        loader = TemplateLoader(tmp_path)
        templates = loader.load_templates("postgres", "v2")

        assert "schema.json" in templates

    def test_load_templates_caching(self, mock_gitops_repo: Path) -> None:
        """Test that templates are cached."""
        loader = TemplateLoader(mock_gitops_repo)

        # First load
        templates1 = loader.load_templates("mysql")
        assert "mysql:v1" in loader._cache

        # Second load (should use cache)
        templates2 = loader.load_templates("mysql")
        assert templates1 is templates2  # Same object reference

    def test_load_templates_missing_directory(self, tmp_path: Path) -> None:
        """Test loading templates when directory doesn't exist."""
        loader = TemplateLoader(tmp_path)
        with pytest.raises(TemplateLoadError, match="Template directory not found"):
            loader.load_templates("nonexistent")

    def test_load_templates_empty_directory(self, tmp_path: Path) -> None:
        """Test loading templates from empty directory."""
        # Create empty template directory
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)

        loader = TemplateLoader(tmp_path)
        with pytest.raises(TemplateLoadError, match="No template files found"):
            loader.load_templates("mysql")

    def test_load_templates_ignores_hidden_files(self, tmp_path: Path) -> None:
        """Test that hidden files are ignored."""
        # Create template directory with hidden file
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')
        (template_dir / ".hidden").write_text("hidden content")

        loader = TemplateLoader(tmp_path)
        templates = loader.load_templates("mysql")

        assert ".hidden" not in templates
        assert "schema.json" in templates


class TestLoadSchema:
    """Test schema loading functionality."""

    def test_load_schema_success(self, mock_gitops_repo: Path) -> None:
        """Test successful schema loading and parsing."""
        loader = TemplateLoader(mock_gitops_repo)
        schema = loader.load_schema("mysql")

        assert schema["type"] == "object"
        assert "database_name" in schema["properties"]
        assert schema["required"] == ["database_name"]

    def test_load_schema_missing(self, tmp_path: Path) -> None:
        """Test loading schema when schema.json doesn't exist."""
        # Create template directory without schema
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "secret.yaml.tmpl").write_text("content")

        loader = TemplateLoader(tmp_path)
        with pytest.raises(TemplateLoadError, match="schema.json not found"):
            loader.load_schema("mysql")

    def test_load_schema_invalid_json(self, tmp_path: Path) -> None:
        """Test loading schema with invalid JSON."""
        # Create template directory with invalid JSON
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text("invalid json {")

        loader = TemplateLoader(tmp_path)
        with pytest.raises(TemplateLoadError, match="Invalid JSON"):
            loader.load_schema("mysql")


class TestGetTemplate:
    """Test getting specific template."""

    def test_get_template_success(self, mock_gitops_repo: Path) -> None:
        """Test getting a specific template."""
        loader = TemplateLoader(mock_gitops_repo)
        template = loader.get_template("mysql", "secret.yaml.tmpl")

        assert "apiVersion: v1" in template
        assert "kind: Secret" in template

    def test_get_template_not_found(self, mock_gitops_repo: Path) -> None:
        """Test getting non-existent template."""
        loader = TemplateLoader(mock_gitops_repo)
        with pytest.raises(TemplateLoadError, match="Template 'nonexistent.yaml' not found"):
            loader.get_template("mysql", "nonexistent.yaml")


class TestClearCache:
    """Test cache clearing functionality."""

    def test_clear_cache_all(self, mock_gitops_repo: Path) -> None:
        """Test clearing entire cache."""
        loader = TemplateLoader(mock_gitops_repo)

        # Load templates
        loader.load_templates("mysql")
        loader.load_templates("postgres")
        assert len(loader._cache) == 2

        # Clear all cache
        loader.clear_cache()
        assert len(loader._cache) == 0

    def test_clear_cache_specific_service(self, mock_gitops_repo: Path) -> None:
        """Test clearing cache for specific service."""
        loader = TemplateLoader(mock_gitops_repo)

        # Load templates
        loader.load_templates("mysql")
        loader.load_templates("postgres")
        assert len(loader._cache) == 2

        # Clear only MySQL cache
        loader.clear_cache("mysql")
        assert "mysql:v1" not in loader._cache
        assert "postgres:v1" in loader._cache

    def test_clear_cache_multiple_versions(self, tmp_path: Path) -> None:
        """Test clearing cache clears all versions of a service."""
        # Create template directories for multiple versions
        for version in ["v1", "v2"]:
            template_dir = tmp_path / "services" / "mysql" / version / "template"
            template_dir.mkdir(parents=True)
            (template_dir / "schema.json").write_text('{"type": "object"}')

        loader = TemplateLoader(tmp_path)

        # Load multiple versions
        loader.load_templates("mysql", "v1")
        loader.load_templates("mysql", "v2")
        assert "mysql:v1" in loader._cache
        assert "mysql:v2" in loader._cache

        # Clear all MySQL versions
        loader.clear_cache("mysql")
        assert "mysql:v1" not in loader._cache
        assert "mysql:v2" not in loader._cache


class TestLoadPlanMetadata:
    """Test plan metadata loading functionality."""

    def test_load_plan_metadata_success(self, tmp_path: Path) -> None:
        """Test successful plan metadata loading."""
        # Create catalog with plan metadata
        catalog_dir = tmp_path / "services" / "qradar" / "v1" / "catalog"
        catalog_dir.mkdir(parents=True)
        catalog_content = """name: QRadar
description: QRadar SIEM
plans:
  - id: "all-in-one-normal-tiny"
    name: "All-in-One Tiny"
    description: "Tiny deployment"
    metadata:
      version: "7.5.0"
      cpu: 8
      memory: 32
      storage: 256
      template: "all-in-one"
"""
        (catalog_dir / "catalog.yaml").write_text(catalog_content)

        loader = TemplateLoader(tmp_path)
        metadata = loader.load_plan_metadata("qradar", "all-in-one-normal-tiny")

        assert metadata is not None
        assert metadata["version"] == "7.5.0"
        assert metadata["cpu"] == 8
        assert metadata["memory"] == 32
        assert metadata["storage"] == 256
        assert metadata["template"] == "all-in-one"

    def test_load_plan_metadata_missing_catalog(self, tmp_path: Path) -> None:
        """Test loading plan metadata when catalog.yaml doesn't exist."""
        # Create service directory without catalog
        service_dir = tmp_path / "services" / "qradar" / "v1"
        service_dir.mkdir(parents=True)

        loader = TemplateLoader(tmp_path)
        metadata = loader.load_plan_metadata("qradar", "some-plan")

        assert metadata == {}

    def test_load_plan_metadata_invalid_yaml(self, tmp_path: Path) -> None:
        """Test loading plan metadata with invalid YAML."""
        # Create catalog with invalid YAML
        catalog_dir = tmp_path / "services" / "qradar" / "v1" / "catalog"
        catalog_dir.mkdir(parents=True)
        (catalog_dir / "catalog.yaml").write_text("invalid: yaml: content: [")

        loader = TemplateLoader(tmp_path)
        metadata = loader.load_plan_metadata("qradar", "some-plan")

        assert metadata == {}

    def test_load_plan_metadata_plan_not_found(self, tmp_path: Path) -> None:
        """Test loading plan metadata when plan doesn't exist."""
        # Create catalog without the requested plan
        catalog_dir = tmp_path / "services" / "qradar" / "v1" / "catalog"
        catalog_dir.mkdir(parents=True)
        catalog_content = """name: QRadar
plans:
  - id: "other-plan"
    name: "Other Plan"
"""
        (catalog_dir / "catalog.yaml").write_text(catalog_content)

        loader = TemplateLoader(tmp_path)
        metadata = loader.load_plan_metadata("qradar", "nonexistent-plan")

        assert metadata == {}

    def test_load_plan_metadata_empty_metadata(self, tmp_path: Path) -> None:
        """Test loading plan metadata when plan has no metadata fields."""
        # Create catalog with plan but no metadata
        catalog_dir = tmp_path / "services" / "qradar" / "v1" / "catalog"
        catalog_dir.mkdir(parents=True)
        catalog_content = """name: QRadar
plans:
  - id: "minimal-plan"
    name: "Minimal Plan"
    description: "Plan with no metadata"
"""
        (catalog_dir / "catalog.yaml").write_text(catalog_content)

        loader = TemplateLoader(tmp_path)
        metadata = loader.load_plan_metadata("qradar", "minimal-plan")

        # Should return empty dict when no metadata fields present
        assert metadata == {}

    def test_load_plan_metadata_partial_metadata(self, tmp_path: Path) -> None:
        """Test loading plan metadata with only some fields."""
        # Create catalog with partial metadata
        catalog_dir = tmp_path / "services" / "qradar" / "v1" / "catalog"
        catalog_dir.mkdir(parents=True)
        catalog_content = """name: QRadar
plans:
  - id: "partial-plan"
    name: "Partial Plan"
    metadata:
      version: "7.5.0"
      cpu: 8
"""
        (catalog_dir / "catalog.yaml").write_text(catalog_content)

        loader = TemplateLoader(tmp_path)
        metadata = loader.load_plan_metadata("qradar", "partial-plan")

        assert metadata["version"] == "7.5.0"
        assert metadata["cpu"] == 8
        assert "memory" not in metadata
        assert "storage" not in metadata

    def test_load_plan_metadata_with_version(self, tmp_path: Path) -> None:
        """Test loading plan metadata with specific version."""
        # Create catalog in v2 directory
        catalog_dir = tmp_path / "services" / "qradar" / "v2" / "catalog"
        catalog_dir.mkdir(parents=True)
        catalog_content = """name: QRadar
plans:
  - id: "v2-plan"
    name: "V2 Plan"
    metadata:
      version: "7.6.0"
"""
        (catalog_dir / "catalog.yaml").write_text(catalog_content)

        loader = TemplateLoader(tmp_path)
        metadata = loader.load_plan_metadata("qradar", "v2-plan", "v2")

        assert metadata["version"] == "7.6.0"

    def test_load_plan_metadata_no_plans_key(self, tmp_path: Path) -> None:
        """Test loading plan metadata when catalog has no plans key."""
        # Create catalog without plans
        catalog_dir = tmp_path / "services" / "qradar" / "v1" / "catalog"
        catalog_dir.mkdir(parents=True)
        catalog_content = """name: QRadar
description: QRadar SIEM
"""
        (catalog_dir / "catalog.yaml").write_text(catalog_content)

        loader = TemplateLoader(tmp_path)
        metadata = loader.load_plan_metadata("qradar", "some-plan")

        assert metadata == {}


class TestListAvailableTemplates:
    """Test listing available templates."""

    def test_list_available_templates(self, mock_gitops_repo: Path) -> None:
        """Test listing available template files."""
        loader = TemplateLoader(mock_gitops_repo)
        templates = loader.list_available_templates("mysql")

        assert len(templates) >= 3
        assert "schema.json" in templates
        assert "secret.yaml.tmpl" in templates
        assert "kustomization.yaml.tmpl" in templates
        assert templates == sorted(templates)  # Verify sorted


class TestValidateRequiredTemplates:
    """Test required template validation."""

    def test_validate_required_templates_success(self, mock_gitops_repo: Path) -> None:
        """Test validation passes when all required templates exist."""
        loader = TemplateLoader(mock_gitops_repo)
        # Should not raise
        loader.validate_required_templates("mysql", ["schema.json", "secret.yaml.tmpl"])

    def test_validate_required_templates_missing(self, tmp_path: Path) -> None:
        """Test validation fails when required templates are missing."""
        # Create template directory with only schema
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')

        loader = TemplateLoader(tmp_path)
        with pytest.raises(TemplateLoadError, match="Missing required templates"):
            loader.validate_required_templates(
                "mysql", ["schema.json", "secret.yaml.tmpl", "configmap.yaml.tmpl"]
            )

    def test_validate_required_templates_error_message(self, tmp_path: Path) -> None:
        """Test validation error message includes missing templates."""
        # Create template directory
        template_dir = tmp_path / "services" / "mysql" / "v1" / "template"
        template_dir.mkdir(parents=True)
        (template_dir / "schema.json").write_text('{"type": "object"}')

        loader = TemplateLoader(tmp_path)
        with pytest.raises(TemplateLoadError) as exc_info:
            loader.validate_required_templates("mysql", ["schema.json", "missing.yaml"])

        error_message = str(exc_info.value)
        assert "missing.yaml" in error_message
        assert "schema.json" in error_message  # Shows available templates

    def test_load_plan_metadata_type_to_template_mapping(self, tmp_path: Path) -> None:
        """Test that 'type' field is mapped to 'template' for backward compatibility."""
        # Create catalog with 'type' instead of 'template'
        catalog_dir = tmp_path / "services" / "qradar" / "v1" / "catalog"
        catalog_dir.mkdir(parents=True)
        catalog_content = """name: QRadar
plans:
  - id: "type-plan"
    name: "Type Plan"
    metadata:
      type: "all-in-one-console"
      version: "7.5.0"
"""
        (catalog_dir / "catalog.yaml").write_text(catalog_content)

        loader = TemplateLoader(tmp_path)
        metadata = loader.load_plan_metadata("qradar", "type-plan")

        # 'type' should be mapped to 'template'
        assert "template" in metadata
        assert metadata["template"] == "all-in-one-console"
        assert "type" not in metadata


class TestGitAwareCacheInvalidation:
    """Test git-aware cache invalidation functionality."""

    def test_cache_invalidated_on_git_change(self, mock_gitops_repo: Path, monkeypatch) -> None:
        """Test that cache is cleared when git commit changes."""
        # Mock git command to return different commit hashes
        call_count = 0

        def mock_run(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            # First two calls return commit1, third call returns commit2
            commit_hash = "abc123def456" if call_count <= 2 else "xyz789uvw012"

            class MockResult:
                stdout = commit_hash
                stderr = ""

            return MockResult()

        monkeypatch.setattr("subprocess.run", mock_run)

        loader = TemplateLoader(mock_gitops_repo)

        # First load (cache miss, commit1)
        templates1 = loader.load_templates("mysql")
        assert "mysql:v1" in loader._cache
        assert loader._cache_commit_hash == "abc123def456"

        # Second load (cache hit, same commit)
        templates2 = loader.load_templates("mysql")
        assert templates1 is templates2  # Same object reference

        # Third load (cache invalidated, commit changed to commit2)
        templates3 = loader.load_templates("mysql")
        assert templates1 is not templates3  # Different object
        assert loader._cache_commit_hash == "xyz789uvw012"

    def test_cache_persists_when_commit_unchanged(
        self, mock_gitops_repo: Path, monkeypatch
    ) -> None:
        """Test that cache persists when git commit hasn't changed."""

        # Mock git command to always return same commit hash
        def mock_run(*args, **kwargs):
            class MockResult:
                stdout = "abc123def456"
                stderr = ""

            return MockResult()

        monkeypatch.setattr("subprocess.run", mock_run)

        loader = TemplateLoader(mock_gitops_repo)

        # Load templates multiple times
        templates1 = loader.load_templates("mysql")
        templates2 = loader.load_templates("mysql")
        templates3 = loader.load_templates("mysql")

        # All should be the same cached object
        assert templates1 is templates2
        assert templates2 is templates3
        assert loader._cache_commit_hash == "abc123def456"

    def test_cache_works_without_git(self, mock_gitops_repo: Path, monkeypatch) -> None:
        """Test that caching still works when git is not available."""

        # Mock git command to raise FileNotFoundError
        def mock_run(*args, **kwargs):
            raise FileNotFoundError("git command not found")

        monkeypatch.setattr("subprocess.run", mock_run)

        loader = TemplateLoader(mock_gitops_repo)

        # Should still load templates successfully
        templates1 = loader.load_templates("mysql")
        assert "schema.json" in templates1

        # Cache should work (returns empty string for commit hash)
        templates2 = loader.load_templates("mysql")
        assert templates1 is templates2
        assert loader._cache_commit_hash == ""

    def test_cache_works_with_git_error(self, mock_gitops_repo: Path, monkeypatch) -> None:
        """Test that caching works when git command fails."""
        # Mock git command to raise CalledProcessError
        import subprocess

        def mock_run(*args, **kwargs):
            raise subprocess.CalledProcessError(
                returncode=128,
                cmd=["git", "rev-parse", "HEAD"],
                stderr="fatal: not a git repository",
            )

        monkeypatch.setattr("subprocess.run", mock_run)

        loader = TemplateLoader(mock_gitops_repo)

        # Should still load templates successfully
        templates1 = loader.load_templates("mysql")
        assert "schema.json" in templates1

        # Cache should work (returns empty string for commit hash)
        templates2 = loader.load_templates("mysql")
        assert templates1 is templates2
        assert loader._cache_commit_hash == ""

    def test_multiple_services_cache_invalidation(
        self, mock_gitops_repo: Path, monkeypatch
    ) -> None:
        """Test that all services are invalidated when git changes."""
        call_count = 0

        def mock_run(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            # Return different commit after 3 calls
            commit_hash = "abc123" if call_count <= 3 else "xyz789"

            class MockResult:
                stdout = commit_hash
                stderr = ""

            return MockResult()

        monkeypatch.setattr("subprocess.run", mock_run)

        loader = TemplateLoader(mock_gitops_repo)

        # Load multiple services
        mysql1 = loader.load_templates("mysql")
        postgres1 = loader.load_templates("postgres")
        assert len(loader._cache) == 2

        # Load again (cache hit)
        mysql2 = loader.load_templates("mysql")
        assert mysql1 is mysql2

        # Git changes - next load should invalidate all cache
        mysql3 = loader.load_templates("mysql")
        assert mysql1 is not mysql3
        assert len(loader._cache) == 1  # Only mysql loaded after invalidation

        # Load postgres again (should be new object)
        postgres2 = loader.load_templates("postgres")
        assert postgres1 is not postgres2

    def test_get_current_commit_hash_success(self, mock_gitops_repo: Path, monkeypatch) -> None:
        """Test _get_current_commit_hash with successful git command."""

        def mock_run(*args, **kwargs):
            class MockResult:
                stdout = "abc123def456789\n"
                stderr = ""

            return MockResult()

        monkeypatch.setattr("subprocess.run", mock_run)

        loader = TemplateLoader(mock_gitops_repo)
        commit_hash = loader._get_current_commit_hash()

        assert commit_hash == "abc123def456789"

    def test_initial_load_sets_commit_hash(self, mock_gitops_repo: Path, monkeypatch) -> None:
        """Test that initial template load sets the commit hash."""

        def mock_run(*args, **kwargs):
            class MockResult:
                stdout = "initial_commit_hash"
                stderr = ""

            return MockResult()

        monkeypatch.setattr("subprocess.run", mock_run)

        loader = TemplateLoader(mock_gitops_repo)
        assert loader._cache_commit_hash is None

        # First load should set commit hash
        loader.load_templates("mysql")
        assert loader._cache_commit_hash == "initial_commit_hash"


# Made with Bob


class TestSubdirectoryTemplates:
    """Test subdirectory template loading functionality."""

    def test_load_templates_with_subdirectories(self, tmp_path: Path) -> None:
        """Test loading templates from subdirectories."""
        # Create template structure with subdirectories
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        # Root level template
        (template_dir / "main.yaml.tmpl").write_text("root: template")

        # Subdirectory templates
        auth_dir = template_dir / "auth"
        auth_dir.mkdir()
        (auth_dir / "role.yaml.tmpl").write_text("auth: template")
        (auth_dir / "rolebinding.yaml.tmpl").write_text("binding: template")

        # Load templates
        loader = TemplateLoader(tmp_path)
        templates = loader.load_templates("test")

        # Verify all templates loaded with correct keys
        assert "main.yaml.tmpl" in templates
        assert "auth/role.yaml.tmpl" in templates
        assert "auth/rolebinding.yaml.tmpl" in templates
        assert templates["main.yaml.tmpl"] == "root: template"
        assert templates["auth/role.yaml.tmpl"] == "auth: template"
        assert templates["auth/rolebinding.yaml.tmpl"] == "binding: template"

    def test_load_templates_multiple_subdirectory_levels(self, tmp_path: Path) -> None:
        """Test loading templates from multiple subdirectory levels."""
        # Create nested directory structure
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        # Root level
        (template_dir / "root.yaml.tmpl").write_text("root")

        # First level subdirectory
        level1_dir = template_dir / "level1"
        level1_dir.mkdir()
        (level1_dir / "file1.yaml.tmpl").write_text("level1")

        # Second level subdirectory
        level2_dir = level1_dir / "level2"
        level2_dir.mkdir()
        (level2_dir / "file2.yaml.tmpl").write_text("level2")

        # Load templates
        loader = TemplateLoader(tmp_path)
        templates = loader.load_templates("test")

        # Verify nested structure preserved
        assert "root.yaml.tmpl" in templates
        assert "level1/file1.yaml.tmpl" in templates
        assert "level1/level2/file2.yaml.tmpl" in templates
        assert templates["level1/level2/file2.yaml.tmpl"] == "level2"

    def test_load_templates_mixed_flat_and_nested(self, tmp_path: Path) -> None:
        """Test loading templates with mixed flat and nested structure."""
        # Create mixed structure
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        # Flat files
        (template_dir / "kustomization.yaml.tmpl").write_text("kustomization")
        (template_dir / "secret.yaml.tmpl").write_text("secret")

        # Nested files
        auth_dir = template_dir / "auth"
        auth_dir.mkdir()
        (auth_dir / "kustomization.yaml.tmpl").write_text("auth-kustomization")

        config_dir = template_dir / "config"
        config_dir.mkdir()
        (config_dir / "configmap.yaml.tmpl").write_text("configmap")

        # Load templates
        loader = TemplateLoader(tmp_path)
        templates = loader.load_templates("test")

        # Verify all templates loaded
        assert len(templates) == 4
        assert "kustomization.yaml.tmpl" in templates
        assert "secret.yaml.tmpl" in templates
        assert "auth/kustomization.yaml.tmpl" in templates
        assert "config/configmap.yaml.tmpl" in templates

    def test_load_templates_skips_hidden_subdirectories(self, tmp_path: Path) -> None:
        """Test that hidden subdirectories are skipped."""
        # Create template structure with hidden directory
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        # Regular file
        (template_dir / "main.yaml.tmpl").write_text("main")

        # Hidden directory
        hidden_dir = template_dir / ".hidden"
        hidden_dir.mkdir()
        (hidden_dir / "secret.yaml.tmpl").write_text("should not load")

        # Regular subdirectory
        auth_dir = template_dir / "auth"
        auth_dir.mkdir()
        (auth_dir / "role.yaml.tmpl").write_text("auth")

        # Load templates
        loader = TemplateLoader(tmp_path)
        templates = loader.load_templates("test")

        # Verify hidden directory skipped
        assert "main.yaml.tmpl" in templates
        assert "auth/role.yaml.tmpl" in templates
        assert ".hidden/secret.yaml.tmpl" not in templates

    def test_load_templates_skips_pycache_directories(self, tmp_path: Path) -> None:
        """Test that __pycache__ directories are skipped."""
        # Create template structure with __pycache__
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        # Regular file
        (template_dir / "main.yaml.tmpl").write_text("main")

        # __pycache__ directory
        pycache_dir = template_dir / "__pycache__"
        pycache_dir.mkdir()
        (pycache_dir / "module.pyc").write_text("bytecode")

        # Load templates
        loader = TemplateLoader(tmp_path)
        templates = loader.load_templates("test")

        # Verify __pycache__ skipped
        assert "main.yaml.tmpl" in templates
        assert "__pycache__/module.pyc" not in templates

    def test_load_templates_subdirectory_with_hidden_files(self, tmp_path: Path) -> None:
        """Test that hidden files in subdirectories are skipped."""
        # Create template structure
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        # Subdirectory with hidden file
        auth_dir = template_dir / "auth"
        auth_dir.mkdir()
        (auth_dir / "role.yaml.tmpl").write_text("role")
        (auth_dir / ".gitkeep").write_text("")

        # Load templates
        loader = TemplateLoader(tmp_path)
        templates = loader.load_templates("test")

        # Verify hidden file skipped
        assert "auth/role.yaml.tmpl" in templates
        assert "auth/.gitkeep" not in templates

    def test_load_templates_empty_subdirectory_ignored(self, tmp_path: Path) -> None:
        """Test that empty subdirectories don't cause errors."""
        # Create template structure with empty subdirectory
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        # Regular file
        (template_dir / "main.yaml.tmpl").write_text("main")

        # Empty subdirectory
        empty_dir = template_dir / "empty"
        empty_dir.mkdir()

        # Load templates
        loader = TemplateLoader(tmp_path)
        templates = loader.load_templates("test")

        # Should load successfully
        assert "main.yaml.tmpl" in templates
        assert len(templates) == 1

    def test_load_templates_subdirectory_path_separators(self, tmp_path: Path) -> None:
        """Test that subdirectory paths use forward slashes."""
        # Create nested structure
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        # Create nested directories
        auth_dir = template_dir / "auth" / "rbac"
        auth_dir.mkdir(parents=True)
        (auth_dir / "role.yaml.tmpl").write_text("role")

        # Load templates
        loader = TemplateLoader(tmp_path)
        templates = loader.load_templates("test")

        # Verify forward slashes used
        assert "auth/rbac/role.yaml.tmpl" in templates
        # Ensure no backslashes (Windows compatibility)
        for key in templates:
            assert "\\" not in key

    def test_load_templates_subdirectory_caching(self, tmp_path: Path) -> None:
        """Test that subdirectory templates are cached correctly."""
        # Create template structure
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        (template_dir / "main.yaml.tmpl").write_text("main")

        auth_dir = template_dir / "auth"
        auth_dir.mkdir()
        (auth_dir / "role.yaml.tmpl").write_text("role")

        # Load templates twice
        loader = TemplateLoader(tmp_path)
        templates1 = loader.load_templates("test")
        templates2 = loader.load_templates("test")

        # Verify caching works
        assert templates1 is templates2
        assert "auth/role.yaml.tmpl" in templates1

    def test_get_template_with_subdirectory_path(self, tmp_path: Path) -> None:
        """Test getting a specific template from subdirectory."""
        # Create template structure
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        auth_dir = template_dir / "auth"
        auth_dir.mkdir()
        (auth_dir / "role.yaml.tmpl").write_text("auth: role")

        # Get specific template
        loader = TemplateLoader(tmp_path)
        template = loader.get_template("test", "auth/role.yaml.tmpl")

        assert template == "auth: role"

    def test_list_available_templates_includes_subdirectories(self, tmp_path: Path) -> None:
        """Test that list_available_templates includes subdirectory templates."""
        # Create template structure
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        (template_dir / "main.yaml.tmpl").write_text("main")

        auth_dir = template_dir / "auth"
        auth_dir.mkdir()
        (auth_dir / "role.yaml.tmpl").write_text("role")
        (auth_dir / "binding.yaml.tmpl").write_text("binding")

        # List templates
        loader = TemplateLoader(tmp_path)
        templates = loader.list_available_templates("test")

        # Verify all templates listed and sorted
        assert "main.yaml.tmpl" in templates
        assert "auth/binding.yaml.tmpl" in templates
        assert "auth/role.yaml.tmpl" in templates
        assert templates == sorted(templates)

    def test_validate_required_templates_with_subdirectories(self, tmp_path: Path) -> None:
        """Test validating required templates in subdirectories."""
        # Create template structure
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        (template_dir / "main.yaml.tmpl").write_text("main")

        auth_dir = template_dir / "auth"
        auth_dir.mkdir()
        (auth_dir / "role.yaml.tmpl").write_text("role")

        # Validate with subdirectory paths
        loader = TemplateLoader(tmp_path)
        # Should not raise
        loader.validate_required_templates("test", ["main.yaml.tmpl", "auth/role.yaml.tmpl"])

    def test_validate_required_templates_missing_subdirectory_file(self, tmp_path: Path) -> None:
        """Test validation fails when subdirectory template is missing."""
        # Create template structure
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        (template_dir / "main.yaml.tmpl").write_text("main")

        auth_dir = template_dir / "auth"
        auth_dir.mkdir()
        (auth_dir / "role.yaml.tmpl").write_text("role")

        # Validate with missing subdirectory file
        loader = TemplateLoader(tmp_path)
        with pytest.raises(TemplateLoadError, match="Missing required templates"):
            loader.validate_required_templates(
                "test", ["main.yaml.tmpl", "auth/role.yaml.tmpl", "auth/missing.yaml.tmpl"]
            )

    def test_backward_compatibility_flat_structure(self, tmp_path: Path) -> None:
        """Test that flat template structures still work (backward compatibility)."""
        # Create flat template structure (old style)
        template_dir = tmp_path / "services" / "test" / "v1" / "template"
        template_dir.mkdir(parents=True)

        (template_dir / "kustomization.yaml.tmpl").write_text("kustomization")
        (template_dir / "secret.yaml.tmpl").write_text("secret")
        (template_dir / "configmap.yaml.tmpl").write_text("configmap")

        # Load templates
        loader = TemplateLoader(tmp_path)
        templates = loader.load_templates("test")

        # Verify all templates loaded without subdirectory paths
        assert "kustomization.yaml.tmpl" in templates
        assert "secret.yaml.tmpl" in templates
        assert "configmap.yaml.tmpl" in templates
        assert len(templates) == 3

        # Verify no forward slashes in keys (flat structure)
        for key in templates:
            assert "/" not in key
