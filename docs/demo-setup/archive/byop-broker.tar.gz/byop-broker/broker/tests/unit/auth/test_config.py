"""Unit tests for authentication configuration."""

import json
from pathlib import Path

import pytest

from broker.auth.config import AuthConfig, load_auth_config


class TestAuthConfig:
    """Test AuthConfig dataclass."""

    def test_default_values(self) -> None:
        """Test default configuration values."""
        config = AuthConfig()

        assert config.enabled is True  # Enabled by default
        assert config.jwks_url == ""
        assert config.issuer == ""
        assert config.audience == ""
        assert config.algorithms == ["RS256"]
        assert config.jwks_cache_ttl == 3600
        assert "/health" in config.exempt_paths
        assert "/health/git" in config.exempt_paths
        assert "/health/cache/clear" in config.exempt_paths

    def test_custom_values(self) -> None:
        """Test custom configuration values."""
        config = AuthConfig(
            enabled=False,
            jwks_url="https://auth.example.com/.well-known/jwks.json",
            issuer="https://auth.example.com/",
            audience="test-audience",
            algorithms=["RS256", "ES256"],
            jwks_cache_ttl=7200,
            exempt_paths=["/health", "/custom"],
        )

        assert config.enabled is False
        assert config.jwks_url == "https://auth.example.com/.well-known/jwks.json"
        assert config.issuer == "https://auth.example.com/"
        assert config.audience == "test-audience"
        assert config.algorithms == ["RS256", "ES256"]
        assert config.jwks_cache_ttl == 7200
        assert config.exempt_paths == ["/health", "/custom"]

    def test_validate_disabled(self) -> None:
        """Test validation when authentication is disabled."""
        config = AuthConfig(enabled=False)

        # Should not raise any errors
        config.validate()

    def test_validate_enabled_missing_jwks_url(self) -> None:
        """Test validation fails when JWKS URL is missing."""
        config = AuthConfig(
            enabled=True,
            issuer="https://auth.example.com/",
            audience="test-audience",
        )

        with pytest.raises(ValueError, match="JWT_JWKS_URL is required"):
            config.validate()

    def test_validate_enabled_missing_issuer(self, caplog: pytest.LogCaptureFixture) -> None:
        """Test validation warns when issuer is missing."""
        config = AuthConfig(
            enabled=True,
            jwks_url="https://auth.example.com/.well-known/jwks.json",
            audience="test-audience",
        )

        config.validate()

        assert "JWT_ISSUER not configured" in caplog.text

    def test_validate_enabled_missing_audience(self, caplog: pytest.LogCaptureFixture) -> None:
        """Test validation warns when audience is missing."""
        config = AuthConfig(
            enabled=True,
            jwks_url="https://auth.example.com/.well-known/jwks.json",
            issuer="https://auth.example.com/",
        )

        config.validate()

        assert "JWT_AUDIENCE not configured" in caplog.text

    def test_validate_enabled_empty_algorithms(self) -> None:
        """Test validation fails when algorithms list is empty."""
        config = AuthConfig(
            enabled=True,
            jwks_url="https://auth.example.com/.well-known/jwks.json",
            issuer="https://auth.example.com/",
            audience="test-audience",
            algorithms=[],
        )

        with pytest.raises(ValueError, match="At least one algorithm must be specified"):
            config.validate()

    def test_validate_enabled_negative_cache_ttl(self) -> None:
        """Test validation fails when cache TTL is negative."""
        config = AuthConfig(
            enabled=True,
            jwks_url="https://auth.example.com/.well-known/jwks.json",
            issuer="https://auth.example.com/",
            audience="test-audience",
            jwks_cache_ttl=-1,
        )

        with pytest.raises(ValueError, match="JWKS cache TTL must be non-negative"):
            config.validate()

    def test_validate_enabled_success(self) -> None:
        """Test validation succeeds with valid configuration."""
        config = AuthConfig(
            enabled=True,
            jwks_url="https://auth.example.com/.well-known/jwks.json",
            issuer="https://auth.example.com/",
            audience="test-audience",
        )

        # Should not raise any errors
        config.validate()


class TestLoadAuthConfig:
    """Test load_auth_config function."""

    def test_load_default_config(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test loading default configuration."""
        # Disable auth for default config test since no JWKS URL is provided
        monkeypatch.setenv("JWT_AUTH_ENABLED", "false")

        config = load_auth_config()

        assert config.enabled is False  # Disabled when no JWKS URL provided
        assert config.algorithms == ["RS256"]
        assert config.jwks_cache_ttl == 3600

    def test_load_from_environment_variables(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test loading configuration from environment variables."""
        monkeypatch.setenv("JWT_AUTH_ENABLED", "true")
        monkeypatch.setenv("JWT_JWKS_URL", "https://auth.example.com/.well-known/jwks.json")
        monkeypatch.setenv("JWT_ISSUER", "https://auth.example.com/")
        monkeypatch.setenv("JWT_AUDIENCE", "test-audience")
        monkeypatch.setenv("JWT_ALGORITHMS", "RS256,ES256")
        monkeypatch.setenv("JWT_CACHE_TTL", "7200")

        config = load_auth_config()

        assert config.enabled is True
        assert config.jwks_url == "https://auth.example.com/.well-known/jwks.json"
        assert config.issuer == "https://auth.example.com/"
        assert config.audience == "test-audience"
        assert config.algorithms == ["RS256", "ES256"]
        assert config.jwks_cache_ttl == 7200

    def test_load_disabled_from_environment(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test disabling authentication via environment variable."""
        monkeypatch.setenv("JWT_AUTH_ENABLED", "false")

        config = load_auth_config()

        assert config.enabled is False

    def test_load_from_config_file(self, tmp_path: Path) -> None:
        """Test loading configuration from file."""
        config_file = tmp_path / "config.json"
        config_data = {
            "auth": {
                "enabled": True,
                "jwks_url": "https://auth.example.com/.well-known/jwks.json",
                "issuer": "https://auth.example.com/",
                "audience": "test-audience",
                "algorithms": ["RS256", "ES256"],
                "jwks_cache_ttl": 7200,
            }
        }
        config_file.write_text(json.dumps(config_data))

        config = load_auth_config(str(config_file))

        assert config.enabled is True
        assert config.jwks_url == "https://auth.example.com/.well-known/jwks.json"
        assert config.issuer == "https://auth.example.com/"
        assert config.audience == "test-audience"
        assert config.algorithms == ["RS256", "ES256"]
        assert config.jwks_cache_ttl == 7200

    def test_environment_overrides_file(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test environment variables override config file."""
        config_file = tmp_path / "config.json"
        config_data = {
            "auth": {
                "enabled": True,
                "jwks_url": "https://file.example.com/.well-known/jwks.json",
                "issuer": "https://file.example.com/",
                "audience": "file-audience",
            }
        }
        config_file.write_text(json.dumps(config_data))

        # Override with environment variables
        monkeypatch.setenv("JWT_JWKS_URL", "https://env.example.com/.well-known/jwks.json")
        monkeypatch.setenv("JWT_ISSUER", "https://env.example.com/")
        monkeypatch.setenv("JWT_AUDIENCE", "env-audience")

        config = load_auth_config(str(config_file))

        # Environment variables should take precedence
        assert config.jwks_url == "https://env.example.com/.well-known/jwks.json"
        assert config.issuer == "https://env.example.com/"
        assert config.audience == "env-audience"

    def test_load_nonexistent_file(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test loading from nonexistent file falls back to defaults."""
        # Disable auth since no JWKS URL provided
        monkeypatch.setenv("JWT_AUTH_ENABLED", "false")

        config = load_auth_config("/nonexistent/config.json")

        # Should use defaults
        assert config.enabled is False
        assert config.algorithms == ["RS256"]

    def test_load_invalid_json_file(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test loading invalid JSON file falls back to defaults."""
        # Disable auth since no JWKS URL provided
        monkeypatch.setenv("JWT_AUTH_ENABLED", "false")

        config_file = tmp_path / "config.json"
        config_file.write_text("invalid json{")

        config = load_auth_config(str(config_file))

        # Should use defaults
        assert config.enabled is False

    def test_load_file_without_auth_section(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test loading file without auth section uses defaults."""
        # Disable auth since no JWKS URL provided
        monkeypatch.setenv("JWT_AUTH_ENABLED", "false")

        config_file = tmp_path / "config.json"
        config_data = {"other": "config"}
        config_file.write_text(json.dumps(config_data))

        config = load_auth_config(str(config_file))

        # Should use defaults
        assert config.enabled is False

    def test_invalid_cache_ttl_environment(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test invalid cache TTL in environment falls back to default."""
        # Disable auth since no JWKS URL provided
        monkeypatch.setenv("JWT_AUTH_ENABLED", "false")
        monkeypatch.setenv("JWT_CACHE_TTL", "invalid")

        config = load_auth_config()

        # Should use default
        assert config.jwks_cache_ttl == 3600

    def test_algorithms_parsing(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test parsing algorithms from comma-separated string."""
        # Disable auth since no JWKS URL provided
        monkeypatch.setenv("JWT_AUTH_ENABLED", "false")
        monkeypatch.setenv("JWT_ALGORITHMS", "RS256, ES256 , PS256")

        config = load_auth_config()

        # Should strip whitespace
        assert config.algorithms == ["RS256", "ES256", "PS256"]

    def test_algorithms_empty_string(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test empty algorithms string is ignored."""
        # Disable auth since no JWKS URL provided
        monkeypatch.setenv("JWT_AUTH_ENABLED", "false")
        monkeypatch.setenv("JWT_ALGORITHMS", "")

        config = load_auth_config()

        # Should use default
        assert config.algorithms == ["RS256"]

    def test_boolean_parsing_variations(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test various boolean string formats."""
        # For enabled tests, provide required config
        required_config = {
            "JWT_JWKS_URL": "https://test.example.com/.well-known/jwks.json",
            "JWT_ISSUER": "https://test.example.com/",
            "JWT_AUDIENCE": "test-audience",
        }

        # Test "true"
        for key, value in required_config.items():
            monkeypatch.setenv(key, value)
        monkeypatch.setenv("JWT_AUTH_ENABLED", "true")
        assert load_auth_config().enabled is True

        # Test "1"
        monkeypatch.setenv("JWT_AUTH_ENABLED", "1")
        assert load_auth_config().enabled is True

        # Test "yes"
        monkeypatch.setenv("JWT_AUTH_ENABLED", "yes")
        assert load_auth_config().enabled is True

        # Test "false" - no required config needed
        monkeypatch.delenv("JWT_JWKS_URL", raising=False)
        monkeypatch.delenv("JWT_ISSUER", raising=False)
        monkeypatch.delenv("JWT_AUDIENCE", raising=False)
        monkeypatch.setenv("JWT_AUTH_ENABLED", "false")
        assert load_auth_config().enabled is False

        # Test "0"
        monkeypatch.setenv("JWT_AUTH_ENABLED", "0")
        assert load_auth_config().enabled is False

        # Test other values (should be false)
        monkeypatch.setenv("JWT_AUTH_ENABLED", "no")
        assert load_auth_config().enabled is False


# Made with Bob
