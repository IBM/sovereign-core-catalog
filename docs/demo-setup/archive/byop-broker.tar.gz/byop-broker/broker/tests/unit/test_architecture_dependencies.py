"""
Architecture dependency tests.

These tests enforce the architectural rules defined in the broker architecture review:
- File storage must not depend on gitops package
- Broker core must not depend on storage implementations
- GitOps package must be self-contained
"""

import ast
import inspect
from pathlib import Path

import pytest


def get_imports_from_source(source_code: str) -> set[str]:
    """Extract all import statements from Python source code.

    Args:
        source_code: Python source code as string

    Returns:
        Set of imported module names
    """
    imports = set()
    try:
        tree = ast.parse(source_code)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.add(alias.name)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imports.add(node.module)
    except SyntaxError:
        # If we can't parse it, skip it
        pass
    return imports


def test_file_storage_no_gitops_imports():
    """File storage must not import from gitops package.

    This ensures file storage remains independent and can be used
    without Git dependencies.
    """
    from broker import file_storage

    source = inspect.getsource(file_storage)
    imports = get_imports_from_source(source)

    gitops_imports = [imp for imp in imports if "gitops" in imp.lower()]

    assert not gitops_imports, (
        f"file_storage.py must not import gitops modules. "
        f"Found: {gitops_imports}\n"
        f"File storage should be pure file-based with no provisioning logic."
    )


def test_file_storage_no_sys_path_manipulation():
    """File storage must not manipulate sys.path.

    This ensures clean imports and no dynamic path modifications.
    """
    from broker import file_storage

    source = inspect.getsource(file_storage)

    assert "sys.path" not in source, (
        "file_storage.py must not manipulate sys.path. Use proper imports instead."
    )


def test_broker_no_storage_implementation_imports():
    """Broker core must not import storage implementations directly.

    This ensures broker depends only on the storage interface abstraction.
    """
    from broker import broker

    source = inspect.getsource(broker)
    imports = get_imports_from_source(source)

    forbidden_imports = [
        imp
        for imp in imports
        if any(
            storage in imp for storage in ["file_storage", "gitops_storage", "git_state_manager"]
        )
    ]

    assert not forbidden_imports, (
        f"broker.py must not import storage implementations directly. "
        f"Found: {forbidden_imports}\n"
        f"Use StorageInterface abstraction instead."
    )


def test_broker_depends_on_storage_interface():
    """Broker must depend on StorageInterface.

    This ensures proper dependency injection pattern.
    """
    from broker import broker

    source = inspect.getsource(broker)
    imports = get_imports_from_source(source)

    assert "broker.storage" in imports, (
        "broker.py must import from broker.storage (StorageInterface)"
    )


def test_gitops_storage_can_import_gitops():
    """GitOps storage is allowed to import from gitops package.

    This is the only storage implementation that should depend on gitops.
    """
    from broker import gitops_storage

    source = inspect.getsource(gitops_storage)
    imports = get_imports_from_source(source)

    gitops_imports = [imp for imp in imports if "broker.gitops" in imp]

    assert gitops_imports, (
        "gitops_storage.py should import from broker.gitops package. "
        "This is the correct dependency for GitOps-based storage."
    )


def test_gitops_storage_no_sys_path_manipulation():
    """GitOps storage must not manipulate sys.path.

    After refactoring, all imports should be clean.
    """
    from broker import gitops_storage

    source = inspect.getsource(gitops_storage)

    assert "sys.path.insert" not in source, (
        "gitops_storage.py must not manipulate sys.path. "
        "Use proper imports from broker.gitops package."
    )


def test_git_state_manager_location():
    """Git state manager must be in gitops package.

    This ensures Git-specific code is properly organized.
    """
    import importlib.util

    spec = importlib.util.find_spec("broker.gitops.git_state_manager")
    if spec is None:
        pytest.fail("git_state_manager should be in broker.gitops package, not in broker root")


def test_git_state_manager_not_in_broker_root():
    """Git state manager must not be in broker root.

    This ensures it's been moved to the gitops package.
    """
    broker_root = Path(__file__).parent.parent.parent / "src" / "broker"
    git_state_manager_file = broker_root / "git_state_manager.py"

    assert not git_state_manager_file.exists(), (
        "git_state_manager.py should be moved to broker/gitops/ package, "
        "not in broker root directory"
    )


def test_file_storage_is_simple():
    """File storage should be simple and lightweight.

    This checks that file storage doesn't have complex provisioning logic.
    """
    from broker import file_storage

    source = inspect.getsource(file_storage)

    # File storage should not have these complex operations
    forbidden_patterns = [
        "provision_instance",
        "deprovision_instance",
        "GitOperations",
        "git_ops",
        "ssh_key",
        "clone",
        "commit",
        "push",
    ]

    found_patterns = [pattern for pattern in forbidden_patterns if pattern in source]

    assert not found_patterns, (
        f"file_storage.py should be simple file-based storage. "
        f"Found complex operations: {found_patterns}\n"
        f"Provisioning logic should be in gitops_storage.py only."
    )


def test_storage_interface_is_abstract():
    """Storage interface must not have implementation details.

    This ensures it remains a pure abstraction.
    """
    from broker import storage

    source = inspect.getsource(storage)

    # Interface should not have these implementation details
    # Note: "gitops" in comments/strings is OK, but actual git operations are not
    forbidden_patterns = [
        "json.dump",
        "yaml.dump",
        "git.clone",
        "git.commit",
        "git.push",
        "subprocess",
        "threading.Thread",
    ]

    found_patterns = [pattern for pattern in forbidden_patterns if pattern in source]

    assert not found_patterns, (
        f"storage.py should be a pure interface with no implementation. "
        f"Found implementation details: {found_patterns}"
    )


def test_app_uses_storage_factory():
    """App must use storage factory pattern.

    This ensures proper dependency injection.
    """
    from broker import app

    source = inspect.getsource(app)

    assert "create_storage" in source, (
        "app.py must use create_storage factory function for dependency injection"
    )

    # App should not directly instantiate storage implementations
    forbidden_patterns = ["FileStorage()", "GitopsStorage()"]

    found_patterns = [pattern for pattern in forbidden_patterns if pattern in source]

    assert not found_patterns, (
        f"app.py must not directly instantiate storage implementations. "
        f"Found: {found_patterns}\n"
        f"Use create_storage factory instead."
    )


# Made with Bob
