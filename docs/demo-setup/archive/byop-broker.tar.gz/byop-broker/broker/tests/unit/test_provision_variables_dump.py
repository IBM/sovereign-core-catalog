"""
Unit tests for provision variables dump functionality.

Tests the _sanitize_variables() method in both GitopsStorage and FileStorage
to ensure sensitive data is properly redacted.
"""

from broker.file_storage import FileStorage
from broker.gitops_storage import GitopsStorage


class TestSanitizeVariablesGitopsStorage:
    """Test _sanitize_variables() method in GitopsStorage."""

    def setup_method(self):
        """Set up test fixtures."""
        self.storage = GitopsStorage()

    def test_sanitize_simple_password(self):
        """Test sanitization of simple password field."""
        variables = {
            "username": "admin",
            "password": "secret123",
            "database": "mydb",
        }

        result = self.storage._sanitize_variables(variables)

        assert result["username"] == "admin"
        assert result["password"] == "<REDACTED>"
        assert result["database"] == "mydb"

    def test_sanitize_case_insensitive(self):
        """Test case-insensitive pattern matching."""
        variables = {
            "Password": "secret1",
            "PASSWORD": "secret2",
            "PaSsWoRd": "secret3",
            "API_KEY": "key123",
            "api_key": "key456",
            "ApiKey": "key789",
        }

        result = self.storage._sanitize_variables(variables)

        assert result["Password"] == "<REDACTED>"
        assert result["PASSWORD"] == "<REDACTED>"
        assert result["PaSsWoRd"] == "<REDACTED>"
        assert result["API_KEY"] == "<REDACTED>"
        assert result["api_key"] == "<REDACTED>"
        assert result["ApiKey"] == "<REDACTED>"

    def test_sanitize_all_sensitive_patterns(self):
        """Test all sensitive key patterns are detected."""
        variables = {
            "password": "secret",
            "passwd": "secret",
            "pwd": "secret",
            "token": "secret",
            "access_token": "secret",
            "refresh_token": "secret",
            "secret": "secret",
            "client_secret": "secret",
            "api_secret": "secret",
            "key": "secret",
            "api_key": "secret",
            "apikey": "secret",
            "private_key": "secret",
            "credential": "secret",
            "credentials": "secret",
            "auth": "secret",
            "authorization": "secret",
        }

        result = self.storage._sanitize_variables(variables)

        # All should be redacted
        for key in variables:
            assert result[key] == "<REDACTED>", f"Key '{key}' was not redacted"

    def test_sanitize_nested_dict(self):
        """Test sanitization of nested dictionaries."""
        variables = {
            "database": {
                "host": "localhost",
                "password": "secret123",
                "credentials": {
                    "username": "admin",
                    "api_key": "key123",
                },
            },
            "name": "myapp",
        }

        result = self.storage._sanitize_variables(variables)

        assert result["database"]["host"] == "localhost"
        assert result["database"]["password"] == "<REDACTED>"
        assert result["database"]["credentials"]["username"] == "admin"
        assert result["database"]["credentials"]["api_key"] == "<REDACTED>"
        assert result["name"] == "myapp"

    def test_sanitize_list_of_dicts(self):
        """Test sanitization of lists containing dictionaries."""
        variables = {
            "users": [
                {"username": "user1", "password": "pass1"},
                {"username": "user2", "password": "pass2"},
            ],
            "config": "value",
        }

        result = self.storage._sanitize_variables(variables)

        assert result["users"][0]["username"] == "user1"
        assert result["users"][0]["password"] == "<REDACTED>"
        assert result["users"][1]["username"] == "user2"
        assert result["users"][1]["password"] == "<REDACTED>"
        assert result["config"] == "value"

    def test_sanitize_list_of_primitives(self):
        """Test that lists of primitives are preserved."""
        variables = {
            "tags": ["tag1", "tag2", "tag3"],
            "ports": [8080, 8443, 9090],
            "enabled": True,
        }

        result = self.storage._sanitize_variables(variables)

        assert result["tags"] == ["tag1", "tag2", "tag3"]
        assert result["ports"] == [8080, 8443, 9090]
        assert result["enabled"] is True

    def test_sanitize_mixed_list(self):
        """Test sanitization of lists with mixed content."""
        variables = {
            "items": [
                "string_value",
                123,
                {"name": "item1", "secret": "hidden"},
                True,
            ]
        }

        result = self.storage._sanitize_variables(variables)

        assert result["items"][0] == "string_value"
        assert result["items"][1] == 123
        assert result["items"][2]["name"] == "item1"
        assert result["items"][2]["secret"] == "<REDACTED>"
        assert result["items"][3] is True

    def test_sanitize_empty_dict(self):
        """Test sanitization of empty dictionary."""
        variables = {}

        result = self.storage._sanitize_variables(variables)

        assert result == {}

    def test_sanitize_none_values(self):
        """Test that None values are preserved."""
        variables = {
            "username": "admin",
            "password": None,
            "token": None,
        }

        result = self.storage._sanitize_variables(variables)

        assert result["username"] == "admin"
        # None values in sensitive fields should still be redacted for consistency
        assert result["password"] == "<REDACTED>"
        assert result["token"] == "<REDACTED>"

    def test_sanitize_numeric_values(self):
        """Test that numeric values in sensitive fields are redacted."""
        variables = {
            "port": 8080,
            "password": 12345,
            "api_key": 67890,
        }

        result = self.storage._sanitize_variables(variables)

        assert result["port"] == 8080
        assert result["password"] == "<REDACTED>"
        assert result["api_key"] == "<REDACTED>"

    def test_sanitize_boolean_values(self):
        """Test that boolean values in sensitive fields are redacted."""
        variables = {
            "enabled": True,
            "password": False,
            "token": True,
        }

        result = self.storage._sanitize_variables(variables)

        assert result["enabled"] is True
        assert result["password"] == "<REDACTED>"
        assert result["token"] == "<REDACTED>"

    def test_sanitize_partial_match(self):
        """Test that partial matches in key names are detected."""
        variables = {
            "user_password": "secret",
            "database_password": "secret",
            "my_api_key": "secret",
            "service_token": "secret",
            "oauth_secret": "secret",
        }

        result = self.storage._sanitize_variables(variables)

        assert result["user_password"] == "<REDACTED>"
        assert result["database_password"] == "<REDACTED>"
        assert result["my_api_key"] == "<REDACTED>"
        assert result["service_token"] == "<REDACTED>"
        assert result["oauth_secret"] == "<REDACTED>"

    def test_sanitize_non_sensitive_keys(self):
        """Test that non-sensitive keys are not redacted."""
        variables = {
            "username": "admin",
            "email": "user@example.com",
            "database": "mydb",
            "host": "localhost",
            "port": 5432,
            "enabled": True,
            "tags": ["tag1", "tag2"],
        }

        result = self.storage._sanitize_variables(variables)

        # All should be preserved
        assert result == variables

    def test_sanitize_deeply_nested(self):
        """Test sanitization of deeply nested structures."""
        variables = {
            "level1": {
                "level2": {
                    "level3": {
                        "level4": {
                            "password": "secret",
                            "data": "value",
                        }
                    }
                }
            }
        }

        result = self.storage._sanitize_variables(variables)

        assert result["level1"]["level2"]["level3"]["level4"]["password"] == "<REDACTED>"
        assert result["level1"]["level2"]["level3"]["level4"]["data"] == "value"

    def test_sanitize_complex_real_world_example(self):
        """Test sanitization with a complex real-world example."""
        variables = {
            "request": {
                "service_id": "mysql-service",
                "plan_id": "small",
                "parameters": {
                    "database_name": "mydb",
                    "username": "admin",
                    "password": "secret123",
                    "spec": {
                        "replicas": 3,
                        "storage_size": "10Gi",
                        "credentials": {
                            "admin_password": "admin_secret",
                            "root_password": "root_secret",
                        },
                    },
                },
                "context": {
                    "platform": "kubernetes",
                    "namespace": "default",
                },
            },
            "broker_config": {
                "dashboard_url": "http://localhost:7329/dash/<instance-id>",
                "gitops_path": "/app/orchestrator",
                "async_enabled": True,
            },
            "computed": {
                "instance_id": "test-instance",
                "crn": "crn:v1:local:public:mysql:region:account:test-instance::",
                "timestamp": "2026-04-23T12:00:00.000Z",
            },
        }

        result = self.storage._sanitize_variables(variables)

        # Check non-sensitive data is preserved
        assert result["request"]["service_id"] == "mysql-service"
        assert result["request"]["plan_id"] == "small"
        assert result["request"]["parameters"]["database_name"] == "mydb"
        assert result["request"]["parameters"]["username"] == "admin"
        assert result["request"]["parameters"]["spec"]["replicas"] == 3
        assert result["request"]["parameters"]["spec"]["storage_size"] == "10Gi"
        assert result["request"]["context"]["platform"] == "kubernetes"
        assert (
            result["broker_config"]["dashboard_url"] == "http://localhost:7329/dash/<instance-id>"
        )
        assert result["computed"]["instance_id"] == "test-instance"

        # Check sensitive data is redacted
        assert result["request"]["parameters"]["password"] == "<REDACTED>"
        assert (
            result["request"]["parameters"]["spec"]["credentials"]["admin_password"] == "<REDACTED>"
        )
        assert (
            result["request"]["parameters"]["spec"]["credentials"]["root_password"] == "<REDACTED>"
        )


class TestSanitizeVariablesFileStorage:
    """Test _sanitize_variables() method in FileStorage."""

    def setup_method(self):
        """Set up test fixtures."""
        self.storage = FileStorage()

    def test_sanitize_simple_password(self):
        """Test sanitization of simple password field."""
        variables = {
            "username": "admin",
            "password": "secret123",
            "database": "mydb",
        }

        result = self.storage._sanitize_variables(variables)

        assert result["username"] == "admin"
        assert result["password"] == "<REDACTED>"
        assert result["database"] == "mydb"

    def test_sanitize_all_sensitive_patterns(self):
        """Test all sensitive key patterns are detected."""
        variables = {
            "password": "secret",
            "token": "secret",
            "api_key": "secret",
            "secret": "secret",
            "credential": "secret",
        }

        result = self.storage._sanitize_variables(variables)

        # All should be redacted
        for key in variables:
            assert result[key] == "<REDACTED>", f"Key '{key}' was not redacted"

    def test_sanitize_nested_dict(self):
        """Test sanitization of nested dictionaries."""
        variables = {
            "database": {
                "host": "localhost",
                "password": "secret123",
            },
            "name": "myapp",
        }

        result = self.storage._sanitize_variables(variables)

        assert result["database"]["host"] == "localhost"
        assert result["database"]["password"] == "<REDACTED>"
        assert result["name"] == "myapp"

    def test_file_storage_same_behavior_as_gitops(self):
        """Test that FileStorage sanitization behaves identically to GitopsStorage."""
        gitops_storage = GitopsStorage()
        file_storage = FileStorage()

        variables = {
            "username": "admin",
            "password": "secret",
            "nested": {
                "api_key": "key123",
                "data": "value",
            },
            "list": [
                {"name": "item1", "token": "token123"},
                {"name": "item2", "secret": "secret456"},
            ],
        }

        gitops_result = gitops_storage._sanitize_variables(variables)
        file_result = file_storage._sanitize_variables(variables)

        # Both should produce identical results
        assert gitops_result == file_result


class TestDumpProvisionVariablesConfiguration:
    """Configuration tests for dump_provision_variables feature."""

    def test_gitops_storage_dump_disabled_by_default(self):
        """Test that dump is disabled by default in GitopsStorage."""
        storage = GitopsStorage()

        # Check default value before init
        assert storage.dump_provision_variables_enabled is False

    def test_file_storage_dump_disabled_by_default(self):
        """Test that dump is disabled by default in FileStorage."""
        storage = FileStorage()

        # Check default value before init
        assert storage.dump_provision_variables_enabled is False

    def test_gitops_storage_flag_set_in_init(self):
        """Test that dump flag is set during init in GitopsStorage."""
        storage = GitopsStorage()

        # Manually set the flag as init() would do
        storage.dump_provision_variables_enabled = True

        assert storage.dump_provision_variables_enabled is True

    def test_file_storage_flag_set_in_init(self):
        """Test that dump flag is set during init in FileStorage."""
        storage = FileStorage()

        # Manually set the flag as init() would do
        storage.dump_provision_variables_enabled = True

        assert storage.dump_provision_variables_enabled is True

    def test_dump_provision_variables_returns_immediately_when_disabled(self):
        """Test that dump_provision_variables returns immediately when disabled."""
        gitops_storage = GitopsStorage()
        file_storage = FileStorage()

        # Both should have feature disabled by default
        assert gitops_storage.dump_provision_variables_enabled is False
        assert file_storage.dump_provision_variables_enabled is False

        # Should not raise error, just return immediately (no-op)
        gitops_storage.dump_provision_variables("test-instance", {"password": "secret"})
        file_storage.dump_provision_variables("test-instance", {"password": "secret"})

        # If we got here without errors, the test passed


# Made with Bob
