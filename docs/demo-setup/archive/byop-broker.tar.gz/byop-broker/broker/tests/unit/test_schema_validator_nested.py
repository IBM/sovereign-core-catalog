"""Unit tests for nested schema defaults and x-generate functionality.

This module tests the recursive application of defaults and auto-generation
of values in nested object structures within JSON schemas.
"""

import json
from pathlib import Path

from broker.gitops.schema_validator import SchemaValidator


def create_test_service(tmp_path: Path, service_name: str, schema: dict) -> SchemaValidator:
    """Helper to create a test service with proper directory structure.

    Args:
        tmp_path: Pytest tmp_path fixture
        service_name: Name of the service
        schema: JSON schema dictionary

    Returns:
        SchemaValidator instance configured for the test service
    """
    # Create proper GitOps repo structure: repo_root/services/service_name/v1/{catalog,template}
    service_dir = tmp_path / "services" / service_name / "v1"
    catalog_dir = service_dir / "catalog"
    template_dir = service_dir / "template"
    catalog_dir.mkdir(parents=True)
    template_dir.mkdir(parents=True)

    with open(catalog_dir / "schema.json", "w") as f:
        json.dump(schema, f)

    # Create a dummy template file (TemplateLoader requires at least one)
    dummy_template = template_dir / "dummy.yaml.tmpl"
    dummy_template.write_text("# Dummy template for testing\n")

    # SchemaValidator expects repo root (tmp_path), not services directory
    return SchemaValidator(tmp_path)


class TestNestedDefaults:
    """Test recursive default value application in nested objects."""

    def test_nested_object_with_defaults(self, tmp_path):
        """Test that defaults are applied to nested objects."""
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "database": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "default": "mydb"},
                        "port": {"type": "integer", "default": 3306},
                    },
                },
            },
        }

        validator = create_test_service(tmp_path, "mysql", schema)
        result = validator.validate_with_defaults("mysql", {})

        assert "database" in result
        assert result["database"]["name"] == "mydb"
        assert result["database"]["port"] == 3306

    def test_nested_object_partial_user_values(self, tmp_path):
        """Test that user values are preserved and only missing fields get defaults."""
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "database": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "default": "mydb"},
                        "port": {"type": "integer", "default": 3306},
                        "host": {"type": "string", "default": "localhost"},
                    },
                },
            },
        }

        validator = create_test_service(tmp_path, "mysql", schema)
        params = {"database": {"name": "custom_db", "host": "db.example.com"}}
        result = validator.validate_with_defaults("mysql", params)

        assert result["database"]["name"] == "custom_db"
        assert result["database"]["host"] == "db.example.com"
        assert result["database"]["port"] == 3306

    def test_deeply_nested_defaults(self, tmp_path):
        """Test defaults in deeply nested structures (3+ levels)."""
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "service": {
                    "type": "object",
                    "properties": {
                        "config": {
                            "type": "object",
                            "properties": {
                                "database": {
                                    "type": "object",
                                    "properties": {
                                        "name": {"type": "string", "default": "mydb"},
                                        "pool_size": {"type": "integer", "default": 10},
                                    },
                                },
                            },
                        },
                    },
                },
            },
        }

        validator = create_test_service(tmp_path, "app", schema)
        result = validator.validate_with_defaults("app", {})

        assert result["service"]["config"]["database"]["name"] == "mydb"
        assert result["service"]["config"]["database"]["pool_size"] == 10


class TestNestedXGenerate:
    """Test recursive x-generate functionality in nested objects."""

    def test_nested_password_generation(self, tmp_path):
        """Test that passwords are auto-generated in nested objects."""
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "credentials": {
                    "type": "object",
                    "properties": {
                        "admin_password": {
                            "type": "string",
                            "x-generate": {
                                "type": "password",
                                "length": 24,
                                "include": "alphanumeric-symbols",
                            },
                        },
                        "root_password": {
                            "type": "string",
                            "x-generate": {
                                "type": "password",
                                "length": 32,
                                "include": "alphanumeric-symbols",
                            },
                        },
                    },
                },
            },
        }

        validator = create_test_service(tmp_path, "db", schema)
        result = validator.validate_with_defaults("db", {})

        assert "credentials" in result
        assert "admin_password" in result["credentials"]
        assert "root_password" in result["credentials"]
        assert len(result["credentials"]["admin_password"]) == 24
        assert len(result["credentials"]["root_password"]) == 32
        assert result["credentials"]["admin_password"] != result["credentials"]["root_password"]

    def test_qradar_schema_structure(self, tmp_path):
        """Test QRadar-like schema with nested qradar.admin_password."""
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "plan": {"type": "string", "default": "small"},
                "vm": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "cpu": {"type": "integer", "default": 8},
                    },
                    "required": ["name"],
                },
                "qradar": {
                    "type": "object",
                    "properties": {
                        "version": {"type": "string", "default": "7.5.0"},
                        "hostname": {"type": "string"},
                        "admin_password": {
                            "type": "string",
                            "x-generate": {
                                "type": "password",
                                "length": 24,
                                "include": "alphanumeric-symbols",
                            },
                        },
                        "root_password": {
                            "type": "string",
                            "x-generate": {
                                "type": "password",
                                "length": 32,
                                "include": "alphanumeric-symbols",
                            },
                        },
                    },
                    "required": ["hostname"],
                },
            },
            "required": ["plan", "vm", "qradar"],
        }

        validator = create_test_service(tmp_path, "qradar", schema)
        params = {
            "vm": {"name": "qradar-vm"},
            "qradar": {"hostname": "qradar.example.com"},
        }
        result = validator.validate_with_defaults("qradar", params)

        assert result["plan"] == "small"
        assert result["vm"]["name"] == "qradar-vm"
        assert result["vm"]["cpu"] == 8
        assert result["qradar"]["hostname"] == "qradar.example.com"
        assert result["qradar"]["version"] == "7.5.0"
        assert "admin_password" in result["qradar"]
        assert "root_password" in result["qradar"]
        assert len(result["qradar"]["admin_password"]) == 24
        assert len(result["qradar"]["root_password"]) == 32

    def test_user_provided_password_not_overwritten(self, tmp_path):
        """Test that user-provided passwords are not overwritten."""
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "credentials": {
                    "type": "object",
                    "properties": {
                        "password": {
                            "type": "string",
                            "x-generate": {
                                "type": "password",
                                "length": 16,
                            },
                        },
                    },
                },
            },
        }

        validator = create_test_service(tmp_path, "app", schema)
        user_password = "MySecurePassword123!"
        params = {"credentials": {"password": user_password}}
        result = validator.validate_with_defaults("app", params)

        assert result["credentials"]["password"] == user_password

    def test_mixed_defaults_and_xgenerate(self, tmp_path):
        """Test nested object with both defaults and x-generate fields."""
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "database": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "default": "mydb"},
                        "port": {"type": "integer", "default": 3306},
                        "password": {
                            "type": "string",
                            "x-generate": {
                                "type": "password",
                                "length": 20,
                            },
                        },
                        "api_key": {
                            "type": "string",
                            "x-generate": {
                                "type": "uuid",
                            },
                        },
                    },
                },
            },
        }

        validator = create_test_service(tmp_path, "app", schema)
        result = validator.validate_with_defaults("app", {})

        assert result["database"]["name"] == "mydb"
        assert result["database"]["port"] == 3306
        assert len(result["database"]["password"]) == 20
        assert "-" in result["database"]["api_key"]
        assert len(result["database"]["api_key"]) == 36


class TestNestedEdgeCases:
    """Test edge cases in nested schema processing."""

    def test_empty_nested_object_not_created(self, tmp_path):
        """Test that empty nested objects are not created if no defaults exist."""
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "optional_config": {
                    "type": "object",
                    "properties": {
                        "setting1": {"type": "string"},
                        "setting2": {"type": "integer"},
                    },
                },
            },
        }

        validator = create_test_service(tmp_path, "app", schema)
        result = validator.validate_with_defaults("app", {})

        assert "optional_config" not in result

    def test_nested_object_created_when_has_defaults(self, tmp_path):
        """Test that nested objects are created when they have defaults."""
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "config": {
                    "type": "object",
                    "properties": {
                        "enabled": {"type": "boolean", "default": True},
                    },
                },
            },
        }

        validator = create_test_service(tmp_path, "app", schema)
        result = validator.validate_with_defaults("app", {})

        assert "config" in result
        assert result["config"]["enabled"] is True

    def test_multiple_nested_objects_at_same_level(self, tmp_path):
        """Test multiple nested objects at the same level."""
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "database": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "default": "mydb"},
                    },
                },
                "cache": {
                    "type": "object",
                    "properties": {
                        "ttl": {"type": "integer", "default": 3600},
                    },
                },
                "logging": {
                    "type": "object",
                    "properties": {
                        "level": {"type": "string", "default": "INFO"},
                    },
                },
            },
        }

        validator = create_test_service(tmp_path, "app", schema)
        result = validator.validate_with_defaults("app", {})

        assert result["database"]["name"] == "mydb"
        assert result["cache"]["ttl"] == 3600
        assert result["logging"]["level"] == "INFO"


# Made with Bob
