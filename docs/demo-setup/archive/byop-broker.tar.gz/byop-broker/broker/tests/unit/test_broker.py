"""Unit tests for broker module."""

from typing import Any

import pytest

from broker.broker import CSBBroker
from broker.storage import StorageInterface


class InMemoryStorage(StorageInterface):
    """Simple in-memory storage for broker unit tests."""

    def __init__(self) -> None:
        self.instances: dict[str, dict[str, Any]] = {}

    def init(self, config: dict[str, Any]) -> None:
        """Initialize storage."""
        _ = config

    def create(self, instance_id: str, data: dict[str, Any]) -> None:
        """Create a new instance."""
        if instance_id in self.instances:
            raise ValueError(f"Instance {instance_id} already exists")
        self.instances[instance_id] = data.copy()

    def get(self, instance_id: str) -> dict[str, Any] | None:
        """Get an instance."""
        instance = self.instances.get(instance_id)
        return instance.copy() if instance is not None else None

    def update(self, instance_id: str, data: dict[str, Any]) -> None:
        """Update an existing instance."""
        if instance_id not in self.instances:
            raise ValueError(f"Instance {instance_id} not found")
        self.instances[instance_id].update(data)

    def delete(self, instance_id: str) -> bool:
        """Delete an instance."""
        if instance_id not in self.instances:
            return False
        del self.instances[instance_id]
        return True

    def exists(self, instance_id: str) -> bool:
        """Check whether an instance exists."""
        return instance_id in self.instances

    def list_all(self) -> list[dict[str, Any]]:
        """List all instances."""
        return [instance.copy() for instance in self.instances.values()]


@pytest.fixture
def storage() -> InMemoryStorage:
    """Provide an in-memory storage backend."""
    return InMemoryStorage()


@pytest.fixture
def broker(storage: InMemoryStorage, monkeypatch: pytest.MonkeyPatch) -> CSBBroker:
    """Provide a broker configured for unit tests."""
    monkeypatch.setattr(
        "broker.broker.discover_services",
        lambda: {
            "services": [
                {
                    "id": "mysql-service",
                    "name": "MySQL",
                    "description": "MySQL database service",
                    "bindable": False,
                    "dashboard_url_template": (
                        "https://service.example.test/instances/{instance_id}"
                    ),
                    "plans": [
                        {
                            "id": "dev",
                            "name": "Development",
                            "description": "Development plan",
                        }
                    ],
                }
            ]
        },
    )
    test_broker = CSBBroker(
        storage=storage,
        dashboard_url="http://localhost:7329/dash/<instance-id>",
        async_enabled=True,
    )
    test_broker.catalog()
    return test_broker


@pytest.mark.unit
def test_broker_exists() -> None:
    """Test that CSBBroker class exists."""
    assert CSBBroker is not None


@pytest.mark.unit
def test_broker_can_be_instantiated(storage: InMemoryStorage) -> None:
    """Test that CSBBroker can be instantiated with a storage backend."""
    test_broker = CSBBroker(
        storage=storage,
        dashboard_url="http://localhost:7329/dash/<instance-id>",
        async_enabled=True,
    )
    assert isinstance(test_broker, CSBBroker)


@pytest.mark.unit
def test_broker_catalog(broker: CSBBroker) -> None:
    """Test that catalog returns a valid service catalog structure."""
    catalog = broker.catalog()

    assert "services" in catalog
    assert isinstance(catalog["services"], list)


@pytest.mark.unit
def test_broker_provision_success(
    broker: CSBBroker,
    storage: InMemoryStorage,
) -> None:
    """Test successful provisioning of a service instance."""
    request_data = {
        "service_id": "test-service-123",
        "plan_id": "standard-plan",
        "context": {"platform": "ibm_cloud"},
        "parameters": {"param1": "value1"},
    }

    response, status = broker.provision(
        "crn:v1:local:public:service:region:account:instance-123::",
        request_data,
    )

    assert status == 202
    assert "dashboard_url" in response
    assert "instance-123" in response["dashboard_url"]
    assert storage.exists("instance-123")


@pytest.mark.unit
def test_broker_provision_uses_configured_dashboard_template(
    storage: InMemoryStorage,
) -> None:
    """Test provision substitutes the instance ID into a configured dashboard URL."""
    test_broker = CSBBroker(
        storage=storage,
        dashboard_url=(
            "https://github.com/example-org/example-repo/tree/main/instances/<instance-id>"
        ),
        async_enabled=True,
    )

    response, status = test_broker.provision(
        "crn:v1:local:public:service:region:account:instance-456::",
        {"service_id": "test-service", "plan_id": "standard-plan"},
    )

    assert status == 202
    assert response["dashboard_url"] == (
        "https://github.com/example-org/example-repo/tree/main/instances/instance-456"
    )


@pytest.mark.unit
def test_broker_provision_uses_service_defined_dashboard_template(
    broker: CSBBroker,
) -> None:
    """Test provision prefers service-defined dashboard URL templates over broker fallback."""
    response, status = broker.provision(
        "crn:v1:local:public:service:region:account:instance-789::",
        {"service_id": "mysql-service", "plan_id": "dev"},
    )

    assert status == 202
    assert response["dashboard_url"] == "https://service.example.test/instances/instance-789"


@pytest.mark.unit
def test_broker_last_operation_uses_service_defined_dashboard_template(
    broker: CSBBroker,
) -> None:
    """Test last_operation returns resolved dashboard URL from the service definition."""
    broker.provision(
        "service-dashboard-instance",
        {"service_id": "mysql-service", "plan_id": "dev"},
    )

    response, status = broker.last_operation("service-dashboard-instance")

    assert status == 200
    assert response["extensions"]["dashboard_url"] == (
        "https://service.example.test/instances/service-dashboard-instance"
    )


@pytest.mark.unit
def test_broker_provision_missing_service_id(broker: CSBBroker) -> None:
    """Test provision fails when service_id is missing."""
    response, status = broker.provision("test-instance", {"plan_id": "standard-plan"})

    assert status == 400
    assert response["error"] == "bad_request"


@pytest.mark.unit
def test_broker_provision_missing_plan_id(broker: CSBBroker) -> None:
    """Test provision fails when plan_id is missing."""
    response, status = broker.provision("test-instance", {"service_id": "test-service"})

    assert status == 400
    assert response["error"] == "bad_request"


@pytest.mark.unit
def test_broker_provision_already_exists_same_config(
    broker: CSBBroker,
) -> None:
    """Test provision returns 200 when instance exists with same config."""
    request_data = {
        "service_id": "test-service",
        "plan_id": "standard-plan",
    }

    first_response, first_status = broker.provision("test-instance", request_data)
    second_response, second_status = broker.provision("test-instance", request_data)

    assert first_status == 202
    assert "dashboard_url" in first_response
    assert second_status == 200
    assert "dashboard_url" in second_response


@pytest.mark.unit
def test_broker_provision_already_exists_different_config(
    broker: CSBBroker,
) -> None:
    """Test provision returns 409 when instance exists with different config."""
    broker.provision(
        "test-instance",
        {"service_id": "test-service", "plan_id": "standard-plan"},
    )

    response, status = broker.provision(
        "test-instance",
        {"service_id": "test-service", "plan_id": "premium-plan"},
    )

    assert status == 409
    assert response["error"] == "conflict"


@pytest.mark.unit
def test_broker_update_provision_success(
    broker: CSBBroker,
    storage: InMemoryStorage,
) -> None:
    """Test successful update of a service instance."""
    broker.provision(
        "test-instance",
        {"service_id": "mysql-service", "plan_id": "dev"},
    )

    response, status = broker.update_provision(
        "test-instance",
        {"plan_id": "premium-plan", "parameters": {"new_param": "new_value"}},
    )

    updated = storage.get("test-instance")
    assert status == 200
    assert response == {"dashboard_url": "https://service.example.test/instances/test-instance"}
    assert updated is not None
    assert updated["plan_id"] == "premium-plan"


@pytest.mark.unit
def test_broker_update_provision_not_found(broker: CSBBroker) -> None:
    """Test update fails when instance doesn't exist."""
    response, status = broker.update_provision(
        "nonexistent-instance",
        {"plan_id": "premium-plan"},
    )

    assert status == 400
    assert response["error"] == "bad_request"


@pytest.mark.unit
def test_broker_deprovision_success(
    broker: CSBBroker,
    storage: InMemoryStorage,
) -> None:
    """Test successful deprovisioning of a service instance."""
    broker.provision(
        "test-instance",
        {"service_id": "test-service", "plan_id": "standard-plan"},
    )

    response, status = broker.deprovision(
        "test-instance",
        service_id="test-service",
        plan_id="standard-plan",
    )

    assert status == 202
    assert response == {}
    assert not storage.exists("test-instance")


@pytest.mark.unit
def test_broker_deprovision_not_found(broker: CSBBroker) -> None:
    """Test deprovision returns gone when instance doesn't exist."""
    response, status = broker.deprovision("nonexistent-instance")

    assert status == 410
    assert response["error"] == "gone"


@pytest.mark.unit
def test_broker_deprovision_service_id_mismatch(
    broker: CSBBroker,
) -> None:
    """Test deprovision fails when service_id doesn't match."""
    broker.provision(
        "test-instance",
        {"service_id": "test-service-1", "plan_id": "standard-plan"},
    )

    response, status = broker.deprovision("test-instance", service_id="test-service-2")

    assert status == 400
    assert response["error"] == "bad_request"


@pytest.mark.unit
def test_broker_deprovision_plan_id_mismatch(
    broker: CSBBroker,
) -> None:
    """Test deprovision fails when plan_id doesn't match."""
    broker.provision(
        "test-instance",
        {"service_id": "test-service", "plan_id": "standard-plan"},
    )

    response, status = broker.deprovision("test-instance", plan_id="premium-plan")

    assert status == 400
    assert response["error"] == "bad_request"


@pytest.mark.unit
def test_broker_extract_instance_id(
    broker: CSBBroker,
) -> None:
    """Test extraction of instance ID from CRN."""
    crn = "crn:v1:local:public:service:region:account:my-instance::"
    assert broker._extract_instance_id(crn) == "my-instance"
    assert broker._extract_instance_id("simple-instance") == "simple-instance"


@pytest.mark.unit
def test_broker_last_operation_success(broker: CSBBroker) -> None:
    """Test last_operation returns instance status."""
    broker.provision(
        "test-instance",
        {"service_id": "test-service", "plan_id": "standard-plan"},
    )

    response, status = broker.last_operation("test-instance")

    assert status == 200
    assert response["state"] == "succeeded"
    assert response["extensions"]["instanceID"] == "test-instance"
    assert "dashboard_url" in response["extensions"]
    assert "test-instance" in response["extensions"]["dashboard_url"]


@pytest.mark.integration
def test_broker_roundtrip_preserves_broker_service_and_plan_ids(
    broker: CSBBroker,
    storage: InMemoryStorage,
) -> None:
    """Provision, query last_operation, and deprovision using caller-facing IDs."""
    request_data = {
        "service_id": "mariadb-service",
        "plan_id": "v11",
        "parameters": {
            "cluster_name": "k3s-cluster-2",
            "storage_size": "10Gi",
            "replicas": 1,
            "environment": "dev",
        },
    }

    provision_response, provision_status = broker.provision(
        "roundtrip-instance",
        request_data,
    )

    assert provision_status == 202
    assert provision_response["dashboard_url"].endswith("/roundtrip-instance")

    stored = storage.get("roundtrip-instance")
    assert stored is not None
    assert stored["service_id"] == "mariadb-service"
    assert stored["plan_id"] == "v11"

    last_operation_response, last_operation_status = broker.last_operation(
        "roundtrip-instance",
    )

    assert last_operation_status == 200
    assert last_operation_response["state"] == "succeeded"
    assert last_operation_response["extensions"]["instanceID"] == "roundtrip-instance"
    assert last_operation_response["extensions"]["serviceID"] == "mariadb-service"
    assert "dashboard_url" in last_operation_response["extensions"]
    assert "roundtrip-instance" in last_operation_response["extensions"]["dashboard_url"]

    deprovision_response, deprovision_status = broker.deprovision(
        "roundtrip-instance",
        service_id="mariadb-service",
        plan_id="v11",
    )

    assert deprovision_status == 202
    assert deprovision_response == {}
    assert storage.get("roundtrip-instance") is None


@pytest.mark.unit
def test_broker_list_instances(
    broker: CSBBroker,
) -> None:
    """Test list_instances returns current instances."""
    broker.provision(
        "instance-1",
        {"service_id": "test-service", "plan_id": "standard-plan"},
    )
    broker.provision(
        "instance-2",
        {"service_id": "test-service", "plan_id": "standard-plan"},
    )

    response, status = broker.list_instances()

    assert status == 200
    assert response["count"] == 2
    assert len(response["instances"]) == 2


# Made with Bob
