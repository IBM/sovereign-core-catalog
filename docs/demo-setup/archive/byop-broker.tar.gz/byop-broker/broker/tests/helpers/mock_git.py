"""
Mock Git operations for testing without requiring real Git repositories.

This module provides a MockGitOperations class that simulates Git operations
in-memory, allowing tests to run without Git credentials or network access.
"""

import logging
from pathlib import Path
from typing import Any


logger = logging.getLogger(__name__)


class MockGitOperations:
    """Mock Git operations for testing.

    This class provides the same interface as GitOperations but operates
    entirely in-memory without requiring a real Git repository or credentials.

    All Git operations are simulated:
    - Clone creates directory structure
    - Pull returns success
    - Commit/push track changes in memory
    - Status/commit queries return mock data
    """

    def __init__(self, repo_dir: Path | None = None) -> None:
        """Initialize mock Git operations.

        Args:
            repo_dir: Optional repository directory (for compatibility)
        """
        self.repo_dir = repo_dir or Path("/tmp/mock-git-repo")
        self.repo_url = "mock://test-repo.git"
        self.branch = "main"
        self.ssh_manager = None

        # Track mock state
        self.commits: list[dict[str, Any]] = []
        self.current_commit = "mock-commit-initial"
        self.files: dict[str, str] = {}  # path -> content
        self.is_cloned = False

        # Ensure directory exists
        self.repo_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"MockGitOperations initialized at {self.repo_dir}")

    def ensure_repo_cloned(self) -> None:
        """Mock clone - just create directory structure."""
        if self.is_cloned:
            logger.info(f"Mock repository already cloned at {self.repo_dir}")
            return

        logger.info(f"Mock cloning repository to {self.repo_dir}")
        self.repo_dir.mkdir(parents=True, exist_ok=True)

        # Create .git directory to simulate real repo
        git_dir = self.repo_dir / ".git"
        git_dir.mkdir(exist_ok=True)

        self.is_cloned = True
        logger.info("✓ Mock repository cloned successfully")

    def pull_latest(self) -> None:
        """Mock pull - always succeeds."""
        logger.info(f"Mock pulling latest changes from {self.branch}")
        # Simulate successful pull
        logger.info("✓ Mock pulled latest changes")

    def commit_and_push(
        self,
        message: str,
        author_name: str = "GitOps Orchestrator",
        author_email: str = "gitops@example.com",
    ) -> None:
        """Mock commit and push - track in memory.

        Args:
            message: Commit message
            author_name: Git author name
            author_email: Git author email
        """
        logger.info(f"Mock committing changes: {message}")

        # Generate mock commit hash
        commit_hash = f"mock-commit-{len(self.commits):04d}"

        # Track commit
        commit_data = {
            "hash": commit_hash,
            "message": message,
            "author_name": author_name,
            "author_email": author_email,
            "files": list(self.files.keys()),
        }
        self.commits.append(commit_data)
        self.current_commit = commit_hash

        logger.info(f"✓ Mock changes committed: {commit_hash}")
        logger.info(f"✓ Mock changes pushed to {self.branch}")

    def get_status(self) -> str:
        """Get mock git status.

        Returns:
            Empty string (no changes)
        """
        return ""

    def get_current_commit(self) -> str:
        """Get current mock commit hash.

        Returns:
            Current mock commit hash
        """
        return self.current_commit

    def get_remote_url(self) -> str:
        """Get mock remote repository URL.

        Returns:
            Mock remote URL
        """
        return self.repo_url

    def check_repo_exists(self) -> bool:
        """Check if mock repository exists.

        Returns:
            True if cloned, False otherwise
        """
        return self.is_cloned and (self.repo_dir / ".git").exists()

    def get_branch_name(self) -> str:
        """Get current mock branch name.

        Returns:
            Current branch name
        """
        return self.branch

    def print_status(self) -> None:
        """Print mock Git status."""
        print("\nMock Git Status:")
        print(f"  Repository: {self.repo_url}")
        print(f"  Local Path: {self.repo_dir}")
        print(f"  Branch: {self.branch}")
        print(f"  Commit: {self.current_commit}")
        print(f"  Commits: {len(self.commits)}")
        print(f"  Files: {len(self.files)}")

    # Helper methods for testing

    def write_file(self, path: str, content: str) -> None:
        """Write file to mock repository.

        Args:
            path: Relative file path
            content: File content
        """
        file_path = self.repo_dir / path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        self.files[path] = content
        logger.debug(f"Mock wrote file: {path}")

    def read_file(self, path: str) -> str:
        """Read file from mock repository.

        Args:
            path: Relative file path

        Returns:
            File content

        Raises:
            FileNotFoundError: If file doesn't exist
        """
        file_path = self.repo_dir / path
        if not file_path.exists():
            raise FileNotFoundError(f"Mock file not found: {path}")
        return file_path.read_text()

    def get_commits(self) -> list[dict[str, Any]]:
        """Get list of mock commits.

        Returns:
            List of commit data dictionaries
        """
        return self.commits.copy()

    def reset(self) -> None:
        """Reset mock state (useful for test cleanup)."""
        self.commits.clear()
        self.files.clear()
        self.current_commit = "mock-commit-initial"
        logger.info("Mock Git state reset")


# Made with Bob
