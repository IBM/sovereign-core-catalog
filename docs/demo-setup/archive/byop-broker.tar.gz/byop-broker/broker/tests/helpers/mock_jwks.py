"""Mock JWKS provider for testing JWT authentication."""

import time
from typing import Any

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa


class MockJWKSProvider:
    """Mock JWKS provider for testing.

    Generates RSA key pairs and provides JWKS endpoints for testing
    JWT validation without requiring a real OAuth 2.0/OIDC provider.
    """

    def __init__(self) -> None:
        """Initialize mock JWKS provider with RSA key pair."""
        # Generate RSA key pair
        self.private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
        self.public_key = self.private_key.public_key()

        # Key ID for JWKS
        self.kid = "test-key-1"

    def get_jwks(self) -> dict[str, Any]:
        """Get JWKS with public key.

        Returns:
            JWKS dictionary with public key
        """
        # Get public key in PEM format
        public_pem = self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

        # Convert to JWK format (simplified for testing)
        # In production, use proper JWK conversion
        return {
            "keys": [
                {
                    "kty": "RSA",
                    "use": "sig",
                    "kid": self.kid,
                    "alg": "RS256",
                    # Note: In real JWKS, we'd include n and e parameters
                    # For testing, PyJWT can work with the PEM directly
                    "x5c": [public_pem.decode("utf-8")],
                }
            ]
        }

    def create_token(
        self,
        claims: dict[str, Any] | None = None,
        issuer: str = "https://test-issuer.example.com/",
        audience: str = "test-audience",
        subject: str = "test-user",
        expires_in: int = 3600,
    ) -> str:
        """Create signed JWT for testing.

        Args:
            claims: Additional claims to include
            issuer: Token issuer (iss claim)
            audience: Token audience (aud claim)
            subject: Token subject (sub claim)
            expires_in: Token expiration time in seconds

        Returns:
            Signed JWT token string
        """
        now = int(time.time())

        payload: dict[str, Any] = {
            "iss": issuer,
            "aud": audience,
            "sub": subject,
            "iat": now,
            "nbf": now,
            "exp": now + expires_in,
        }

        # Add custom claims
        if claims:
            payload.update(claims)

        # Sign token with private key
        token = jwt.encode(
            payload,
            self.private_key,
            algorithm="RS256",
            headers={"kid": self.kid},
        )

        return token

    def create_expired_token(
        self,
        issuer: str = "https://test-issuer.example.com/",
        audience: str = "test-audience",
    ) -> str:
        """Create expired JWT for testing.

        Args:
            issuer: Token issuer
            audience: Token audience

        Returns:
            Expired JWT token string
        """
        now = int(time.time())

        payload: dict[str, Any] = {
            "iss": issuer,
            "aud": audience,
            "sub": "test-user",
            "iat": now - 7200,  # 2 hours ago
            "nbf": now - 7200,
            "exp": now - 3600,  # Expired 1 hour ago
        }

        token = jwt.encode(
            payload,
            self.private_key,
            algorithm="RS256",
            headers={"kid": self.kid},
        )

        return token

    def create_token_with_wrong_key(
        self,
        issuer: str = "https://test-issuer.example.com/",
        audience: str = "test-audience",
    ) -> str:
        """Create JWT signed with different key for testing signature validation.

        Args:
            issuer: Token issuer
            audience: Token audience

        Returns:
            JWT token signed with wrong key
        """
        # Generate different key
        wrong_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )

        now = int(time.time())

        payload: dict[str, Any] = {
            "iss": issuer,
            "aud": audience,
            "sub": "test-user",
            "iat": now,
            "nbf": now,
            "exp": now + 3600,
        }

        token = jwt.encode(
            payload,
            wrong_key,
            algorithm="RS256",
            headers={"kid": self.kid},
        )

        return token

    def get_public_key_pem(self) -> str:
        """Get public key in PEM format.

        Returns:
            Public key PEM string
        """
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode("utf-8")


# Made with Bob
