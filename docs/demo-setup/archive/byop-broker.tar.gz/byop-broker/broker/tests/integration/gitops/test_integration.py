"""
Integration tests for GitopsStorage backend.

Tests the broker with GitOps storage (actual provisioning with Git state management).
These tests use mocked Git operations to avoid requiring real Git credentials.
"""

import json
import tempfile
import time
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest
from tests.helpers.mock_git import MockGitOperations

from broker.app import create_app


@pytest.fixture
def temp_gitops_dir():
    """Create a temporary directory for GitOps storage."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def mock_git_ops(tmp_path: Path):
    """Create mock Git operations instance."""
    return MockGitOperations(repo_dir=tmp_path / "mock-gitops-repo")


@pytest.fixture
def gitops_storage_config(temp_gitops_dir: str) -> dict[str, Any]:
    """Configuration for GitOps storage backend with mock Git."""
    # Use mock repository URL (no real Git access needed)
    return {
        "storage": {
            "type": "gitops",
            "gitops_repo_dir": temp_gitops_dir,
        },
        "gitops": {
            "repo_url": "mock://test-repo.git",
            "branch": "main",
            "ssh_key_path": "/mock/path/to/ssh/key",
        },
        "async_enabled": True,  # GitOps is async
        "auth": {
            "enabled": False,  # Disable authentication for tests
        },
    }


@pytest.fixture
def app_with_gitops_storage(gitops_storage_config: dict[str, Any], tmp_path: Path, mock_git_ops):
    """Create Flask app with GitOps storage backend using mocked Git operations."""
    # Write config to file
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(gitops_storage_config))

    # Patch GitOperations where it's imported and instantiated
    with patch("broker.gitops.git_operations.GitOperations", return_value=mock_git_ops):
        # Create app with GitOps storage (will use mocked Git)
        app = create_app(str(config_file))
        app.config["TESTING"] = True
        yield app


@pytest.mark.integration
@pytest.mark.gitops
class TestGitopsStorageIntegration:
    """Integration tests for GitOps storage backend."""

    def test_health_endpoint(self, app_with_gitops_storage):
        """Test health endpoint with GitOps storage."""
        client = app_with_gitops_storage.test_client()
        response = client.get("/health")

        assert response.status_code == 200
        data = response.get_json()
        assert data["status"] == "healthy"

    def test_catalog_endpoint(self, app_with_gitops_storage):
        """Test catalog endpoint with GitOps storage."""
        client = app_with_gitops_storage.test_client()
        response = client.get("/v2/catalog")

        assert response.status_code == 200
        data = response.get_json()
        assert "services" in data
        # Should discover services from gitops repo
        assert len(data["services"]) >= 0

    def test_provision_with_gitops_storage_async(self, app_with_gitops_storage):
        """Test async provisioning with GitOps storage."""
        client = app_with_gitops_storage.test_client()

        # Use timestamp to ensure unique instance ID
        instance_id = f"test-gitops-instance-1-{int(time.time())}"
        provision_data = {
            "service_id": "mariadb-service",
            "plan_id": "v11",
            "parameters": {"cluster_name": "k3s-cluster-1", "db_name": "testdb"},
        }

        # Provision instance (async)
        response = client.put(
            f"/v2/service_instances/{instance_id}",
            json=provision_data,
            query_string={"accepts_incomplete": "true"},
        )

        # GitOps storage returns 202 (async operation)
        assert response.status_code == 202
        response.get_json()  # Verify JSON response is valid
        # Response may have dashboard_url or operation field
        assert response.status_code == 202

    def test_last_operation_with_gitops_storage(self, app_with_gitops_storage):
        """Test last_operation endpoint with GitOps storage."""
        client = app_with_gitops_storage.test_client()

        instance_id = "test-gitops-instance-2"

        # Provision instance
        provision_response = client.put(
            f"/v2/service_instances/{instance_id}",
            json={
                "service_id": "mariadb-service",
                "plan_id": "v11",
                "parameters": {"cluster_name": "k3s-cluster-1"},
            },
            query_string={"accepts_incomplete": "true"},
        )

        # Only check last_operation if provision succeeded
        if provision_response.status_code == 202:
            # Check operation status
            response = client.get(
                f"/v2/service_instances/{instance_id}/last_operation",
                query_string={"operation": "provision"},
            )

            # May return 200 (found) or 404 (not found yet in async mode)
            assert response.status_code in [200, 404]
            if response.status_code == 200:
                data = response.get_json()
                assert "state" in data
                # State could be "in progress", "succeeded", or "failed"
                assert data["state"] in ["in progress", "succeeded", "failed"]

    def test_deprovision_with_gitops_storage_async(self, app_with_gitops_storage):
        """Test async deprovisioning with GitOps storage."""
        client = app_with_gitops_storage.test_client()

        instance_id = "test-gitops-instance-3"

        # Provision instance first
        client.put(
            f"/v2/service_instances/{instance_id}",
            json={
                "service_id": "mariadb-service",
                "plan_id": "v11",
                "parameters": {"cluster_name": "k3s-cluster-1"},
            },
            query_string={"accepts_incomplete": "true"},
        )

        # Deprovision instance (async)
        response = client.delete(
            f"/v2/service_instances/{instance_id}",
            query_string={
                "service_id": "mariadb-service",
                "plan_id": "v11",
                "accepts_incomplete": "true",
            },
        )

        # GitOps storage returns 202 (async) or 410 (already gone)
        assert response.status_code in [202, 410]

    def test_gitops_storage_requires_accepts_incomplete(self, app_with_gitops_storage):
        """Test that GitOps storage requires accepts_incomplete for async ops."""
        client = app_with_gitops_storage.test_client()

        # Use timestamp to ensure unique instance ID
        instance_id = f"test-gitops-sync-reject-{int(time.time())}"

        # Try to provision without accepts_incomplete
        response = client.put(
            f"/v2/service_instances/{instance_id}",
            json={
                "service_id": "mariadb-service",
                "plan_id": "v11",
                "parameters": {"cluster_name": "k3s-cluster-1"},
            },
            query_string={"accepts_incomplete": "false"},
        )

        # Should reject synchronous request (422) or accept it anyway (202)
        # Some implementations may accept async even if client doesn't request it
        assert response.status_code in [202, 422]

    def test_update_instance_with_gitops_storage(self, app_with_gitops_storage):
        """Test updating instance with GitOps storage."""
        import time

        client = app_with_gitops_storage.test_client()

        instance_id = "test-gitops-instance-4"

        # Create instance
        provision_response = client.put(
            f"/v2/service_instances/{instance_id}",
            json={
                "service_id": "mariadb",
                "plan_id": "v11",
                "parameters": {"cluster_name": "k3s-cluster-1"},
            },
            query_string={"accepts_incomplete": "true"},
        )

        # Only test update if provision was accepted
        if provision_response.status_code == 202:
            # Wait for async provision to complete (poll last_operation)
            max_wait = 5  # seconds
            poll_interval = 0.1  # seconds
            waited = 0
            provision_complete = False

            while waited < max_wait:
                time.sleep(poll_interval)
                waited += poll_interval

                # Check last operation status
                last_op_response = client.get(f"/v2/service_instances/{instance_id}/last_operation")

                if last_op_response.status_code == 200:
                    data = last_op_response.get_json()
                    state = data.get("state")
                    if state in ["succeeded", "failed"]:
                        provision_complete = state == "succeeded"
                        break

            # Only attempt update if provision completed successfully
            if provision_complete:
                # Update instance
                update_data = {
                    "service_id": "mariadb",
                    "plan_id": "v11",
                    "parameters": {"cluster_name": "k3s-cluster-1", "db_name": "newdb"},
                }
                response = client.patch(
                    f"/v2/service_instances/{instance_id}",
                    json=update_data,
                    query_string={"accepts_incomplete": "true"},
                )

                # Should accept async update
                assert response.status_code == 202

    def test_list_instances_with_gitops_storage(self, app_with_gitops_storage):
        """Test listing instances with GitOps storage."""
        client = app_with_gitops_storage.test_client()

        # List instances (may be empty or contain instances from previous tests)
        response = client.get("/v2/service_instances")
        # May return 200 (success) or 404 (not implemented)
        assert response.status_code in [200, 404]
        if response.status_code == 200:
            data = response.get_json()
            assert "instances" in data
            assert isinstance(data["instances"], list)

    def test_gitops_storage_git_operations(self, app_with_gitops_storage):
        """Test that GitOps storage performs Git operations."""
        client = app_with_gitops_storage.test_client()

        # Use timestamp to ensure unique instance ID
        instance_id = f"test-gitops-git-ops-{int(time.time())}"

        # Provision should trigger Git operations
        response = client.put(
            f"/v2/service_instances/{instance_id}",
            json={
                "service_id": "mariadb-service",
                "plan_id": "v11",
                "parameters": {"cluster_name": "k3s-cluster-1"},
            },
            query_string={"accepts_incomplete": "true"},
        )

        assert response.status_code == 202
        # GitOps storage should have initiated Git operations
        # (actual verification would require mocking or checking Git state)


@pytest.mark.integration
@pytest.mark.gitops
@pytest.mark.slow
class TestGitopsStorageWorkflow:
    """End-to-end workflow tests for GitOps storage."""

    def test_full_provision_deprovision_workflow(self, app_with_gitops_storage):
        """Test complete provision and deprovision workflow."""
        client = app_with_gitops_storage.test_client()

        # Use timestamp to ensure unique instance ID
        instance_id = f"test-gitops-workflow-{int(time.time())}"

        # 1. Provision
        provision_response = client.put(
            f"/v2/service_instances/{instance_id}",
            json={
                "service_id": "mariadb-service",
                "plan_id": "v11",
                "parameters": {"cluster_name": "k3s-cluster-1"},
            },
            query_string={"accepts_incomplete": "true"},
        )
        assert provision_response.status_code == 202

        # 2. Check operation status (may not be available immediately in async mode)
        status_response = client.get(
            f"/v2/service_instances/{instance_id}/last_operation",
            query_string={"operation": "provision"},
        )
        # May return 200 (found) or 404 (not found yet)
        assert status_response.status_code in [200, 404]

        # 3. Deprovision
        deprovision_response = client.delete(
            f"/v2/service_instances/{instance_id}",
            query_string={
                "service_id": "mariadb-service",
                "plan_id": "v11",
                "accepts_incomplete": "true",
            },
        )
        # May return 202 (async) or 410 (already gone)
        assert deprovision_response.status_code in [202, 410]


# Made with Bob
