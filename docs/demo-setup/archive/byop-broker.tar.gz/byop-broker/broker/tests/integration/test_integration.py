"""Tests for Flask app factory, discovery modules, and config."""

import importlib
import json
import sys
from pathlib import Path

import pytest


# Import helper from conftest
sys.path.insert(0, str(Path(__file__).parent.parent))
from conftest import create_service_catalog


def test_load_config_file_success(tmp_path: Path) -> None:
    """Load JSON configuration from disk."""
    config_file = tmp_path / "config.json"
    config_file.write_text(
        json.dumps({"storage": {"type": "dummy"}, "gitops": {"branch": "main"}}),
        encoding="utf-8",
    )

    app_module = importlib.import_module("broker.app")
    data = app_module.load_config_file(str(config_file))

    assert data["storage"]["type"] == "dummy"
    assert data["gitops"]["branch"] == "main"


def test_load_config_file_missing(tmp_path: Path) -> None:
    """Raise when the config file does not exist."""
    app_module = importlib.import_module("broker.app")

    with pytest.raises(FileNotFoundError):
        app_module.load_config_file(str(tmp_path / "missing.json"))


def test_load_config_file_non_dict_json(tmp_path: Path) -> None:
    """Return empty dict for valid non-object JSON content."""
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(["not", "a", "dict"]), encoding="utf-8")

    app_module = importlib.import_module("broker.app")
    data = app_module.load_config_file(str(config_file))

    assert data == {}


def test_create_app_routes_and_health(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Create the Flask app and verify core routes."""
    app_module = importlib.import_module("broker.app")

    class DummyStorage:
        """Minimal storage for Flask route tests."""

        def exists(self, instance_id: str) -> bool:
            return False

        def get(self, instance_id: str):
            return None

        def create(self, instance_id: str, data):
            return None

        def update(self, instance_id: str, data):
            return None

        def delete(self, instance_id: str) -> bool:
            return True

        def list_all(self):
            return []

    monkeypatch.setattr(app_module, "create_storage", lambda *_args, **_kwargs: DummyStorage())

    # Create minimal config with auth disabled
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps({"auth": {"enabled": False}}))

    flask_app = app_module.create_app(str(config_file))
    client = flask_app.test_client()

    health_response = client.get("/health")
    assert health_response.status_code == 200
    assert health_response.get_json() == {"status": "healthy"}

    not_found_response = client.get("/does-not-exist")
    assert not_found_response.status_code == 404
    assert not_found_response.get_json()["error"] == "not_found"


def test_create_app_cluster_route(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Expose discovered clusters via the Flask route."""
    app_module = importlib.import_module("broker.app")

    class DummyStorage:
        """Minimal storage for Flask route tests."""

        def exists(self, instance_id: str) -> bool:
            return False

        def get(self, instance_id: str):
            return None

        def create(self, instance_id: str, data):
            return None

        def update(self, instance_id: str, data):
            return None

        def delete(self, instance_id: str) -> bool:
            return True

        def list_all(self):
            return []

    monkeypatch.setattr(app_module, "create_storage", lambda *_args, **_kwargs: DummyStorage())

    # Create minimal config with auth disabled
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps({"auth": {"enabled": False}}))

    flask_app = app_module.create_app(str(config_file))
    client = flask_app.test_client()

    response = client.get("/v2/clusters")
    assert response.status_code == 404


def test_create_app_accepts_incomplete_required_for_patch_and_delete(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Reject PATCH and DELETE when accepts_incomplete is missing in async mode."""
    app_module = importlib.import_module("broker.app")

    class DummyStorage:
        """Minimal storage for Flask route tests."""

        def exists(self, instance_id: str) -> bool:
            return False

        def get(self, instance_id: str):
            return None

        def create(self, instance_id: str, data):
            return None

        def update(self, instance_id: str, data):
            return None

        def delete(self, instance_id: str) -> bool:
            return True

        def list_all(self):
            return []

    monkeypatch.setattr(app_module, "create_storage", lambda *_args, **_kwargs: DummyStorage())

    # Create minimal config with auth disabled
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps({"auth": {"enabled": False}}))

    flask_app = app_module.create_app(str(config_file))
    client = flask_app.test_client()

    patch_response = client.patch("/v2/service_instances/test-instance", json={})
    assert patch_response.status_code == 422
    assert patch_response.get_json()["error"] == "unprocessable_entity"

    delete_response = client.delete("/v2/service_instances/test-instance")
    assert delete_response.status_code == 422
    assert delete_response.get_json()["error"] == "unprocessable_entity"


def test_catalog_build_service_definition_uses_runtime_service_yaml(tmp_path: Path) -> None:
    """Build metadata from GitOps runtime catalog/catalog.yaml content."""
    catalog_discovery = importlib.import_module("broker.catalog_discovery")
    service_dir = tmp_path / "mysql"

    # Use helper function to create catalog structure
    create_service_catalog(
        tmp_path,
        "mysql",
        description="MySQL Database Server",
        display_name="mysql",  # Keep lowercase as expected by test
        plans=[
            {
                "id": "v8",
                "name": "MySQL 8.0",
                "description": "MySQL 8.0 single-instance deployment",
            }
        ],
    )

    service = catalog_discovery._build_service_definition("mysql", service_dir)

    assert service is not None
    assert service["id"] == "mysql"
    assert service["name"] == "mysql"
    assert service["description"] == "MySQL Database Server"
    assert service["plans"] == [
        {
            "id": "v8",
            "name": "MySQL 8.0",
            "description": "MySQL 8.0 single-instance deployment",
        }
    ]


def test_catalog_build_service_definition_requires_defined_plans(tmp_path: Path) -> None:
    """Skip services that do not define plans in catalog/catalog.yaml."""
    catalog_discovery = importlib.import_module("broker.catalog_discovery")
    service_dir = tmp_path / "redis"
    catalog_dir = service_dir / "catalog"
    catalog_dir.mkdir(parents=True)
    (catalog_dir / "catalog.yaml").write_text(
        "name: redis\ndescription: Redis Cache\n",
        encoding="utf-8",
    )

    service = catalog_discovery._build_service_definition("redis", service_dir)

    assert service is None


def test_discover_services_from_explicit_repo_dir(tmp_path: Path) -> None:
    """Discover only services with explicit plan definitions."""
    services_dir = tmp_path / "services"
    services_dir.mkdir(parents=True)

    # Use helper function to create catalog structures
    create_service_catalog(
        services_dir,
        "mysql",
        description="MySQL Database Server",
        display_name="MySQL",  # Uppercase as expected by test
        plans=[
            {
                "id": "v8",
                "name": "MySQL 8.0",
                "description": "MySQL 8.0 single-instance deployment",
            }
        ],
    )

    create_service_catalog(
        services_dir,
        "mariadb",
        description="MariaDB Database Server",
        display_name="MariaDB",  # Uppercase as expected by test
        plans=[
            {
                "id": "v11",
                "name": "MariaDB 11.2",
                "description": "MariaDB 11.2 single-instance deployment",
            }
        ],
    )

    # Create invalid service (no plans)
    invalid_catalog_dir = services_dir / "invalid" / "latest" / "catalog"
    invalid_catalog_dir.mkdir(parents=True)
    (invalid_catalog_dir / "catalog.yaml").write_text(
        "name: Invalid\ndescription: Missing plans\n",
        encoding="utf-8",
    )

    # Add a non-service file to test filtering
    (services_dir / "README.txt").write_text("ignore me", encoding="utf-8")

    catalog_discovery = importlib.import_module("broker.catalog_discovery")
    result = catalog_discovery.discover_services(str(tmp_path))

    assert result["services"]
    assert {service["id"] for service in result["services"]} == {
        "mysql",
        "mariadb",
    }
    assert {service["name"] for service in result["services"]} == {"MySQL", "MariaDB"}


def test_discover_services_missing_services_dir(tmp_path: Path) -> None:
    """Return an empty service list when the services directory is absent."""
    catalog_discovery = importlib.import_module("broker.catalog_discovery")

    result = catalog_discovery.discover_services(str(tmp_path))

    assert result == {"services": []}


def test_config_reads_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    """Read configuration values from environment variables."""
    config_module = importlib.import_module("broker.config")

    monkeypatch.setenv("PORT", "9999")
    monkeypatch.setenv("HOST", "127.0.0.1")
    monkeypatch.setenv("STORAGE_DIR", "/tmp/broker-data")
    monkeypatch.setenv("DASHBOARD_URL", "http://example.test/dash/<instance-id>")
    monkeypatch.setenv("ASYNC_ENABLED", "false")
    monkeypatch.setenv("TLS_ENABLED", "true")
    monkeypatch.setenv("MTLS_ENABLED", "true")

    cfg = config_module.Config()

    assert cfg.port == 9999
    assert cfg.host == "127.0.0.1"
    assert cfg.storage_dir == "/tmp/broker-data"
    assert cfg.async_enabled is False
    assert cfg.tls_enabled is True
    assert cfg.mtls_enabled is True
    assert "Config(port=9999" in repr(cfg)


# Made with Bob


def test_get_service_schema_success(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test successful schema retrieval from /services/<service_id>/schema endpoint."""
    # Create a mock GitOps repository with service and schema
    services_dir = tmp_path / "services"
    services_dir.mkdir(parents=True)

    # Create MySQL service with schema
    mysql_dir = services_dir / "mysql" / "latest"
    template_dir = mysql_dir / "template"
    template_dir.mkdir(parents=True)

    # Create schema.json
    schema = {
        "type": "object",
        "properties": {
            "database_name": {
                "type": "string",
                "description": "Name of the database",
                "minLength": 1,
                "maxLength": 63,
            },
            "database_user": {"type": "string", "description": "Database username"},
        },
        "required": ["database_name", "database_user"],
    }
    (template_dir / "schema.json").write_text(json.dumps(schema), encoding="utf-8")

    # Create catalog
    catalog_dir = mysql_dir / "catalog"
    catalog_dir.mkdir(parents=True)
    (catalog_dir / "catalog.yaml").write_text(
        "name: MySQL\nplans:\n  - id: v8\n    name: MySQL 8.0\n    description: MySQL 8.0\n",
        encoding="utf-8",
    )

    # Create config file
    config_file = tmp_path / "config.json"
    config_data = {
        "storage": {"type": "file", "config": {"storage_dir": str(tmp_path / "storage")}},
        "gitops": {"repo_url": "file://" + str(tmp_path), "branch": "main"},
        "auth": {"enabled": False},  # Disable authentication for tests
    }
    config_file.write_text(json.dumps(config_data), encoding="utf-8")

    # Set environment variable for GitOps repo directory
    monkeypatch.setenv("GITOPS_REPO_DIR", str(tmp_path))

    # Create app
    app_module = importlib.import_module("broker.app")
    app = app_module.create_app(str(config_file))
    client = app.test_client()

    # Test schema endpoint
    response = client.get("/services/mysql/schema")

    assert response.status_code == 200
    data = response.get_json()
    assert data["type"] == "object"
    assert "properties" in data
    assert "database_name" in data["properties"]
    assert "database_user" in data["properties"]
    assert data["required"] == ["database_name", "database_user"]


def test_get_service_schema_not_found(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test schema endpoint returns 404 for non-existent service."""
    # Create empty services directory
    services_dir = tmp_path / "services"
    services_dir.mkdir(parents=True)

    # Create config file
    config_file = tmp_path / "config.json"
    config_data = {
        "storage": {"type": "file", "config": {"storage_dir": str(tmp_path / "storage")}},
        "gitops": {"repo_url": "file://" + str(tmp_path), "branch": "main"},
        "auth": {"enabled": False},  # Disable authentication for tests
    }
    config_file.write_text(json.dumps(config_data), encoding="utf-8")

    # Set environment variable for GitOps repo directory
    monkeypatch.setenv("GITOPS_REPO_DIR", str(tmp_path))

    # Create app
    app_module = importlib.import_module("broker.app")
    app = app_module.create_app(str(config_file))
    client = app.test_client()

    # Test schema endpoint for non-existent service
    response = client.get("/services/nonexistent-service/schema")

    assert response.status_code == 404
    data = response.get_json()
    assert "error" in data
    assert data["error"] == "not_found"
    assert "No schema found" in data["description"]


def test_get_service_schema_maps_service_id(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test that service_id is correctly mapped to service_type (removes -service suffix)."""
    # Create a mock GitOps repository with service and schema
    services_dir = tmp_path / "services"
    services_dir.mkdir(parents=True)

    # Create MariaDB service with schema (note: directory is "mariadb", not "mariadb-service")
    mariadb_dir = services_dir / "mariadb" / "v1"
    template_dir = mariadb_dir / "template"
    template_dir.mkdir(parents=True)

    # Create schema.json
    schema = {
        "type": "object",
        "properties": {"db_name": {"type": "string"}},
        "required": ["db_name"],
    }
    (template_dir / "schema.json").write_text(json.dumps(schema), encoding="utf-8")

    # Create catalog
    catalog_dir = mariadb_dir / "catalog"
    catalog_dir.mkdir(parents=True)
    (catalog_dir / "catalog.yaml").write_text(
        "name: MariaDB\nplans:\n  - id: v11\n    name: MariaDB 11\n    description: MariaDB 11\n",
        encoding="utf-8",
    )

    # Create config file
    config_file = tmp_path / "config.json"
    config_data = {
        "storage": {"type": "file", "config": {"storage_dir": str(tmp_path / "storage")}},
        "gitops": {"repo_url": "file://" + str(tmp_path), "branch": "main"},
        "auth": {"enabled": False},  # Disable authentication for tests
    }
    config_file.write_text(json.dumps(config_data), encoding="utf-8")

    # Set environment variable for GitOps repo directory
    monkeypatch.setenv("GITOPS_REPO_DIR", str(tmp_path))

    # Create app
    app_module = importlib.import_module("broker.app")
    app = app_module.create_app(str(config_file))
    client = app.test_client()

    # Test schema endpoint - service_id should match directory name
    response = client.get("/services/mariadb/schema")

    # Should successfully load schema for "mariadb" service type
    assert response.status_code == 200
    data = response.get_json()
    assert data["type"] == "object"
    assert "db_name" in data["properties"]
