"""
Integration tests for FileStorage backend.

Tests the broker with file-based storage (metadata-only, no actual provisioning).
"""

import json
import tempfile
from pathlib import Path
from typing import Any

import pytest

from broker.app import create_app


@pytest.fixture
def temp_storage_dir():
    """Create a temporary directory for file storage."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def file_storage_config(temp_storage_dir: str) -> dict[str, Any]:
    """Configuration for file storage backend."""
    return {
        "storage": {
            "type": "file",
            "config": {
                "storage_dir": temp_storage_dir,
                "async_enabled": False,  # File storage is synchronous
            },
        },
        "gitops": {
            "repo_url": "",  # Not used for file storage
            "branch": "main",
        },
        "auth": {
            "enabled": False,  # Disable authentication for tests
        },
    }


@pytest.fixture
def app_with_file_storage(file_storage_config: dict[str, Any], tmp_path: Path):
    """Create Flask app with file storage backend."""
    # Write config to file
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(file_storage_config))

    # Create app with file storage
    app = create_app(str(config_file))
    app.config["TESTING"] = True
    return app


class TestFileStorageIntegration:
    """Integration tests for file storage backend."""

    def test_health_endpoint(self, app_with_file_storage):
        """Test health endpoint with file storage."""
        client = app_with_file_storage.test_client()
        response = client.get("/health")

        assert response.status_code == 200
        data = response.get_json()
        assert data["status"] == "healthy"

    def test_catalog_endpoint(self, app_with_file_storage):
        """Test catalog endpoint with file storage."""
        client = app_with_file_storage.test_client()
        response = client.get("/v2/catalog")

        assert response.status_code == 200
        data = response.get_json()
        assert "services" in data
        # Should discover services from gitops repo
        assert len(data["services"]) >= 0

    def test_provision_with_file_storage(self, app_with_file_storage):
        """Test provisioning with file storage (metadata only)."""
        client = app_with_file_storage.test_client()

        instance_id = "test-file-instance-1"
        provision_data = {
            "service_id": "mysql-service",
            "plan_id": "small",
            "parameters": {"db_name": "testdb"},
        }

        # Provision instance
        response = client.put(
            f"/v2/service_instances/{instance_id}",
            json=provision_data,
            query_string={"accepts_incomplete": "false"},
        )

        # File storage returns 201 (synchronous, metadata-only)
        assert response.status_code == 201
        data = response.get_json()
        assert data.get("dashboard_url") is not None

    def test_get_instance_with_file_storage(self, app_with_file_storage):
        """Test retrieving instance with file storage."""
        client = app_with_file_storage.test_client()

        instance_id = "test-file-instance-2"
        provision_data = {
            "service_id": "mysql-service",
            "plan_id": "small",
        }

        # Create instance
        client.put(
            f"/v2/service_instances/{instance_id}",
            json=provision_data,
            query_string={"accepts_incomplete": "false"},
        )

        # Get instance
        response = client.get(f"/v2/service_instances/{instance_id}")
        assert response.status_code == 200
        data = response.get_json()
        assert data["service_id"] == "mysql-service"
        assert data["plan_id"] == "small"
        assert data["state"] == "succeeded"

    def test_update_instance_with_file_storage(self, app_with_file_storage):
        """Test updating instance with file storage."""
        client = app_with_file_storage.test_client()

        instance_id = "test-file-instance-3"

        # Create instance
        client.put(
            f"/v2/service_instances/{instance_id}",
            json={"service_id": "mysql-service", "plan_id": "small"},
            query_string={"accepts_incomplete": "false"},
        )

        # Update instance
        update_data = {
            "service_id": "mysql-service",
            "plan_id": "large",
            "parameters": {"db_name": "newdb"},
        }
        response = client.patch(
            f"/v2/service_instances/{instance_id}",
            json=update_data,
            query_string={"accepts_incomplete": "false"},
        )

        assert response.status_code == 200
        data = response.get_json()
        assert data.get("dashboard_url") is not None

    def test_deprovision_with_file_storage(self, app_with_file_storage):
        """Test deprovisioning with file storage."""
        client = app_with_file_storage.test_client()

        instance_id = "test-file-instance-4"

        # Create instance
        client.put(
            f"/v2/service_instances/{instance_id}",
            json={"service_id": "mysql-service", "plan_id": "small"},
            query_string={"accepts_incomplete": "false"},
        )

        # Deprovision instance
        response = client.delete(
            f"/v2/service_instances/{instance_id}",
            query_string={
                "service_id": "mysql-service",
                "plan_id": "small",
                "accepts_incomplete": "false",
            },
        )

        assert response.status_code == 200
        data = response.get_json()
        assert data == {}

    def test_list_instances_with_file_storage(self, app_with_file_storage):
        """Test listing instances with file storage."""
        client = app_with_file_storage.test_client()

        # Create multiple instances
        for i in range(3):
            client.put(
                f"/v2/service_instances/test-file-list-{i}",
                json={"service_id": "mysql-service", "plan_id": "small"},
                query_string={"accepts_incomplete": "false"},
            )

        # List instances (custom extension endpoint, not OSB v2 spec)
        response = client.get("/service_instances")
        assert response.status_code == 200
        data = response.get_json()
        assert "instances" in data
        assert len(data["instances"]) >= 3

    def test_duplicate_provision_with_file_storage(self, app_with_file_storage):
        """Test that duplicate provision is handled correctly."""
        client = app_with_file_storage.test_client()

        instance_id = "test-file-duplicate"
        provision_data = {
            "service_id": "mysql-service",
            "plan_id": "small",
        }

        # First provision
        response1 = client.put(
            f"/v2/service_instances/{instance_id}",
            json=provision_data,
            query_string={"accepts_incomplete": "false"},
        )
        assert response1.status_code == 201

        # Duplicate provision with same config
        response2 = client.put(
            f"/v2/service_instances/{instance_id}",
            json=provision_data,
            query_string={"accepts_incomplete": "false"},
        )
        assert response2.status_code == 200  # Already exists

    def test_file_storage_is_synchronous(self, app_with_file_storage):
        """Test that file storage operations are synchronous."""
        client = app_with_file_storage.test_client()

        instance_id = "test-file-sync"

        # Provision should return 201 (not 202)
        response = client.put(
            f"/v2/service_instances/{instance_id}",
            json={"service_id": "mysql-service", "plan_id": "small"},
            query_string={"accepts_incomplete": "false"},
        )
        assert response.status_code == 201  # Synchronous completion

        # Instance should be immediately available
        get_response = client.get(f"/v2/service_instances/{instance_id}")
        assert get_response.status_code == 200
        data = get_response.get_json()
        assert data["state"] == "succeeded"


# Made with Bob
