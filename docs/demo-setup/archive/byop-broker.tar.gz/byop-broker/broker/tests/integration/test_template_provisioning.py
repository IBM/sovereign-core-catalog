"""Integration tests for template-based provisioning.

This module tests the end-to-end template provisioning flow including:
- Template loading
- Schema validation
- Template rendering
- File creation
- Fallback to legacy provisioning
"""

import json
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from broker.gitops.provision_templates import (
    TemplateProvisioningError,
    check_template_support,
    create_instance_files_from_templates,
    validate_service_parameters,
)


class TestTemplateProvisioning:
    """Test template-based provisioning integration."""

    @pytest.fixture
    def gitops_repo_dir(self, tmp_path: Path) -> Path:
        """Create a temporary GitOps repository directory structure."""
        gitops_repo = tmp_path / "gitops-repo"
        gitops_repo.mkdir()

        # Create schema and templates
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "database_name": {
                    "type": "string",
                    "pattern": "^[a-zA-Z][a-zA-Z0-9_]*$",
                },
                "database_user": {
                    "type": "string",
                    "default": "appuser",
                },
            },
            "required": ["database_name"],
        }

        secret_template = """apiVersion: v1
kind: Secret
metadata:
  name: {{ instance_name }}-secret
  namespace: {{ namespace }}
stringData:
  database: {{ spec.database_name }}
  user: {{ spec.database_user }}
"""

        kust_template = """apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
namespace: {{ namespace }}
resources:
  - secret.yaml
"""

        # Create MySQL service with templates in both v1 and latest versions
        for version in ["v1", "latest"]:
            mysql_dir = gitops_repo / "services" / "mysql" / version / "template"
            mysql_dir.mkdir(parents=True)
            (mysql_dir / "schema.json").write_text(json.dumps(schema))
            (mysql_dir / "secret.yaml.tmpl").write_text(secret_template)
            (mysql_dir / "kustomization.yaml.tmpl").write_text(kust_template)

        return gitops_repo

    @pytest.fixture
    def gitops_repo_dir_v2(self, tmp_path: Path) -> Path:
        """Create a temporary GitOps repository directory (v2)."""
        repo_dir = tmp_path / "gitops-repo"
        repo_dir.mkdir()
        return repo_dir

    def test_check_template_support_exists(
        self, gitops_repo_dir: Path, monkeypatch: pytest.MonkeyPatch
    ):
        """Test checking template support for service with templates."""
        # Mock GitConfig to return our test directories
        with patch("broker.gitops.provision_templates.GitConfig") as mock_config:
            mock_config.get_repo_dir.return_value = gitops_repo_dir

            result = check_template_support("mysql")
            assert result is True

    def test_check_template_support_missing(self, gitops_repo_dir: Path):
        """Test checking template support for service without templates."""
        with patch("broker.gitops.provision_templates.GitConfig") as mock_config:
            mock_config.get_repo_dir.return_value = gitops_repo_dir

            result = check_template_support("redis")
            assert result is False

    def test_validate_service_parameters_valid(self, gitops_repo_dir: Path):
        """Test parameter validation with valid parameters."""
        with patch("broker.gitops.provision_templates.GitConfig") as mock_config:
            mock_config.get_repo_dir.return_value = gitops_repo_dir

            params = {"database_name": "myapp", "database_user": "appuser"}
            result = validate_service_parameters("mysql", params)
            assert result is True

    def test_validate_service_parameters_invalid(self, gitops_repo_dir: Path):
        """Test parameter validation with invalid parameters."""
        with patch("broker.gitops.provision_templates.GitConfig") as mock_config:
            mock_config.get_repo_dir.return_value = gitops_repo_dir

            # Missing required field
            params = {"database_user": "appuser"}
            result = validate_service_parameters("mysql", params)
            assert result is False

    def test_create_instance_files_from_templates_success(self, gitops_repo_dir: Path):
        """Test successful template-based instance file creation."""
        with patch("broker.gitops.provision_templates.GitConfig") as mock_config:
            mock_config.get_repo_dir.return_value = gitops_repo_dir

            # Create instances directory
            instances_dir = gitops_repo_dir / "instances"
            instances_dir.mkdir()

            instance_dir, rendered_files = create_instance_files_from_templates(
                instance_name="test-mysql-001",
                instance_id="test-id-001",
                namespace="mysql-test-001",
                service_type="mysql",
                service_version="v1",
                cluster_name="test-cluster",
                cluster_url="https://test-cluster:6443",
                environment="dev",
                replicas=1,
                storage_size="10Gi",
                deployment_registry="quay.io/test",
                image_pull_secret_name=None,
                parameters_spec={"database_name": "testdb", "database_user": "testuser"},
                context=None,
            )

            # Verify instance directory created
            assert instance_dir.exists()
            assert instance_dir.name == "test-mysql-001"

            # Verify files were rendered
            assert "secret.yaml" in rendered_files
            assert "kustomization.yaml" in rendered_files

            # Verify secret content
            secret_content = rendered_files["secret.yaml"]
            assert "test-mysql-001-secret" in secret_content
            assert "testdb" in secret_content
            assert "testuser" in secret_content

            # Verify files were written
            assert (instance_dir / "secret.yaml").exists()
            assert (instance_dir / "kustomization.yaml").exists()

            # Verify secret file content
            with open(instance_dir / "secret.yaml") as f:
                secret_data = yaml.safe_load(f)
                assert secret_data["metadata"]["name"] == "test-mysql-001-secret"
                assert secret_data["stringData"]["database"] == "testdb"
                assert secret_data["stringData"]["user"] == "testuser"

    def test_create_instance_files_validation_error(self, gitops_repo_dir: Path):
        """Test template provisioning with validation errors."""
        with patch("broker.gitops.provision_templates.GitConfig") as mock_config:
            mock_config.get_repo_dir.return_value = gitops_repo_dir

            # Missing required field
            with pytest.raises(TemplateProvisioningError) as exc_info:
                create_instance_files_from_templates(
                    instance_name="test-mysql-002",
                    instance_id="test-id-002",
                    namespace="mysql-test-002",
                    service_type="mysql",
                    service_version="v1",
                    cluster_name="test-cluster",
                    cluster_url="https://test-cluster:6443",
                    environment="dev",
                    replicas=1,
                    storage_size="10Gi",
                    deployment_registry="quay.io/test",
                    image_pull_secret_name=None,
                    parameters_spec={},  # Missing database_name
                    context=None,
                )

            assert "validation failed" in str(exc_info.value).lower()

    def test_create_instance_files_with_defaults(self, gitops_repo_dir: Path):
        """Test template provisioning applies defaults."""
        with patch("broker.gitops.provision_templates.GitConfig") as mock_config:
            mock_config.get_repo_dir.return_value = gitops_repo_dir

            instances_dir = gitops_repo_dir / "instances"
            instances_dir.mkdir()

            # Only provide required field, let defaults apply
            instance_dir, rendered_files = create_instance_files_from_templates(
                instance_name="test-mysql-003",
                instance_id="test-id-003",
                namespace="mysql-test-003",
                service_type="mysql",
                service_version="v1",
                cluster_name="test-cluster",
                cluster_url="https://test-cluster:6443",
                environment="dev",
                replicas=1,
                storage_size="10Gi",
                deployment_registry="quay.io/test",
                image_pull_secret_name=None,
                parameters_spec={"database_name": "testdb"},  # Only required field
                context=None,
            )

            # Verify default was applied
            secret_content = rendered_files["secret.yaml"]
            assert "appuser" in secret_content  # Default database_user

    def test_create_instance_files_with_subdirectories(self, tmp_path: Path):
        """Test that subdirectory structure is preserved when writing files."""
        gitops_repo = tmp_path / "gitops-repo"
        gitops_repo.mkdir()

        # Create schema
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {"service_name": {"type": "string", "default": "test-service"}},
        }

        # Create templates with subdirectory structure
        # Main template (root level)
        main_template = """apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
namespace: {{ namespace }}
resources:
  - secret.yaml
  - auth
"""

        secret_template = """apiVersion: v1
kind: Secret
metadata:
  name: {{ instance_name }}-secret
  namespace: {{ namespace }}
stringData:
  service: {{ spec.service_name }}
"""

        # Auth subdirectory templates
        auth_kust_template = """apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
  - rolebinding.yaml
"""

        auth_rolebinding_template = """apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ instance_name }}-binding
  namespace: {{ namespace }}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: admin
subjects:
  - kind: ServiceAccount
    name: {{ instance_name }}-sa
    namespace: {{ namespace }}
"""

        # Create directory structure
        template_dir = gitops_repo / "services" / "testservice" / "v1" / "template"
        template_dir.mkdir(parents=True)

        # Write root level templates
        (template_dir / "schema.json").write_text(json.dumps(schema))
        (template_dir / "kustomization.yaml.tmpl").write_text(main_template)
        (template_dir / "secret.yaml.tmpl").write_text(secret_template)

        # Write auth subdirectory templates
        auth_dir = template_dir / "auth"
        auth_dir.mkdir()
        (auth_dir / "kustomization.yaml.tmpl").write_text(auth_kust_template)
        (auth_dir / "rolebinding.yaml.tmpl").write_text(auth_rolebinding_template)

        with patch("broker.gitops.provision_templates.GitConfig") as mock_config:
            mock_config.get_repo_dir.return_value = gitops_repo

            # Create instances directory
            instances_dir = gitops_repo / "instances"
            instances_dir.mkdir()

            # Provision instance
            instance_dir, rendered_files = create_instance_files_from_templates(
                instance_name="test-subdirs-001",
                instance_id="test-id-subdirs",
                namespace="test-subdirs-ns",
                service_type="testservice",
                service_version="v1",
                cluster_name="test-cluster",
                cluster_url="https://test-cluster:6443",
                environment="dev",
                replicas=1,
                storage_size="10Gi",
                deployment_registry="quay.io/test",
                image_pull_secret_name=None,
                parameters_spec={},
                context=None,
            )

            # Verify rendered files include subdirectory paths
            assert "kustomization.yaml" in rendered_files
            assert "secret.yaml" in rendered_files
            assert "auth/kustomization.yaml" in rendered_files
            assert "auth/rolebinding.yaml" in rendered_files

            # Verify files were written to correct locations
            assert (instance_dir / "kustomization.yaml").exists()
            assert (instance_dir / "secret.yaml").exists()
            assert (instance_dir / "auth" / "kustomization.yaml").exists()
            assert (instance_dir / "auth" / "rolebinding.yaml").exists()

            # Verify auth subdirectory was created
            auth_output_dir = instance_dir / "auth"
            assert auth_output_dir.exists()
            assert auth_output_dir.is_dir()

            # Verify file contents
            with open(instance_dir / "auth" / "rolebinding.yaml") as f:
                rolebinding_data = yaml.safe_load(f)
                assert rolebinding_data["metadata"]["name"] == "test-subdirs-001-binding"
                assert rolebinding_data["metadata"]["namespace"] == "test-subdirs-ns"

            # Verify main kustomization references auth subdirectory
            with open(instance_dir / "kustomization.yaml") as f:
                kust_data = yaml.safe_load(f)
                assert "auth" in kust_data["resources"]

    def test_create_instance_files_with_subdirectories_creates_metadata(self, tmp_path: Path):
        """Test that provisioning with subdirectory templates creates metadata in subdirs."""
        gitops_repo = tmp_path / "gitops-repo"
        gitops_repo.mkdir()

        # Create schema
        schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {"service_name": {"type": "string", "default": "test-service"}},
        }

        # Create templates with subdirectory structure
        # Main template (root level)
        main_kust_template = """apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
namespace: {{ namespace }}
resources:
  - secret.yaml
"""

        secret_template = """apiVersion: v1
kind: Secret
metadata:
  name: {{ instance_name }}-secret
  namespace: {{ namespace }}
stringData:
  service: {{ spec.service_name }}
"""

        # Auth subdirectory templates
        auth_kust_template = """apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
  - rolebinding.yaml
"""

        auth_rolebinding_template = """apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ instance_name }}-binding
  namespace: {{ namespace }}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: admin
subjects:
  - kind: ServiceAccount
    name: {{ instance_name }}-sa
    namespace: {{ namespace }}
"""

        # Create directory structure
        template_dir = gitops_repo / "services" / "testservice" / "v1" / "template"
        template_dir.mkdir(parents=True)

        # Write main subdirectory templates
        main_dir = template_dir / "main"
        main_dir.mkdir()
        (main_dir / "kustomization.yaml.tmpl").write_text(main_kust_template)
        (main_dir / "secret.yaml.tmpl").write_text(secret_template)

        # Write auth subdirectory templates
        auth_dir = template_dir / "auth"
        auth_dir.mkdir()
        (auth_dir / "kustomization.yaml.tmpl").write_text(auth_kust_template)
        (auth_dir / "rolebinding.yaml.tmpl").write_text(auth_rolebinding_template)

        # Write schema
        (template_dir / "schema.json").write_text(json.dumps(schema))

        with patch("broker.gitops.provision_templates.GitConfig") as mock_config:
            mock_config.get_repo_dir.return_value = gitops_repo

            # Create instances directory
            instances_dir = gitops_repo / "instances"
            instances_dir.mkdir()

            # Use create_instance_files_from_templates directly (simpler than full API)
            from broker.gitops.provision import _create_metadata
            from broker.gitops.provision_templates import create_instance_files_from_templates

            instance_dir, rendered_files = create_instance_files_from_templates(
                instance_name="test-metadata-001",
                instance_id="test-id-metadata",
                namespace="test-metadata-ns",
                service_type="testservice",
                service_version="v1",
                cluster_name="test-cluster",
                cluster_url="https://test-cluster:6443",
                environment="dev",
                replicas=1,
                storage_size="10Gi",
                deployment_registry="quay.io/test",
                image_pull_secret_name=None,
                parameters_spec={},
                context=None,
            )

            # Now create metadata (this is what provision_instance does)
            _create_metadata(
                instance_dir=instance_dir,
                instance_name="test-metadata-001",
                namespace="test-metadata-ns",
                environment="dev",
                replicas=1,
                storage_size="10Gi",
                cluster_url="https://test-cluster:6443",
                cluster_name="test-cluster",
                service_type="testservice",
                image="testservice:1.0",
            )

            # Verify metadata files in subdirectories
            assert (instance_dir / "main" / "metadata.yaml").exists()
            assert (instance_dir / "auth" / "metadata.yaml").exists()

            # Verify NO metadata at root (subdirectory structure)
            assert not (instance_dir / "metadata.yaml").exists()

            # Verify metadata content in main/
            with open(instance_dir / "main" / "metadata.yaml") as f:
                metadata = yaml.safe_load(f)
                assert metadata["instance_name"] == "test-metadata-001"
                assert metadata["namespace"] == "test-metadata-ns"
                assert metadata["service_type"] == "testservice"
                assert metadata["environment"] == "dev"
                assert metadata["status"] == "provisioned"

            # Verify metadata content in auth/
            with open(instance_dir / "auth" / "metadata.yaml") as f:
                metadata = yaml.safe_load(f)
                assert metadata["instance_name"] == "test-metadata-001"
                assert metadata["namespace"] == "test-metadata-ns"


class TestTemplateRequired:
    """Test that templates are required for provisioning."""

    def test_error_when_no_templates(self, tmp_path: Path):
        """Test that provisioning raises error when templates don't exist."""
        import pytest

        from broker.gitops.provision import _create_instance_files

        with patch("broker.gitops.provision.GitConfig") as mock_config:
            mock_config.get_repo_dir.return_value = tmp_path / "gitops-repo"
            (tmp_path / "gitops-repo" / "instances").mkdir(parents=True)

            # Call with service that has no templates should raise ValueError
            with pytest.raises(ValueError, match="No templates found for service 'redis'"):
                _create_instance_files(
                    instance_name="test-redis-001",
                    namespace="redis-test-001",
                    replicas=1,
                    storage_size="10Gi",
                    service_type="redis",  # No templates for redis
                    service_version="v1",
                )


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

# Made with Bob
