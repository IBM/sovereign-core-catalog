"""Pytest configuration and shared fixtures for broker tests."""

import json
import sys
from pathlib import Path

import pytest


sys.path.insert(0, str(Path(__file__).parent.parent))


def create_service_catalog(
    services_dir: Path,
    service_name: str,
    description: str = "",
    plans: list[dict[str, str]] | None = None,
    display_name: str | None = None,
) -> None:
    """Helper function to create a service catalog structure.

    Creates the proper directory structure: services/{service}/latest/catalog/catalog.yaml

    Args:
        services_dir: Path to the services directory
        service_name: Name of the service (e.g., 'mysql', 'mariadb')
        description: Service description
        plans: List of plan dictionaries with 'id', 'name', 'description'
        display_name: Display name for the service (defaults to service_name.title())
    """
    catalog_dir = services_dir / service_name / "latest" / "catalog"
    catalog_dir.mkdir(parents=True)

    # Use provided display_name or default to title case
    if display_name is None:
        display_name = service_name.title()

    if plans is None:
        plans = [
            {
                "id": "v1",
                "name": f"{display_name} Default",
                "description": f"{display_name} single-instance deployment",
            }
        ]

    catalog_content = f"name: {display_name}\n"
    if description:
        catalog_content += f"description: {description}\n"
    catalog_content += "plans:\n"
    for plan in plans:
        catalog_content += f'  - id: "{plan["id"]}"\n'
        catalog_content += f'    name: "{plan["name"]}"\n'
        catalog_content += f'    description: "{plan["description"]}"\n'

    (catalog_dir / "catalog.yaml").write_text(catalog_content)


@pytest.fixture
def mock_gitops_repo(tmp_path: Path) -> Path:
    """Create a mock GitOps repository with proper structure.

    Creates a repository structure matching the expected layout with both latest and v1 versions.
    Uses the standard directory structure: services/{service}/{version}/catalog/catalog.yaml

    Args:
        tmp_path: Pytest temporary directory fixture

    Returns:
        Path to the mock GitOps repository root
    """
    repo_dir = tmp_path / "gitops-repo"
    services_dir = repo_dir / "services"
    services_dir.mkdir(parents=True)

    # Create valid services with proper structure
    services = ["mysql", "mariadb", "postgres"]
    for service in services:
        # Create catalog using helper function (only in latest)
        create_service_catalog(
            services_dir,
            service,
            description=f"{service.title()} Database Server",
        )

        # Create both latest and v1 versions with templates
        for version in ["latest", "v1"]:
            # Create template directory with schema.json
            template_dir = services_dir / service / version / "template"
            template_dir.mkdir(parents=True)

            # Create basic schema
            schema = {
                "type": "object",
                "properties": {
                    "database_name": {"type": "string"},
                    "database_user": {"type": "string"},
                },
                "required": ["database_name"],
            }
            (template_dir / "schema.json").write_text(json.dumps(schema))

            # Create template files for mysql (most commonly used in tests)
            if service == "mysql":
                (template_dir / "secret.yaml.tmpl").write_text(
                    "apiVersion: v1\n"
                    "kind: Secret\n"
                    "metadata:\n"
                    "  name: {{ database_name }}\n"
                    "data:\n"
                    "  username: {{ database_user | b64encode }}\n"
                )
                (template_dir / "kustomization.yaml.tmpl").write_text(
                    "resources:\n  - secret.yaml\n"
                )

    return repo_dir


@pytest.fixture
def mock_service_with_templates(
    tmp_path: Path, service_name: str = "mysql", version: str = "v1"
) -> Path:
    """Create a mock service directory with templates.

    Creates a single service with the specified version and templates.
    Useful for tests that need to test specific template scenarios.

    Args:
        tmp_path: Pytest temporary directory fixture
        service_name: Name of the service to create (default: "mysql")
        version: Version of the service (default: "v1")

    Returns:
        Path to the repository root
    """
    repo_dir = tmp_path / "gitops-repo"
    template_dir = repo_dir / "services" / service_name / version / "template"
    template_dir.mkdir(parents=True)

    # Create catalog directory
    catalog_dir = repo_dir / "services" / service_name / version / "catalog"
    catalog_dir.mkdir(parents=True)
    (catalog_dir / "catalog.yaml").write_text(f"name: {service_name}\n")

    return repo_dir


# Made with Bob
