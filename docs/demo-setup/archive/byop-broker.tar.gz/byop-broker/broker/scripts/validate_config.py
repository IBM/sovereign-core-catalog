#!/usr/bin/env python3
"""Validate broker configuration files.

This script checks:
- Configuration file syntax (JSON/YAML)
- Required fields are present
- Field values are valid
"""

import json
import sys
from pathlib import Path
from typing import Any


def validate_json_syntax(config_path: Path) -> dict[str, Any] | None:
    """Validate JSON syntax and load configuration."""
    try:
        with open(config_path) as f:
            config = json.load(f)
        print(f"✓ Valid JSON syntax")
        return config
    except json.JSONDecodeError as e:
        print(f"✗ Invalid JSON: {e}")
        return None
    except FileNotFoundError:
        print(f"✗ File not found: {config_path}")
        return None


def validate_required_fields(config: dict[str, Any]) -> bool:
    """Validate that required fields are present."""
    required_fields = [
        "git_repo_url",
        "git_branch",
        "storage_path",
    ]
    
    all_ok = True
    for field in required_fields:
        if field in config:
            print(f"✓ Required field '{field}' present")
        else:
            print(f"✗ Missing required field '{field}'")
            all_ok = False
    
    return all_ok


def validate_field_values(config: dict[str, Any]) -> bool:
    """Validate field values are reasonable."""
    all_ok = True
    
    # Check git_repo_url format
    if "git_repo_url" in config:
        repo_url = config["git_repo_url"]
        if repo_url.startswith(("http://", "https://", "git@", "ssh://")):
            print(f"✓ git_repo_url format valid")
        else:
            print(f"✗ git_repo_url should start with http://, https://, or git@")
            all_ok = False
    
    # Check storage_path is not empty
    if "storage_path" in config:
        if config["storage_path"]:
            print(f"✓ storage_path is not empty")
        else:
            print(f"✗ storage_path cannot be empty")
            all_ok = False
    
    return all_ok


def main() -> int:
    """Run configuration validation."""
    if len(sys.argv) < 2:
        print("Usage: python validate_config.py <config_file>")
        print("\nExample: python validate_config.py config.gitops.json")
        return 1
    
    config_path = Path(sys.argv[1])
    print(f"Validating configuration: {config_path}\n")
    
    # Validate JSON syntax
    config = validate_json_syntax(config_path)
    if config is None:
        return 1
    
    print()
    
    # Validate required fields
    print("Checking required fields:")
    fields_ok = validate_required_fields(config)
    print()
    
    # Validate field values
    print("Checking field values:")
    values_ok = validate_field_values(config)
    print()
    
    if fields_ok and values_ok:
        print("✓ Configuration is valid")
        return 0
    else:
        print("✗ Configuration has errors")
        return 1


if __name__ == "__main__":
    sys.exit(main())

# Made with Bob
