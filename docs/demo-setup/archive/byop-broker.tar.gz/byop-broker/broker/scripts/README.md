# Broker Helper Scripts

This directory contains helper scripts for development, testing, and automation tasks.

## Available Scripts

### check_dependencies.py
Validates that all required dependencies are installed and compatible.

**Usage:**
```bash
python scripts/check_dependencies.py
```

### validate_config.py
Validates broker configuration files for correctness.

**Usage:**
```bash
python scripts/validate_config.py [config_file]
```

## Adding New Scripts

When adding new helper scripts:
1. Follow Python best practices
2. Include docstrings and type hints
3. Add usage examples to this README
4. Make scripts executable: `chmod +x script_name.py`