#!/usr/bin/env python3
"""Check that all required dependencies are installed and compatible.

This script validates:
- Python version compatibility
- Required packages are installed
- Package versions meet minimum requirements
"""

import sys
from importlib.metadata import version, PackageNotFoundError


def check_python_version() -> bool:
    """Check if Python version meets requirements."""
    required_version = (3, 10)
    current_version = sys.version_info[:2]
    
    if current_version >= required_version:
        print(f"✓ Python {current_version[0]}.{current_version[1]} (required: {required_version[0]}.{required_version[1]}+)")
        return True
    else:
        print(f"✗ Python {current_version[0]}.{current_version[1]} (required: {required_version[0]}.{required_version[1]}+)")
        return False


def check_package(package_name: str, min_version: str | None = None) -> bool:
    """Check if a package is installed and meets version requirements."""
    try:
        installed_version = version(package_name)
        if min_version:
            print(f"✓ {package_name} {installed_version} (required: {min_version}+)")
        else:
            print(f"✓ {package_name} {installed_version}")
        return True
    except PackageNotFoundError:
        print(f"✗ {package_name} not installed")
        return False


def main() -> int:
    """Run all dependency checks."""
    print("Checking dependencies...\n")
    
    all_ok = True
    
    # Check Python version
    all_ok &= check_python_version()
    print()
    
    # Check required packages
    print("Required packages:")
    all_ok &= check_package("flask", "3.0.0")
    all_ok &= check_package("pyyaml")
    all_ok &= check_package("gitpython")
    print()
    
    # Check development packages
    print("Development packages:")
    all_ok &= check_package("pytest", "7.0.0")
    all_ok &= check_package("ruff")
    all_ok &= check_package("mypy")
    print()
    
    if all_ok:
        print("✓ All dependencies satisfied")
        return 0
    else:
        print("✗ Some dependencies are missing or incompatible")
        print("\nRun: pip install -r requirements.txt -r requirements-dev.txt")
        return 1


if __name__ == "__main__":
    sys.exit(main())

# Made with Bob
