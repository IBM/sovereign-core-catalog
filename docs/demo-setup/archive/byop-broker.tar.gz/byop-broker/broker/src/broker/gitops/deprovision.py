"""Database Instance Deprovisioning Module.

This module deprovisions a MySQL or MariaDB instance by:
1. Removing the ArgoCD Application CR from target cluster
2. Removing instance configuration from GitOps repository
3. ArgoCD automatically cleans up Kubernetes resources

Usage:
    This module is designed to be used as a library via the api.py interface.
    Direct CLI usage has been removed in version 1.0.0.

    Example:
        from broker.gitops.api import deprovision_instance

        result = deprovision_instance(
            instance_name="dev-001",
            service_type="mysql"
        )
"""

import sys
from pathlib import Path


# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))


# Made with Bob
