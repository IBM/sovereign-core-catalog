"""
Gitops Provisioning Library API

This module provides a library-style API for provisioning and deprovisioning
service instances. It wraps the CLI-based orchestrator functions to provide
a clean Python API that can be imported and called directly.

This eliminates the need for subprocess calls and provides better error handling,
type safety, and integration with the broker.
"""

import contextlib
import sys
from pathlib import Path
from typing import Any

from broker.gitops.git_config import GitConfig
from broker.gitops.git_operations import GitOperations, GitOperationsError
from broker.gitops.service_discovery import validate_service_type


# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))


class ProvisioningError(Exception):
    """Raised when provisioning fails."""

    pass


class DeprovisioningError(Exception):
    """Raised when deprovisioning fails."""

    pass


class ValidationError(Exception):
    """Raised when input validation fails."""

    pass


def _copy_dry_run_files(
    instance_dir: Path,
    argocd_app_file: Path | None,
    dry_run_output_dir: Path,
    instance_name: str,
) -> None:
    """Copy generated files to dry-run output directory.

    Args:
        instance_dir: Path to instance directory in Git working directory
        argocd_app_file: Path to ArgoCD application file (optional)
        dry_run_output_dir: Destination directory for dry-run files
        instance_name: Name of the instance

    Raises:
        Exception: If file copying fails
    """
    import logging
    import shutil

    logger = logging.getLogger(__name__)

    # Create output directory structure for instances
    instances_dir = dry_run_output_dir / "instances" / instance_name
    instances_dir.mkdir(parents=True, exist_ok=True)

    # Copy instance files
    if instance_dir and instance_dir.exists():
        logger.info(f"Copying instance files from {instance_dir} to {instances_dir}")
        for item in instance_dir.iterdir():
            if item.is_file():
                shutil.copy2(item, instances_dir / item.name)
                logger.debug(f"Copied {item.name}")
            elif item.is_dir():
                # Copy subdirectories (e.g., sbom/)
                dest_subdir = instances_dir / item.name
                if dest_subdir.exists():
                    shutil.rmtree(dest_subdir)
                shutil.copytree(item, dest_subdir)
                logger.debug(f"Copied directory {item.name}")

    # Copy ArgoCD application file (only if it exists)
    # Note: argocd_app_file may be None if CREATE_ARGOCD_APP=false
    if argocd_app_file and argocd_app_file.exists():
        argocd_apps_dir = dry_run_output_dir / "argocd-apps"
        argocd_apps_dir.mkdir(parents=True, exist_ok=True)
        dest_file = argocd_apps_dir / argocd_app_file.name
        shutil.copy2(argocd_app_file, dest_file)
        logger.info(f"Copied ArgoCD app file to {dest_file}")

    logger.info(f"Dry-run files copied to {dry_run_output_dir}")


def provision_instance(
    instance_name: str,
    service_type: str,
    cluster_name: str,
    replicas: int = 1,
    storage_size: str = "10Gi",
    environment: str = "dev",
    service_version: str = "latest",
    namespace: str | None = None,
    cluster_url: str | None = None,
    image: str | None = None,
    image_pull_secret_name: str | None = None,
    registry_server: str | None = None,
    registry_username: str | None = None,
    registry_password: str | None = None,
    registry_email: str = "noreply@example.com",
    deployment_registry: str | None = None,
    broker_service_id: str | None = None,
    broker_plan_id: str | None = None,
    parameters_spec: dict[str, Any] | None = None,
    context: dict[str, Any] | None = None,
    instance_id: str | None = None,
    debug_retain_failed_files: bool = False,
    dry_run: bool = False,
    dry_run_output_dir: Path | None = None,
) -> dict[str, Any]:
    """Provision a service instance using GitOps.

    This is a library-style API that can be called directly from Python code
    without spawning a subprocess.

    Args:
        instance_name: Unique name for the service instance (e.g., "dev-001")
        service_type: Service type ("mysql" or "mariadb")
        cluster_name: Target cluster name (e.g., "k3s-cluster-1")
        replicas: Number of replicas (default: 1)
        storage_size: Persistent volume size (default: "10Gi")
        environment: Environment type ("dev", "staging", or "prod", default: "dev")
        service_version: Service version from GitOps repo (default: "latest")
        namespace: Kubernetes namespace (default: instance_name)
        cluster_url: Target cluster API server URL (optional)
        image: Container image reference (optional)
        image_pull_secret_name: Name of imagePullSecret for private registries (optional)
        registry_server: Container registry server hostname (optional)
        registry_username: Container registry username (optional)
        registry_password: Container registry password (optional)
        registry_email: Container registry email (default: "noreply@example.com")
        deployment_registry: Deployment registry path for DEPLOYMENT_REGISTRY env var (optional)
        parameters_spec: Service-specific parameters for template-based provisioning (optional)
        context: Additional context from OSB API (optional)
        instance_id: Unique instance ID (optional, defaults to instance_name)
        debug_retain_failed_files: Skip cleanup of failed provisioning files for debugging (default: False)
        dry_run: If True, generate files but skip Git push (default: False)
        dry_run_output_dir: Directory to copy generated files to in dry-run mode (optional)

    Returns:
        Dictionary with provisioning result:
        {
            "instance_name": str,
            "namespace": str,
            "service_type": str,
            "cluster_name": str,
            "status": "success",
            "message": str
        }

    Raises:
        ValidationError: If input validation fails
        ProvisioningError: If provisioning fails
        GitOperationsError: If Git operations fail
    """
    # Import here to avoid circular dependencies and allow lazy loading
    from broker.gitops.provision import (
        _commit_changes,
        _copy_sbom_from_service,
        _create_instance_files,
        _create_metadata,
        _resolve_cluster_url,
        _setup_git_operations,
        generate_argocd_application,
        validate_instance_name,
        write_yaml_file,
    )

    # Validate inputs
    try:
        validate_instance_name(instance_name)
    except SystemExit as e:
        raise ValidationError(f"Invalid instance name: {instance_name}") from e

    # Validate service type exists in GitOps repository
    git_ops = GitOperations()
    repo_dir = Path(git_ops.repo_dir)
    is_valid, error_msg = validate_service_type(repo_dir, service_type)
    if not is_valid:
        raise ValidationError(f"Invalid service type: {service_type}. {error_msg}")

    if environment not in ["dev", "staging", "prod"]:
        raise ValidationError(
            f"Invalid environment: {environment}. Must be 'dev', 'staging', or 'prod'"
        )

    if image_pull_secret_name and (
        not registry_server or not registry_username or not registry_password
    ):
        raise ValidationError(
            "registry_server, registry_username, and registry_password are required "
            "when image_pull_secret_name is specified"
        )

    # Use instance_name as namespace if not specified
    if namespace is None:
        namespace = instance_name

    # Resolve cluster URL if needed
    try:
        cluster_url, exit_code = _resolve_cluster_url(cluster_name, cluster_url)
        if exit_code != 0:
            raise ProvisioningError(f"Failed to resolve cluster URL for {cluster_name}")
    except Exception as e:
        raise ProvisioningError(f"Failed to resolve cluster URL: {e}") from e

    # Setup Git operations
    try:
        git_operations, exit_code = _setup_git_operations()
        if exit_code != 0 or git_operations is None:
            raise ProvisioningError("Failed to setup Git operations")
    except GitOperationsError as e:
        raise ProvisioningError(f"Git operations failed: {e}") from e
    except Exception as e:
        raise ProvisioningError(f"Failed to setup Git operations: {e}") from e

    # Create instance files - wrap in try/except to cleanup on failure
    instance_dir = None
    argocd_app_file = None

    try:
        # Create instance files
        try:
            instance_dir = _create_instance_files(
                instance_name=instance_name,
                namespace=namespace,
                replicas=replicas,
                storage_size=storage_size,
                service_type=service_type,
                service_version=service_version,
                image_pull_secret_name=image_pull_secret_name,
                registry_server=registry_server,
                registry_username=registry_username,
                registry_password=registry_password,
                registry_email=registry_email,
                instance_id=instance_id or instance_name,
                cluster_name=cluster_name,
                cluster_url=cluster_url,
                environment=environment,
                deployment_registry=deployment_registry,
                parameters_spec=parameters_spec,
                context=context,
                broker_plan_id=broker_plan_id,
            )
        except Exception as e:
            raise ProvisioningError(f"Failed to create instance files: {e}") from e

        # Get image or use default
        if image is None:
            image = f"{service_type}:8.0"

        # Copy SBOM from published service
        # SBOM copy failure is not critical, log but continue
        with contextlib.suppress(Exception):
            _copy_sbom_from_service(instance_name, service_type, service_version, instance_dir)

        # Create ArgoCD Application file (if enabled)
        # Read environment variable directly to ensure runtime configuration is used
        import logging
        import os

        create_argocd_app_env = os.getenv("CREATE_ARGOCD_APP", "true")
        create_argocd_app = create_argocd_app_env.lower() == "true"

        logger = logging.getLogger(__name__)
        logger.info(
            f"ArgoCD Application creation setting: CREATE_ARGOCD_APP={create_argocd_app_env}, "
            f"enabled={create_argocd_app}"
        )

        if create_argocd_app:
            try:
                application = generate_argocd_application(
                    instance_name, namespace, service_type, cluster_url, cluster_name
                )
                repo_dir = GitConfig.get_repo_dir()
                argocd_apps_dir = repo_dir / "argocd-apps"
                argocd_apps_dir.mkdir(parents=True, exist_ok=True)

                # Ensure .gitkeep exists to prevent ArgoCD App-of-Apps sync issues
                gitkeep_file = argocd_apps_dir / ".gitkeep"
                if not gitkeep_file.exists():
                    gitkeep_content = """# ArgoCD Applications Directory

This directory contains ArgoCD Application manifests for service instances.
Each instance gets its own Application YAML file.

This .gitkeep file prevents the directory from being empty, which would
trigger ArgoCD's safety mechanism that blocks auto-sync when all resources
would be deleted.
"""
                    gitkeep_file.write_text(gitkeep_content)

                argocd_app_file = argocd_apps_dir / f"{instance_name}.yaml"
                write_yaml_file(argocd_app_file, application)
            except Exception as e:
                raise ProvisioningError(f"Failed to create ArgoCD application: {e}") from e
        else:
            import logging

            logger = logging.getLogger(__name__)
            logger.info(
                f"Skipping ArgoCD Application file creation for {instance_name} "
                "(CREATE_ARGOCD_APP=false)"
            )

        # Create metadata
        try:
            _create_metadata(
                instance_dir,
                instance_name,
                namespace,
                environment,
                replicas,
                storage_size,
                cluster_url,
                cluster_name,
                service_type,
                image,
                image_pull_secret_name,
                registry_server,
                deployment_registry,
                broker_service_id,
                broker_plan_id,
            )
        except Exception as e:
            raise ProvisioningError(f"Failed to create metadata: {e}") from e

        # Commit changes (skip in dry-run mode)
        try:
            _commit_changes(git_operations, instance_name, service_type, dry_run=dry_run)
        except GitOperationsError as e:
            raise ProvisioningError(f"Failed to commit changes: {e}") from e
        except Exception as e:
            raise ProvisioningError(f"Failed to commit changes: {e}") from e

        # Copy files to dry-run output directory if in dry-run mode
        if dry_run and dry_run_output_dir:
            try:
                _copy_dry_run_files(
                    instance_dir, argocd_app_file, dry_run_output_dir, instance_name
                )
            except Exception as e:
                raise ProvisioningError(f"Failed to copy dry-run files: {e}") from e

    except (ProvisioningError, ValidationError, GitOperationsError):
        # Cleanup on failure: remove instance directory and ArgoCD app file
        import logging
        import shutil

        logger = logging.getLogger(__name__)

        if debug_retain_failed_files:
            # Debug mode: retain files for inspection
            logger.warning(
                f"Provisioning failed for {instance_name}, retaining files for debugging "
                f"(DEBUG_RETAIN_FAILED_FILES=true)"
            )
            if instance_dir and instance_dir.exists():
                logger.info(f"Instance directory retained for inspection: {instance_dir}")
            if argocd_app_file and argocd_app_file.exists():
                logger.info(f"ArgoCD app file retained for inspection: {argocd_app_file}")
        else:
            # Production mode: cleanup failed files
            logger.error(f"Provisioning failed for {instance_name}, cleaning up local files")

            # Remove instance directory if it was created
            if instance_dir and instance_dir.exists():
                try:
                    shutil.rmtree(instance_dir)
                    logger.info(f"Cleaned up instance directory: {instance_dir}")
                except Exception as cleanup_error:
                    logger.warning(f"Failed to cleanup instance directory: {cleanup_error}")

            # Remove ArgoCD app file if it was created
            if argocd_app_file and argocd_app_file.exists():
                try:
                    argocd_app_file.unlink()
                    logger.info(f"Cleaned up ArgoCD app file: {argocd_app_file}")
                except Exception as cleanup_error:
                    logger.warning(f"Failed to cleanup ArgoCD app file: {cleanup_error}")

        # Re-raise the original exception
        raise

    # Return success result
    return {
        "instance_name": instance_name,
        "namespace": namespace,
        "service_type": service_type,
        "cluster_name": cluster_name,
        "cluster_url": cluster_url,
        "status": "success",
        "message": f"Provisioned {service_type} instance {instance_name} successfully",
    }


def deprovision_instance(
    instance_name: str,
    service_type: str,
    cluster_name: str | None = None,
    force: bool = False,
) -> dict[str, Any]:
    """Deprovision a service instance using GitOps.

    This is a library-style API that can be called directly from Python code
    without spawning a subprocess.

    Args:
        instance_name: Name/ID of the instance to deprovision
        service_type: Service type ("mysql" or "mariadb")
        cluster_name: Target cluster name (optional, for logging only)
        force: Skip confirmation prompt (default: False, always True for library API)

    Returns:
        Dictionary with deprovisioning result:
        {
            "instance_name": str,
            "service_type": str,
            "status": "success",
            "message": str
        }

    Raises:
        ValidationError: If input validation fails
        DeprovisioningError: If deprovisioning fails
        GitOperationsError: If Git operations fail
    """
    import shutil

    # Validate service type exists in GitOps repository
    git_ops_temp = GitOperations()
    repo_dir = Path(git_ops_temp.repo_dir)
    is_valid, error_msg = validate_service_type(repo_dir, service_type)
    if not is_valid:
        raise ValidationError(f"Invalid service type: {service_type}. {error_msg}")

    # Initialize Git operations
    try:
        GitConfig.validate_config()
        git_ops = GitOperations()
        git_ops.ensure_repo_cloned()
        git_ops.pull_latest()
    except GitOperationsError as e:
        raise DeprovisioningError(f"Git operations failed: {e}") from e
    except Exception as e:
        raise DeprovisioningError(f"Failed to initialize Git operations: {e}") from e

    # Check if instance exists
    from broker.gitops.path_utils import get_instance_path

    repo_dir = GitConfig.get_repo_dir()
    instance_dir = get_instance_path(repo_dir, instance_name, service_type)
    if not instance_dir.exists():
        raise DeprovisioningError(
            f"Instance '{instance_name}' not found. Directory does not exist: {instance_dir}"
        )

    # Find ArgoCD application file
    argocd_apps_dir = repo_dir / "argocd-apps"
    app_file: Path | None = argocd_apps_dir / f"{instance_name}.yaml"

    # If file doesn't exist, search for any file matching the instance name
    if app_file and not app_file.exists():
        matching_files = list(argocd_apps_dir.glob(f"*{instance_name}.yaml"))
        app_file = matching_files[0] if matching_files else None

    # Remove ArgoCD Application file from Git
    if app_file and app_file.exists():
        try:
            app_file.unlink()
        except Exception as e:
            raise DeprovisioningError(f"Failed to remove ArgoCD application file: {e}") from e

    # Remove instance directory
    try:
        shutil.rmtree(instance_dir)
    except Exception as e:
        raise DeprovisioningError(f"Failed to remove instance directory: {e}") from e

    # Commit and push changes
    try:
        git_ops.commit_and_push(
            message=f"Remove {service_type.upper()} instance: {instance_name}",
            author_name="GitOps Orchestrator",
            author_email="gitops@example.com",
        )
    except GitOperationsError as e:
        raise DeprovisioningError(f"Failed to commit changes: {e}") from e
    except Exception as e:
        raise DeprovisioningError(f"Failed to commit changes: {e}") from e

    # Return success result
    return {
        "instance_name": instance_name,
        "service_type": service_type,
        "cluster_name": cluster_name,
        "status": "success",
        "message": f"Deprovisioned {service_type} instance {instance_name} successfully",
    }


# Made with Bob
