"""Output formatting utilities for CLI.

This module provides consistent, colorized output formatting using Rich.
All CLI output should go through these functions for consistency.
"""

from rich.console import Console
from rich.panel import Panel
from rich.table import Table


console = Console()


def print_success(message: str) -> None:
    """Print a success message in green.

    Args:
        message: Success message to display
    """
    console.print(f"[green]✓[/green] {message}")


def print_error(message: str) -> None:
    """Print an error message in red.

    Args:
        message: Error message to display
    """
    console.print(f"[red]✗[/red] {message}", style="red")


def print_warning(message: str) -> None:
    """Print a warning message in yellow.

    Args:
        message: Warning message to display
    """
    console.print(f"[yellow]⚠[/yellow] {message}")


def print_info(message: str) -> None:
    """Print an informational message.

    Args:
        message: Info message to display
    """
    console.print(f"[blue]ℹ[/blue] {message}")


def print_header(title: str, subtitle: str | None = None) -> None:
    """Print a formatted header.

    Args:
        title: Header title
        subtitle: Optional subtitle
    """
    if subtitle:
        console.print(Panel(f"[bold]{title}[/bold]\n{subtitle}", border_style="blue"))
    else:
        console.print(Panel(f"[bold]{title}[/bold]", border_style="blue"))


def print_table(
    title: str,
    columns: list[str],
    rows: list[list[str]],
    show_header: bool = True,
) -> None:
    """Print a formatted table.

    Args:
        title: Table title
        columns: Column headers
        rows: Table rows (list of lists)
        show_header: Whether to show column headers
    """
    table = Table(title=title, show_header=show_header)

    for column in columns:
        table.add_column(column, style="cyan")

    for row in rows:
        table.add_row(*row)

    console.print(table)


def print_key_value(key: str, value: str, key_style: str = "bold") -> None:
    """Print a key-value pair.

    Args:
        key: Key name
        value: Value
        key_style: Style for the key (default: bold)
    """
    console.print(f"[{key_style}]{key}:[/{key_style}] {value}")


def print_list(items: list[str], bullet: str = "•") -> None:
    """Print a bulleted list.

    Args:
        items: List items to display
        bullet: Bullet character (default: •)
    """
    for item in items:
        console.print(f"  {bullet} {item}")


def print_json(data: dict, title: str | None = None) -> None:
    """Print JSON data with syntax highlighting.

    Args:
        data: Dictionary to display as JSON
        title: Optional title
    """
    import json

    from rich.syntax import Syntax

    json_str = json.dumps(data, indent=2)
    syntax = Syntax(json_str, "json", theme="monokai", line_numbers=False)

    if title:
        console.print(f"\n[bold]{title}[/bold]")
    console.print(syntax)


# Made with Bob
