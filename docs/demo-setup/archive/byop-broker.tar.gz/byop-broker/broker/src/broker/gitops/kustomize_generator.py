"""Kustomize infrastructure file generation module.

This module previously contained functions to generate Kustomize infrastructure files.
All such functionality has been moved to service templates following the template-first
architecture principle.

Important:
    ALL Kustomize files (kustomization.yaml, ksops-generator.yaml, patches) MUST come
    from service templates, not programmatic generation by the broker.

    See docs/dev/feat-sops/lessons-learned-double-implementation.md for details on why
    programmatic generation violates separation of concerns.

Architecture:
    - Service templates define WHAT (files, patches, configuration)
    - Broker defines HOW (rendering, encryption, orchestration)
    - Broker NEVER generates service-specific files programmatically
"""


class KustomizeGenerationError(Exception):
    """Raised when Kustomize file generation fails.

    Note: This exception is retained for backward compatibility but should not
    be used in new code since the broker no longer generates Kustomize files.
    """

    pass


# Made with Bob
