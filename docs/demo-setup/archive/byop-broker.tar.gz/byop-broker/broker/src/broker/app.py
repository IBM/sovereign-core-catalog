"""
GitOps CSB Broker - Flask application entry point

This broker combines the CSB v2 API with GitOps provisioning.
When a service instance is provisioned, it triggers the GitOps orchestrator
to deploy actual infrastructure to Kubernetes clusters.
"""

import argparse
import json
import os
import ssl
import sys
from pathlib import Path
from typing import Any

from flask import Flask, Response, jsonify, request
from flask_cors import CORS

from broker.auth.config import AuthConfig, load_auth_config
from broker.auth.jwt_validator import JWTValidator
from broker.auth.middleware import require_jwt_auth
from broker.broker import CSBBroker
from broker.config import config
from broker.logging_config import configure_logging, get_logger
from broker.storage import create_storage


logger = get_logger(__name__)


def load_config_file(config_path: str) -> dict[str, Any]:
    """Load configuration from JSON file.

    Args:
        config_path: Path to JSON configuration file

    Returns:
        Configuration dictionary

    Raises:
        FileNotFoundError: If config file doesn't exist
        json.JSONDecodeError: If config file is invalid JSON
    """
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(path, encoding="utf-8") as f:
        config_data = json.load(f)
    return config_data if isinstance(config_data, dict) else {}


def load_cluster_config() -> dict[str, dict[str, Any]]:
    """Load cluster configuration from environment.

    Clusters are registered ArgoCD clusters that the broker can deploy to.
    Configuration is provided via CLUSTERS environment variable as JSON array.

    Returns:
        Dictionary mapping server URLs to cluster metadata

    Example:
        {
            "https://kubernetes.default.svc": {
                "name": "in-cluster",
                "type": "hub",
                "default": True
            },
            "https://192.168.2.89:6443": {
                "name": "spoke-cluster-2",
                "type": "spoke",
                "default": False
            }
        }
    """
    clusters_json = os.getenv("CLUSTERS", "[]")
    try:
        clusters_list = json.loads(clusters_json)

        # Convert list to dict keyed by server URL
        clusters_dict: dict[str, dict[str, Any]] = {}
        for cluster in clusters_list:
            server = cluster.get("server")
            if server:
                clusters_dict[server] = {
                    "name": cluster.get("name", server),
                    "type": cluster.get("type", "spoke"),
                    "default": cluster.get("default", False),
                }

        # Ensure at least in-cluster exists
        if "https://kubernetes.default.svc" not in clusters_dict:
            clusters_dict["https://kubernetes.default.svc"] = {
                "name": "in-cluster",
                "type": "hub",
                "default": True,
            }

        logger.info(
            "Loaded cluster configuration",
            extra={"cluster_count": len(clusters_dict), "clusters": list(clusters_dict.keys())},
        )

        return clusters_dict

    except json.JSONDecodeError as e:
        logger.error("Failed to parse CLUSTERS configuration", extra={"error": str(e)})
        # Return minimal default
        return {
            "https://kubernetes.default.svc": {"name": "in-cluster", "type": "hub", "default": True}
        }


def create_app(config_file: str | None = None) -> Flask:
    """Application factory with GitOps storage dependency injection.

    Args:
        config_file: Optional path to JSON configuration file

    Returns:
        Configured Flask application
    """
    # Configure logging only if not running under Gunicorn
    # Gunicorn has its own logging configuration in gunicorn.conf.py
    # Check if we're running under Gunicorn by looking for SERVER_SOFTWARE env var
    if not os.getenv("SERVER_SOFTWARE", "").startswith("gunicorn"):
        configure_logging()

    app = Flask(__name__)

    # Enable CORS for all routes
    CORS(app)

    # Load configuration
    if config_file:
        try:
            file_config = load_config_file(config_file)
            logger.info("Loaded configuration from file", extra={"config_file": config_file})
        except Exception as e:
            logger.error(
                "Failed to load configuration file",
                extra={"config_file": config_file, "error": str(e)},
            )
            raise
    else:
        file_config = {}

    # Get storage configuration
    storage_config = file_config.get("storage", {})
    # Environment variable takes precedence over config file
    storage_type = os.getenv("STORAGE_TYPE", storage_config.get("type", "gitops"))
    storage_init_config = storage_config.get("config", {})

    # Get GitOps configuration from file
    gitops_config = file_config.get("gitops", {})

    # Merge with environment variables (env vars take precedence)
    if not storage_init_config.get("storage_dir"):
        storage_init_config["storage_dir"] = config.storage_dir
    if not storage_init_config.get("cluster_name"):
        storage_init_config["cluster_name"] = os.getenv("GITOPS_CLUSTER_NAME", "k3s-cluster-1")
    if not storage_init_config.get("gitops_path"):
        gitops_path = os.getenv("GITOPS_ORCHESTRATOR_PATH")
        if gitops_path:
            storage_init_config["gitops_path"] = gitops_path

    # Merge GitOps configuration with environment variables (env vars take precedence)
    if not gitops_config.get("repo_url"):
        gitops_config["repo_url"] = os.getenv("GITOPS_REPO_URL")
    if not gitops_config.get("branch"):
        gitops_config["branch"] = os.getenv("GITOPS_BRANCH", "main")
    if not gitops_config.get("git_backend"):
        gitops_config["git_backend"] = os.getenv("GIT_BACKEND", "remote")
    if not gitops_config.get("git_auth_method"):
        gitops_config["git_auth_method"] = os.getenv("GIT_AUTH_METHOD", "ssh")
    if not gitops_config.get("ssh_private_key"):
        gitops_config["ssh_private_key"] = os.getenv("SSH_PRIVATE_KEY")
    if not gitops_config.get("ssh_private_key_path"):
        gitops_config["ssh_private_key_path"] = os.getenv("SSH_PRIVATE_KEY_PATH")
    if not gitops_config.get("github_token"):
        gitops_config["github_token"] = os.getenv("GITHUB_TOKEN")

    # Add GitOps configuration to storage init config
    storage_init_config["gitops_config"] = gitops_config

    # Add dump_provision_variables configuration
    dump_provision_variables = os.getenv("DUMP_PROVISION_VARIABLES", "false").lower() == "true"
    storage_init_config["dump_provision_variables"] = dump_provision_variables
    logger.info(
        "Provision variables dump configuration", extra={"enabled": dump_provision_variables}
    )

    # Load cluster configuration and add to storage init config
    clusters = load_cluster_config()
    app.config["CLUSTERS"] = clusters
    storage_init_config["clusters"] = clusters

    # Create storage using factory
    try:
        storage = create_storage(storage_type, storage_init_config)
        logger.info("Storage initialized", extra={"storage_type": storage_type})
    except Exception as e:
        logger.error(
            "Failed to initialize storage", extra={"storage_type": storage_type, "error": str(e)}
        )
        raise

    # Get orchestrator path from storage config or use default
    gitops_path = storage_init_config.get("gitops_path", "./orchestrator")

    # Get async_enabled from storage config or use config default
    async_enabled = storage_init_config.get("async_enabled", config.async_enabled)

    # Initialize broker with injected storage, orchestrator path, and async flag
    broker = CSBBroker(storage, config.dashboard_url, gitops_path, async_enabled)

    # Load authentication configuration
    auth_config: AuthConfig | None = None
    jwt_validator: JWTValidator | None = None

    try:
        auth_config = load_auth_config(config_file)

        if auth_config.enabled:
            # Initialize JWT validator
            jwt_validator = JWTValidator(auth_config)
            logger.info(
                "JWT authentication enabled",
                extra={"issuer": auth_config.issuer, "audience": auth_config.audience},
            )
        else:
            logger.info("JWT authentication disabled")
    except Exception as e:
        # If auth config fails to load but is not critical, log warning and continue
        logger.error("Failed to load authentication configuration", extra={"error": str(e)})
        # Re-raise if it's a validation error (missing required config when enabled)
        if "required when authentication is enabled" in str(e):
            raise

    # Authentication middleware (runs before request logging)
    @app.before_request
    def authenticate() -> Response | None:
        if jwt_validator and auth_config:
            return require_jwt_auth(jwt_validator, auth_config)
        return None

    # Middleware to log all requests
    @app.before_request
    def log_request() -> None:
        # Skip logging for health check endpoints to reduce noise
        if request.path in ["/health", "/health/git", "/health/cache/clear"]:
            return

        # Build log data
        log_data: dict[str, Any] = {
            "method": request.method,
            "path": request.path,
            "query": dict(request.args),
        }

        # Add request data payload if provided
        if request.is_json:
            try:
                log_data["payload"] = request.get_json()
            except Exception:
                log_data["payload"] = "<invalid JSON>"
        elif request.data:
            # For non-JSON data, log content type and size
            log_data["payload_info"] = {
                "content_type": request.content_type,
                "size_bytes": len(request.data),
            }

        # Add caller information if available
        caller_info: dict[str, Any] = {}

        # Remote address
        if request.remote_addr:
            caller_info["remote_addr"] = request.remote_addr

        # X-Forwarded-For header (proxy/load balancer)
        if request.headers.get("X-Forwarded-For"):
            caller_info["x_forwarded_for"] = request.headers.get("X-Forwarded-For")

        # User-Agent
        if request.headers.get("User-Agent"):
            caller_info["user_agent"] = request.headers.get("User-Agent")

        # Authorization header (log presence, not value)
        if request.headers.get("Authorization"):
            auth_header = request.headers.get("Authorization", "")
            if auth_header.startswith("Bearer "):
                caller_info["auth_type"] = "Bearer"
            elif auth_header.startswith("Basic "):
                caller_info["auth_type"] = "Basic"
            else:
                caller_info["auth_type"] = "Other"

        # X-Request-ID or similar tracking headers
        if request.headers.get("X-Request-ID"):
            caller_info["request_id"] = request.headers.get("X-Request-ID")

        # Add caller info to log data if any was found
        if caller_info:
            log_data["caller"] = caller_info

        # Add authentication context if available
        from flask import g

        if hasattr(g, "authenticated") and g.authenticated:
            auth_context: dict[str, Any] = {"authenticated": True}
            if hasattr(g, "jwt_payload"):
                payload = g.jwt_payload
                # Add safe claims to log (don't log full payload)
                auth_context["subject"] = payload.get("sub", "unknown")
                auth_context["issuer"] = payload.get("iss", "unknown")
            log_data["auth"] = auth_context

        logger.info("Incoming request", extra=log_data)

    @app.after_request
    def log_response(response: Response) -> Response:
        # Skip logging for health check endpoints to reduce noise
        if request.path in ["/health", "/health/git", "/health/cache/clear"]:
            return response

        log_data: dict[str, Any] = {
            "method": request.method,
            "path": request.path,
            "status": response.status_code,
        }

        # Optionally log response payload if enabled
        if config.log_response_payloads:
            if response.is_json:
                try:
                    log_data["response_payload"] = response.get_json()
                except Exception:
                    log_data["response_payload"] = "<invalid JSON>"
            elif response.data:
                # For non-JSON responses, log content type and size
                log_data["response_payload_info"] = {
                    "content_type": response.content_type,
                    "size_bytes": len(response.data),
                }

        logger.info("Outgoing response", extra=log_data)
        return response

    # ========== CSB v2 API Endpoints ==========

    @app.route("/v2/catalog", methods=["GET"])
    def catalog() -> tuple[Response, int]:
        """Get service catalog."""
        catalog_data = broker.catalog()
        return jsonify(catalog_data), 200

    @app.route("/v2/service_instances/<path:crn>", methods=["PUT"])
    def provision(
        crn: str,
    ) -> tuple[Response, int]:
        """Provision a service instance via GitOps."""
        request_data = request.get_json() or {}
        response_data, status_code = broker.provision(crn, request_data)
        return jsonify(response_data), status_code

    @app.route("/v2/service_instances/<path:crn>", methods=["GET"])
    def get_service_instance(
        crn: str,
    ) -> tuple[Response, int]:
        """Fetch service instance details.

        This endpoint retrieves the current state and metadata of a service instance.
        It's part of the OSB v2 API specification and enables clients to query
        instance details without listing all instances.
        """
        instance = storage.get(crn)
        if not instance:
            return (
                jsonify(
                    {
                        "error": "not_found",
                        "description": f"Service instance {crn} not found",
                    }
                ),
                404,
            )
        return jsonify(instance), 200

    @app.route("/v2/service_instances/<path:crn>", methods=["PATCH"])
    def update_provision(
        crn: str,
    ) -> tuple[Response, int]:
        """Update a service instance."""
        # Check accepts_incomplete parameter
        accepts_incomplete = request.args.get("accepts_incomplete", "false")
        if accepts_incomplete != "true" and broker.async_enabled:
            return (
                jsonify(
                    {
                        "error": "unprocessable_entity",
                        "description": "accepts_incomplete was not true",
                    }
                ),
                422,
            )

        request_data = request.get_json() or {}
        response_data, status_code = broker.update_provision(crn, request_data)
        return jsonify(response_data), status_code

    @app.route("/v2/service_instances/<path:crn>/last_operation", methods=["GET"])
    def last_operation(
        crn: str,
    ) -> tuple[Response, int]:
        """Poll last operation status."""
        response_data, status_code = broker.last_operation(crn)
        return jsonify(response_data), status_code

    @app.route("/v2/service_instances/<path:crn>", methods=["DELETE"])
    def deprovision(
        crn: str,
    ) -> tuple[Response, int]:
        """Deprovision a service instance via GitOps."""
        # Check accepts_incomplete parameter
        accepts_incomplete = request.args.get("accepts_incomplete", "false")
        if accepts_incomplete != "true" and broker.async_enabled:
            return (
                jsonify(
                    {
                        "error": "unprocessable_entity",
                        "description": "accepts_incomplete was not true",
                    }
                ),
                422,
            )

        service_id = request.args.get("service_id")
        plan_id = request.args.get("plan_id")
        response_data, status_code = broker.deprovision(crn, service_id, plan_id)
        return jsonify(response_data), status_code

    # ========== Custom Extension Endpoints ==========

    @app.route("/service_instances", methods=["GET"])
    def list_instances_new() -> tuple[Response, int]:
        """List all provisioned service instances (GitOps-sourced extension).

        This endpoint is NOT part of the OSB v2 API specification.
        It's a custom extension that lists instances from the GitOps repository.
        """
        response_data, status_code = broker.list_instances()
        return jsonify(response_data), status_code

    @app.route("/services/<service_id>/schema", methods=["GET"])
    def get_service_schema(service_id: str) -> tuple[Response, int]:
        """
        Get JSON schema for service parameters.

        NOTE: This endpoint is NOT part of the OSB/CSB v2 API specification.
        It's a custom extension to support client-side parameter validation.

        This endpoint returns the JSON schema that defines the parameters
        for a service. The schema is loaded from the service's template
        directory in the GitOps repository.

        IMPORTANT: This endpoint always pulls the latest schema from Git to ensure
        freshness. The TemplateLoader cache is cleared before loading to prevent
        serving stale schemas.

        Args:
            service_id: Service identifier (e.g., "mysql-service")

        Returns:
            JSON schema dictionary and HTTP status code

        Example Response:
            {
                "type": "object",
                "properties": {
                    "database_name": {
                        "type": "string",
                        "description": "Name of the database",
                        "minLength": 1,
                        "maxLength": 63
                    },
                    "database_user": {
                        "type": "string",
                        "description": "Database username"
                    },
                    "database_password": {
                        "type": "string",
                        "description": "Database password (auto-generated if not provided)",
                        "x-auto-generate": true
                    }
                },
                "required": ["database_name", "database_user"]
            }
        """
        try:
            # Use service_id directly as service_type
            service_type = service_id

            # Get GitOps repo directory from storage or environment
            repo_dir: Path | None = None
            if hasattr(storage, "state_manager") and storage.state_manager:
                # Pull latest from Git to ensure fresh schema
                try:
                    storage.state_manager.git_ops.pull_latest()
                    logger.info(
                        "Pulled latest from Git for schema fetch", extra={"service_id": service_id}
                    )
                except Exception as pull_error:
                    logger.warning(
                        "Failed to pull latest from Git, using existing repo state",
                        extra={"service_id": service_id, "error": str(pull_error)},
                    )

                repo_dir = storage.state_manager.git_ops.repo_dir
            else:
                # Fallback: try environment variable or use gitops_path
                repo_dir_str = os.getenv("GITOPS_REPO_DIR")
                if repo_dir_str:
                    repo_dir = Path(repo_dir_str)
                elif gitops_path:
                    # Use gitops_path as fallback (orchestrator directory)
                    repo_dir = Path(gitops_path).parent

            if not repo_dir or not repo_dir.exists():
                logger.error(
                    "Cannot determine GitOps repository directory",
                    extra={
                        "service_id": service_id,
                        "repo_dir": str(repo_dir) if repo_dir else None,
                    },
                )
                return jsonify(
                    {
                        "error": "configuration_error",
                        "description": "GitOps repository directory not configured or does not exist",
                    }
                ), 500

            # Load schema using TemplateLoader
            from broker.gitops.template_loader import TemplateLoader, TemplateLoadError

            loader = TemplateLoader(repo_dir)

            # Clear cache for this service to ensure fresh schema
            loader.clear_cache(service_type)
            logger.info(
                "Cleared TemplateLoader cache for service", extra={"service_type": service_type}
            )

            # Try to load schema for latest version first
            schema: dict[str, Any] | None = None
            try:
                schema = loader.load_schema(service_type, "latest")
            except TemplateLoadError:
                # Fallback to v1 if latest not found
                try:
                    schema = loader.load_schema(service_type, "v1")
                except TemplateLoadError:
                    # Schema not found in either version
                    logger.error(
                        "Schema not found",
                        extra={
                            "service_id": service_id,
                            "service_type": service_type,
                            "repo_dir": str(repo_dir),
                        },
                    )
                    return jsonify(
                        {
                            "error": "not_found",
                            "description": f"No schema found for service '{service_id}'",
                        }
                    ), 404

            logger.info(
                "Schema retrieved successfully",
                extra={
                    "service_id": service_id,
                    "service_type": service_type,
                    "properties_count": len(schema.get("properties", {})),
                },
            )

            return jsonify(schema), 200

        except Exception as e:
            # Catch any unexpected errors (not FileNotFoundError, which is handled above)
            logger.error(
                "Failed to retrieve schema",
                extra={"service_id": service_id, "error": str(e)},
            )
            return jsonify(
                {
                    "error": "internal_server_error",
                    "description": str(e),
                }
            ), 500

    # ========== Health Check Endpoints ==========

    @app.route("/health", methods=["GET"])
    def health() -> tuple[Response, int]:
        """Health check endpoint."""
        return jsonify({"status": "healthy"}), 200

    @app.route("/health/git", methods=["GET"])
    def health_git() -> tuple[Response, int]:
        """Git connectivity health check endpoint."""
        try:
            storage_type = type(storage).__name__

            # GitopsStorage - check Git connectivity
            if hasattr(storage, "state_manager") and storage.state_manager:
                git_ops = storage.state_manager.git_ops

                # Try to pull latest to verify connectivity
                git_ops.pull_latest()

                return jsonify(
                    {
                        "status": "healthy",
                        "storage_type": "gitops",
                        "mode": "stateless",
                        "commit": git_ops.get_current_commit(),
                        "branch": git_ops.get_branch_name(),
                        "cache_stats": storage.state_manager.get_cache_stats(),
                    }
                ), 200
            # FileStorage or other storage types
            else:
                return jsonify(
                    {
                        "status": "healthy",
                        "storage_type": storage_type.replace("Storage", "").lower(),
                        "mode": "stateful",
                        "message": f"Running with {storage_type} (no Git dependency)",
                    }
                ), 200
        except Exception as e:
            logger.error("Git health check failed", extra={"error": str(e)})
            return jsonify({"status": "unhealthy", "error": str(e)}), 503

    @app.route("/health/cache/clear", methods=["POST"])
    def clear_cache() -> tuple[Response, int]:
        """Clear cache endpoint (admin operation)."""
        try:
            storage_type = type(storage).__name__

            if hasattr(storage, "state_manager") and storage.state_manager:
                storage.state_manager.clear_cache()
                return jsonify({"status": "success", "message": "Cache cleared"}), 200
            else:
                return jsonify(
                    {
                        "status": "not_applicable",
                        "storage_type": storage_type.replace("Storage", "").lower(),
                        "message": f"Cache not available for {storage_type}",
                    }
                ), 200
        except Exception as e:
            logger.error("Failed to clear cache", extra={"error": str(e)})
            return jsonify({"status": "error", "error": str(e)}), 500

    # Error handlers
    @app.errorhandler(404)
    def not_found(
        error: Exception,
    ) -> tuple[Response, int]:
        return (
            jsonify({"error": "not_found", "description": "Resource not found"}),
            404,
        )

    @app.errorhandler(500)
    def internal_error(
        error: Exception,
    ) -> tuple[Response, int]:
        logger.error("Internal server error", extra={"error": str(error)})
        return (
            jsonify({"error": "internal_server_error", "description": "Internal server error"}),
            500,
        )

    return app


if __name__ == "__main__":
    # Configure logging first (before any log calls)
    configure_logging()

    # Parse command-line arguments
    parser = argparse.ArgumentParser(
        description="GitOps CSB Broker - Service broker with GitOps provisioning"
    )
    parser.add_argument(
        "--config",
        type=str,
        help="Path to JSON configuration file (optional)",
    )
    parser.add_argument(
        "--dev",
        action="store_true",
        help="Run with Flask development server (NOT for production)",
    )
    args = parser.parse_args()

    logger.info(
        "Starting GitOps CSB Broker", extra={"config": str(config), "config_file": args.config}
    )

    try:
        app = create_app(config_file=args.config)
    except Exception as e:
        logger.error("Failed to create application", extra={"error": str(e)})
        sys.exit(1)

    # Development mode - use Flask development server
    if args.dev:
        logger.warning(
            "Running with Flask development server - NOT SUITABLE FOR PRODUCTION",
            extra={"host": config.host, "port": config.port},
        )

        # Configure TLS/mTLS if enabled
        if config.tls_enabled:
            ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ssl_context.load_cert_chain(config.server_cert_path, config.server_key_path)

            if config.mtls_enabled:
                ssl_context.verify_mode = ssl.CERT_REQUIRED
                ssl_context.load_verify_locations(config.client_ca_path)
                logger.info(
                    "Starting with mTLS enabled",
                    extra={
                        "server_cert": config.server_cert_path,
                        "client_ca": config.client_ca_path,
                    },
                )
            else:
                logger.info(
                    "Starting with TLS enabled", extra={"server_cert": config.server_cert_path}
                )

            app.run(host=config.host, port=config.port, ssl_context=ssl_context, debug=False)
        else:
            logger.info("Starting without TLS (HTTP only)")
            app.run(host=config.host, port=config.port, debug=False)

    # Production mode - print instructions for Gunicorn
    else:
        logger.error(
            "Direct execution not supported in production mode - use Gunicorn",
            extra={
                "gunicorn_command": (
                    f"gunicorn --config gunicorn.conf.py "
                    f"--bind {config.host}:{config.port} "
                    f"'broker.app:create_app(config_file=\"{args.config or 'config.gitops.json'}\")'"
                )
            },
        )
        sys.exit(1)

# Made with Bob
