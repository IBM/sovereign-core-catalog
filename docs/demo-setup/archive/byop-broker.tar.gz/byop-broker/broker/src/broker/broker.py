"""
CSB v2 API broker logic with dependency injection
"""

from typing import Any

from broker.catalog_discovery import discover_services
from broker.logging_config import get_logger
from broker.storage import StorageInterface


logger = get_logger(__name__)


DASHBOARD_URL_TEMPLATE_KEY = "dashboard_url_template"


class CSBBroker:
    """CSB v2 API implementation"""

    def __init__(
        self,
        storage: StorageInterface,
        dashboard_url: str,
        gitops_path: str = "./orchestrator",
        async_enabled: bool = True,
    ):
        self.storage = storage
        self.dashboard_url = dashboard_url
        self.gitops_path = gitops_path
        self.async_enabled = async_enabled
        self._service_dashboard_urls: dict[str, str] = {}
        logger.info(
            "CSBBroker initialized",
            extra={"gitops_path": gitops_path, "async_enabled": async_enabled},
        )

    def catalog(self) -> dict[str, Any]:
        """
        Return the service catalog (GET /v2/catalog)

        Dynamically discovers services from the GitOps repository's services directory.
        The discover_services() function always pulls latest changes to ensure catalog is up-to-date.

        Returns: catalog data with list of services and plans
        """
        logger.info("Fetching catalog from GitOps repository services")

        # discover_services() will handle git pull to ensure catalog is up-to-date
        catalog_data = discover_services()
        self._service_dashboard_urls = {
            service["id"]: service[DASHBOARD_URL_TEMPLATE_KEY]
            for service in catalog_data.get("services", [])
            if service.get("id") and service.get(DASHBOARD_URL_TEMPLATE_KEY)
        }
        return catalog_data

    def _extract_instance_id(self, crn: str) -> str:
        """Extract instance ID from CRN (Cloud Resource Name)"""
        # CRN format: crn:v1:local:public:service:region:account:instance-id::
        parts = crn.split(":")
        if len(parts) >= 8:
            return parts[7]
        # If CRN format is simple, use the whole CRN as instance_id
        return crn

    def _build_extensions(
        self,
        instance_id: str,
        crn: str,
        service_id: str | None = None,
        dashboard_url: str | None = None,
    ) -> dict[str, Any]:
        """Build default extensions dict"""
        exts = {"instanceID": instance_id, "crn": crn}
        if service_id:
            exts["serviceID"] = service_id
        if dashboard_url:
            exts["dashboard_url"] = dashboard_url
        return exts

    def _resolve_dashboard_url(self, service_id: str | None, instance_id: str) -> str:
        """Resolve dashboard URL with service-specific override and broker fallback."""
        template = self._service_dashboard_urls.get(service_id or "", self.dashboard_url)
        resolved_url = template.replace("{instance_id}", instance_id).replace(
            "<instance-id>", instance_id
        )
        logger.info(
            "Resolved dashboard URL",
            extra={
                "service_id": service_id,
                "instance_id": instance_id,
                "template": template,
                "resolved_url": resolved_url,
                "source": "service"
                if service_id and service_id in self._service_dashboard_urls
                else "broker",
            },
        )
        return resolved_url

    def provision(self, crn: str, request_data: dict[str, Any]) -> tuple[dict[str, Any], int]:
        """
        Handle provision request (PUT /v2/service_instances/:crn)

        Returns: (response_data, status_code)
        """
        instance_id = self._extract_instance_id(crn)

        # Validate required fields
        if "service_id" not in request_data:
            logger.error("Missing service_id", extra={"instance_id": instance_id})
            return {"error": "bad_request", "description": "service_id is required"}, 400

        if "plan_id" not in request_data:
            logger.error("Missing plan_id", extra={"instance_id": instance_id})
            return {"error": "bad_request", "description": "plan_id is required"}, 400

        # Check if instance already exists
        if self.storage.exists(instance_id):
            existing = self.storage.get(instance_id)

            # This should not happen since exists() returned True, but check for type safety
            if existing is None:
                return {
                    "error": "internal_server_error",
                    "description": "Instance exists but could not be retrieved",
                }, 500

            # If same service_id and plan_id, return 200 (already exists)
            if (
                existing.get("service_id") == request_data["service_id"]
                and existing.get("plan_id") == request_data["plan_id"]
            ):
                logger.info(
                    "Instance already exists with same config", extra={"instance_id": instance_id}
                )
                return {
                    "dashboard_url": self._resolve_dashboard_url(
                        request_data["service_id"], instance_id
                    )
                }, 200
            else:
                logger.error(
                    "Instance already exists with different config",
                    extra={"instance_id": instance_id},
                )
                return {
                    "error": "conflict",
                    "description": "Instance already exists with different configuration",
                }, 409

        # Create service instance
        instance_data = {
            "instance_id": instance_id,
            "crn": crn,
            "service_id": request_data["service_id"],
            "plan_id": request_data["plan_id"],
            "context": request_data.get("context", {}),
            "parameters": request_data.get("parameters", {}),
            "organization_guid": request_data.get("organization_guid"),
            "space_guid": request_data.get("space_guid"),
            "state": "succeeded",
            "description": "Service instance provisioned successfully",
        }

        try:
            self.storage.create(instance_id, instance_data)
            logger.info(
                "Provision initiated",
                extra={
                    "instance_id": instance_id,
                    "service_id": request_data["service_id"],
                    "async_mode": self.async_enabled,
                },
            )

            # Dump provision variables if enabled
            if hasattr(self.storage, "dump_provision_variables"):
                from datetime import datetime, timezone

                # Use service_id directly as service_type
                service_type = request_data["service_id"]

                variables = {
                    "request": request_data,
                    "instance_data": instance_data,
                    "broker_config": {
                        "dashboard_url": self.dashboard_url,
                        "gitops_path": str(self.gitops_path),
                        "async_enabled": self.async_enabled,
                    },
                    "computed": {
                        "instance_id": instance_id,
                        "crn": crn,
                        "service_type": service_type,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    },
                }
                self.storage.dump_provision_variables(instance_id, variables)

            # Return 202 Accepted for async, 201 Created for sync
            if self.async_enabled:
                return {
                    "dashboard_url": self._resolve_dashboard_url(
                        request_data["service_id"], instance_id
                    )
                }, 202
            else:
                return {
                    "dashboard_url": self._resolve_dashboard_url(
                        request_data["service_id"], instance_id
                    )
                }, 201
        except Exception as e:
            logger.error("Provision failed", extra={"instance_id": instance_id, "error": str(e)})
            return {"error": "internal_server_error", "description": str(e)}, 500

    def update_provision(
        self, crn: str, request_data: dict[str, Any]
    ) -> tuple[dict[str, Any], int]:
        """
        Handle update provision request (PATCH /v2/service_instances/:crn)

        Returns: (response_data, status_code)
        """
        instance_id = self._extract_instance_id(crn)

        # Check if instance exists
        if not self.storage.exists(instance_id):
            logger.error("Instance not found for update", extra={"instance_id": instance_id})
            return {"error": "bad_request", "description": "Instance not found"}, 400

        # Update the instance
        update_data = {}
        if "service_id" in request_data:
            update_data["service_id"] = request_data["service_id"]
        if "plan_id" in request_data:
            update_data["plan_id"] = request_data["plan_id"]
        if "context" in request_data:
            update_data["context"] = request_data["context"]
        if "parameters" in request_data:
            update_data["parameters"] = request_data["parameters"]

        update_data["state"] = "succeeded"
        update_data["description"] = "Service instance updated successfully"

        try:
            self.storage.update(instance_id, update_data)
            logger.info("Update successful", extra={"instance_id": instance_id})
            # Return dashboard_url like provision does
            existing_instance = self.storage.get(instance_id)
            service_id = update_data.get("service_id")
            if service_id is None and existing_instance is not None:
                service_id = existing_instance.get("service_id")

            return {"dashboard_url": self._resolve_dashboard_url(service_id, instance_id)}, 200
        except Exception as e:
            logger.error("Update failed", extra={"instance_id": instance_id, "error": str(e)})
            return {"error": "internal_server_error", "description": str(e)}, 500

    def last_operation(self, crn: str) -> tuple[dict[str, Any], int]:
        """
        Handle last operation polling (GET /v2/service_instances/:crn/last_operation)

        Returns: (response_data, status_code)
        """
        instance_id = self._extract_instance_id(crn)

        # Check if instance exists
        if not self.storage.exists(instance_id):
            logger.error(
                "Instance not found for last_operation", extra={"instance_id": instance_id}
            )
            return {"error": "not_found", "description": "Cannot find service instance"}, 404

        instance = self.storage.get(instance_id)

        # This should not happen since exists() returned True, but check for type safety
        if instance is None:
            return {"error": "not_found", "description": "Cannot find service instance"}, 404

        logger.info(
            "Last operation polled",
            extra={"instance_id": instance_id, "state": instance.get("state")},
        )

        return {
            "state": instance.get("state", "succeeded"),
            "description": instance.get("description", "Operation completed"),
            "extensions": self._build_extensions(
                instance_id,
                crn,
                instance.get("service_id"),
                dashboard_url=self._resolve_dashboard_url(instance.get("service_id"), instance_id),
            ),
        }, 200

    def deprovision(
        self, crn: str, service_id: str | None = None, plan_id: str | None = None
    ) -> tuple[dict[str, Any], int]:
        """
        Handle deprovision request (DELETE /v2/service_instances/:crn)

        Returns: (response_data, status_code)
        """
        instance_id = self._extract_instance_id(crn)

        # Check if instance exists
        if not self.storage.exists(instance_id):
            logger.info(
                "Instance not found for deprovision (already gone)",
                extra={"instance_id": instance_id},
            )
            return {"error": "gone", "description": "No instance found with this ID"}, 410

        existing = self.storage.get(instance_id)

        # This should not happen since exists() returned True, but check for type safety
        if existing is None:
            return {"error": "gone", "description": "No instance found with this ID"}, 410

        # Validate service_id if provided
        if service_id and existing.get("service_id") != service_id:
            logger.error("Service ID mismatch", extra={"instance_id": instance_id})
            return {
                "error": "bad_request",
                "description": (
                    "Request service_id query parameter does not match "
                    "the ServiceInstance service ID"
                ),
            }, 400

        # Validate plan_id if provided
        if plan_id and existing.get("plan_id") != plan_id:
            logger.error("Plan ID mismatch", extra={"instance_id": instance_id})
            return {
                "error": "bad_request",
                "description": (
                    "Request plan_id query parameter does not match the ServiceInstance plan ID"
                ),
            }, 400

        try:
            self.storage.delete(instance_id)
            logger.info(
                "Deprovision initiated",
                extra={"instance_id": instance_id, "async_mode": self.async_enabled},
            )

            # Return 202 Accepted for async, 200 OK for sync
            if self.async_enabled:
                return {}, 202
            else:
                return {}, 200
        except Exception as e:
            logger.error("Deprovision failed", extra={"instance_id": instance_id, "error": str(e)})
            return {"error": "internal_server_error", "description": str(e)}, 500

    def list_instances(self) -> tuple[dict[str, Any], int]:
        """
        List all provisioned service instances (custom extension endpoint).

        This is not part of the standard CSB v2 API, but a useful extension
        for management and monitoring.

        Returns: (response_data, status_code)
        """
        try:
            instances = self.storage.list_all()
            logger.info("Listed instances", extra={"count": len(instances)})

            return {"instances": instances, "count": len(instances)}, 200
        except Exception as e:
            logger.error("Failed to list instances", extra={"error": str(e)})
            return {"error": "internal_server_error", "description": str(e)}, 500
