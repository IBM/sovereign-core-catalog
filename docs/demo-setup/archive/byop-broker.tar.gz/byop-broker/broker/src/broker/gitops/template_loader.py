"""Template loader for service provisioning templates.

This module provides functionality to load and cache service templates from the
GitOps repository. Templates are used to generate Kubernetes manifests for
service instances.

Example:
    >>> from pathlib import Path
    >>> loader = TemplateLoader(Path("/path/to/gitops/repo"))
    >>> templates = loader.load_templates("mysql", "v1")
    >>> print(templates.keys())
    dict_keys(['schema.json', 'secret.yaml.tmpl', 'kustomization.yaml.tmpl'])
"""

import json
import logging
import subprocess
from pathlib import Path
from typing import Any


logger = logging.getLogger(__name__)


class TemplateLoadError(Exception):
    """Raised when template loading fails."""

    pass


class TemplateLoader:
    """Load and cache service templates from GitOps repository.

    This class handles loading template files from service directories in the
    GitOps repository. It provides caching to improve performance and supports
    versioned templates.

    Attributes:
        repo_dir: Path to the GitOps repository root
        _cache: Internal cache for loaded templates
    """

    def __init__(self, repo_dir: Path) -> None:
        """Initialize template loader.

        Args:
            repo_dir: Path to GitOps repository root directory

        Raises:
            TemplateLoadError: If repo_dir doesn't exist or isn't a directory
        """
        if not repo_dir.exists():
            raise TemplateLoadError(f"Repository directory not found: {repo_dir}")
        if not repo_dir.is_dir():
            raise TemplateLoadError(f"Repository path is not a directory: {repo_dir}")

        self.repo_dir = repo_dir
        self._cache: dict[str, dict[str, str]] = {}
        self._cache_commit_hash: str | None = None
        logger.debug(f"Initialized TemplateLoader with repo_dir: {repo_dir}")

    def load_templates(self, service_type: str, service_version: str = "v1") -> dict[str, str]:
        """Load all template files for a service.

        Loads all template files from the service's template directory. Template
        files have extensions like .tmpl, .json, .yaml, etc. Results are cached
        for performance. Cache is automatically invalidated when git repository
        changes are detected.

        Args:
            service_type: Service type name (e.g., "mysql", "postgres")
            service_version: Service version (default: "v1")

        Returns:
            Dictionary mapping template filenames to their content

        Raises:
            TemplateLoadError: If template directory not found or templates invalid

        Example:
            >>> loader = TemplateLoader(Path("/repo"))
            >>> templates = loader.load_templates("mysql")
            >>> schema = templates["schema.json"]
            >>> secret_tmpl = templates["secret.yaml.tmpl"]
        """
        # Check if git repository has changed and invalidate cache if needed
        current_commit = self._get_current_commit_hash()
        if current_commit != self._cache_commit_hash:
            if self._cache_commit_hash is not None:
                logger.info(
                    f"Git commit changed ({self._cache_commit_hash[:8]} -> {current_commit[:8]}), "
                    "clearing template cache"
                )
            self._cache.clear()
            self._cache_commit_hash = current_commit

        cache_key = f"{service_type}:{service_version}"

        # Return cached templates if available
        if cache_key in self._cache:
            logger.debug(f"Returning cached templates for {cache_key}")
            return self._cache[cache_key]

        # Load templates from filesystem
        template_dir = self._get_template_directory(service_type, service_version)
        templates = self._load_template_files(template_dir)

        # Cache and return
        self._cache[cache_key] = templates
        logger.info(f"Loaded {len(templates)} templates for {service_type}:{service_version}")
        return templates

    def load_schema(self, service_type: str, service_version: str = "v1") -> dict[str, Any]:
        """Load and parse JSON schema for a service.

        Convenience method to load and parse the schema.json file for a service.

        Args:
            service_type: Service type name
            service_version: Service version (default: "v1")

        Returns:
            Parsed JSON schema as dictionary

        Raises:
            TemplateLoadError: If schema.json not found or invalid JSON

        Example:
            >>> loader = TemplateLoader(Path("/repo"))
            >>> schema = loader.load_schema("mysql")
            >>> required_fields = schema["required"]
        """
        templates = self.load_templates(service_type, service_version)

        if "schema.json" not in templates:
            raise TemplateLoadError(
                f"schema.json not found in templates for {service_type}:{service_version}"
            )

        try:
            schema: dict[str, Any] = json.loads(templates["schema.json"])
            logger.debug(f"Parsed schema for {service_type}:{service_version}")
            return schema
        except json.JSONDecodeError as e:
            raise TemplateLoadError(
                f"Invalid JSON in schema.json for {service_type}:{service_version}: {e}"
            ) from e

    def get_template(
        self, service_type: str, template_name: str, service_version: str = "v1"
    ) -> str:
        """Get a specific template file by name.

        Args:
            service_type: Service type name
            template_name: Template filename (e.g., "secret.yaml.tmpl")
            service_version: Service version (default: "v1")

        Returns:
            Template file content as string

        Raises:
            TemplateLoadError: If template not found

        Example:
            >>> loader = TemplateLoader(Path("/repo"))
            >>> secret_tmpl = loader.get_template("mysql", "secret.yaml.tmpl")
        """
        templates = self.load_templates(service_type, service_version)

        if template_name not in templates:
            available = ", ".join(templates.keys())
            raise TemplateLoadError(
                f"Template '{template_name}' not found for {service_type}:{service_version}. "
                f"Available templates: {available}"
            )

        return templates[template_name]

    def clear_cache(self, service_type: str | None = None) -> None:
        """Clear template cache.

        Args:
            service_type: If provided, clear cache only for this service type.
                         If None, clear entire cache.

        Example:
            >>> loader = TemplateLoader(Path("/repo"))
            >>> loader.clear_cache("mysql")  # Clear only MySQL templates
            >>> loader.clear_cache()  # Clear all cached templates
        """
        if service_type is None:
            self._cache.clear()
            logger.debug("Cleared entire template cache")
        else:
            # Clear all versions of the service type
            keys_to_remove = [k for k in self._cache if k.startswith(f"{service_type}:")]
            for key in keys_to_remove:
                del self._cache[key]
            logger.debug(f"Cleared cache for service type: {service_type}")

    def _get_current_commit_hash(self) -> str:
        """Get current git commit hash.

        Returns:
            Current git commit hash (full SHA-1)

        Raises:
            TemplateLoadError: If git command fails or repo is not a git repository
        """
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=self.repo_dir,
                capture_output=True,
                text=True,
                check=True,
            )
            commit_hash = result.stdout.strip()
            logger.debug(f"Current git commit: {commit_hash[:8]}")
            return commit_hash
        except subprocess.CalledProcessError as e:
            # If git command fails, log warning and return empty string
            # This allows the loader to work in non-git environments
            logger.warning(
                f"Failed to get git commit hash: {e.stderr.strip()}. "
                "Template caching will work but won't auto-invalidate on git changes."
            )
            return ""
        except FileNotFoundError:
            # Git not installed
            logger.warning(
                "Git command not found. Template caching will work but won't "
                "auto-invalidate on git changes."
            )
            return ""

    def _get_template_directory(self, service_type: str, service_version: str) -> Path:
        """Get path to template directory for a service.

        Args:
            service_type: Service type name
            service_version: Service version

        Returns:
            Path to template directory

        Raises:
            TemplateLoadError: If template directory doesn't exist
        """
        # Use service_version if provided, otherwise default to "latest"
        version = service_version if service_version else "latest"
        template_dir = self.repo_dir / "services" / service_type / version / "template"

        if not template_dir.exists():
            raise TemplateLoadError(
                f"Template directory not found: {template_dir}. "
                f"Service '{service_type}' version '{version}' may not have templates configured."
            )

        if not template_dir.is_dir():
            raise TemplateLoadError(f"Template path is not a directory: {template_dir}")

        return template_dir

    def _load_template_files(self, template_dir: Path) -> dict[str, str]:
        """Load all template files from a directory, including subdirectories.

        Recursively loads template files while preserving directory structure.
        Template keys include relative paths (e.g., 'auth/rolebinding.yaml.tmpl').
        Also loads schema.json from the catalog directory if it exists.

        Args:
            template_dir: Path to template directory

        Returns:
            Dictionary mapping relative paths to content

        Raises:
            TemplateLoadError: If no template files found or read error
        """
        templates: dict[str, str] = {}

        def _load_recursive(current_dir: Path, relative_path: str = "") -> None:
            """Recursively load templates from directory."""
            for item in current_dir.iterdir():
                # Skip hidden files and directories
                if item.name.startswith("."):
                    continue

                # Skip common non-template directories
                if item.name in ("__pycache__", ".git", ".pytest_cache"):
                    continue

                if item.is_file():
                    # Build relative path for template key
                    template_key = f"{relative_path}{item.name}" if relative_path else item.name

                    try:
                        content = item.read_text(encoding="utf-8")
                        templates[template_key] = content
                        logger.debug(f"Loaded template: {template_key}")
                    except Exception as e:
                        raise TemplateLoadError(f"Failed to read template file {item}: {e}") from e

                elif item.is_dir():
                    # Recurse into subdirectory
                    subdir_path = f"{relative_path}{item.name}/"
                    _load_recursive(item, subdir_path)

        # Start recursive loading
        _load_recursive(template_dir)

        if not templates:
            raise TemplateLoadError(f"No template files found in {template_dir}")

        # Also load schema.json from catalog directory if it exists
        # Template dir is: services/{type}/{version}/template
        # Catalog dir is:  services/{type}/{version}/catalog
        catalog_dir = template_dir.parent / "catalog"
        schema_file = catalog_dir / "schema.json"

        if schema_file.exists():
            try:
                content = schema_file.read_text(encoding="utf-8")
                templates["schema.json"] = content
                logger.debug("Loaded schema from catalog: schema.json")
            except Exception as e:
                logger.warning(f"Failed to load schema.json from catalog: {e}")
                # Don't fail if schema.json can't be loaded - it's optional

        return templates

    def list_available_templates(self, service_type: str, service_version: str = "v1") -> list[str]:
        """List available template files for a service.

        Args:
            service_type: Service type name
            service_version: Service version (default: "v1")

        Returns:
            List of template filenames

        Raises:
            TemplateLoadError: If template directory not found

        Example:
            >>> loader = TemplateLoader(Path("/repo"))
            >>> templates = loader.list_available_templates("mysql")
            >>> print(templates)
            ['schema.json', 'secret.yaml.tmpl', 'kustomization.yaml.tmpl']
        """
        templates = self.load_templates(service_type, service_version)
        return sorted(templates.keys())

    def validate_required_templates(
        self, service_type: str, required: list[str], service_version: str = "v1"
    ) -> None:
        """Validate that required templates exist for a service.

        Args:
            service_type: Service type name
            required: List of required template filenames
            service_version: Service version (default: "v1")

        Raises:
            TemplateLoadError: If any required template is missing

        Example:
            >>> loader = TemplateLoader(Path("/repo"))
            >>> loader.validate_required_templates(
            ...     "mysql",
            ...     ["schema.json", "secret.yaml.tmpl"]
            ... )
        """
        templates = self.load_templates(service_type, service_version)
        missing = [name for name in required if name not in templates]

        if missing:
            available = ", ".join(templates.keys())
            raise TemplateLoadError(
                f"Missing required templates for {service_type}:{service_version}: "
                f"{', '.join(missing)}. Available templates: {available}"
            )

    def load_plan_metadata(
        self, service_type: str, plan_id: str, service_version: str = "v1"
    ) -> dict[str, Any]:
        """Load plan metadata from catalog.yaml.

        Args:
            service_type: Service type name (e.g., "mysql", "qradar")
            plan_id: Plan identifier (e.g., "all-in-one-normal-tiny")
            service_version: Service version (default: "v1")

        Returns:
            Dictionary containing plan metadata, or empty dict if not found

        Raises:
            TemplateLoadError: If catalog.yaml cannot be read

        Example:
            >>> loader = TemplateLoader(Path("/repo"))
            >>> metadata = loader.load_plan_metadata("qradar", "all-in-one-normal-tiny")
            >>> print(metadata)
            {'type': 'all-in-one-console', 'version': '7.5.0', 'cpu': 8, 'memory': 32}
        """
        import yaml

        # Catalog dir is: services/{type}/{version}/catalog
        catalog_dir = self.repo_dir / "services" / service_type / service_version / "catalog"
        catalog_file = catalog_dir / "catalog.yaml"

        if not catalog_file.exists():
            logger.warning(
                f"Catalog file not found: {catalog_file}. "
                f"Plan metadata will not be available for {service_type}:{plan_id}"
            )
            return {}

        try:
            with open(catalog_file, encoding="utf-8") as f:
                catalog_data = yaml.safe_load(f)
        except Exception as e:
            logger.warning(f"Failed to load catalog.yaml from {catalog_file}: {e}")
            return {}

        if not isinstance(catalog_data, dict):
            logger.warning(f"Invalid catalog.yaml format in {catalog_file}")
            return {}

        # Find the plan in the plans list
        plans = catalog_data.get("plans", [])
        if not plans:
            logger.warning(f"No plans found in catalog for {service_type}:{service_version}")
            return {}

        for plan in plans:
            if plan.get("id") == plan_id:
                # Extract metadata from plan's metadata section
                plan_metadata = plan.get("metadata", {})

                # Extract relevant fields (version, cpu, memory, storage, template/type)
                metadata_fields = ["version", "cpu", "memory", "storage", "template", "type"]
                metadata: dict[str, Any] = {
                    key: plan_metadata[key] for key in metadata_fields if key in plan_metadata
                }

                # Map 'type' to 'template' for backward compatibility
                if "type" in metadata and "template" not in metadata:
                    metadata["template"] = metadata.pop("type")

                if metadata:
                    logger.info(
                        f"Loaded plan metadata for {service_type}:{plan_id}",
                        extra={"metadata_keys": list(metadata.keys())},
                    )
                return metadata

        logger.warning(
            f"Plan '{plan_id}' not found in catalog for {service_type}:{service_version}. "
            f"Available plans: {[p.get('id') for p in plans]}"
        )
        return {}


# Made with Bob
