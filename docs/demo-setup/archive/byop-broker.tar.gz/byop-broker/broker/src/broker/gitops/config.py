"""Configuration module for GitOps orchestrator.

This module provides configuration settings for the GitOps orchestrator,
including ArgoCD settings, SOPS encryption, and environment-specific defaults.
"""

import os
from pathlib import Path
from typing import Any


class Config:
    """Configuration settings for the orchestrator."""

    # Base directories
    BASE_DIR: Path = Path(__file__).parent.parent

    # ArgoCD configuration
    ARGOCD_NAMESPACE: str = "argocd"
    ARGOCD_PROJECT: str = "default"

    # Default values
    DEFAULT_NAMESPACE_PREFIX: str = "service"
    DEFAULT_STORAGE_CLASS: str = "local-path"
    DEFAULT_MYSQL_IMAGE: str = "quay.io/mysql/mysql-server:8.0"
    DEFAULT_MARIADB_IMAGE: str = "mariadb:11.2"

    # Environment-specific defaults
    ENVIRONMENT_DEFAULTS: dict[str, dict[str, Any]] = {
        "dev": {
            "replicas": 1,
            "storage_size": "10Gi",
            "resources": {
                "requests": {"memory": "512Mi", "cpu": "250m"},
                "limits": {"memory": "1Gi", "cpu": "500m"},
            },
        },
        "staging": {
            "replicas": 2,
            "storage_size": "50Gi",
            "resources": {
                "requests": {"memory": "1Gi", "cpu": "500m"},
                "limits": {"memory": "2Gi", "cpu": "1000m"},
            },
        },
        "prod": {
            "replicas": 3,
            "storage_size": "100Gi",
            "resources": {
                "requests": {"memory": "2Gi", "cpu": "1000m"},
                "limits": {"memory": "4Gi", "cpu": "2000m"},
            },
        },
    }

    # SOPS encryption configuration
    SOPS_ENABLED: bool = os.getenv("SOPS_ENABLED", "false").lower() == "true"
    SOPS_AGE_RECIPIENT: str = os.getenv("SOPS_AGE_RECIPIENT", "")
    SOPS_ENCRYPT_SECRETS: bool = os.getenv("SOPS_ENCRYPT_SECRETS", "true").lower() == "true"

    @classmethod
    def get_environment_defaults(cls, environment: str) -> dict[str, Any]:
        """Get default configuration for an environment.

        Args:
            environment: Environment name ('dev', 'staging', or 'prod')

        Returns:
            Dictionary containing environment-specific configuration defaults.
            Returns 'dev' defaults if environment is not found.
            Returns a copy to prevent accidental modification of class defaults.

        Example:
            >>> config = Config.get_environment_defaults('prod')
            >>> config['replicas']
            3
        """
        defaults = cls.ENVIRONMENT_DEFAULTS.get(environment, cls.ENVIRONMENT_DEFAULTS["dev"])
        return defaults.copy()


# Made with Bob
