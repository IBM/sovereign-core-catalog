"""Standalone CLI for BYOP Service Provisioning.

This package provides a command-line interface for testing and managing
service instance provisioning without running the full broker server.

Features:
    - Dry-run mode for local testing
    - Direct provisioning with GitOps storage
    - Instance management (list, get, clean)
    - Rich terminal output with colors and progress indicators

Usage:
    $ broker-cli provision --service mysql --instance dev-001 --dry-run
    $ broker-cli list
    $ broker-cli clean --all

The CLI reuses the broker's core provisioning logic but provides a
developer-friendly interface for local testing and debugging.
"""

__version__ = "1.1.0"
__author__ = "Development Team"

# Made with Bob
