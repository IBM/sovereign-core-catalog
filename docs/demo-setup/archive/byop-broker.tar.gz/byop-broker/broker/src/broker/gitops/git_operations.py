"""Git operations for GitHub Enterprise repository management.

Handles clone, pull, commit, and push operations.

This module provides a GitOperations class that manages all Git interactions
for the GitOps orchestrator with GitHub Enterprise.
"""

import logging
import subprocess
from pathlib import Path

from broker.gitops.git_config import GitConfig
from broker.gitops.ssh_key_manager import SSHKeyManager


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class GitOperationsError(Exception):
    """Custom exception for Git operations errors."""

    pass


class GitOperations:
    """Handle Git operations for GitHub Enterprise repositories."""

    def __init__(self) -> None:
        """Initialize Git operations with current configuration.

        Raises:
            GitOperationsError: If Git configuration is invalid
        """
        self.repo_dir: Path = GitConfig.get_repo_dir()
        self.repo_url: str = GitConfig.get_repo_url()
        self.branch: str = GitConfig.get_branch()
        self.ssh_manager: SSHKeyManager | None = None

        # Validate configuration
        try:
            GitConfig.validate_config()
        except ValueError as e:
            raise GitOperationsError(f"Invalid Git configuration: {e}") from e

        # Setup SSH key for SSH URLs
        if self.repo_url.startswith("git@") or self.repo_url.startswith("ssh://"):
            self._setup_ssh_key()

        # Ensure working directory exists
        self.repo_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"Git working directory: {self.repo_dir}")

        # Configure Git to trust the working directory
        # This is needed because the directory may be mounted as an emptyDir volume
        # with different ownership (e.g., root) than the running user
        self._configure_safe_directory()

    def _setup_ssh_key(self) -> None:
        """Setup SSH key from environment or file.

        Raises:
            GitOperationsError: If SSH key setup fails
        """
        try:
            self.ssh_manager = SSHKeyManager()
            key_path = self.ssh_manager.setup_ssh_key()
            logger.info(f"SSH key configured: {key_path}")

            # Set GIT_SSH_COMMAND for this process
            self.ssh_manager.setup_git_ssh_command(key_path)
        except ValueError as e:
            # SSH key configuration is required for SSH Git operations
            # Do not fall back silently - this masks configuration errors
            error_msg = f"SSH key setup failed: {e}"
            logger.error(error_msg)
            raise GitOperationsError(error_msg) from e

    def _configure_safe_directory(self) -> None:
        """Configure Git to trust the working directory.

        This is needed because the directory may be mounted as an emptyDir volume
        with different ownership than the running user, which Git 2.35.2+ blocks
        for security reasons.

        Tries multiple approaches:
        1. Global config (requires writable home directory)
        2. System config (requires root/system access)
        3. Per-repository config (always works if repo exists)
        """
        # Try global config first (preferred)
        try:
            subprocess.run(
                ["git", "config", "--global", "--add", "safe.directory", str(self.repo_dir)],
                check=True,
                capture_output=True,
                text=True,
            )
            logger.info(f"Configured Git safe.directory (global): {self.repo_dir}")
            return
        except subprocess.CalledProcessError as e:
            logger.warning(f"Could not configure global safe.directory: {e.stderr}")

        # Try system config as fallback
        try:
            subprocess.run(
                ["git", "config", "--system", "--add", "safe.directory", str(self.repo_dir)],
                check=True,
                capture_output=True,
                text=True,
            )
            logger.info(f"Configured Git safe.directory (system): {self.repo_dir}")
            return
        except subprocess.CalledProcessError as e:
            logger.warning(f"Could not configure system safe.directory: {e.stderr}")

        # If repo exists, try per-repository config as last resort
        git_dir = self.repo_dir / ".git"
        if git_dir.exists():
            try:
                subprocess.run(
                    [
                        "git",
                        "-C",
                        str(self.repo_dir),
                        "config",
                        "--local",
                        "--add",
                        "safe.directory",
                        str(self.repo_dir),
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                )
                logger.info(f"Configured Git safe.directory (local): {self.repo_dir}")
                return
            except subprocess.CalledProcessError as e:
                logger.warning(f"Could not configure local safe.directory: {e.stderr}")

        # All methods failed - log warning but continue
        # The ensure_repo_cloned() method will handle ownership issues by re-cloning if needed
        logger.warning(
            f"Could not configure safe.directory for {self.repo_dir} - will attempt to fix on clone/pull"
        )

    def _run_git_command(
        self,
        args: list[str],
        check: bool = True,
        capture_output: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        """Run a git command and return the result.

        Args:
            args: List of git command arguments
            check: Whether to raise exception on non-zero exit code
            capture_output: Whether to capture stdout/stderr

        Returns:
            Command result

        Raises:
            GitOperationsError: If command fails and check=True
        """
        cmd = ["git", "-C", str(self.repo_dir)] + args
        logger.debug(f"Running: {' '.join(cmd)}")

        try:
            result = subprocess.run(
                cmd,
                capture_output=capture_output,
                text=True,
                check=check,
            )
            return result
        except subprocess.CalledProcessError as e:
            error_msg = f"Git command failed: {' '.join(cmd)}\n"
            if e.stderr:
                error_msg += f"Error: {e.stderr}"
            logger.error(error_msg)
            if check:
                raise GitOperationsError(error_msg) from e
            return e  # type: ignore[return-value]

    def _is_ownership_issue(self, error_output: str) -> bool:
        """Check if error is due to dubious ownership.

        Args:
            error_output: Error message from Git command

        Returns:
            True if error is ownership-related
        """
        return "dubious ownership" in error_output or "detected dubious ownership" in error_output

    def _fix_ownership_in_place(self) -> None:
        """Fix ownership issues by configuring Git to trust the repository.

        Instead of trying to delete and re-clone (which requires write permissions),
        we configure Git directly in the repository's local config to bypass the
        ownership check. This works even when we can't delete the directory.
        """
        logger.warning(f"Fixing ownership issue by configuring repository trust at {self.repo_dir}")

        try:
            # Use git config --local to add safe.directory in the repo's own config
            # This bypasses the ownership check for this specific repository
            result = subprocess.run(
                [
                    "git",
                    "-C",
                    str(self.repo_dir),
                    "config",
                    "--local",
                    "safe.directory",
                    str(self.repo_dir),
                ],
                capture_output=True,
                text=True,
            )

            if result.returncode == 0:
                logger.info(f"Configured repository to trust directory: {self.repo_dir}")
            else:
                # If local config fails, try using GIT_CONFIG_GLOBAL to point to a writable location
                logger.warning("Local config failed, trying alternative approach")

                # Create a temporary git config in /tmp (always writable)
                import os

                try:
                    # Use /tmp for temporary config (always writable in containers)
                    # Safe in containerized environment with ephemeral filesystem
                    temp_config = Path("/tmp") / ".gitconfig-broker"  # nosec B108
                    with open(temp_config, "w") as f:
                        f.write(f"[safe]\n\tdirectory = {self.repo_dir}\n")

                    # Set GIT_CONFIG_GLOBAL for this process
                    os.environ["GIT_CONFIG_GLOBAL"] = str(temp_config)
                    logger.info(f"Created temporary git config at {temp_config}")
                except Exception as e:
                    logger.warning(f"Could not create temporary config: {e}")
                    # Last resort: use GIT_CONFIG_NOSYSTEM to disable system config
                    os.environ["GIT_CONFIG_NOSYSTEM"] = "1"
                    logger.info("Disabled system git config to bypass ownership check")

        except Exception as e:
            error_msg = f"Failed to fix ownership in place: {e}"
            logger.error(error_msg)
            raise GitOperationsError(error_msg) from e

    def ensure_repo_cloned(self) -> None:
        """Clone repository if it doesn't exist.

        Raises:
            GitOperationsError: If clone fails
        """
        git_dir = self.repo_dir / ".git"

        if git_dir.exists():
            logger.info(f"Repository already cloned at {self.repo_dir}")

            # Test if we can access the repository (ownership check)
            try:
                subprocess.run(
                    ["git", "-C", str(self.repo_dir), "status"],
                    check=True,
                    capture_output=True,
                    text=True,
                )
            except subprocess.CalledProcessError as e:
                if self._is_ownership_issue(e.stderr):
                    logger.warning("Detected ownership issue with existing repository")
                    self._fix_ownership_in_place()
                else:
                    # Some other error - log but continue
                    logger.warning(f"Repository access check failed: {e.stderr}")

            return

        logger.info(f"Cloning repository from {self.repo_url}")

        try:
            # Clone the repository
            subprocess.run(
                ["git", "clone", self.repo_url, str(self.repo_dir)],
                check=True,
                capture_output=True,
                text=True,
            )
            logger.info("Repository cloned successfully")
        except subprocess.CalledProcessError as e:
            error_msg = f"Failed to clone repository: {e.stderr}"
            logger.error(error_msg)
            raise GitOperationsError(error_msg) from e

    def pull_latest(self) -> None:
        """Pull latest changes from remote.

        Raises:
            GitOperationsError: If pull fails
        """
        logger.info(f"Pulling latest changes from {self.branch}")

        try:
            self._run_git_command(["pull", "origin", self.branch])
            logger.info("Pulled latest changes")
        except GitOperationsError as e:
            # Check if this is an ownership issue
            if self._is_ownership_issue(str(e)):
                logger.warning("Detected ownership issue during pull")
                self._fix_ownership_in_place()
                # After fixing, retry the pull
                try:
                    self._run_git_command(["pull", "origin", self.branch])
                    logger.info("Pulled latest changes after fixing ownership")
                    return
                except GitOperationsError:
                    pass  # Fall through to reset logic

            logger.warning("Pull failed, attempting to reset and pull...")
            try:
                self._run_git_command(["fetch", "origin"])
                self._run_git_command(["reset", "--hard", f"origin/{self.branch}"])
                logger.info("Reset to remote state")
            except GitOperationsError as reset_error:
                # Check if reset also failed due to ownership
                if self._is_ownership_issue(str(reset_error)):
                    logger.warning("Detected ownership issue during reset")
                    self._fix_ownership_in_place()
                    # Retry reset after fixing
                    try:
                        self._run_git_command(["fetch", "origin"])
                        self._run_git_command(["reset", "--hard", f"origin/{self.branch}"])
                        logger.info("Reset to remote state after fixing ownership")
                        return
                    except GitOperationsError:
                        pass  # Give up
                raise GitOperationsError(
                    f"Failed to sync with remote: {reset_error}"
                ) from reset_error

    def commit_and_push(
        self,
        message: str,
        author_name: str = "GitOps Orchestrator",
        author_email: str = "gitops@example.com",
    ) -> None:
        """Commit changes and push to remote.

        Args:
            message: Commit message
            author_name: Git author name
            author_email: Git author email

        Raises:
            GitOperationsError: If commit or push fails
        """
        logger.info(f"Committing changes: {message}")

        # Configure git user if not set
        self._run_git_command(["config", "user.name", author_name], check=False)
        self._run_git_command(["config", "user.email", author_email], check=False)

        # Add all changes before any remote reconciliation so new files are tracked
        self._run_git_command(["add", "."])

        # Check if there are changes to commit
        status = self._run_git_command(["status", "--porcelain"], check=False)
        if not status.stdout.strip():
            logger.info("No changes to commit")
            return

        # Commit changes
        try:
            self._run_git_command(["commit", "-m", message])
            logger.info("Changes committed")
        except GitOperationsError as e:
            raise GitOperationsError(f"Failed to commit changes: {e}") from e

        # Push to remote
        logger.info(f"Pushing to {self.branch}")
        try:
            self._run_git_command(["push", "origin", self.branch])
            logger.info("Changes pushed to remote")
        except GitOperationsError:
            logger.warning("Push failed, attempting fetch and rebase before retrying push")
            try:
                self._run_git_command(["fetch", "origin"])
                self._run_git_command(["rebase", f"origin/{self.branch}"])
                self._run_git_command(["push", "origin", self.branch])
                logger.info("Changes rebased and pushed to remote")
            except GitOperationsError as rebase_error:
                raise GitOperationsError(
                    "Failed to push to remote after fetch/rebase retry. "
                    f"Check your authentication, branch state, and network connection: {rebase_error}"
                ) from rebase_error

    def get_status(self) -> str:
        """Get git status.

        Returns:
            Git status output
        """
        result = self._run_git_command(["status", "--short"], check=False)
        return result.stdout if result.stdout else ""

    def get_current_commit(self) -> str:
        """Get current commit hash.

        Returns:
            Current commit hash (short form)
        """
        result = self._run_git_command(["rev-parse", "--short", "HEAD"], check=False)
        return result.stdout.strip() if result.stdout else ""

    def get_remote_url(self) -> str:
        """Get remote repository URL.

        Returns:
            Remote URL or empty string if not configured
        """
        result = self._run_git_command(
            ["config", "--get", "remote.origin.url"],
            check=False,
        )
        return result.stdout.strip() if result.stdout else ""

    def check_repo_exists(self) -> bool:
        """Check if repository directory exists and is a git repository.

        Returns:
            True if repository exists, False otherwise
        """
        git_dir = self.repo_dir / ".git"
        return git_dir.exists()

    def get_branch_name(self) -> str:
        """Get current branch name.

        Returns:
            Current branch name
        """
        result = self._run_git_command(
            ["rev-parse", "--abbrev-ref", "HEAD"],
            check=False,
        )
        return result.stdout.strip() if result.stdout else ""

    def get_status_info(self) -> dict[str, str]:
        """Get current Git status information.

        Returns structured data instead of printing. Replaces the old print_status method.

        Returns:
            Dictionary containing Git status information
        """
        status = self.get_status()
        return {
            "repository": self.repo_url,
            "local_path": str(self.repo_dir),
            "branch": self.get_branch_name() or self.branch,
            "commit": self.get_current_commit() or "N/A",
            "changes": status if status else "None",
        }

    def print_status(self) -> None:
        """Print current Git status.

        Deprecated: Use get_status_info() instead for library usage.
        This method is kept for backward compatibility but will be removed in a future version.
        """
        info = self.get_status_info()
        print("\nGit Status:")
        print(f"  Repository: {info['repository']}")
        print(f"  Local Path: {info['local_path']}")
        print(f"  Branch: {info['branch']}")
        print(f"  Commit: {info['commit']}")
        print(f"  Changes: {info['changes']}")


# Made with Bob
