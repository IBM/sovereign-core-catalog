"""CLI entry point for broker-cli command.

This module provides the main entry point for the broker-cli command-line tool.
It sets up the Click command group and registers all available commands.

Usage:
    python -m cli [COMMAND] [OPTIONS]

    Or after installation:
    broker-cli [COMMAND] [OPTIONS]

Command Groups:
    config       - Manage configuration profiles
    catalog      - Discover available services
    instance     - Manage service instances

Examples:
    broker-cli config init
    broker-cli catalog list
    broker-cli instance provision --service mysql --instance dev-001 --dry-run
    broker-cli instance list
"""

import json
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from broker.cli import __version__
from broker.cli.commands import clean, deprovision, get, list_cmd, provision, update


console = Console()


def find_default_config() -> str | None:
    """Find default config file in standard locations.

    Search order:
    1. ./config.gitops.json (current directory)
    2. ~/.broker-cli/config (user config directory)

    Returns:
        Path to config file or None if not found
    """
    # Check current directory first (project-specific config)
    local_config = Path("config.gitops.json")
    if local_config.exists():
        return str(local_config)

    # Check user config directory
    user_config = Path.home() / ".broker-cli" / "config"
    if user_config.exists():
        return str(user_config)

    return None


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(version=__version__, prog_name="broker-cli")
@click.option(
    "--config",
    "-c",
    type=click.Path(dir_okay=False, readable=True),
    help="Path to configuration file",
    default=None,
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Enable verbose output (DEBUG level logging)",
)
@click.option(
    "--quiet",
    "-q",
    is_flag=True,
    help="Suppress all output except errors",
)
@click.pass_context
def cli(ctx: click.Context, config: str | None, verbose: bool, quiet: bool) -> None:
    """BYOP Service Provisioning CLI.

    A standalone command-line tool for testing and managing service instance
    provisioning without running the full broker server.

    Features:

    \b
    • Dry-run mode for local testing
    • Direct provisioning with GitOps storage
    • Instance management (list, get, clean)
    • Rich terminal output with colors and progress
    • Configuration file support for GitOps integration
    • User config directory (~/.broker-cli/)
    • Multiple profile support

    Configuration Search Order:
    1. --config /path/to/config.json (explicit)
    2. ./config.gitops.json (project-specific)
    3. ~/.broker-cli/config (user default)

    Use --help with any command for detailed information.
    """
    # Store global options in context
    ctx.ensure_object(dict)

    # Resolve config path if not explicitly provided
    if config is None:
        config = find_default_config()
    elif config and not Path(config).exists():
        console.print(f"[red]Error: Config file not found: {config}[/red]")
        sys.exit(1)

    ctx.obj["config"] = config
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet

    # Configure logging based on verbosity
    # Default: ERROR (only show critical errors, suppress INFO/WARNING)
    # Verbose: INFO (show all messages including INFO/WARNING/ERROR)
    # Quiet: CRITICAL (only show critical errors)
    import os

    from broker.logging_config import configure_logging

    if verbose:
        configure_logging(level="INFO")
    elif quiet:
        configure_logging(level="CRITICAL")
    else:
        configure_logging(level="ERROR")

    # Disable ArgoCD Application file creation by default for CLI
    # App-of-Apps is managed externally by argocd-configure-repo.sh script
    # Users can override by setting CREATE_ARGOCD_APP=true in environment
    if "CREATE_ARGOCD_APP" not in os.environ:
        os.environ["CREATE_ARGOCD_APP"] = "false"


# Configuration management command group
@cli.group()
def config() -> None:
    """Manage configuration profiles.

    Commands for managing configuration files and profiles in ~/.broker-cli/.

    Examples:
        broker-cli config init
        broker-cli config list
        broker-cli config use prod
    """
    pass


@config.command()
@click.option(
    "--profile",
    "-p",
    default="default",
    help="Profile name (default: default)",
)
def init(profile: str) -> None:
    """Initialize user configuration directory.

    Creates ~/.broker-cli/ directory and example config file.

    Examples:
        broker-cli config init
        broker-cli config init --profile k3s
        broker-cli config init --profile prod
    """
    config_dir = Path.home() / ".broker-cli"
    config_dir.mkdir(exist_ok=True)

    config_file = config_dir / f"{profile}.json"

    if config_file.exists():
        console.print(f"[yellow]Config already exists: {config_file}[/yellow]")
        console.print("[dim]Edit it or use a different profile name[/dim]")
        return

    # Create example config
    example_config = {
        "cluster_name": "k3s-cluster-1",
        "gitops": {
            "repo_url": "git@github.com:your-org/gitops-repo.git",
            "branch": "main",
            "git_backend": "remote",
            "git_auth_method": "ssh",
            "ssh_private_key_path": "~/.ssh/gitops_deploy_key",
        },
    }

    with open(config_file, "w") as f:
        json.dump(example_config, f, indent=2)

    console.print(f"[green]✓[/green] Created config: [cyan]{config_file}[/cyan]")

    # Create symlink if this is the first profile
    config_link = config_dir / "config"
    if not config_link.exists():
        config_link.symlink_to(config_file.name)
        console.print("[green]✓[/green] Set as active profile")
        console.print(f"[dim]  {config_link} -> {config_file.name}[/dim]")
    else:
        console.print("\n[dim]To activate this profile:[/dim]")
        console.print(f"  broker-cli config use {profile}")


@config.command(name="list")
def list_profiles() -> None:
    """List available configuration profiles.

    Shows all profiles in ~/.broker-cli/ and indicates the active one.

    Example:
        broker-cli config list
    """
    config_dir = Path.home() / ".broker-cli"

    if not config_dir.exists():
        console.print("[yellow]No config directory found.[/yellow]")
        console.print("[dim]Run 'broker-cli config init' to create one.[/dim]")
        return

    # Find active profile
    config_link = config_dir / "config"
    active_profile = None
    if config_link.is_symlink():
        active_profile = config_link.readlink().name.replace(".json", "")

    # List all profiles
    profile_files = sorted(config_dir.glob("*.json"))

    if not profile_files:
        console.print("[yellow]No profiles found.[/yellow]")
        console.print("[dim]Run 'broker-cli config init' to create one.[/dim]")
        return

    table = Table(title="Configuration Profiles", show_header=True)
    table.add_column("Profile", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Path", style="dim")

    for profile_file in profile_files:
        profile_name = profile_file.stem
        status = "→ active" if profile_name == active_profile else ""
        table.add_row(profile_name, status, str(profile_file))

    console.print(table)

    if active_profile:
        console.print(f"\n[dim]Active profile: {active_profile}[/dim]")
    else:
        console.print("\n[yellow]No active profile set[/yellow]")
        console.print("[dim]Use 'broker-cli config use <profile>' to activate one[/dim]")


@config.command()
@click.argument("profile")
def use(profile: str) -> None:
    """Switch to a different configuration profile.

    Creates a symlink at ~/.broker-cli/config pointing to the specified profile.

    Examples:
        broker-cli config use k3s
        broker-cli config use prod
        broker-cli config use dev
    """
    config_dir = Path.home() / ".broker-cli"
    config_file = config_dir / f"{profile}.json"

    if not config_file.exists():
        console.print(f"[red]Profile not found: {profile}[/red]")

        # Show available profiles
        available = list(config_dir.glob("*.json"))
        if available:
            console.print("\n[dim]Available profiles:[/dim]")
            for p in available:
                console.print(f"  • {p.stem}")
        else:
            console.print(
                "[dim]No profiles found. Run 'broker-cli config init' to create one.[/dim]"
            )
        return

    config_link = config_dir / "config"
    if config_link.exists() or config_link.is_symlink():
        config_link.unlink()

    config_link.symlink_to(config_file.name)
    console.print(f"[green]✓[/green] Switched to profile: [cyan]{profile}[/cyan]")
    console.print(f"[dim]  {config_link} -> {config_file.name}[/dim]")


# Service catalog discovery command group
@cli.group()
def catalog() -> None:
    """Discover available services.

    Commands for discovering and viewing available services from the GitOps repository.

    Examples:
        broker-cli catalog list
        broker-cli catalog show mariadb
    """
    pass


@catalog.command(name="list")
@click.option(
    "--output",
    "-o",
    type=click.Choice(["table", "json", "yaml"], case_sensitive=False),
    default="table",
    help="Output format (default: table)",
)
@click.pass_context
def catalog_list(ctx: click.Context, output: str) -> None:
    """List all available services.

    This command lists all services available for provisioning from the GitOps repository.

    Examples:

    \b
    # List services (table format)
    broker-cli catalog list

    \b
    # List services (JSON format)
    broker-cli catalog list --output json
    """
    from broker.cli.controller import CLIController
    from broker.cli.output import print_error, print_info

    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)
    global_config = ctx.obj.get("config")

    # Create controller
    controller = CLIController(
        dry_run=False,  # Catalog discovery needs GitOps repo
        output_dir=None,
        config_file=Path(global_config) if global_config else None,
        verbose=verbose,
        quiet=quiet,
    )

    # Execute catalog list
    try:
        result = controller.catalog_list()

        if result["success"]:
            services = result["services"]
            count = result["count"]

            if count == 0:
                if not quiet:
                    print_info("No services found in GitOps repository")
                return

            if output == "json":
                console.print_json(data=services)
            elif output == "yaml":
                import yaml

                console.print(yaml.dump(services, default_flow_style=False))
            else:  # table format
                from rich.table import Table

                table = Table(title=f"Available Services ({count} total)")
                table.add_column("Service", style="cyan")
                table.add_column("Name", style="green")
                table.add_column("Description", style="dim")
                table.add_column("Plans", style="yellow")

                for service in services:
                    service_id = service.get("id", "N/A")
                    name = service.get("name", "N/A")
                    description = service.get("description", "")
                    plans = service.get("plans", [])
                    plan_names = ", ".join([p.get("id", "") for p in plans])

                    table.add_row(service_id, name, description, plan_names)

                console.print(table)
        else:
            print_error(f"Catalog list failed: {result.get('error', 'Unknown error')}")
            sys.exit(1)

    except Exception as e:
        print_error(f"Catalog list failed: {e}")
        if verbose:
            console.print_exception()
        sys.exit(1)


@catalog.command(name="show")
@click.argument("service")
@click.option(
    "--output",
    "-o",
    type=click.Choice(["table", "json", "yaml"], case_sensitive=False),
    default="table",
    help="Output format (default: table)",
)
@click.option(
    "--show-schema",
    is_flag=True,
    help="Include parameter schema (provision payload requirements)",
)
@click.option(
    "--show-example",
    is_flag=True,
    help="Include example payload generated from schema",
)
@click.pass_context
def catalog_show(
    ctx: click.Context, service: str, output: str, show_schema: bool, show_example: bool
) -> None:
    """Show details of a specific service.

    This command displays detailed information about a service including all available plans,
    optionally the parameter schema, and/or an example payload.

    Examples:

    \b
    # Show service details (table format)
    broker-cli catalog show mariadb

    \b
    # Show service details with parameter schema
    broker-cli catalog show mariadb --show-schema

    \b
    # Show service details with example payload
    broker-cli catalog show mariadb --show-example

    \b
    # Show service details (JSON format with schema and example)
    broker-cli catalog show mariadb --output json --show-schema --show-example
    """
    from broker.cli.controller import CLIController
    from broker.cli.output import print_error

    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)
    global_config = ctx.obj.get("config")

    # Create controller
    controller = CLIController(
        dry_run=False,  # Catalog discovery needs GitOps repo
        output_dir=None,
        config_file=Path(global_config) if global_config else None,
        verbose=verbose,
        quiet=quiet,
    )

    # Execute catalog show
    try:
        result = controller.catalog_show(
            service_name=service, show_schema=show_schema, show_example=show_example
        )

        if result["success"]:
            service_data = result["service"]
            schema_data = result.get("schema")
            example_data = result.get("example")

            if output == "json":
                output_data = {"service": service_data}
                if show_schema and schema_data:
                    output_data["schema"] = schema_data
                if show_example and example_data:
                    output_data["example"] = example_data
                console.print_json(data=output_data)
            elif output == "yaml":
                import yaml

                output_data = {"service": service_data}
                if show_schema and schema_data:
                    output_data["schema"] = schema_data
                if show_example and example_data:
                    output_data["example"] = example_data
                console.print(yaml.dump(output_data, default_flow_style=False))
            else:  # table format
                from rich.panel import Panel
                from rich.syntax import Syntax
                from rich.table import Table

                # Service info panel
                info_text = f"[cyan]Name:[/cyan] {service_data.get('name', 'N/A')}\n"
                info_text += f"[cyan]ID:[/cyan] {service_data.get('id', 'N/A')}\n"
                info_text += f"[cyan]Description:[/cyan] {service_data.get('description', 'N/A')}\n"
                info_text += f"[cyan]Bindable:[/cyan] {service_data.get('bindable', False)}"

                console.print(Panel(info_text, title="Service Details", border_style="green"))

                # Plans table
                plans = service_data.get("plans", [])
                if plans:
                    console.print()  # Blank line
                    table = Table(title="Available Plans")
                    table.add_column("Plan ID", style="cyan")
                    table.add_column("Name", style="green")
                    table.add_column("Description", style="dim")

                    for plan in plans:
                        table.add_row(
                            plan.get("id", "N/A"),
                            plan.get("name", "N/A"),
                            plan.get("description", ""),
                        )

                    console.print(table)

                # Schema panel (if requested)
                if show_schema and schema_data:
                    console.print()  # Blank line
                    if "error" in schema_data:
                        console.print(
                            Panel(
                                f"[yellow]{schema_data['error']}[/yellow]",
                                title="Parameter Schema",
                                border_style="yellow",
                            )
                        )
                    else:
                        import json

                        schema_json = json.dumps(schema_data, indent=2)
                        syntax = Syntax(schema_json, "json", theme="monokai", line_numbers=True)
                        console.print(
                            Panel(
                                syntax,
                                title="Parameter Schema (Provision Payload Requirements)",
                                border_style="blue",
                            )
                        )

                # Example panel (if requested)
                if show_example and example_data:
                    console.print()  # Blank line
                    import json

                    example_json = json.dumps(example_data, indent=2)
                    syntax = Syntax(example_json, "json", theme="monokai", line_numbers=True)
                    console.print(
                        Panel(syntax, title="Example Provision Payload", border_style="green")
                    )
        else:
            print_error(f"Catalog show failed: {result.get('error', 'Unknown error')}")
            sys.exit(1)

    except Exception as e:
        print_error(f"Catalog show failed: {e}")
        if verbose:
            console.print_exception()
        sys.exit(1)


# Service instance management command group
@cli.group()
def instance() -> None:
    """Manage service instances.

    Commands for provisioning, updating, and managing service instances.

    Examples:
        broker-cli instance provision --service mysql --instance dev-001 --dry-run
        broker-cli instance list
        broker-cli instance get dev-001
    """
    pass


# Add instance commands to the instance group
instance.add_command(provision)
instance.add_command(deprovision)
instance.add_command(update)
instance.add_command(get)
# Note: list_cmd is named 'list' in the CLI
instance.add_command(list_cmd, name="list")
instance.add_command(clean)


def main() -> None:
    """Main entry point for the CLI."""
    try:
        cli(obj={})
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled by user[/yellow]")
        sys.exit(130)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()


# Made with Bob
