"""Simple configuration module using environment variables."""

import os


class Config:
    """Configuration class with sensible defaults."""

    def __init__(self) -> None:
        # Server configuration
        self.port = int(os.getenv("PORT", "7329"))
        # Bind to all interfaces for container deployment - safe in Kubernetes with network policies
        self.host = os.getenv("HOST", "0.0.0.0")  # nosec B104

        # Storage configuration
        self.storage_dir = os.getenv("STORAGE_DIR", "./data")

        # Broker default dashboard URL template.
        # Prefer the canonical "{instance_id}" placeholder; legacy "<instance-id>" is also supported.
        self.dashboard_url = os.getenv("DASHBOARD_URL", "https://example.com")

        # Async operations support
        self.async_enabled = os.getenv("ASYNC_ENABLED", "true").lower() == "true"

        # TLS/mTLS configuration
        self.tls_enabled = os.getenv("TLS_ENABLED", "false").lower() == "true"
        self.server_cert_path = os.getenv("SERVER_CERT_PATH", "./certs/server.crt")
        self.server_key_path = os.getenv("SERVER_KEY_PATH", "./certs/server.key")

        # mTLS - client certificate verification
        self.mtls_enabled = os.getenv("MTLS_ENABLED", "false").lower() == "true"
        self.client_ca_path = os.getenv("CLIENT_CA_PATH", "./certs/client-ca.crt")

        # Logging configuration
        self.log_response_payloads = os.getenv("LOG_RESPONSE_PAYLOADS", "false").lower() == "true"

        # ArgoCD application file creation
        # When true, creates ArgoCD Application YAML in argocd-apps/ directory during provisioning
        # When false, skips ArgoCD Application file creation (useful for external ArgoCD management)
        self.create_argocd_app = os.getenv("CREATE_ARGOCD_APP", "true").lower() == "true"

        # Debug mode - retain failed provisioning files for inspection
        # When true, skips cleanup of instance files when provisioning fails
        # Useful for debugging service definitions and troubleshooting provisioning issues
        # Default: false (cleanup enabled for production)
        self.debug_retain_failed_files = (
            os.getenv("DEBUG_RETAIN_FAILED_FILES", "false").lower() == "true"
        )

    def __repr__(self) -> str:
        return (
            f"Config(port={self.port}, storage_dir={self.storage_dir}, "
            f"async_enabled={self.async_enabled}, tls_enabled={self.tls_enabled}, "
            f"mtls_enabled={self.mtls_enabled}, log_response_payloads={self.log_response_payloads}, "
            f"create_argocd_app={self.create_argocd_app}, "
            f"debug_retain_failed_files={self.debug_retain_failed_files})"
        )


# Global config instance
config = Config()
