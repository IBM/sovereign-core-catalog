"""Git repository configuration for GitOps orchestrator.

GitHub Enterprise integration only.

Environment Variables:
    GITOPS_REPO_URL: GitHub Enterprise repository URL (required)
    GITOPS_BRANCH: Git branch name (default: 'main')

Configuration Methods:
    1. Environment variables (highest priority)
    2. .env file in broker/ directory
    3. .env file in broker/gitops/ directory

Example:
    export GITOPS_REPO_URL=git@github.com:org/gitops-repo.git
    export GITOPS_BRANCH=main

    # Or use .env file
    echo "GITOPS_REPO_URL=git@github.com:org/repo.git" > broker/.env
"""

import os
from pathlib import Path


def load_env_file(env_path: Path) -> None:
    """Load environment variables from .env file.

    Args:
        env_path: Path to .env file

    Example:
        >>> load_env_file(Path('.env'))
    """
    if not env_path.exists():
        return

    with open(env_path) as f:
        for line in f:
            line = line.strip()
            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue

            # Parse KEY=VALUE
            if "=" in line:
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip()

                # Remove quotes if present
                if (
                    value.startswith('"')
                    and value.endswith('"')
                    or value.startswith("'")
                    and value.endswith("'")
                ):
                    value = value[1:-1]

                # Only set if not already in environment
                if key not in os.environ:
                    os.environ[key] = value


# Load .env files (if they exist)
# Priority: broker/gitops/.env > broker/.env
_base_dir = Path(__file__).parent.parent
_broker_env = _base_dir / ".env"
_orchestrator_env = Path(__file__).parent / ".env"

# Load broker/.env first (lower priority)
load_env_file(_broker_env)
# Load broker/gitops/.env second (higher priority)
load_env_file(_orchestrator_env)


class GitConfig:
    """Git repository configuration for GitHub Enterprise."""

    # Working directory for Git operations
    # Use /app/data for container deployments (writable volume)
    # Fall back to source directory for local development
    WORK_DIR: Path = Path(
        os.getenv("GITOPS_WORK_DIR", str(Path(__file__).parent.parent / ".gitops-work"))
    )

    @classmethod
    def get_repo_url(cls) -> str:
        """Get repository URL.

        Reads from GITOPS_REPO_URL environment variable.

        Returns:
            GitHub Enterprise repository URL

        Example:
            >>> url = GitConfig.get_repo_url()
            >>> url.startswith('git@') or url.startswith('ssh://')
            True
        """
        return os.getenv("GITOPS_REPO_URL", "")

    @classmethod
    def get_repo_dir(cls) -> Path:
        """Get local working directory for Git operations.

        Returns:
            Local directory path for cloned repository

        Example:
            >>> repo_dir = GitConfig.get_repo_dir()
            >>> repo_dir.name
            '.gitops-work'
        """
        return cls.WORK_DIR

    @classmethod
    def get_branch(cls) -> str:
        """Get Git branch name.

        Reads from GITOPS_BRANCH environment variable.

        Returns:
            Branch name (default: 'main')

        Example:
            >>> branch = GitConfig.get_branch()
            >>> branch
            'main'
        """
        return os.getenv("GITOPS_BRANCH", "main")

    @classmethod
    def validate_config(cls) -> None:
        """Validate configuration.

        Raises:
            ValueError: If configuration is invalid

        Example:
            >>> GitConfig.validate_config()  # doctest: +SKIP
        """
        repo_url = cls.get_repo_url()
        if not repo_url:
            raise ValueError(
                "GITOPS_REPO_URL must be set. "
                "Example: export GITOPS_REPO_URL=git@github.com:org/repo.git"
            )

        # Validate URL format
        if not (
            repo_url.startswith("git@")
            or repo_url.startswith("https://")
            or repo_url.startswith("ssh://")
        ):
            raise ValueError(
                f"Invalid GITOPS_REPO_URL format: {repo_url}\n"
                "Must start with 'git@' or 'ssh://' (SSH) or 'https://' (HTTPS)"
            )

    @classmethod
    def get_config_summary(cls) -> dict[str, str]:
        """Get configuration summary for display.

        Returns:
            Configuration summary dictionary

        Example:
            >>> config = GitConfig.get_config_summary()
            >>> 'repo_url' in config
            True
        """
        return {
            "repo_url": cls.get_repo_url(),
            "repo_dir": str(cls.get_repo_dir()),
            "branch": cls.get_branch(),
        }

    @classmethod
    def print_config(cls) -> None:
        """Print current configuration.

        Deprecated: Use get_config_summary() instead for library usage.
        This method is kept for backward compatibility but will be removed in a future version.

        Example:
            >>> GitConfig.print_config()  # doctest: +SKIP
            Git Configuration:
              Repository URL: git@github.com:org/repo.git
              Working Directory: /path/to/.gitops-work
              Branch: main
        """
        config = cls.get_config_summary()
        print("Git Configuration:")
        print(f"  Repository URL: {config['repo_url']}")
        print(f"  Working Directory: {config['repo_dir']}")
        print(f"  Branch: {config['branch']}")


# Made with Bob
