"""
Simple structured logging to stderr
"""

import json
import sys
from datetime import datetime, timezone
from typing import Any


def _log(level: str, message: str, **kwargs: Any) -> None:
    """Internal logging function."""
    timestamp = datetime.now(timezone.utc).isoformat()
    log_data: dict[str, Any] = {"timestamp": timestamp, "level": level, "message": message}
    log_data.update(kwargs)
    print(json.dumps(log_data), file=sys.stderr, flush=True)


def log_info(message: str, **kwargs: Any) -> None:
    """Log info level message to stderr."""
    _log("INFO", message, **kwargs)


def log_error(message: str, **kwargs: Any) -> None:
    """Log error level message to stderr."""
    _log("ERROR", message, **kwargs)


def log_warning(message: str, **kwargs: Any) -> None:
    """Log warning level message to stderr."""
    _log("WARNING", message, **kwargs)


def log_debug(message: str, **kwargs: Any) -> None:
    """Log debug level message to stderr."""
    _log("DEBUG", message, **kwargs)
