"""Service Discovery Module.

This module provides functionality to discover available service types from the GitOps repository.
It eliminates the need for hardcoded service type lists by dynamically scanning the repository structure.

The module looks for service directories in the GitOps repository's `services/` directory.
Each service must have a `latest/catalog/catalog.yaml` file to be considered valid.

Example Repository Structure:
    services/
    ├── mysql/
    │   └── latest/
    │       ├── catalog/
    │       │   └── catalog.yaml
    │       ├── template/
    │       └── manifests/
    ├── mariadb/
    │   └── latest/
    │       ├── catalog/
    │       │   └── catalog.yaml
    │       ├── template/
    │       └── manifests/
    └── postgres/
        └── latest/
            ├── catalog/
            │   └── catalog.yaml
            ├── template/
            └── manifests/

Usage:
    from broker.gitops.service_discovery import discover_available_services
    from broker.gitops.git_config import GitConfig

    repo_dir = GitConfig.get_repo_dir()
    services = discover_available_services(repo_dir)
    print(f"Available services: {services}")
    # Output: ['mariadb', 'mysql', 'postgres']
"""

import logging
from pathlib import Path


logger = logging.getLogger(__name__)


def discover_available_services(repo_dir: Path) -> list[str]:
    """Discover available service types from GitOps repository.

    Scans the services/ directory in the GitOps repository and returns a list
    of service type names. A service is considered valid if it has a latest/catalog/catalog.yaml file.

    Args:
        repo_dir: Path to the GitOps repository root directory

    Returns:
        Sorted list of available service type names (e.g., ['mariadb', 'mysql', 'postgres'])
        Returns empty list if services directory doesn't exist or contains no valid services

    Example:
        >>> from pathlib import Path
        >>> repo_dir = Path("/path/to/gitops-repo")
        >>> services = discover_available_services(repo_dir)
        >>> print(services)
        ['mariadb', 'mysql', 'postgres']

        >>> # Check if a service type is available
        >>> if 'mysql' in services:
        ...     print("MySQL is available")
    """
    services_dir = repo_dir / "services"

    if not services_dir.exists():
        logger.warning(f"Services directory not found: {services_dir}")
        return []

    if not services_dir.is_dir():
        logger.warning(f"Services path exists but is not a directory: {services_dir}")
        return []

    available_services: list[str] = []

    try:
        for item in services_dir.iterdir():
            # Skip non-directories
            if not item.is_dir():
                logger.debug(f"Skipping non-directory: {item.name}")
                continue

            # Skip hidden directories (starting with .)
            if item.name.startswith("."):
                logger.debug(f"Skipping hidden directory: {item.name}")
                continue

            # Check if latest/catalog/catalog.yaml exists
            catalog_yaml = item / "latest" / "catalog" / "catalog.yaml"
            if catalog_yaml.exists() and catalog_yaml.is_file():
                available_services.append(item.name)
                logger.debug(f"Found service: {item.name}")
            else:
                logger.debug(f"Skipping directory without latest/catalog/catalog.yaml: {item.name}")

    except PermissionError as e:
        logger.error(f"Permission denied accessing services directory: {e}")
        return []
    except Exception as e:
        logger.error(f"Error discovering services: {e}")
        return []

    # Return sorted list for consistent ordering
    return sorted(available_services)


def is_service_available(repo_dir: Path, service_type: str) -> bool:
    """Check if a specific service type is available.

    Args:
        repo_dir: Path to the GitOps repository root directory
        service_type: Service type name to check (e.g., 'mysql', 'postgres')

    Returns:
        True if the service type is available, False otherwise

    Example:
        >>> from pathlib import Path
        >>> repo_dir = Path("/path/to/gitops-repo")
        >>> is_service_available(repo_dir, 'mysql')
        True
        >>> is_service_available(repo_dir, 'redis')
        False
    """
    service_dir = repo_dir / "services" / service_type
    catalog_yaml = service_dir / "latest" / "catalog" / "catalog.yaml"

    return (
        service_dir.exists()
        and service_dir.is_dir()
        and catalog_yaml.exists()
        and catalog_yaml.is_file()
    )


def get_service_directory(repo_dir: Path, service_type: str) -> Path | None:
    """Get the directory path for a specific service type.

    Args:
        repo_dir: Path to the GitOps repository root directory
        service_type: Service type name (e.g., 'mysql', 'postgres')

    Returns:
        Path to the service directory if it exists and is valid, None otherwise

    Example:
        >>> from pathlib import Path
        >>> repo_dir = Path("/path/to/gitops-repo")
        >>> service_dir = get_service_directory(repo_dir, 'mysql')
        >>> if service_dir:
        ...     print(f"MySQL service directory: {service_dir}")
    """
    if not is_service_available(repo_dir, service_type):
        return None

    return repo_dir / "services" / service_type


def validate_service_type(repo_dir: Path, service_type: str) -> tuple[bool, str]:
    """Validate a service type and provide helpful error messages.

    Args:
        repo_dir: Path to the GitOps repository root directory
        service_type: Service type name to validate

    Returns:
        Tuple of (is_valid, error_message)
        - is_valid: True if service type is valid, False otherwise
        - error_message: Empty string if valid, descriptive error message if invalid

    Example:
        >>> from pathlib import Path
        >>> repo_dir = Path("/path/to/gitops-repo")
        >>> is_valid, error = validate_service_type(repo_dir, 'mysql')
        >>> if not is_valid:
        ...     print(f"Error: {error}")
        >>> else:
        ...     print("Service type is valid")
    """
    if not service_type:
        return False, "Service type cannot be empty"

    # Check if service is available
    if is_service_available(repo_dir, service_type):
        return True, ""

    # Provide helpful error message
    available_services = discover_available_services(repo_dir)

    if not available_services:
        return False, (
            f"Service type '{service_type}' not found. "
            f"No services are available in the repository. "
            f"Please ensure services are properly configured in {repo_dir / 'services'}"
        )

    return False, (
        f"Service type '{service_type}' not found. "
        f"Available services: {', '.join(available_services)}"
    )


# Made with Bob
