"""
Dynamic service catalog discovery from GitOps repository.
"""

from pathlib import Path
from typing import Any

from broker.logging_config import get_logger


logger = get_logger(__name__)


DASHBOARD_URL_TEMPLATE_KEY = "dashboard_url_template"
INSTANCE_ID_PLACEHOLDERS = ("{instance_id}", "<instance-id>")


def discover_services(gitops_repo_dir: str | None = None) -> dict[str, Any]:
    """
    Discover available services from the GitOps repository services directory.

    Args:
        gitops_repo_dir: Path to GitOps repository working directory.
            If None, uses git_config.GitConfig.get_repo_dir().

    Returns:
        Dictionary with 'services' key containing list of discovered services.
    """
    from broker.gitops.git_config import GitConfig
    from broker.gitops.git_operations import GitOperations

    services: list[dict[str, Any]] = []

    # Always use GitConfig to get repo directory for consistency
    repo_dir = GitConfig.get_repo_dir() if gitops_repo_dir is None else Path(gitops_repo_dir)

    # Always pull latest changes to ensure catalog is up-to-date
    # This matches the behavior of TemplateLoader's git-aware cache invalidation
    try:
        logger.info("Ensuring GitOps repository is cloned and up-to-date")
        git_ops = GitOperations()
        git_ops.ensure_repo_cloned()
        git_ops.pull_latest()
        logger.info("Successfully synced GitOps repository")
    except Exception as sync_error:
        logger.error(
            "Failed to sync GitOps repository",
            extra={"error": str(sync_error)},
        )

    services_dir = repo_dir / "services"

    if not services_dir.exists():
        logger.error(
            "Services directory not found in GitOps repository",
            extra={"path": str(services_dir)},
        )
        return {"services": []}

    logger.info("Discovering services from GitOps repo", extra={"services_dir": str(services_dir)})

    for service_dir in services_dir.iterdir():
        if not service_dir.is_dir():
            continue

        service_name = service_dir.name
        logger.info("Found service in GitOps repo", extra={"service": service_name})

        service = _build_service_definition(service_name, service_dir)
        if service is not None:
            services.append(service)

    logger.info("Service discovery complete", extra={"service_count": len(services)})
    return {"services": services}


def _build_service_definition(service_name: str, service_dir: Path) -> dict[str, Any] | None:
    """
    Build a service definition from GitOps-discovered service content.

    Args:
        service_name: Name of the service directory.
        service_dir: Path to the service directory in the GitOps repository.

    Returns:
        Service definition dictionary, or None if service config is invalid.
    """
    # Look for catalog/catalog.yaml in latest version (version-specific structure)
    catalog_config_path = service_dir / "latest" / "catalog" / "catalog.yaml"
    service_config = _parse_service_yaml(catalog_config_path)

    if not service_config:
        logger.error(
            "Skipping service with missing or invalid catalog/catalog.yaml",
            extra={"service": service_name, "path": str(catalog_config_path)},
        )
        return None

    plans = _build_service_plans(service_name, service_config)
    if not plans:
        logger.error(
            "Skipping service with no defined plans",
            extra={"service": service_name, "path": str(catalog_config_path)},
        )
        return None

    display_name = service_config.get("display_name") or service_config.get("name") or service_name
    description = service_config.get("description") or f"{service_name.capitalize()} service"
    dashboard_url_template = _validate_dashboard_url_template(
        service_name,
        service_config.get(DASHBOARD_URL_TEMPLATE_KEY),
    )

    service_definition = {
        "id": service_name,
        "name": str(display_name),
        "description": str(description),
        "bindable": False,
        "plans": plans,
    }
    if dashboard_url_template:
        service_definition[DASHBOARD_URL_TEMPLATE_KEY] = dashboard_url_template

    return service_definition


def _build_service_plans(
    service_name: str,
    service_config: dict[str, Any],
) -> list[dict[str, str]]:
    """Build plan metadata strictly from service-defined plans."""
    raw_plans = service_config.get("plans")
    if not isinstance(raw_plans, list):
        return []

    plans: list[dict[str, str]] = []
    for raw_plan in raw_plans:
        if not isinstance(raw_plan, dict):
            continue

        plan_id = raw_plan.get("id")
        if not isinstance(plan_id, str) or not plan_id:
            continue

        plan_name = raw_plan.get("name")
        if not isinstance(plan_name, str) or not plan_name:
            plan_name = plan_id

        description = raw_plan.get("description")
        if not isinstance(description, str) or not description:
            description = f"{service_name.capitalize()} plan {plan_id}"

        plans.append(
            {
                "id": plan_id,
                "name": plan_name,
                "description": description,
            }
        )

    return plans


def _validate_dashboard_url_template(
    service_name: str,
    dashboard_url_template: Any,
) -> str | None:
    """Validate optional dashboard URL template from catalog.yaml."""
    if dashboard_url_template is None:
        return None

    if not isinstance(dashboard_url_template, str) or not dashboard_url_template:
        logger.error(
            "Invalid dashboard_url_template type, must be non-empty string",
            extra={"service": service_name, "value_type": type(dashboard_url_template).__name__},
        )
        return None

    if not dashboard_url_template.startswith(("http://", "https://")):
        logger.error(
            "Invalid dashboard_url_template scheme",
            extra={"service": service_name, "template": dashboard_url_template},
        )
        return None

    if not any(placeholder in dashboard_url_template for placeholder in INSTANCE_ID_PLACEHOLDERS):
        logger.error(
            "Invalid dashboard_url_template, missing instance identifier placeholder",
            extra={
                "service": service_name,
                "template": dashboard_url_template,
                "supported_placeholders": list(INSTANCE_ID_PLACEHOLDERS),
            },
        )
        return None

    if "<instance-id>" in dashboard_url_template:
        canonical_template = dashboard_url_template.replace("<instance-id>", "{instance_id}")
        logger.info(
            "Normalizing legacy dashboard_url_template placeholder",
            extra={
                "service": service_name,
                "template": dashboard_url_template,
                "normalized_template": canonical_template,
            },
        )
        return canonical_template

    return dashboard_url_template


def _parse_service_yaml(catalog_config_path: Path) -> dict[str, Any]:
    """Parse catalog.yaml using YAML for service metadata and plans."""
    if not catalog_config_path.exists():
        return {}

    try:
        import yaml
    except ImportError:
        logger.error(
            "PyYAML is required to parse catalog.yaml", extra={"path": str(catalog_config_path)}
        )
        return {}

    with open(catalog_config_path, encoding="utf-8") as catalog_file:
        parsed = yaml.safe_load(catalog_file)

    if not isinstance(parsed, dict):
        return {}

    return parsed


# Made with Bob
