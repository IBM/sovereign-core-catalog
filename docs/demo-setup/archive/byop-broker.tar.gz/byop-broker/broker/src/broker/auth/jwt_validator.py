"""JWT token validation using JWKS."""

import logging
import time
from typing import Any

import jwt
import requests

from broker.auth.config import AuthConfig
from broker.auth.exceptions import (
    InvalidClaimError,
    InvalidSignatureError,
    InvalidTokenError,
    JWKSError,
    MissingClaimError,
    TokenExpiredError,
)


logger = logging.getLogger(__name__)


class JWKSClient:
    """Client for fetching and caching JWKS from provider.

    This client fetches JSON Web Key Sets from an OAuth 2.0/OIDC provider
    and caches them for efficient token validation.
    """

    def __init__(
        self, jwks_url: str, cache_ttl: int = 3600, verify_ssl: bool = True, ca_cert_path: str = ""
    ) -> None:
        """Initialize JWKS client.

        Args:
            jwks_url: URL of the JWKS endpoint
            cache_ttl: Cache time-to-live in seconds (default: 3600)
            verify_ssl: Verify SSL certificates (default: True)
            ca_cert_path: Path to CA certificate bundle for verification (optional)
        """
        self.jwks_url = jwks_url
        self.cache_ttl = cache_ttl
        self.verify_ssl = verify_ssl
        self.ca_cert_path = ca_cert_path
        self._jwks_cache: dict[str, Any] | None = None
        self._cache_timestamp: float = 0.0

        # Disable SSL warnings when verification is disabled
        # (Warning already logged during config loading)
        if not verify_ssl:
            import urllib3

            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        # Don't use PyJWKClient - it doesn't support custom SSL settings easily
        # We'll fetch JWKS manually and use jwt.decode with the keys
        self._pyjwt_client = None

        logger.info(
            "Initialized JWKS client: url=%s, cache_ttl=%d, verify_ssl=%s, ca_cert_path=%s",
            jwks_url,
            cache_ttl,
            verify_ssl,
            ca_cert_path or "system_default",
        )

    def get_signing_key(self, kid: str) -> Any:
        """Get signing key for the given key ID.

        Args:
            kid: Key ID from JWT header

        Returns:
            Signing key for token validation

        Raises:
            JWKSError: If key cannot be fetched or found
        """
        try:
            # Fetch JWKS
            jwks = self.fetch_jwks()

            # Find the key with matching kid
            for key in jwks.get("keys", []):
                if key.get("kid") == kid:
                    # Convert JWK to public key using PyJWT
                    from jwt.algorithms import RSAAlgorithm

                    return RSAAlgorithm.from_jwk(key)

            raise JWKSError(f"Key with kid={kid} not found in JWKS")

        except Exception as e:
            logger.error("Failed to get signing key for kid=%s: %s", kid, e)
            raise JWKSError(f"Failed to get signing key: {e}") from e

    def fetch_jwks(self) -> dict[str, Any]:
        """Fetch JWKS from provider.

        Returns:
            JWKS dictionary

        Raises:
            JWKSError: If JWKS cannot be fetched
        """
        # Check cache
        current_time = time.time()
        if self._jwks_cache is not None and (current_time - self._cache_timestamp) < self.cache_ttl:
            logger.debug("Using cached JWKS")
            return self._jwks_cache

        # Fetch fresh JWKS
        try:
            # Determine verify parameter for requests
            # - If verify_ssl is False, use False (skip verification)
            # - If ca_cert_path is provided, use it (custom CA bundle)
            # - Otherwise, use True (system default CA bundle)
            verify_param: bool | str = self.verify_ssl
            if self.verify_ssl and self.ca_cert_path:
                verify_param = self.ca_cert_path
                logger.info(
                    "Fetching JWKS from %s (verify_ssl=%s, ca_cert=%s)",
                    self.jwks_url,
                    self.verify_ssl,
                    self.ca_cert_path,
                )
            else:
                logger.info("Fetching JWKS from %s (verify_ssl=%s)", self.jwks_url, self.verify_ssl)

            response = requests.get(self.jwks_url, timeout=10, verify=verify_param)
            response.raise_for_status()

            jwks_data = response.json()
            if not isinstance(jwks_data, dict):
                raise JWKSError("Invalid JWKS response: expected JSON object")

            jwks: dict[str, Any] = jwks_data

            # Update cache
            self._jwks_cache = jwks
            self._cache_timestamp = current_time

            logger.info("Successfully fetched and cached JWKS")
            return jwks

        except requests.RequestException as e:
            logger.error("Failed to fetch JWKS: %s", e)
            raise JWKSError(f"Failed to fetch JWKS: {e}") from e
        except ValueError as e:
            logger.error("Invalid JWKS response: %s", e)
            raise JWKSError(f"Invalid JWKS response: {e}") from e

    def refresh_cache(self) -> None:
        """Force refresh of JWKS cache."""
        logger.info("Forcing JWKS cache refresh")
        self._jwks_cache = None
        self._cache_timestamp = 0.0
        self.fetch_jwks()


class JWTValidator:
    """Validates JWT tokens using JWKS.

    This validator checks JWT signatures, expiration, and claims
    according to OAuth 2.0/OIDC standards.
    """

    def __init__(self, config: AuthConfig) -> None:
        """Initialize JWT validator.

        Args:
            config: Authentication configuration
        """
        self.config = config
        self.jwks_client = JWKSClient(
            config.jwks_url, config.jwks_cache_ttl, config.verify_ssl, config.ca_cert_path
        )

        logger.info(
            "Initialized JWT validator: issuer=%s, audience=%s, verify_ssl=%s, ca_cert_path=%s",
            config.issuer,
            config.audience,
            config.verify_ssl,
            config.ca_cert_path or "system_default",
        )

    def validate_token(self, token: str) -> dict[str, Any]:
        """Validate JWT token and return decoded payload.

        Args:
            token: JWT token string

        Returns:
            Decoded token payload

        Raises:
            InvalidTokenError: If token is invalid
            TokenExpiredError: If token has expired
            InvalidSignatureError: If signature validation fails
            MissingClaimError: If required claim is missing
            InvalidClaimError: If claim value is invalid
        """
        try:
            # Build validation options based on configuration
            # Make issuer and audience optional for easier debugging
            options = {
                "verify_signature": True,
                "verify_exp": True,
                "verify_nbf": True,
                "verify_iat": True,
                "verify_aud": bool(self.config.audience),  # Only verify if configured
                "verify_iss": bool(self.config.issuer),  # Only verify if configured
                "require": ["exp"],  # Only require exp, not iss/aud
            }

            # Build decode kwargs
            decode_kwargs: dict[str, Any] = {
                "algorithms": self.config.algorithms,
                "options": options,
            }

            # Only add issuer/audience if configured
            if self.config.issuer:
                decode_kwargs["issuer"] = self.config.issuer
            if self.config.audience:
                decode_kwargs["audience"] = self.config.audience

            # Get the kid from token header
            unverified_header = jwt.get_unverified_header(token)
            kid = unverified_header.get("kid")
            if not kid:
                raise InvalidTokenError("Token header missing 'kid' field")

            # Get signing key from JWKS
            signing_key = self.jwks_client.get_signing_key(kid)

            # Decode and validate token
            payload = jwt.decode(
                token,
                signing_key,
                **decode_kwargs,
            )

            # Log token claims for debugging (without sensitive data)
            logger.info(
                "JWT token validated successfully - Claims: iss=%s, aud=%s, sub=%s, exp=%s",
                payload.get("iss", "NOT_SET"),
                payload.get("aud", "NOT_SET"),
                payload.get("sub", "NOT_SET"),
                payload.get("exp", "NOT_SET"),
            )

            logger.debug("Successfully validated JWT token")
            return payload

        except jwt.ExpiredSignatureError as e:
            logger.warning("Token has expired: %s", e)
            raise TokenExpiredError("Token has expired") from e

        except jwt.InvalidSignatureError as e:
            logger.warning("Invalid token signature: %s", e)
            raise InvalidSignatureError("Invalid token signature") from e

        except jwt.MissingRequiredClaimError as e:
            logger.warning("Missing required claim: %s", e)
            raise MissingClaimError(f"Missing required claim: {e}") from e

        except jwt.InvalidIssuerError as e:
            # Decode token to get actual issuer for better error message
            try:
                unverified_payload = jwt.decode(token, options={"verify_signature": False})
                actual_issuer = unverified_payload.get("iss", "NOT_SET")
            except Exception:
                actual_issuer = "UNKNOWN"

            logger.warning(
                "Invalid issuer - Expected: %s, Actual: %s, Error: %s",
                self.config.issuer,
                actual_issuer,
                e,
            )
            raise InvalidClaimError(
                f"Invalid issuer - Expected: {self.config.issuer}, Actual: {actual_issuer}"
            ) from e

        except jwt.InvalidAudienceError as e:
            # Decode token to get actual audience for better error message
            try:
                unverified_payload = jwt.decode(token, options={"verify_signature": False})
                actual_audience = unverified_payload.get("aud", "NOT_SET")
            except Exception:
                actual_audience = "UNKNOWN"

            logger.warning(
                "Invalid audience - Expected: %s, Actual: %s, Error: %s",
                self.config.audience,
                actual_audience,
                e,
            )
            raise InvalidClaimError(
                f"Invalid audience - Expected: {self.config.audience}, Actual: {actual_audience}"
            ) from e

        except jwt.InvalidTokenError as e:
            logger.warning("Invalid token: %s", e)
            raise InvalidTokenError(f"Invalid token: {e}") from e

        except Exception as e:
            logger.error("Unexpected error validating token: %s", e)
            raise InvalidTokenError(f"Token validation failed: {e}") from e

    def decode_token(self, token: str) -> dict[str, Any]:
        """Decode JWT token without validation (for debugging).

        WARNING: This method does not validate the token signature or claims.
        Use only for debugging purposes.

        Args:
            token: JWT token string

        Returns:
            Decoded token payload

        Raises:
            InvalidTokenError: If token cannot be decoded
        """
        try:
            payload = jwt.decode(
                token,
                options={"verify_signature": False},
            )
            return payload
        except Exception as e:
            logger.error("Failed to decode token: %s", e)
            raise InvalidTokenError(f"Failed to decode token: {e}") from e

    def verify_claims(self, payload: dict[str, Any]) -> bool:
        """Verify token claims match configuration.

        Args:
            payload: Decoded token payload

        Returns:
            True if claims are valid

        Raises:
            MissingClaimError: If required claim is missing
            InvalidClaimError: If claim value is invalid
        """
        # Check required claims
        required_claims = ["exp", "iss", "aud"]
        for claim in required_claims:
            if claim not in payload:
                raise MissingClaimError(f"Missing required claim: {claim}")

        # Verify issuer
        if payload["iss"] != self.config.issuer:
            raise InvalidClaimError(
                f"Invalid issuer: expected {self.config.issuer}, got {payload['iss']}"
            )

        # Verify audience
        audience = payload["aud"]
        if isinstance(audience, str):
            audience = [audience]
        if self.config.audience not in audience:
            raise InvalidClaimError(
                f"Invalid audience: expected {self.config.audience}, got {audience}"
            )

        return True


# Made with Bob
