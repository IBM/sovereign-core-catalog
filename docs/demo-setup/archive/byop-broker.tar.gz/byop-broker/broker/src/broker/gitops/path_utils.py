"""Utilities for constructing GitOps repository paths.

This module provides centralized path construction logic for instance directories
in the GitOps repository, supporting hierarchical organization by service type.
"""

from pathlib import Path


def get_instance_path(repo_dir: Path, instance_id: str, service_type: str) -> Path:
    """Construct the path to an instance directory in the GitOps repository.

    Creates hierarchical structure: instances/<service_type>/<instance_id>

    Args:
        repo_dir: Root directory of the GitOps repository
        instance_id: Instance identifier (e.g., 'dev-mysql-001')
        service_type: Service type (e.g., 'mysql', 'postgres')

    Returns:
        Path to the instance directory

    Examples:
        >>> repo = Path('/repo')
        >>> get_instance_path(repo, 'dev-mysql-001', 'mysql')
        PosixPath('/repo/instances/mysql/dev-mysql-001')
    """
    return repo_dir / "instances" / service_type / instance_id


def get_argocd_app_path(instance_id: str, service_type: str) -> str:
    """Construct the ArgoCD Application source path for an instance.

    Args:
        instance_id: Instance identifier
        service_type: Service type

    Returns:
        Relative path string for ArgoCD Application spec.source.path

    Examples:
        >>> get_argocd_app_path('dev-mysql-001', 'mysql')
        'instances/mysql/dev-mysql-001'
    """
    return f"instances/{service_type}/{instance_id}"


def get_service_instances_dir(repo_dir: Path, service_type: str) -> Path:
    """Get the directory containing all instances of a service type.

    Args:
        repo_dir: Root directory of the GitOps repository
        service_type: Service type (e.g., 'mysql', 'postgres')

    Returns:
        Path to the service type directory

    Examples:
        >>> repo = Path('/repo')
        >>> get_service_instances_dir(repo, 'mysql')
        PosixPath('/repo/instances/mysql')
    """
    return repo_dir / "instances" / service_type


# Made with Bob
