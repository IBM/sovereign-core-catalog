"""
GitOps CSB Broker - Module entry point

This module allows the broker to be run as: python -m broker
It delegates to the app.py module's __main__ block.
"""

if __name__ == "__main__":
    # Import and run the app module
    pass

# Made with Bob
