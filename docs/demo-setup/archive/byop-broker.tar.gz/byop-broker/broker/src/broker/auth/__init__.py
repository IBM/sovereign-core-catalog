"""Authentication module for JWT Bearer token validation.

This module provides JWT authentication middleware for the GitOps CSB Broker,
including JWKS-based token validation and Flask integration.
"""

from broker.auth.config import AuthConfig, load_auth_config
from broker.auth.exceptions import (
    AuthenticationError,
    InvalidTokenError,
    JWKSError,
    TokenExpiredError,
)
from broker.auth.jwt_validator import JWKSClient, JWTValidator
from broker.auth.middleware import extract_bearer_token, require_jwt_auth


__all__ = [
    "AuthConfig",
    "load_auth_config",
    "AuthenticationError",
    "InvalidTokenError",
    "JWKSError",
    "TokenExpiredError",
    "JWKSClient",
    "JWTValidator",
    "extract_bearer_token",
    "require_jwt_auth",
]

# Made with Bob
