"""Template renderer for service provisioning.

This module provides functionality to render Jinja2 templates with service
provisioning parameters. It handles context building, auto-generation of
passwords and secrets, and template rendering.

Example:
    >>> from pathlib import Path
    >>> renderer = TemplateRenderer(Path("/path/to/gitops/repo"))
    >>> context = {
    ...     "instance_name": "my-instance",
    ...     "namespace": "mysql-my-instance",
    ...     "spec": {"database_name": "myapp", "database_user": "appuser"}
    ... }
    >>> rendered = renderer.render_templates("mysql", context)
    >>> print(rendered["secret.yaml.tmpl"])
"""

import logging
import re
import secrets
import string
from pathlib import Path
from typing import Any

from jinja2 import FileSystemLoader, StrictUndefined, TemplateSyntaxError
from jinja2.sandbox import SandboxedEnvironment

from broker.gitops.template_loader import TemplateLoader, TemplateLoadError


logger = logging.getLogger(__name__)


class RenderError(Exception):
    """Raised when template rendering fails."""

    pass


class TemplateRenderer:
    """Render Jinja2 templates for service provisioning.

    This class handles rendering service templates with provisioning parameters.
    It provides auto-generation of passwords and secrets, and ensures templates
    are rendered in a sandboxed environment for security.

    Attributes:
        template_loader: TemplateLoader instance for loading templates
        jinja_env: Jinja2 sandboxed environment for rendering
    """

    def __init__(self, repo_dir: Path) -> None:
        """Initialize template renderer.

        Args:
            repo_dir: Path to GitOps repository root directory

        Raises:
            TemplateLoadError: If repo_dir doesn't exist or isn't a directory
        """
        self.template_loader = TemplateLoader(repo_dir)

        # Create sandboxed Jinja2 environment for security
        self.jinja_env = SandboxedEnvironment(
            undefined=StrictUndefined,  # Fail on undefined variables
            autoescape=False,  # Don't escape (we're generating YAML, not HTML)
            trim_blocks=True,  # Remove first newline after block
            lstrip_blocks=True,  # Strip leading spaces before blocks
        )

        # Add custom filters for YAML safety
        self.jinja_env.filters["yaml_safe"] = self._yaml_safe_filter

        logger.debug(f"Initialized TemplateRenderer with repo_dir: {repo_dir}")

    def render_templates(
        self,
        service_type: str,
        context: dict[str, Any],
        service_version: str = "v1",
        auto_generate_secrets: bool = True,
    ) -> dict[str, str]:
        """Render all templates for a service.

        Args:
            service_type: Service type name (e.g., "mysql", "postgres")
            context: Template context with system and user variables
            service_version: Service version (default: "v1")
            auto_generate_secrets: Auto-generate missing passwords/secrets (default: True)

        Returns:
            Dictionary mapping template filenames to rendered content

        Raises:
            RenderError: If rendering fails
            TemplateLoadError: If templates cannot be loaded

        Example:
            >>> renderer = TemplateRenderer(Path("/repo"))
            >>> context = {
            ...     "instance_name": "my-instance",
            ...     "namespace": "mysql-my-instance",
            ...     "spec": {"database_name": "myapp"}
            ... }
            >>> rendered = renderer.render_templates("mysql", context)
        """
        # Load templates
        try:
            templates = self.template_loader.load_templates(service_type, service_version)
        except TemplateLoadError as e:
            raise RenderError(f"Failed to load templates: {e}") from e

        # Set up FileSystemLoader for {% include %} support
        # Point to the service version directory so relative paths work
        service_dir = self.template_loader.repo_dir / "services" / service_type / service_version
        if service_dir.exists():
            self.jinja_env.loader = FileSystemLoader(str(service_dir))
            logger.debug(f"Set FileSystemLoader to: {service_dir}")

        # Build complete context with auto-generated values
        complete_context = self._build_context(context, auto_generate_secrets=auto_generate_secrets)

        # Render each template
        rendered: dict[str, str] = {}
        for template_name, template_content in templates.items():
            # Skip schema.json (not a template)
            if template_name == "schema.json":
                continue

            try:
                rendered_content = self._render_template(
                    template_content, complete_context, template_name
                )
                rendered[template_name] = rendered_content
                logger.debug(f"Rendered template: {template_name}")
            except RenderError:
                # Re-raise with context
                raise

        logger.info(f"Rendered {len(rendered)} templates for {service_type}:{service_version}")
        return rendered

    def render_template(
        self,
        service_type: str,
        template_name: str,
        context: dict[str, Any],
        service_version: str = "v1",
        auto_generate_secrets: bool = True,
    ) -> str:
        """Render a specific template.

        Args:
            service_type: Service type name
            template_name: Template filename (e.g., "secret.yaml.tmpl")
            context: Template context
            service_version: Service version (default: "v1")
            auto_generate_secrets: Auto-generate missing passwords/secrets

        Returns:
            Rendered template content

        Raises:
            RenderError: If rendering fails
            TemplateLoadError: If template cannot be loaded

        Example:
            >>> renderer = TemplateRenderer(Path("/repo"))
            >>> context = {"instance_name": "my-instance", "spec": {...}}
            >>> secret = renderer.render_template("mysql", "secret.yaml.tmpl", context)
        """
        # Load template
        try:
            template_content = self.template_loader.get_template(
                service_type, template_name, service_version
            )
        except TemplateLoadError as e:
            raise RenderError(f"Failed to load template: {e}") from e

        # Set up FileSystemLoader for {% include %} support
        service_dir = self.template_loader.repo_dir / "services" / service_type / service_version
        if service_dir.exists():
            self.jinja_env.loader = FileSystemLoader(str(service_dir))
            logger.debug(f"Set FileSystemLoader to: {service_dir}")

        # Build complete context
        complete_context = self._build_context(context, auto_generate_secrets=auto_generate_secrets)

        # Render template
        return self._render_template(template_content, complete_context, template_name)

    def _render_template(
        self, template_content: str, context: dict[str, Any], template_name: str
    ) -> str:
        """Render a template with context.

        Args:
            template_content: Template content string
            context: Template context
            template_name: Template filename (for error messages)

        Returns:
            Rendered content

        Raises:
            RenderError: If rendering fails
        """
        try:
            template = self.jinja_env.from_string(template_content)
            rendered = template.render(**context)
            return rendered
        except TemplateSyntaxError as e:
            raise RenderError(
                f"Template syntax error in {template_name} at line {e.lineno}: {e.message}"
            ) from e
        except Exception as e:
            raise RenderError(f"Failed to render template {template_name}: {e}") from e

    def _build_context(
        self, context: dict[str, Any], auto_generate_secrets: bool = True
    ) -> dict[str, Any]:
        """Build complete template context with auto-generated values.

        Args:
            context: Base context from caller
            auto_generate_secrets: Auto-generate missing passwords/secrets

        Returns:
            Complete context with auto-generated values
        """
        complete_context = context.copy()

        # Auto-generate secrets if enabled and spec exists
        if auto_generate_secrets and "spec" in complete_context:
            spec = complete_context["spec"]

            # Auto-generate common password fields if not provided
            password_fields = [
                "password",
                "root_password",
                "database_password",
                "admin_password",
                "user_password",
            ]

            for field in password_fields:
                if field in spec and not spec[field]:
                    # Field exists but is empty - generate password
                    spec[field] = self.generate_password()
                    logger.debug(f"Auto-generated password for field: {field}")

            complete_context["spec"] = spec

        return complete_context

    @staticmethod
    def _yaml_safe_filter(value: Any) -> str:
        """Jinja2 filter to make values YAML-safe by quoting when necessary.

        This filter ensures that string values containing special YAML characters
        are properly quoted to prevent parsing errors.

        Args:
            value: Value to make YAML-safe

        Returns:
            YAML-safe string representation

        Example:
            >>> TemplateRenderer._yaml_safe_filter("simple")
            'simple'
            >>> TemplateRenderer._yaml_safe_filter("has?special")
            '"has?special"'
            >>> TemplateRenderer._yaml_safe_filter("[starts-with-bracket")
            '"[starts-with-bracket"'
        """
        if value is None:
            return "null"

        # Convert to string
        str_value = str(value)

        # Check if value needs quoting (contains YAML special characters)
        # YAML special chars: : { } [ ] , & * # ? | - < > = ! % @ \
        yaml_special_chars = r"[:\{\}\[\],&*#\?|\-<>=!%@\\]"

        # Also quote if starts with special chars or contains quotes
        needs_quoting = (
            re.search(yaml_special_chars, str_value) is not None
            or str_value.startswith(("!", "&", "*", "-", "?", ":", ">", "|", "[", "{"))
            or '"' in str_value
            or "'" in str_value
        )

        if needs_quoting:
            # Escape any existing double quotes and wrap in double quotes
            escaped = str_value.replace("\\", "\\\\").replace('"', '\\"')
            return f'"{escaped}"'

        return str_value

    @staticmethod
    def generate_password(length: int = 20, include_special: bool = True) -> str:
        """Generate a cryptographically secure random password.

        Args:
            length: Password length (default: 20)
            include_special: Include special characters (default: True)

        Returns:
            Generated password string

        Example:
            >>> password = TemplateRenderer.generate_password(16)
            >>> len(password)
            16
        """
        if length < 8:
            raise ValueError("Password length must be at least 8 characters")

        # Define character sets
        lowercase = string.ascii_lowercase
        uppercase = string.ascii_uppercase
        digits = string.digits
        special = "!@#$%^&*()-_=+[]{}|;:,.<>?"

        # Build character set
        if include_special:
            chars = lowercase + uppercase + digits + special
        else:
            chars = lowercase + uppercase + digits

        # Generate password ensuring at least one of each type
        password_chars = [
            secrets.choice(lowercase),
            secrets.choice(uppercase),
            secrets.choice(digits),
        ]

        if include_special:
            password_chars.append(secrets.choice(special))

        # Fill remaining length with random characters
        remaining_length = length - len(password_chars)
        password_chars.extend(secrets.choice(chars) for _ in range(remaining_length))

        # Shuffle to avoid predictable patterns
        secrets.SystemRandom().shuffle(password_chars)

        return "".join(password_chars)

    @staticmethod
    def generate_secret(length: int = 32) -> str:
        """Generate a cryptographically secure random secret (hex).

        Args:
            length: Secret length in bytes (default: 32)

        Returns:
            Hex-encoded secret string

        Example:
            >>> secret = TemplateRenderer.generate_secret(16)
            >>> len(secret)
            32  # 16 bytes = 32 hex characters
        """
        return secrets.token_hex(length)

    def validate_context(self, context: dict[str, Any], required_fields: list[str]) -> None:
        """Validate that required fields exist in context.

        Args:
            context: Template context to validate
            required_fields: List of required field names

        Raises:
            RenderError: If any required field is missing

        Example:
            >>> renderer = TemplateRenderer(Path("/repo"))
            >>> context = {"instance_name": "my-instance"}
            >>> renderer.validate_context(context, ["instance_name", "namespace"])
        """
        missing = [field for field in required_fields if field not in context]

        if missing:
            raise RenderError(f"Missing required context fields: {', '.join(missing)}")

        logger.debug("Context validation passed")

    def get_template_variables(
        self, service_type: str, template_name: str, service_version: str = "v1"
    ) -> set[str]:
        """Extract variable names used in a template.

        Args:
            service_type: Service type name
            template_name: Template filename
            service_version: Service version (default: "v1")

        Returns:
            Set of variable names used in template

        Raises:
            TemplateLoadError: If template cannot be loaded
            RenderError: If template has syntax errors

        Example:
            >>> renderer = TemplateRenderer(Path("/repo"))
            >>> vars = renderer.get_template_variables("mysql", "secret.yaml.tmpl")
            >>> print(vars)
            {'instance_name', 'namespace', 'spec'}
        """
        # Load template
        try:
            template_content = self.template_loader.get_template(
                service_type, template_name, service_version
            )
        except TemplateLoadError as e:
            raise RenderError(f"Failed to load template: {e}") from e

        # Parse template to extract variables
        try:
            from jinja2 import meta

            ast = self.jinja_env.parse(template_content)
            variables = meta.find_undeclared_variables(ast)
            return variables
        except TemplateSyntaxError as e:
            raise RenderError(
                f"Template syntax error in {template_name} at line {e.lineno}: {e.message}"
            ) from e


# Made with Bob
