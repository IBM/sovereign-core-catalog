"""CLI command definitions.

This module defines all CLI commands using the Click framework.
Each command delegates to the CLIController for business logic.
"""

import json
import sys
from pathlib import Path
from typing import Any

import click
from rich.console import Console

from broker.cli.controller import CLIController
from broker.cli.diff import display_file_diff, display_parameter_changes
from broker.cli.output import print_error, print_info, print_success, print_warning


console = Console()


@click.command()
@click.option(
    "--service",
    "-s",
    required=True,
    help="Service type (e.g., mysql, mariadb, postgres)",
)
@click.option(
    "--instance",
    "-i",
    required=True,
    help="Instance name (must be Kubernetes-compatible: lowercase, numbers, hyphens)",
)
@click.option(
    "--plan",
    "-p",
    default="default",
    help="Service plan (default: default)",
)
@click.option(
    "--cluster",
    "-c",
    help="Target cluster name (default: k3s-cluster-1)",
)
@click.option(
    "--environment",
    "-e",
    default="dev",
    type=click.Choice(["dev", "staging", "prod"], case_sensitive=False),
    help="Environment (default: dev)",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Dry-run mode: output to local directory without Git operations",
)
@click.option(
    "--output-dir",
    default="./dry-run-output",
    help="Output directory for dry-run mode (default: ./dry-run-output)",
)
@click.option(
    "--config",
    type=click.Path(exists=True),
    help="Path to configuration file (JSON)",
)
@click.option(
    "--param",
    multiple=True,
    help="Service-specific parameters (format: key=value, can be used multiple times)",
)
@click.option(
    "--params-file",
    type=click.Path(),
    help="Path to JSON file containing service parameters (use '-' for stdin)",
)
@click.pass_context
def provision(
    ctx: click.Context,
    service: str,
    instance: str,
    plan: str,
    cluster: str | None,
    environment: str,
    dry_run: bool,
    output_dir: str,
    config: str | None,
    param: tuple[str, ...],
    params_file: str | None,
) -> None:
    """Provision a service instance.
    
    This command provisions a new service instance either in dry-run mode
    (local files only) or with full GitOps integration (Git commit + push).
    
    Examples:
    
    \b
    # Dry-run mode (local testing)
    broker-cli provision --service mysql --instance dev-001 --dry-run
    
    \b
    # Full provisioning with GitOps
    broker-cli provision --service mysql --instance prod-001 --environment prod
    
    \b
    # With custom parameters (CLI flags)
    broker-cli provision --service mysql --instance dev-001 \\
        --param database_name=myapp \\
        --param database_user=appuser \\
        --dry-run
    
    \b
    # With parameters from JSON file
    broker-cli provision --service mysql --instance dev-001 \\
        --params-file params.json --dry-run
    
    \b
    # Combine file and CLI parameters (CLI overrides file)
    broker-cli provision --service mysql --instance dev-001 \\
        --params-file params.json \\
        --param database_name=override_name \\
        --dry-run
    
    \b
    # With configuration file (for GitOps settings)
    broker-cli provision --service mysql --instance dev-001 \\
        --config config.json --dry-run
    """
    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)
    global_config = ctx.obj.get("config")

    # Load parameters from file or stdin if provided
    parameters: dict[str, Any] = {}
    if params_file:
        try:
            if params_file == "-":
                # Read from stdin
                params_data = json.load(sys.stdin)
            else:
                # Read from file
                with open(params_file) as f:
                    params_data = json.load(f)

            if not isinstance(params_data, dict):
                print_error(
                    f"Parameters file must contain a JSON object, got {type(params_data).__name__}"
                )
                sys.exit(1)

            parameters.update(params_data)
        except FileNotFoundError:
            print_error(f"Parameters file not found: {params_file}")
            sys.exit(1)
        except json.JSONDecodeError as e:
            print_error(f"Invalid JSON in parameters file: {e}")
            sys.exit(1)
        except Exception as e:
            print_error(f"Error reading parameters file: {e}")
            sys.exit(1)

    # Parse CLI parameters (these override file parameters)
    for p in param:
        if "=" not in p:
            print_error(f"Invalid parameter format: {p}. Use key=value")
            sys.exit(1)
        key, value = p.split("=", 1)
        parameters[key] = value

    # Use local --config if provided, otherwise use global --config
    config_path = config if config else global_config

    # Create controller
    controller = CLIController(
        dry_run=dry_run,
        output_dir=Path(output_dir),
        config_file=Path(config_path) if config_path else None,
        verbose=verbose,
        quiet=quiet,
    )

    # Execute provision
    try:
        if not quiet:
            mode = "dry-run" if dry_run else "GitOps"
            print_info(f"Provisioning {service} instance '{instance}' ({mode} mode)")

        result = controller.provision(
            service_type=service,
            instance_name=instance,
            plan_id=plan,
            cluster_name=cluster,
            environment=environment,
            parameters=parameters,
        )

        if result["success"]:
            if not quiet:
                print_success(f"Successfully provisioned {service} instance '{instance}'")

                if dry_run:
                    print_info(f"Output directory: {controller.output_dir}")
                    print_info("Files created:")
                    for file in result.get("files_created", []):
                        console.print(f"  • {file}")
                else:
                    print_info("Next steps:")
                    for step in result.get("next_steps", []):
                        console.print(f"  {step}")
        else:
            print_error(f"Provisioning failed: {result.get('error', 'Unknown error')}")
            sys.exit(1)

    except Exception as e:
        print_error(f"Provisioning failed: {e}")
        if verbose:
            console.print_exception()
        sys.exit(1)


@click.command()
@click.option(
    "--all",
    "clean_all",
    is_flag=True,
    help="Clean all dry-run artifacts",
)
@click.option(
    "--instance",
    "-i",
    help="Clean specific instance artifacts",
)
@click.option(
    "--output-dir",
    default="./dry-run-output",
    help="Dry-run output directory to clean (default: ./dry-run-output)",
)
@click.option(
    "--confirm",
    is_flag=True,
    help="Skip confirmation prompt",
)
@click.pass_context
def clean(
    ctx: click.Context,
    clean_all: bool,
    instance: str | None,
    output_dir: str,
    confirm: bool,
) -> None:
    """Clean up dry-run artifacts.

    This command removes files created during dry-run provisioning.
    Use with caution as this operation cannot be undone.

    Examples:

    \b
    # Clean all dry-run artifacts (with confirmation)
    broker-cli clean --all

    \b
    # Clean specific instance
    broker-cli clean --instance dev-001

    \b
    # Clean without confirmation
    broker-cli clean --all --confirm
    """
    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)

    if not clean_all and not instance:
        print_error("Must specify either --all or --instance")
        sys.exit(1)

    # Create controller
    controller = CLIController(
        dry_run=True,  # Clean only works with dry-run artifacts
        output_dir=Path(output_dir),
        config_file=None,  # Clean doesn't need config
        verbose=verbose,
        quiet=quiet,
    )

    # Confirm if not --confirm flag
    if not confirm:
        if clean_all:
            message = f"Delete all artifacts in {output_dir}?"
        else:
            message = f"Delete artifacts for instance '{instance}'?"

        if not click.confirm(message):
            print_warning("Operation cancelled")
            return

    # Execute clean
    try:
        result = controller.clean(
            instance_name=instance,
            clean_all=clean_all,
        )

        if result["success"]:
            if not quiet:
                files_deleted = result.get("files_deleted", 0)
                if files_deleted > 0:
                    print_success(f"Deleted {files_deleted} file(s)")
                else:
                    print_info("No files to delete")
        else:
            print_error(f"Clean failed: {result.get('error', 'Unknown error')}")
            sys.exit(1)

    except Exception as e:
        print_error(f"Clean failed: {e}")
        if verbose:
            console.print_exception()
        sys.exit(1)


@click.command()
@click.option(
    "--instance",
    "-i",
    required=True,
    help="Instance name to deprovision",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Dry-run mode: remove from local directory only",
)
@click.option(
    "--output-dir",
    default="./dry-run-output",
    help="Output directory for dry-run mode (default: ./dry-run-output)",
)
@click.option(
    "--confirm",
    is_flag=True,
    help="Skip confirmation prompt",
)
@click.pass_context
def deprovision(
    ctx: click.Context,
    instance: str,
    dry_run: bool,
    output_dir: str,
    confirm: bool,
) -> None:
    """Deprovision a service instance.

    This command removes a service instance either from local dry-run storage
    or from GitOps (with Git commit + push).

    Examples:

    \b
    # Deprovision from dry-run storage
    broker-cli deprovision --instance dev-001 --dry-run

    \b
    # Deprovision from GitOps (with confirmation)
    broker-cli deprovision --instance prod-001

    \b
    # Deprovision without confirmation
    broker-cli deprovision --instance dev-001 --dry-run --confirm
    """
    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)
    global_config = ctx.obj.get("config")

    # Confirm if not --confirm flag
    if not confirm:
        mode = "dry-run storage" if dry_run else "GitOps"
        message = f"Deprovision instance '{instance}' from {mode}?"
        if not click.confirm(message):
            print_warning("Operation cancelled")
            return

    # Create controller
    controller = CLIController(
        dry_run=dry_run,
        output_dir=Path(output_dir),
        config_file=Path(global_config) if global_config else None,
        verbose=verbose,
        quiet=quiet,
    )

    # Execute deprovision
    try:
        if not quiet:
            mode = "dry-run" if dry_run else "GitOps"
            print_info(f"Deprovisioning instance '{instance}' ({mode} mode)")

        result = controller.deprovision(instance_name=instance)

        if result["success"]:
            if not quiet:
                print_success(f"Successfully deprovisioned instance '{instance}'")

                if not dry_run:
                    print_info("Next steps:")
                    for step in result.get("next_steps", []):
                        console.print(f"  {step}")
        else:
            print_error(f"Deprovision failed: {result.get('error', 'Unknown error')}")
            sys.exit(1)

    except Exception as e:
        print_error(f"Deprovision failed: {e}")
        if verbose:
            console.print_exception()
        sys.exit(1)


@click.command()
@click.option(
    "--instance",
    "-i",
    required=True,
    help="Instance name to update",
)
@click.option(
    "--param",
    multiple=True,
    help="Parameters to update (format: key=value, can be used multiple times)",
)
@click.option(
    "--params-file",
    type=click.Path(),
    help="Path to JSON file containing service parameters (use '-' for stdin)",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Dry-run mode: update local directory only",
)
@click.option(
    "--output-dir",
    default="./dry-run-output",
    help="Output directory for dry-run mode (default: ./dry-run-output)",
)
@click.pass_context
def update(
    ctx: click.Context,
    instance: str,
    param: tuple[str, ...],
    params_file: str | None,
    dry_run: bool,
    output_dir: str,
) -> None:
    """Update a service instance.
    
    This command updates parameters of an existing service instance.
    
    Examples:
    
    \b
    # Update parameters in dry-run storage
    broker-cli update --instance dev-001 --param replicas=3 --dry-run
    
    \b
    # Update parameters in GitOps
    broker-cli update --instance prod-001 --param replicas=5
    
    \b
    # Update multiple parameters (CLI flags)
    broker-cli update --instance dev-001 \\
        --param database_size=10Gi \\
        --param backup_enabled=true \\
        --dry-run
    
    \b
    # Update from JSON file
    broker-cli update --instance dev-001 \\
        --params-file new-params.json --dry-run
    
    \b
    # Combine file and CLI parameters (CLI overrides file)
    broker-cli update --instance dev-001 \\
        --params-file params.json \\
        --param replicas=5 \\
        --dry-run
    """
    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)
    global_config = ctx.obj.get("config")

    # Load parameters from file or stdin if provided
    parameters: dict[str, Any] = {}
    if params_file:
        try:
            if params_file == "-":
                # Read from stdin
                file_params = json.load(sys.stdin)
            else:
                # Read from file
                with open(params_file, encoding="utf-8") as f:
                    file_params = json.load(f)

            if not isinstance(file_params, dict):
                print_error(f"Parameters must be a JSON object, got {type(file_params).__name__}")
                sys.exit(1)
            parameters.update(file_params)
        except json.JSONDecodeError as e:
            print_error(f"Invalid JSON in parameters: {e}")
            sys.exit(1)
        except Exception as e:
            print_error(f"Failed to read parameters: {e}")
            sys.exit(1)

    # Parse and merge CLI parameters (override file parameters)
    for p in param:
        if "=" not in p:
            print_error(f"Invalid parameter format: {p}. Use key=value")
            sys.exit(1)
        key, value = p.split("=", 1)
        parameters[key] = value

    if not parameters:
        print_error("No parameters specified. Use --param key=value")
        sys.exit(1)

    # Create controller
    controller = CLIController(
        dry_run=dry_run,
        output_dir=Path(output_dir),
        config_file=Path(global_config) if global_config else None,
        verbose=verbose,
        quiet=quiet,
    )

    # Execute update
    try:
        if not quiet:
            mode = "dry-run" if dry_run else "GitOps"
            print_info(f"Updating instance '{instance}' ({mode} mode)")

        result = controller.update(
            instance_name=instance,
            parameters=parameters,
        )

        if result["success"]:
            if not quiet:
                # Display parameter changes
                old_params = result.get("old_parameters", {})
                new_params = result.get("new_parameters", {})
                display_parameter_changes(old_params, new_params)

                # Display file diff
                old_instance = result.get("old_instance_data", {})
                new_instance = result.get("new_instance_data", {})
                if old_instance and new_instance:
                    console.print()  # Blank line
                    display_file_diff(
                        old_instance,
                        new_instance,
                        f"instances/{instance}/instance.yaml",
                        format_type="yaml",
                    )

                console.print()  # Blank line
                print_success(f"Successfully updated instance '{instance}'")

                if not dry_run:
                    print_info("Next steps:")
                    for step in result.get("next_steps", []):
                        console.print(f"  {step}")
        else:
            print_error(f"Update failed: {result.get('error', 'Unknown error')}")
            sys.exit(1)

    except Exception as e:
        print_error(f"Update failed: {e}")
        if verbose:
            console.print_exception()
        sys.exit(1)


@click.command()
@click.option(
    "--instance",
    "-i",
    required=True,
    help="Instance name to retrieve",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Dry-run mode: get from local directory",
)
@click.option(
    "--output-dir",
    default="./dry-run-output",
    help="Output directory for dry-run mode (default: ./dry-run-output)",
)
@click.option(
    "--output",
    "-o",
    type=click.Choice(["table", "json", "yaml"], case_sensitive=False),
    default="table",
    help="Output format (default: table)",
)
@click.pass_context
def get(
    ctx: click.Context,
    instance: str,
    dry_run: bool,
    output_dir: str,
    output: str,
) -> None:
    """Get details of a service instance.

    This command displays detailed information about a service instance.

    Examples:

    \b
    # Get instance details (table format)
    broker-cli get --instance dev-001 --dry-run

    \b
    # Get instance details (JSON format)
    broker-cli get --instance dev-001 --output json --dry-run

    \b
    # Get instance from GitOps
    broker-cli get --instance prod-001
    """
    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)
    global_config = ctx.obj.get("config")

    # Create controller
    controller = CLIController(
        dry_run=dry_run,
        output_dir=Path(output_dir),
        config_file=Path(global_config) if global_config else None,
        verbose=verbose,
        quiet=quiet,
    )

    # Execute get
    try:
        result = controller.get(instance_name=instance)

        if result["success"]:
            instance_data = result["instance"]

            if output == "json":
                console.print_json(data=instance_data)
            elif output == "yaml":
                import yaml

                console.print(yaml.dump(instance_data, default_flow_style=False))
            else:  # table format
                from rich.table import Table

                table = Table(title=f"Instance: {instance}")
                table.add_column("Field", style="cyan")
                table.add_column("Value", style="green")

                for key, value in instance_data.items():
                    if isinstance(value, dict):
                        value_str = json.dumps(value, indent=2)
                    else:
                        value_str = str(value)
                    table.add_row(key, value_str)

                console.print(table)
        else:
            print_error(f"Get failed: {result.get('error', 'Unknown error')}")
            sys.exit(1)

    except Exception as e:
        print_error(f"Get failed: {e}")
        if verbose:
            console.print_exception()
        sys.exit(1)


@click.command()
@click.option(
    "--dry-run",
    is_flag=True,
    help="Dry-run mode: list from local directory",
)
@click.option(
    "--output-dir",
    default="./dry-run-output",
    help="Output directory for dry-run mode (default: ./dry-run-output)",
)
@click.option(
    "--output",
    "-o",
    type=click.Choice(["table", "json", "yaml"], case_sensitive=False),
    default="table",
    help="Output format (default: table)",
)
@click.pass_context
def list_cmd(
    ctx: click.Context,
    dry_run: bool,
    output_dir: str,
    output: str,
) -> None:
    """List all service instances.

    This command lists all service instances with their basic information.

    Examples:

    \b
    # List instances (table format)
    broker-cli list --dry-run

    \b
    # List instances (JSON format)
    broker-cli list --output json --dry-run

    \b
    # List instances from GitOps
    broker-cli list
    """
    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)
    global_config = ctx.obj.get("config")

    # Create controller
    controller = CLIController(
        dry_run=dry_run,
        output_dir=Path(output_dir),
        config_file=Path(global_config) if global_config else None,
        verbose=verbose,
        quiet=quiet,
    )

    # Execute list
    try:
        result = controller.list_instances()

        if result["success"]:
            instances = result["instances"]
            count = result["count"]

            if count == 0:
                if not quiet:
                    print_info("No instances found")
                return

            if output == "json":
                console.print_json(data=instances)
            elif output == "yaml":
                import yaml

                console.print(yaml.dump(instances, default_flow_style=False))
            else:  # table format
                from rich.table import Table

                table = Table(title=f"Service Instances ({count} total)")
                table.add_column("Instance", style="cyan")
                table.add_column("Service", style="green")
                table.add_column("Plan", style="yellow")
                table.add_column("Environment", style="magenta")
                table.add_column("Cluster", style="blue")

                for instance in instances:
                    table.add_row(
                        instance.get("instance_id", "N/A"),
                        instance.get("service_id", "N/A"),
                        instance.get("plan_id", "N/A"),
                        instance.get("environment", "N/A"),
                        instance.get("cluster_name", "N/A"),
                    )

                console.print(table)
        else:
            print_error(f"List failed: {result.get('error', 'Unknown error')}")
            sys.exit(1)

    except Exception as e:
        print_error(f"List failed: {e}")
        if verbose:
            console.print_exception()
        sys.exit(1)


# Made with Bob
