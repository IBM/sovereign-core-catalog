"""JSON Schema validator for service provisioning parameters.

This module provides functionality to validate service provisioning parameters
against JSON schemas. It uses the jsonschema library to perform validation and
generates user-friendly error messages.

Example:
    >>> from pathlib import Path
    >>> validator = SchemaValidator(Path("/path/to/gitops/repo"))
    >>> parameters = {"database_name": "myapp", "database_user": "appuser"}
    >>> validator.validate("mysql", parameters)  # Raises ValidationError if invalid
"""

import logging
from pathlib import Path
from typing import Any

import jsonschema
from jsonschema import Draft7Validator
from jsonschema import ValidationError as JsonSchemaValidationError

from broker.gitops.template_loader import TemplateLoader, TemplateLoadError


logger = logging.getLogger(__name__)


class ValidationError(Exception):
    """Raised when parameter validation fails."""

    def __init__(self, message: str, errors: list[dict[str, str]] | None = None):
        """Initialize validation error.

        Args:
            message: Error message
            errors: List of validation errors with field and message
        """
        super().__init__(message)
        self.errors = errors or []


class SchemaValidator:
    """Validate service provisioning parameters against JSON schemas.

    This class handles loading JSON schemas and validating parameters against
    them. It provides detailed, user-friendly error messages for validation
    failures.

    Attributes:
        template_loader: TemplateLoader instance for loading schemas
    """

    def __init__(self, repo_dir: Path) -> None:
        """Initialize schema validator.

        Args:
            repo_dir: Path to GitOps repository root directory

        Raises:
            TemplateLoadError: If repo_dir doesn't exist or isn't a directory
        """
        self.template_loader = TemplateLoader(repo_dir)
        logger.debug(f"Initialized SchemaValidator with repo_dir: {repo_dir}")

    def validate(
        self,
        service_type: str,
        parameters: dict[str, Any],
        service_version: str = "v1",
    ) -> None:
        """Validate parameters against service schema.

        Args:
            service_type: Service type name (e.g., "mysql", "postgres")
            parameters: Parameters to validate
            service_version: Service version (default: "v1")

        Raises:
            ValidationError: If validation fails with detailed error information
            TemplateLoadError: If schema cannot be loaded

        Example:
            >>> validator = SchemaValidator(Path("/repo"))
            >>> params = {"database_name": "myapp", "database_user": "appuser"}
            >>> validator.validate("mysql", params)
        """
        # Load schema
        try:
            schema = self.template_loader.load_schema(service_type, service_version)
        except TemplateLoadError as e:
            raise ValidationError(f"Failed to load schema: {e}") from e

        self._inject_common_properties(schema)

        # Validate parameters
        try:
            self._validate_with_schema(schema, parameters)
            logger.info(f"Parameters validated successfully for {service_type}:{service_version}")
        except ValidationError:
            # Re-raise validation errors as-is
            raise

    def validate_with_defaults(
        self,
        service_type: str,
        parameters: dict[str, Any],
        service_version: str = "v1",
    ) -> dict[str, Any]:
        """Validate parameters and apply default values from schema.

        Args:
            service_type: Service type name
            parameters: Parameters to validate
            service_version: Service version (default: "v1")

        Returns:
            Parameters with default values applied

        Raises:
            ValidationError: If validation fails
            TemplateLoadError: If schema cannot be loaded

        Example:
            >>> validator = SchemaValidator(Path("/repo"))
            >>> params = {"database_name": "myapp"}
            >>> validated = validator.validate_with_defaults("mysql", params)
            >>> print(validated)
            {'database_name': 'myapp', 'database_user': 'appuser'}  # default applied
        """
        # Load schema
        try:
            schema = self.template_loader.load_schema(service_type, service_version)
        except TemplateLoadError as e:
            raise ValidationError(f"Failed to load schema: {e}") from e

        self._inject_common_properties(schema)

        # Apply defaults
        params_with_defaults = self._apply_defaults(schema, parameters)

        # Validate with defaults applied
        try:
            self._validate_with_schema(schema, params_with_defaults)
            logger.info(f"Parameters validated with defaults for {service_type}:{service_version}")
        except ValidationError:
            raise

        return params_with_defaults

    def get_required_fields(self, service_type: str, service_version: str = "v1") -> list[str]:
        """Get list of required fields from schema.

        Args:
            service_type: Service type name
            service_version: Service version (default: "v1")

        Returns:
            List of required field names

        Raises:
            TemplateLoadError: If schema cannot be loaded

        Example:
            >>> validator = SchemaValidator(Path("/repo"))
            >>> required = validator.get_required_fields("mysql")
            >>> print(required)
            ['database_name', 'database_user']
        """
        schema = self.template_loader.load_schema(service_type, service_version)
        required: list[str] = schema.get("required", [])
        return required

    def get_schema_properties(
        self, service_type: str, service_version: str = "v1"
    ) -> dict[str, Any]:
        """Get schema properties (field definitions).

        Args:
            service_type: Service type name
            service_version: Service version (default: "v1")

        Returns:
            Dictionary of property definitions

        Raises:
            TemplateLoadError: If schema cannot be loaded

        Example:
            >>> validator = SchemaValidator(Path("/repo"))
            >>> props = validator.get_schema_properties("mysql")
            >>> print(props["database_name"])
            {'type': 'string', 'description': 'Database name', ...}
        """
        schema = self.template_loader.load_schema(service_type, service_version)
        properties: dict[str, Any] = schema.get("properties", {})
        return properties

    def _validate_with_schema(self, schema: dict[str, Any], parameters: dict[str, Any]) -> None:
        """Validate parameters against a JSON schema.

        Args:
            schema: JSON schema dictionary
            parameters: Parameters to validate

        Raises:
            ValidationError: If validation fails with detailed errors
        """
        # Create validator
        try:
            validator = Draft7Validator(schema)
        except jsonschema.SchemaError as e:
            raise ValidationError(f"Invalid JSON schema: {e}") from e

        # Collect all validation errors
        errors = list(validator.iter_errors(parameters))

        if errors:
            # Convert jsonschema errors to user-friendly format
            formatted_errors = self._format_validation_errors(errors)
            error_messages = [f"{err['field']}: {err['message']}" for err in formatted_errors]

            raise ValidationError(
                f"Parameter validation failed: {'; '.join(error_messages)}",
                errors=formatted_errors,
            )

    def _format_validation_errors(
        self, errors: list[JsonSchemaValidationError]
    ) -> list[dict[str, str]]:
        """Format jsonschema validation errors into user-friendly format.

        Args:
            errors: List of jsonschema ValidationError objects

        Returns:
            List of error dictionaries with 'field' and 'message' keys

        Example:
            >>> errors = [...]  # jsonschema errors
            >>> formatted = self._format_validation_errors(errors)
            >>> print(formatted)
            [
                {'field': 'database_name', 'message': 'Field is required'},
                {'field': 'database_user', 'message': 'Must match pattern ^[a-zA-Z].*'}
            ]
        """
        formatted: list[dict[str, str]] = []

        for error in errors:
            # Build field path (e.g., "spec.database_name")
            field_path = ".".join(str(p) for p in error.path) if error.path else "root"

            # Generate user-friendly message
            message = self._generate_error_message(error)

            formatted.append({"field": field_path, "message": message})

        return formatted

    def _generate_error_message(self, error: JsonSchemaValidationError) -> str:
        """Generate user-friendly error message from jsonschema error.

        Args:
            error: jsonschema ValidationError object

        Returns:
            User-friendly error message
        """
        validator_type = error.validator

        if validator_type == "required":
            missing_field = error.message.split("'")[1]
            return f"Field '{missing_field}' is required"

        elif validator_type == "type":
            expected_type = error.validator_value
            return f"Must be of type {expected_type}"

        elif validator_type == "pattern":
            pattern = error.validator_value
            return f"Must match pattern: {pattern}"

        elif validator_type == "minLength":
            min_length = error.validator_value
            return f"Must be at least {min_length} characters long"

        elif validator_type == "maxLength":
            max_length = error.validator_value
            return f"Must be at most {max_length} characters long"

        elif validator_type == "minimum":
            minimum = error.validator_value
            return f"Must be at least {minimum}"

        elif validator_type == "maximum":
            maximum = error.validator_value
            return f"Must be at most {maximum}"

        elif validator_type == "enum":
            allowed = error.validator_value
            if isinstance(allowed, list):
                return f"Must be one of: {', '.join(str(v) for v in allowed)}"
            return "Must be one of the allowed values"

        else:
            # Fallback to jsonschema's message
            message: str = error.message
            return message

    def _inject_common_properties(self, schema: dict[str, Any]) -> None:
        """Inject common broker properties into a loaded schema.

        Adds properties that are always available regardless of the service-specific
        schema defined in the GitOps repository. Existing properties are not overwritten.

        Args:
            schema: JSON schema dictionary (mutated in place)
        """
        properties = schema.setdefault("properties", {})
        if "instanceName" not in properties:
            properties["instanceName"] = {
                "type": "string",
                "description": "Name of the service instance",
                "default": "unknown",
            }

    def _apply_defaults(self, schema: dict[str, Any], parameters: dict[str, Any]) -> dict[str, Any]:
        """Apply default values and auto-generate values from schema to parameters.

        This method recursively processes nested objects to apply defaults and
        auto-generate values at all levels of the parameter hierarchy.

        Args:
            schema: JSON schema dictionary
            parameters: Parameters dictionary

        Returns:
            New parameters dictionary with defaults applied and values generated
        """
        result = parameters.copy()
        properties = schema.get("properties", {})

        for field_name, field_schema in properties.items():
            field_type = field_schema.get("type")

            # Handle nested objects recursively
            if field_type == "object":
                if field_name in result:
                    # Field exists - recursively apply defaults to nested object
                    if isinstance(result[field_name], dict):
                        result[field_name] = self._apply_defaults(field_schema, result[field_name])
                else:
                    # Field doesn't exist - check if it has defaults or required nested fields
                    nested_result = self._apply_defaults(field_schema, {})
                    if nested_result:
                        # Only add the nested object if it has any values
                        result[field_name] = nested_result
                continue

            # Skip if field already provided (non-object fields)
            if field_name in result:
                continue

            # Apply default if exists
            if "default" in field_schema:
                result[field_name] = field_schema["default"]
                logger.debug(f"Applied default value for field: {field_name}")
                continue

            # Auto-generate value if x-generate extension exists
            if "x-generate" in field_schema:
                generated_value = self._generate_value(field_name, field_schema["x-generate"])
                result[field_name] = generated_value
                logger.debug(f"Auto-generated value for field: {field_name}")

        return result

    def _generate_value(self, field_name: str, generate_spec: dict[str, Any]) -> str:
        """Generate a value based on x-generate specification.

        Args:
            field_name: Name of the field
            generate_spec: Generation specification from x-generate

        Returns:
            Generated value as string
        """
        import secrets
        import string

        gen_type = generate_spec.get("type", "string")
        length = generate_spec.get("length", 16)
        include = generate_spec.get("include", "alphanumeric")

        if gen_type == "password":
            # Generate secure password
            if include == "alphanumeric-symbols":
                chars = string.ascii_letters + string.digits + "!@#$%^&*()-_=+[]{}|;:,.<>?"
            elif include == "alphanumeric":
                chars = string.ascii_letters + string.digits
            elif include == "numeric":
                chars = string.digits
            else:
                chars = string.ascii_letters + string.digits

            # Ensure password has at least one of each required character type
            if include == "alphanumeric-symbols":
                password = (
                    secrets.choice(string.ascii_uppercase)
                    + secrets.choice(string.ascii_lowercase)
                    + secrets.choice(string.digits)
                    + secrets.choice("!@#$%^&*()-_=+")
                )
                # Fill remaining length
                password += "".join(secrets.choice(chars) for _ in range(length - 4))
                # Shuffle to avoid predictable pattern
                password_list = list(password)
                secrets.SystemRandom().shuffle(password_list)
                return "".join(password_list)
            else:
                return "".join(secrets.choice(chars) for _ in range(length))

        elif gen_type == "uuid":
            import uuid

            return str(uuid.uuid4())

        elif gen_type == "string":
            # Generate random alphanumeric string
            chars = string.ascii_letters + string.digits
            return "".join(secrets.choice(chars) for _ in range(length))

        else:
            # Default: random alphanumeric
            chars = string.ascii_letters + string.digits
            return "".join(secrets.choice(chars) for _ in range(length))


# Made with Bob
