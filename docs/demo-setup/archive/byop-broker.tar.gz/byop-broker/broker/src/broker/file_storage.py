"""
File-based storage implementation for CSB broker.

This module provides a StorageInterface implementation that stores service instance
metadata as JSON files on the local filesystem. This is ideal for local development
and testing scenarios where Git-based storage is not required.

Key Features:
- Simple file-based persistence (metadata only)
- No Git dependencies
- No provisioning/deprovisioning (just metadata management)
- Suitable for local development and testing
- Fast and lightweight

Note: This storage backend does NOT perform actual provisioning. It only manages
instance metadata. For actual infrastructure provisioning, use GitopsStorage.
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from broker.logging_config import get_logger
from broker.storage import StorageInterface


logger = get_logger(__name__)


class FileStorage(StorageInterface):
    """
    File-based storage implementation for local development.

    This storage backend stores service instance metadata as JSON files in a local
    directory. It does NOT perform actual provisioning - it only manages metadata.
    This makes it ideal for testing broker logic without requiring Git or Kubernetes.
    """

    def __init__(self) -> None:
        """Initialize file storage (configuration happens in init())."""
        self.storage_dir: Path | None = None
        self.dump_provision_variables_enabled: bool = False  # Default: disabled

    def init(self, config: dict[str, Any]) -> None:
        """
        Initialize file storage with JSON configuration.

        Args:
            config: Configuration dictionary with keys:
                - storage_dir: Directory for storing instance metadata (default: "./data")
                - dump_provision_variables: Enable provision variables dump (default: false)
        """
        storage_dir = config.get("storage_dir", "./data")
        self.storage_dir = Path(storage_dir)
        self.dump_provision_variables_enabled = config.get("dump_provision_variables", False)

        # Create storage directory
        self._ensure_storage_dir()

        logger.info(
            "FileStorage initialized (metadata-only mode)",
            extra={
                "storage_dir": str(self.storage_dir),
                "dump_provision_variables": self.dump_provision_variables_enabled,
            },
        )

    def _ensure_storage_dir(self) -> None:
        """Create storage directory if it doesn't exist."""
        if self.storage_dir is None:
            raise RuntimeError("Storage not initialized. Call init() first.")
        try:
            self.storage_dir.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            logger.error("Failed to create storage directory", extra={"error": str(e)})
            raise

    def _get_instance_path(self, instance_id: str) -> Path:
        """Get the file path for an instance metadata.

        Args:
            instance_id: Instance identifier

        Returns:
            Path to instance JSON file
        """
        if self.storage_dir is None:
            raise RuntimeError("Storage not initialized. Call init() first.")
        safe_id = instance_id.replace("/", "_").replace(":", "_")
        return self.storage_dir / f"{safe_id}.json"

    def create(self, instance_id: str, data: dict[str, Any]) -> None:
        """Create a new service instance (metadata only).

        Args:
            instance_id: Instance identifier
            data: Instance data

        Raises:
            ValueError: If instance already exists
        """
        path = self._get_instance_path(instance_id)
        if path.exists():
            logger.error("Instance already exists", extra={"instance_id": instance_id})
            raise ValueError(f"Instance {instance_id} already exists")

        # Add timestamps and mark as succeeded (no actual provisioning)
        data["created_at"] = datetime.now(timezone.utc).isoformat()
        data["updated_at"] = datetime.now(timezone.utc).isoformat()
        data["state"] = "succeeded"
        data["description"] = "Service instance metadata created (no provisioning)"

        # Save metadata
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            logger.info("Instance metadata created", extra={"instance_id": instance_id})
        except Exception as e:
            logger.error(
                "Failed to create instance metadata",
                extra={"instance_id": instance_id, "error": str(e)},
            )
            raise

    def get(self, instance_id: str) -> dict[str, Any] | None:
        """Retrieve a service instance.

        Args:
            instance_id: Instance identifier

        Returns:
            Instance data or None if not found
        """
        path = self._get_instance_path(instance_id)
        if not path.exists():
            return None

        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                raise ValueError(f"Invalid instance data format for {instance_id}")
            logger.info("Instance retrieved", extra={"instance_id": instance_id})
            return data
        except Exception as e:
            logger.error(
                "Failed to read instance", extra={"instance_id": instance_id, "error": str(e)}
            )
            raise

    def update(self, instance_id: str, data: dict[str, Any]) -> None:
        """Update an existing service instance.

        Args:
            instance_id: Instance identifier
            data: Updated instance data

        Raises:
            ValueError: If instance doesn't exist
        """
        path = self._get_instance_path(instance_id)
        if not path.exists():
            logger.error("Instance not found for update", extra={"instance_id": instance_id})
            raise ValueError(f"Instance {instance_id} not found")

        # Update timestamp
        data["updated_at"] = datetime.now(timezone.utc).isoformat()

        try:
            # Read existing data to preserve fields not in update
            with open(path, encoding="utf-8") as f:
                existing_data = json.load(f)

            # Merge updates into existing data
            existing_data.update(data)

            # Write updated data
            with open(path, "w", encoding="utf-8") as f:
                json.dump(existing_data, f, indent=2)

            logger.info("Instance updated", extra={"instance_id": instance_id})
        except Exception as e:
            logger.error(
                "Failed to update instance", extra={"instance_id": instance_id, "error": str(e)}
            )
            raise

    def delete(self, instance_id: str) -> bool:
        """Delete a service instance (metadata only).

        Args:
            instance_id: Instance identifier

        Returns:
            True if deleted, False if not found
        """
        path = self._get_instance_path(instance_id)
        if not path.exists():
            logger.info("Instance not found for deletion", extra={"instance_id": instance_id})
            return False

        try:
            path.unlink()
            logger.info("Instance deleted", extra={"instance_id": instance_id})
            return True
        except Exception as e:
            logger.error(
                "Failed to delete instance", extra={"instance_id": instance_id, "error": str(e)}
            )
            raise

    def exists(self, instance_id: str) -> bool:
        """Check if a service instance exists.

        Args:
            instance_id: Instance identifier

        Returns:
            True if instance exists
        """
        path = self._get_instance_path(instance_id)
        return path.exists()

    def list_all(self) -> list[dict[str, Any]]:
        """List all service instances.

        Returns:
            List of instance data dictionaries

        Raises:
            RuntimeError: If storage not initialized
        """
        if self.storage_dir is None:
            raise RuntimeError("Storage not initialized. Call init() first.")

        instances = []
        try:
            # Find all JSON files in storage directory
            for json_file in self.storage_dir.glob("*.json"):
                try:
                    with open(json_file, encoding="utf-8") as f:
                        data = json.load(f)
                        # Extract instance_id from filename (remove .json extension)
                        instance_id = json_file.stem
                        # Add instance_id to data if not present
                        if "instance_id" not in data:
                            data["instance_id"] = instance_id
                        instances.append(data)
                except Exception as e:
                    logger.error(
                        "Failed to read instance file",
                        extra={"file": str(json_file), "error": str(e)},
                    )
                    # Continue with other files
                    continue

            logger.info("Listed all instances", extra={"count": len(instances)})
            return instances
        except Exception as e:
            logger.error("Failed to list instances", extra={"error": str(e)})
            raise

    def dump_provision_variables(self, instance_id: str, variables: dict[str, Any]) -> None:
        """
        Dump provisioning variables to JSON file in instance directory.

        Creates a provision-variables.json file alongside the instance metadata
        containing all variables used during provisioning. Sensitive data is
        automatically redacted.

        Args:
            instance_id: Service instance ID
            variables: Dictionary of all provisioning variables

        Note:
            - Feature must be enabled via dump_provision_variables_enabled flag
            - Errors are logged but do not fail provisioning (non-blocking)
            - File is written to storage directory
        """
        if not self.dump_provision_variables_enabled:
            return

        try:
            # Sanitize sensitive data
            sanitized = self._sanitize_variables(variables)

            # Add metadata
            dump_data = {
                "metadata": {
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "instance_id": instance_id,
                    "feature_enabled": True,
                    "broker_version": "1.0.12",
                },
                "variables": sanitized,
            }

            # Write to storage directory
            if self.storage_dir is None:
                raise RuntimeError("Storage not initialized")

            safe_id = instance_id.replace("/", "_").replace(":", "_")
            dump_file = self.storage_dir / f"{safe_id}-provision-variables.json"

            with open(dump_file, "w", encoding="utf-8") as f:
                json.dump(dump_data, f, indent=2, sort_keys=True)

            logger.info(
                "Provision variables dumped",
                extra={"instance_id": instance_id, "file": str(dump_file)},
            )
        except Exception as e:
            # Log error but don't fail provisioning
            logger.error(
                "Failed to dump provision variables",
                extra={"instance_id": instance_id, "error": str(e)},
            )

    def _sanitize_variables(self, variables: dict[str, Any]) -> dict[str, Any]:
        """
        Sanitize sensitive data from variables.

        Recursively scans the variables dictionary and replaces sensitive values
        with "<REDACTED>" placeholder. Sensitive keys are identified by common
        patterns like "password", "token", "secret", "key", etc.

        Args:
            variables: Dictionary of variables to sanitize

        Returns:
            Sanitized copy of variables dictionary
        """
        sensitive_keys = {
            "password",
            "passwd",
            "pwd",
            "token",
            "access_token",
            "refresh_token",
            "secret",
            "client_secret",
            "api_secret",
            "key",
            "api_key",
            "apikey",
            "private_key",
            "credential",
            "credentials",
            "auth",
            "authorization",
        }

        def sanitize_dict(d: dict[str, Any]) -> dict[str, Any]:
            """Recursively sanitize a dictionary."""
            result: dict[str, Any] = {}
            for k, v in d.items():
                key_lower = k.lower()
                # Check type first - always recurse into dicts and lists
                if isinstance(v, dict):
                    # Recurse into nested dict
                    result[k] = sanitize_dict(v)
                elif isinstance(v, list):
                    # Recurse into list items
                    result[k] = [
                        sanitize_dict(item) if isinstance(item, dict) else item for item in v
                    ]
                elif any(sensitive in key_lower for sensitive in sensitive_keys):
                    # Only redact primitive values with sensitive keys
                    result[k] = "<REDACTED>"
                else:
                    # Preserve non-sensitive primitive values
                    result[k] = v
            return result

        return sanitize_dict(variables)


# Made with Bob
