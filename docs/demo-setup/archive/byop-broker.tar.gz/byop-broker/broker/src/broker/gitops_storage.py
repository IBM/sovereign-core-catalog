"""
GitOps-based storage implementation for CSB broker.

This module provides a StorageInterface implementation that drives GitOps provisioning
instead of just storing JSON files. When a service instance is created, it triggers
the GitOps provisioning workflow to deploy actual infrastructure.

Supports asynchronous operations using background threads for long-running
provisioning and deprovisioning tasks.

STATELESS OPERATION:
This storage backend now uses GitStateManager to read/write state directly from/to
the Git repository, making the broker stateless. Multiple broker instances can run
concurrently without conflicts.
"""

import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from broker.gitops.git_state_manager import GitStateManager
from broker.logging_config import get_logger
from broker.storage import StorageInterface


logger = get_logger(__name__)


class GitopsStorage(StorageInterface):
    """
    GitOps-based storage implementation that drives provisioning.

    This storage backend uses the GitOps GitHub repository as the storage mechanism.
    When instances are created, updated, or deleted, the changes are committed to
    the GitHub repository, which triggers ArgoCD to deploy the actual infrastructure.
    """

    def __init__(self) -> None:
        """Initialize GitOps storage (configuration happens in init())."""
        self.storage_dir: Path | None = None
        self.gitops_path: Path | None = None
        self.cluster_name: str | None = None
        self.gitops_env: dict[str, str] = {}
        self.async_enabled: bool = True  # Default to async mode
        self.state_manager: GitStateManager  # Git-based state manager (required)
        self.registry_profiles: dict[str, Any] = {}
        self.cluster_registry_links: dict[str, str] = {}
        self.default_registry_profile: str | None = None
        self._registry_lock = threading.Lock()
        self.dump_provision_variables_enabled: bool = False  # Default: disabled
        self.dry_run: bool = False  # Dry-run mode: generate files without Git push
        self.dry_run_output_dir: Path | None = None  # Output directory for dry-run files

    def init(self, config: dict[str, Any]) -> None:
        """
        Initialize GitOps storage with JSON configuration.

        Args:
            config: Configuration dictionary with keys:
                - storage_dir: Directory for storing instance metadata (DEPRECATED - not used, kept for compatibility)
                - gitops_path: Path to GitOps orchestrator directory (optional)
                - cluster_name: Default cluster name for provisioning (default: "k3s-cluster-1")
                - async_enabled: Enable async operations (default: true)
                - gitops_config: GitOps configuration (repo_url, branch, auth, etc.)
                - registry_profiles: Registry profile definitions
                - cluster_registry_links: Cluster to registry profile mapping
                - default_registry_profile: Default registry profile name
                - cache_ttl: Cache TTL in seconds (default: 30)
                - cache_enabled: Enable caching (default: true)
                - max_retries: Max retries for Git operations (default: 3)
        """
        # DEPRECATED: storage_dir kept for backward compatibility with tests
        # State is now stored in Git repository via GitStateManager
        storage_dir = config.get("storage_dir", "./data")
        self.storage_dir = Path(storage_dir)

        self.cluster_name = config.get("cluster_name", "k3s-cluster-1")
        self.async_enabled = config.get("async_enabled", True)
        self.registry_profiles = config.get("registry_profiles", {})
        self.cluster_registry_links = config.get("cluster_registry_links", {})
        self.default_registry_profile = config.get("default_registry_profile")
        self.dump_provision_variables_enabled = config.get("dump_provision_variables", False)
        self.dry_run = config.get("dry_run", False)
        if self.dry_run:
            dry_run_dir = config.get("dry_run_output_dir", "./dry-run-output")
            self.dry_run_output_dir = Path(dry_run_dir)
            logger.info(f"Dry-run mode enabled, output directory: {self.dry_run_output_dir}")

        # Resolve orchestrator path
        gitops_path = config.get("gitops_path")
        if gitops_path:
            self.gitops_path = Path(gitops_path).resolve()
        else:
            # Default: ./orchestrator relative to this file (in gitops-csb directory)
            self.gitops_path = (Path(__file__).parent / "orchestrator").resolve()

        # Store clusters configuration for async workers (avoid Flask context dependency)
        self._clusters = config.get("clusters", {})

        # Extract GitOps configuration for environment variables
        gitops_config = config.get("gitops_config", {})
        self._setup_gitops_env(gitops_config)

        # Initialize GitStateManager for stateless operation
        self._init_state_manager(config)

        # DEPRECATED: Create storage_dir for backward compatibility (not used for state)
        self._ensure_storage_dir()

        logger.info(
            "GitopsStorage initialized via init (STATELESS MODE)",
            extra={
                "storage_dir": str(self.storage_dir),
                "gitops_path": str(self.gitops_path),
                "cluster_name": self.cluster_name,
                "async_enabled": self.async_enabled,
                "registry_profiles": list(self.registry_profiles.keys()),
                "cluster_registry_links": self.cluster_registry_links,
                "default_registry_profile": self.default_registry_profile,
                "gitops_env_keys": list(self.gitops_env.keys()),
                "state_manager_enabled": self.state_manager is not None,
            },
        )

    def _setup_gitops_env(self, gitops_config: dict[str, Any]) -> None:
        """
        Setup environment variables for GitOps orchestrator from configuration.

        Args:
            gitops_config: GitOps configuration dictionary
        """
        # Map configuration keys to environment variable names
        env_mapping = {
            "repo_url": "GITOPS_REPO_URL",
            "branch": "GITOPS_BRANCH",
            "git_backend": "GIT_BACKEND",
            "git_auth_method": "GIT_AUTH_METHOD",
            "ssh_private_key": "SSH_PRIVATE_KEY",
            "ssh_private_key_path": "SSH_PRIVATE_KEY_PATH",
            "github_token": "GITHUB_TOKEN",
        }

        for config_key, env_var in env_mapping.items():
            value = gitops_config.get(config_key)
            if value is not None:
                self.gitops_env[env_var] = str(value)

    def _init_state_manager(self, config: dict[str, Any]) -> None:
        """
        Initialize GitStateManager for stateless operation.

        Args:
            config: Configuration dictionary

        Raises:
            RuntimeError: If GitStateManager initialization fails
        """
        if self.gitops_path is None:
            raise RuntimeError("Cannot initialize state manager: gitops_path not set")

        try:
            from broker.gitops.git_operations import GitOperations

            # Set environment variables for GitOperations
            for key, value in self.gitops_env.items():
                os.environ[key] = value

            # Initialize GitOperations
            git_ops = GitOperations()
            git_ops.ensure_repo_cloned()

            # Initialize GitStateManager with configuration
            cache_ttl = config.get("cache_ttl", 30)
            cache_enabled = config.get("cache_enabled", True)
            max_retries = config.get("max_retries", 3)
            retry_backoff = config.get("retry_backoff", 1.0)

            self.state_manager = GitStateManager(
                git_ops=git_ops,
                cache_ttl=cache_ttl,
                cache_enabled=cache_enabled,
                max_retries=max_retries,
                retry_backoff=retry_backoff,
            )

            logger.info(
                "GitStateManager initialized",
                extra={
                    "cache_ttl": cache_ttl,
                    "cache_enabled": cache_enabled,
                    "max_retries": max_retries,
                },
            )

        except Exception as e:
            logger.error("Failed to initialize GitStateManager", extra={"error": str(e)})
            raise RuntimeError(f"GitStateManager initialization failed: {e}") from e

        logger.info(
            "GitOps environment configured", extra={"env_vars": list(self.gitops_env.keys())}
        )

    def _ensure_storage_dir(self) -> None:
        """Create storage directory if it doesn't exist."""
        if self.storage_dir is None:
            raise RuntimeError("Storage not initialized. Call init() first.")
        try:
            self.storage_dir.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            logger.error("Failed to create storage directory", extra={"error": str(e)})
            raise

    def _get_instance_path(self, instance_id: str) -> Path:
        """Get the file path for an instance metadata."""
        if self.storage_dir is None:
            raise RuntimeError("Storage not initialized. Call init() first.")
        safe_id = instance_id.replace("/", "_").replace(":", "_")
        return self.storage_dir / f"{safe_id}.json"

    def _map_service_to_type(self, service_id: str) -> str:
        """Map CSB service_id to GitOps service type.

        This uses dynamic service discovery from the GitOps repository
        instead of hardcoded mappings. The service_id is mapped to service_type
        by removing the -service suffix if present (for backward compatibility).

        Args:
            service_id: CSB service identifier

        Returns:
            GitOps service type (mysql, mariadb, etc.)

        Raises:
            ValueError: If service type is not found in GitOps repository
            RuntimeError: If GitOps repository is not initialized
        """
        from broker.gitops.service_discovery import validate_service_type

        # Derive service_type from service_id by removing -service suffix
        # This handles backward compatibility with old instances that have
        # service_id with -service suffix
        service_type = service_id.removesuffix("-service")

        # Validate that service exists in GitOps repository
        repo_dir = self._get_gitops_repo_dir()
        if repo_dir is None:
            raise RuntimeError("GitOps repository not initialized")

        is_valid, error_msg = validate_service_type(repo_dir, service_type)

        if not is_valid:
            raise ValueError(
                f"Service '{service_id}' (type: '{service_type}') not found in GitOps repository. {error_msg}"
            )

        return service_type

    def _extract_parameters(self, data: dict[str, Any]) -> dict[str, Any]:
        """Extract provisioning parameters from instance data.

        Args:
            data: Instance data from CSB request

        Returns:
            Dictionary of provisioning parameters
        """
        parameters = data.get("parameters", {})
        service_id = data.get("service_id")
        plan_id = data.get("plan_id")
        plan_defaults = self._load_plan_defaults(service_id=service_id, plan_id=plan_id)

        replicas = parameters.get("replicas")
        if replicas is None:
            replicas = plan_defaults.get("replicas", 1)

        storage_size = parameters.get("storage_size")
        if storage_size is None:
            storage_size = plan_defaults.get("storage_size", "10Gi")

        environment = parameters.get("environment")
        if environment is None:
            environment = plan_defaults.get("environment", "dev")

        return {
            "replicas": replicas,
            "storage_size": storage_size,
            "environment": environment,
        }

    def _load_plan_defaults(
        self,
        service_id: Any,
        plan_id: Any,
    ) -> dict[str, Any]:
        """Load default provisioning values from the service's plan definition."""
        if not isinstance(service_id, str) or not service_id:
            logger.error("Missing service_id for plan lookup")
            return {}

        if not isinstance(plan_id, str) or not plan_id:
            logger.error("Missing plan_id for plan lookup", extra={"service_id": service_id})
            return {}

        repo_dir = self._get_gitops_repo_dir()
        if repo_dir is None:
            return {}

        service_name = service_id
        service_config_path = (
            repo_dir / "services" / service_name / "latest" / "catalog" / "catalog.yaml"
        )
        if not service_config_path.exists():
            logger.error(
                "Service configuration not found for plan lookup",
                extra={
                    "service_id": service_id,
                    "plan_id": plan_id,
                    "path": str(service_config_path),
                },
            )
            return {}

        try:
            with open(service_config_path, encoding="utf-8") as service_file:
                service_config = yaml.safe_load(service_file)
        except Exception as error:
            logger.error(
                "Failed to load service configuration for plan lookup",
                extra={
                    "service_id": service_id,
                    "plan_id": plan_id,
                    "path": str(service_config_path),
                    "error": str(error),
                },
            )
            return {}

        if not isinstance(service_config, dict):
            logger.error(
                "Invalid service configuration for plan lookup",
                extra={
                    "service_id": service_id,
                    "plan_id": plan_id,
                    "path": str(service_config_path),
                },
            )
            return {}

        raw_plans = service_config.get("plans")
        if not isinstance(raw_plans, list):
            logger.error(
                "Service configuration missing plans list",
                extra={
                    "service_id": service_id,
                    "plan_id": plan_id,
                    "path": str(service_config_path),
                },
            )
            return {}

        for raw_plan in raw_plans:
            if not isinstance(raw_plan, dict):
                continue

            candidate_plan_id = raw_plan.get("id")
            if candidate_plan_id != plan_id:
                continue

            defaults = raw_plan.get("parameters")
            if isinstance(defaults, dict):
                return defaults

            logger.info(
                "Plan definition has no parameters block; using request/default fallbacks",
                extra={"service_id": service_id, "plan_id": plan_id},
            )
            return {}

        logger.warning(
            "Plan not found in service configuration - using in-cluster defaults",
            extra={"service_id": service_id, "plan_id": plan_id, "path": str(service_config_path)},
        )
        return {}

    def _get_gitops_repo_dir(self) -> Path | None:
        """Resolve the local GitOps repository directory."""
        if self.gitops_path is None:
            logger.error("Cannot resolve GitOps repo dir: gitops_path not set")
            return None

        try:
            from broker.gitops.git_config import GitConfig

            return GitConfig.get_repo_dir()
        except Exception as error:
            logger.error("Failed to resolve GitOps repo dir", extra={"error": str(error)})
            return None

    def _get_available_clusters(self) -> dict[str, dict[str, Any]]:
        """Get available clusters from instance variable.

        Returns:
            Dictionary mapping server URLs to cluster metadata
        """
        return getattr(self, "_clusters", {})

    def _resolve_cluster_url(
        self, cluster_url: str | None, available_clusters: dict[str, dict[str, Any]]
    ) -> str:
        """Resolve and validate cluster URL.

        Args:
            cluster_url: Cluster URL from request (optional)
            available_clusters: Dict of available clusters

        Returns:
            Validated cluster URL

        Raises:
            ValueError: If cluster URL is invalid or not registered
        """
        # If no cluster specified, use default
        if not cluster_url:
            # Find default cluster
            for server, info in available_clusters.items():
                if info.get("default"):
                    logger.info(
                        "No cluster specified, using default",
                        extra={"cluster_url": server, "cluster_name": info.get("name")},
                    )
                    return server

            # Fallback to in-cluster
            default_url = "https://kubernetes.default.svc"
            logger.info("Using in-cluster default", extra={"cluster_url": default_url})
            return default_url

        # Validate cluster URL is registered
        if cluster_url not in available_clusters:
            available_urls = list(available_clusters.keys())
            raise ValueError(
                f"Cluster '{cluster_url}' is not registered with broker. "
                f"Available clusters: {', '.join(available_urls)}"
            )

        cluster_info = available_clusters[cluster_url]
        logger.info(
            "Using specified cluster",
            extra={
                "cluster_url": cluster_url,
                "cluster_name": cluster_info.get("name"),
                "cluster_type": cluster_info.get("type"),
            },
        )

        return cluster_url

    def _run_provision(self, instance_id: str, data: dict[str, Any]) -> None:
        """Run GitOps provisioning for an instance using library API.

        Args:
            instance_id: Instance identifier
            data: Instance data with service_id, plan_id, parameters

        Raises:
            RuntimeError: If provisioning fails
            ValueError: If cluster_url not specified in parameters
        """
        if self.gitops_path is None or self.cluster_name is None:
            raise RuntimeError("Storage not initialized. Call init() first.")

        from broker.config import config
        from broker.gitops.api import ProvisioningError, ValidationError, provision_instance

        service_type = self._map_service_to_type(data["service_id"])
        params = self._extract_parameters(data)

        # Extract service parameters (handle Sovereign Core structure)
        parameters = data.get("parameters", {})
        service_params = parameters.get("spec", parameters)

        # Get cluster URL from service parameters
        cluster_url = service_params.get("cluster_url")

        # Get available clusters from configuration
        available_clusters = self._get_available_clusters()

        # Validate and resolve cluster URL
        target_cluster_url = self._resolve_cluster_url(cluster_url, available_clusters)

        registry_profile = None

        # Prepare kwargs for provision_instance
        provision_kwargs = {
            "instance_name": instance_id,
            "service_type": service_type,
            "cluster_name": target_cluster_url,  # Use server URL
            "cluster_url": target_cluster_url,  # Also pass as cluster_url
            "replicas": params["replicas"],
            "storage_size": params["storage_size"],
            "environment": params["environment"],
            "broker_service_id": data["service_id"],
            "broker_plan_id": data["plan_id"],
            "parameters_spec": service_params,  # Pass service params for validation
            "context": data.get("context", {}),  # Pass context
        }

        # Add registry configuration if available
        if registry_profile:
            if image_pull_secret_name := registry_profile.get("image_pull_secret_name"):
                provision_kwargs["image_pull_secret_name"] = image_pull_secret_name
            if registry_server := registry_profile.get("registry_server"):
                provision_kwargs["registry_server"] = registry_server
            if registry_path := registry_profile.get("registry_path"):
                provision_kwargs["deployment_registry"] = registry_path
            if registry_username := registry_profile.get("registry_username"):
                provision_kwargs["registry_username"] = registry_username
            if registry_password := registry_profile.get("registry_password"):
                provision_kwargs["registry_password"] = registry_password
            if registry_email := registry_profile.get("registry_email"):
                provision_kwargs["registry_email"] = registry_email

        logger.info(
            "Running GitOps provision via library API",
            extra={
                "instance_id": instance_id,
                "service_type": service_type,
                "target_cluster": target_cluster_url,
                "registry_profile": registry_profile.get("profile_name")
                if registry_profile
                else None,
                "debug_retain_failed_files": config.debug_retain_failed_files,
            },
        )

        try:
            # Call library API directly instead of subprocess
            # Pass debug flag to control cleanup behavior on failure
            # Pass dry-run parameters if in dry-run mode
            result = provision_instance(
                debug_retain_failed_files=config.debug_retain_failed_files,
                dry_run=self.dry_run,
                dry_run_output_dir=self.dry_run_output_dir,
                **provision_kwargs,
            )
            logger.info(
                "GitOps provision successful",
                extra={"instance_id": instance_id, "result": result, "dry_run": self.dry_run},
            )
        except (ValidationError, ProvisioningError) as e:
            logger.error(
                "GitOps provision failed",
                extra={"instance_id": instance_id, "error": str(e)},
            )
            raise RuntimeError(f"Provisioning failed: {e}") from e
        except Exception as e:
            logger.error(
                "GitOps provision failed with unexpected error",
                extra={"instance_id": instance_id, "error": str(e)},
            )
            raise RuntimeError(f"Provisioning failed: {e}") from e

    def _run_deprovision(self, instance_id: str, data: dict[str, Any]) -> None:
        """Run GitOps deprovisioning for an instance using library API.

        Args:
            instance_id: Instance identifier
            data: Instance data with service_id

        Raises:
            RuntimeError: If deprovisioning fails
        """
        if self.gitops_path is None or self.cluster_name is None:
            raise RuntimeError("Storage not initialized. Call init() first.")

        from broker.gitops.api import (
            DeprovisioningError,
            ValidationError,
            deprovision_instance,
        )

        service_type = self._map_service_to_type(data["service_id"])

        logger.info(
            "Running GitOps deprovision via library API",
            extra={
                "instance_id": instance_id,
                "service_type": service_type,
                "cluster_name": self.cluster_name,
            },
        )

        try:
            # Call library API directly instead of subprocess
            result = deprovision_instance(
                instance_name=instance_id,
                service_type=service_type,
                cluster_name=self.cluster_name,
                force=True,  # Always force in library mode (no interactive prompt)
            )
            logger.info(
                "GitOps deprovision successful",
                extra={"instance_id": instance_id, "result": result},
            )
        except (ValidationError, DeprovisioningError) as e:
            logger.error(
                "GitOps deprovision failed",
                extra={"instance_id": instance_id, "error": str(e)},
            )
            raise RuntimeError(f"Deprovisioning failed: {e}") from e
        except Exception as e:
            logger.error(
                "GitOps deprovision failed with unexpected error",
                extra={"instance_id": instance_id, "error": str(e)},
            )
            raise RuntimeError(f"Deprovisioning failed: {e}") from e

    def _provision_worker(self, instance_id: str, data: dict[str, Any]) -> None:
        """Background worker for async provisioning.

        Args:
            instance_id: Instance identifier
            data: Instance data
        """
        path = self._get_instance_path(instance_id)

        try:
            self._run_provision(instance_id, data)

            # Invalidate cache after provisioning creates files in Git
            self.state_manager.clear_cache()
            logger.info("Cache cleared after async provision", extra={"instance_id": instance_id})

            # Update state to succeeded
            data["state"] = "succeeded"
            data["description"] = "Service instance provisioned successfully"
            data["updated_at"] = datetime.now(timezone.utc).isoformat()

            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

            logger.info(
                "Async provision completed successfully", extra={"instance_id": instance_id}
            )
        except Exception as e:
            # Invalidate cache on failure too
            self.state_manager.clear_cache()

            # Update state to failed
            data["state"] = "failed"
            data["description"] = f"Provisioning failed: {str(e)}"
            data["updated_at"] = datetime.now(timezone.utc).isoformat()

            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

            logger.error(
                "Async provision failed", extra={"instance_id": instance_id, "error": str(e)}
            )

    def _deprovision_worker(self, instance_id: str, data: dict[str, Any]) -> None:
        """Background worker for async deprovisioning.

        Args:
            instance_id: Instance identifier
            data: Instance data (already has state set to in_progress)
        """
        path = self._get_instance_path(instance_id)

        try:
            # Run deprovisioning (state already set to in_progress by delete() method)
            # NOTE: _run_deprovision() already removes files from Git and commits/pushes
            self._run_deprovision(instance_id, data)

            # Invalidate cache after deletion (deprovision already removed from Git)
            self.state_manager.clear_cache()
            logger.info("Cache cleared after async deprovision", extra={"instance_id": instance_id})

            # Delete local metadata file after successful deprovision
            if path.exists():
                path.unlink()
                logger.info("Local metadata file deleted", extra={"instance_id": instance_id})

            logger.info(
                "Async deprovision completed successfully", extra={"instance_id": instance_id}
            )
        except Exception as e:
            # Invalidate cache on failure too
            self.state_manager.clear_cache()

            # Update state to failed in Git
            data["state"] = "failed"
            data["description"] = f"Deprovisioning failed: {str(e)}"
            data["updated_at"] = datetime.now(timezone.utc).isoformat()

            try:
                self.state_manager.update_instance(instance_id, data)
            except Exception as update_error:
                logger.error(
                    "Failed to update failed state in Git",
                    extra={"instance_id": instance_id, "error": str(update_error)},
                )

            # Also update local file for backward compatibility
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

            logger.error(
                "Async deprovision failed", extra={"instance_id": instance_id, "error": str(e)}
            )

    def create(self, instance_id: str, data: dict[str, Any]) -> None:
        """Create a new service instance via GitOps provisioning.

        Args:
            instance_id: Instance identifier
            data: Instance data

        Raises:
            ValueError: If instance already exists
            RuntimeError: If provisioning fails (sync mode only)
        """
        # CRITICAL FIX: Check Git state instead of local file
        # Pull latest to ensure we have fresh state from Git
        try:
            self.state_manager.git_ops.pull_latest()
        except Exception as e:
            logger.error("Failed to pull latest from Git before create", extra={"error": str(e)})
            # Continue - we'll detect conflicts during provisioning

        # Check if instance exists in Git (not just local file)
        if self.state_manager.exists(instance_id):
            logger.error("Instance already exists in Git", extra={"instance_id": instance_id})
            raise ValueError(f"Instance {instance_id} already exists")

        # Add timestamps
        data["created_at"] = datetime.now(timezone.utc).isoformat()
        data["updated_at"] = datetime.now(timezone.utc).isoformat()
        data["state"] = "in_progress"
        data["description"] = "Provisioning in progress"

        # Save metadata to local file for tracking (backward compatibility)
        path = self._get_instance_path(instance_id)
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            logger.info(
                "Instance metadata created (local file)",
                extra={"instance_id": instance_id, "async_mode": self.async_enabled},
            )
        except Exception as e:
            logger.error(
                "Failed to create local metadata file",
                extra={"instance_id": instance_id, "error": str(e)},
            )
            # Non-critical - continue with provisioning

        # Run provisioning (async or sync)
        if self.async_enabled:
            # Start background thread for async provisioning
            thread = threading.Thread(
                target=self._provision_worker,
                args=(instance_id, data.copy()),
                daemon=True,
                name=f"provision-{instance_id}",
            )
            thread.start()
            logger.info(
                "Async provisioning started",
                extra={"instance_id": instance_id, "thread_name": thread.name},
            )
        else:
            # Synchronous provisioning (original behavior)
            try:
                self._run_provision(instance_id, data)

                # Invalidate cache after provisioning creates files in Git
                self.state_manager.clear_cache()
                logger.info("Cache cleared after provision", extra={"instance_id": instance_id})

                # Update state to succeeded
                data["state"] = "succeeded"
                data["description"] = "Service instance provisioned successfully"
                data["updated_at"] = datetime.now(timezone.utc).isoformat()

                with open(path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2)

                logger.info("Instance provisioned successfully", extra={"instance_id": instance_id})
            except Exception as e:
                # Invalidate cache on failure too
                self.state_manager.clear_cache()

                # Update state to failed
                data["state"] = "failed"
                data["description"] = f"Provisioning failed: {str(e)}"
                data["updated_at"] = datetime.now(timezone.utc).isoformat()

                with open(path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2)

                logger.error(
                    "Instance provisioning failed",
                    extra={"instance_id": instance_id, "error": str(e)},
                )
                raise

    def get(self, instance_id: str) -> dict[str, Any] | None:
        """Retrieve a service instance from Git.

        Args:
            instance_id: Instance identifier

        Returns:
            Instance data or None if not found
        """
        return self.state_manager.get_instance(instance_id)

    def update(self, instance_id: str, data: dict[str, Any]) -> None:
        """Update an existing service instance in Git.

        Args:
            instance_id: Instance identifier
            data: Updated instance data

        Raises:
            ValueError: If instance not found
        """
        self.state_manager.update_instance(instance_id, data)

    def delete(self, instance_id: str) -> bool:
        """Delete a service instance via GitOps deprovisioning.

        Args:
            instance_id: Instance identifier

        Returns:
            True if deleted, False if not found

        Raises:
            RuntimeError: If deprovisioning fails (sync mode only)
        """
        # Check if instance exists
        if not self.exists(instance_id):
            logger.info("Instance not found for deletion", extra={"instance_id": instance_id})
            return False

        # Get instance data for deprovisioning from Git
        data = self.state_manager.get_instance(instance_id)
        if data is None:
            logger.info("Instance not found for deletion", extra={"instance_id": instance_id})
            return False

        # Run deprovisioning (async or sync)
        if self.async_enabled:
            # Update state to in_progress BEFORE starting worker thread
            data["state"] = "in_progress"
            data["description"] = "Deprovisioning in progress"
            data["updated_at"] = datetime.now(timezone.utc).isoformat()

            # Update state in Git
            self.state_manager.update_instance(instance_id, data)

            # Start background thread for async deprovisioning
            thread = threading.Thread(
                target=self._deprovision_worker,
                args=(instance_id, data.copy()),
                daemon=True,
                name=f"deprovision-{instance_id}",
            )
            thread.start()
            logger.info(
                "Async deprovisioning started",
                extra={"instance_id": instance_id, "thread_name": thread.name},
            )
            return True
        else:
            # Synchronous deprovisioning
            try:
                # Run deprovisioning (already removes files from Git and commits/pushes)
                self._run_deprovision(instance_id, data)

                # Invalidate cache after deletion (deprovision already removed from Git)
                self.state_manager.clear_cache()
                logger.info("Cache cleared after deprovision", extra={"instance_id": instance_id})

                # Delete local metadata file
                path = self._get_instance_path(instance_id)
                if path.exists():
                    path.unlink()
                    logger.info("Local metadata file deleted", extra={"instance_id": instance_id})

                logger.info("Instance deleted", extra={"instance_id": instance_id})
                return True
            except Exception as e:
                # Invalidate cache on failure too
                self.state_manager.clear_cache()
                logger.error(
                    "Deprovisioning failed", extra={"instance_id": instance_id, "error": str(e)}
                )
                raise

    def exists(self, instance_id: str) -> bool:
        """Check if a service instance exists in Git.

        Args:
            instance_id: Instance identifier

        Returns:
            True if instance exists
        """
        return self.state_manager.exists(instance_id)

    def list_all(self) -> list[dict[str, Any]]:
        """List all service instances from Git.

        Returns:
            List of instance data dictionaries
        """
        return self.state_manager.list_instances()

    def dump_provision_variables(self, instance_id: str, variables: dict[str, Any]) -> None:
        """
        Dump provisioning variables to JSON file in instance directory.

        Creates a provision-variables.json file in the instance directory containing
        all variables used during provisioning. Sensitive data is automatically redacted.

        This method is called BEFORE schema validation and template rendering, which means
        the provision-variables.json file will be written to Git even if provisioning
        subsequently fails. This is intentional behavior to enable debugging of failed
        provision attempts.

        Args:
            instance_id: Service instance ID
            variables: Dictionary of all provisioning variables

        Note:
            - Feature must be enabled via dump_provision_variables_enabled flag
            - Errors are logged but do not fail provisioning (non-blocking)
            - File is written to Git repository via state manager
            - **Debug behavior**: This file is written BEFORE validation, so orphaned
              provision-variables.json files in Git are expected when provisioning fails
              due to validation errors or other issues. This allows inspection of the
              parameters that caused the failure.
        """
        if not self.dump_provision_variables_enabled:
            return

        try:
            # Sanitize sensitive data
            sanitized = self._sanitize_variables(variables)

            # Add metadata
            dump_data = {
                "metadata": {
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "instance_id": instance_id,
                    "feature_enabled": True,
                    "broker_version": "1.0.12",
                },
                "variables": sanitized,
            }

            # Write to instance directory in Git
            from broker.gitops.path_utils import get_instance_path

            repo_dir = self._get_gitops_repo_dir()
            if repo_dir is None:
                raise RuntimeError("Cannot access GitOps repository directory")

            # Extract service_type from variables (check computed section first, then top-level)
            computed = variables.get("computed", {})
            service_type = computed.get("service_type") or variables.get("service_type", "unknown")

            instance_dir = get_instance_path(repo_dir, instance_id, service_type)
            instance_dir.mkdir(parents=True, exist_ok=True)
            dump_file = instance_dir / "provision-variables.json"

            with open(dump_file, "w", encoding="utf-8") as f:
                json.dump(dump_data, f, indent=2, sort_keys=True)

            logger.info(
                "Provision variables dumped",
                extra={"instance_id": instance_id, "file": str(dump_file)},
            )
        except Exception as e:
            # Log error but don't fail provisioning
            logger.error(
                "Failed to dump provision variables",
                extra={"instance_id": instance_id, "error": str(e)},
            )

    def _sanitize_variables(self, variables: dict[str, Any]) -> dict[str, Any]:
        """
        Sanitize sensitive data from variables.

        Recursively scans the variables dictionary and replaces sensitive values
        with "<REDACTED>" placeholder. Sensitive keys are identified by common
        patterns like "password", "token", "secret", "key", etc.

        Args:
            variables: Dictionary of variables to sanitize

        Returns:
            Sanitized copy of variables dictionary
        """
        sensitive_keys = {
            "password",
            "passwd",
            "pwd",
            "token",
            "access_token",
            "refresh_token",
            "secret",
            "client_secret",
            "api_secret",
            "key",
            "api_key",
            "apikey",
            "private_key",
            "credential",
            "credentials",
            "auth",
            "authorization",
        }

        def sanitize_dict(d: dict[str, Any]) -> dict[str, Any]:
            """Recursively sanitize a dictionary."""
            result: dict[str, Any] = {}
            for k, v in d.items():
                key_lower = k.lower()
                # Check type first - always recurse into dicts and lists
                if isinstance(v, dict):
                    # Recurse into nested dict
                    result[k] = sanitize_dict(v)
                elif isinstance(v, list):
                    # Recurse into list items
                    result[k] = [
                        sanitize_dict(item) if isinstance(item, dict) else item for item in v
                    ]
                elif any(sensitive in key_lower for sensitive in sensitive_keys):
                    # Only redact primitive values with sensitive keys
                    result[k] = "<REDACTED>"
                else:
                    # Preserve non-sensitive primitive values
                    result[k] = v
            return result

        return sanitize_dict(variables)


# Made with Bob
