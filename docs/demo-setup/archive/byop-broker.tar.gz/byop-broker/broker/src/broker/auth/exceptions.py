"""Authentication-specific exceptions for JWT validation."""


class AuthenticationError(Exception):
    """Base exception for authentication errors."""

    pass


class InvalidTokenError(AuthenticationError):
    """Raised when JWT token is invalid or malformed."""

    pass


class TokenExpiredError(AuthenticationError):
    """Raised when JWT token has expired."""

    pass


class JWKSError(AuthenticationError):
    """Raised when JWKS fetching or processing fails."""

    pass


class MissingClaimError(InvalidTokenError):
    """Raised when required JWT claim is missing."""

    pass


class InvalidClaimError(InvalidTokenError):
    """Raised when JWT claim value is invalid."""

    pass


class InvalidSignatureError(InvalidTokenError):
    """Raised when JWT signature validation fails."""

    pass


class MissingAuthorizationError(AuthenticationError):
    """Raised when Authorization header is missing."""

    pass


class InvalidAuthorizationFormatError(AuthenticationError):
    """Raised when Authorization header format is invalid."""

    pass


# Made with Bob
