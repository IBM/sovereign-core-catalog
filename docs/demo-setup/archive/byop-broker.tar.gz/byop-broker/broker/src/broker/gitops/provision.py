"""Service Instance Provisioning Module.

This module provides functionality to provision service instances (MySQL, MariaDB, etc.) in a GitOps-managed
Kubernetes environment using ArgoCD for continuous deployment.

Overview:
    The provisioning process follows a GitOps workflow where all configuration is
    stored in a Git repository and ArgoCD automatically syncs changes to the cluster.
    This ensures declarative, version-controlled infrastructure management.

Workflow:
    1. Validate instance name and parameters
    2. Resolve target cluster URL from ArgoCD (if multi-cluster)
    3. Initialize Git operations and clone/update repository
    4. Generate instance-specific manifests:
       - Kubernetes Secret with MySQL credentials
       - Kustomization overlay referencing versioned service base
    5. Copy SBOM from published service version
    6. Commit and push changes to Git repository
    7. Create ArgoCD Application CR to manage deployment
    8. Apply Application to hub cluster
    9. Create metadata file for tracking

Architecture:
    - Hub-and-spoke model: Hub cluster (k3s-cluster-1) runs ArgoCD
    - ArgoCD manages deployments to hub and spoke clusters
    - Git repository is the single source of truth
    - Instance isolation through namespaces and labels
    - Versioned service bases published by services-ci pipeline

Service Versioning:
    - Services are published with incrementing versions (v1, v2, v3, etc.)
    - Each version contains manifests and SBOM
    - Instances reference specific service versions
    - 'latest' symlink always points to newest version

Key Functions:
    - provision_service_instance: Main orchestration function
    - _resolve_cluster_url: Lookup cluster URL from ArgoCD
    - _setup_git_operations: Initialize Git repository access
    - _create_instance_files: Generate Kubernetes manifests
    - _copy_sbom_from_service: Copy SBOM from published service
    - _apply_argocd_application: Create ArgoCD Application CR

Dependencies:
    - GitConfig: Configuration management for Git repository
    - GitOperations: Git operations (clone, commit, push)
    - kubectl: Kubernetes CLI for cluster operations
    - ArgoCD: Continuous deployment tool

Environment Variables:
    - GITOPS_REPO_URL: Git repository URL
    - GITOPS_BRANCH: Git branch (default: main)
    - SSH_PRIVATE_KEY or SSH_PRIVATE_KEY_PATH: Git authentication

Usage:
    This module is designed to be used as a library via the api.py interface.
    Direct CLI usage has been removed in version 1.0.0.

    Example:
        from broker.gitops.api import provision_instance

        result = provision_instance(
            instance_name="dev-001",
            service_type="mysql",
            cluster_name="k3s-cluster-1",
            environment="dev"
        )
"""

import json
import os
import re
import secrets
import string
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

from broker.gitops.git_config import GitConfig
from broker.gitops.git_operations import GitOperations, GitOperationsError
from broker.logging_config import get_logger


logger = get_logger(__name__)


# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))


def get_cluster_server_url(cluster_name: str) -> str | None:
    """Get the cluster server URL from AVAILABLE_CLUSTERS environment variable.

    This function reads cluster information from the AVAILABLE_CLUSTERS environment
    variable (set by Helm deployment) instead of querying Kubernetes API.
    This eliminates the need for oc or Kubernetes Python client.

    Args:
        cluster_name: Name of the cluster (e.g., 'k3s-cluster-2')

    Returns:
        Cluster server URL or None if not found

    Example:
        >>> os.environ['AVAILABLE_CLUSTERS'] = '[{"name":"k3s-cluster-1","server":"https://kubernetes.default.svc"}]'
        >>> url = get_cluster_server_url('k3s-cluster-1')
        >>> url
        'https://kubernetes.default.svc'
    """

    # Read cluster configuration from environment variable
    clusters_json = os.getenv("AVAILABLE_CLUSTERS")
    if not clusters_json:
        logger.warning(
            "AVAILABLE_CLUSTERS environment variable not set, using default for local cluster",
            extra={"cluster_name": cluster_name},
        )
        # Default to local cluster if not configured
        if cluster_name == "k3s-cluster-1":
            return "https://kubernetes.default.svc"
        return None

    try:
        clusters = json.loads(clusters_json)
        for cluster in clusters:
            if cluster.get("name") == cluster_name:
                server = cluster.get("server")
                return str(server) if server is not None else None
        return None
    except json.JSONDecodeError as e:
        logger.error("Failed to parse AVAILABLE_CLUSTERS", extra={"error": str(e)})
        return None


def generate_password(length: int = 16) -> str:
    """Generate a secure random password.

    Uses Python's secrets module for cryptographically strong random generation.
    The password includes uppercase, lowercase, digits, and special characters
    to meet common security requirements.

    Args:
        length: Password length (default: 16)

    Returns:
        Randomly generated password

    Example:
        >>> pwd = generate_password(20)
        >>> len(pwd)
        20
    """
    # Define character set: letters, digits, and safe special characters
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    # Use secrets.choice for cryptographically secure random selection
    return "".join(secrets.choice(alphabet) for _ in range(length))


def create_instance_directory(instance_name: str, service_type: str) -> Path:
    """Create directory structure for instance.

    Creates the instance directory within the GitOps repository structure.
    The directory will contain instance-specific manifests (secret, kustomization).

    Args:
        instance_name: Name of the service instance
        service_type: Type of service (e.g., 'mysql', 'postgres')

    Returns:
        Path to created instance directory

    Example:
        >>> path = create_instance_directory('test-001', 'mysql')  # doctest: +SKIP
    """
    from broker.gitops.path_utils import get_instance_path

    # Use GitConfig to get the correct repository directory
    repo_dir = GitConfig.get_repo_dir()
    # Create instance directory: <repo>/instances/<service_type>/<instance-name>
    instance_dir = get_instance_path(repo_dir, instance_name, service_type)
    # Create directory and any missing parent directories
    instance_dir.mkdir(parents=True, exist_ok=True)
    return instance_dir


def generate_argocd_application(
    instance_name: str,
    namespace: str,
    service_type: str,
    cluster_url: str | None = None,
    cluster_name: str | None = None,
    project: str = "default",
) -> dict[str, Any]:
    """Generate ArgoCD Application CR with cluster targeting.

    Args:
        instance_name: Name of the service instance
        namespace: Target namespace
        service_type: Type of service (e.g., 'postgres', 'redis', etc.) - REQUIRED
        cluster_url: Kubernetes API server URL
        cluster_name: Cluster name for reference (optional, for metadata)
        project: ArgoCD project name

    Returns:
        ArgoCD Application manifest dictionary

    Example:
        >>> app = generate_argocd_application('test-001', 'postgres-test-001', 'postgres')
        >>> app['kind']
        'Application'
    """
    import re

    # Get repository URL from GitConfig
    gitops_repo_path = GitConfig.get_repo_url()

    # Default to local cluster if not specified
    if not cluster_url:
        cluster_url = "https://kubernetes.default.svc"

    from broker.gitops.path_utils import get_argocd_app_path

    application: dict[str, Any] = {
        "apiVersion": "argoproj.io/v1alpha1",
        "kind": "Application",
        "metadata": {
            "name": instance_name,
            "namespace": "argocd",
            "labels": {
                "app": service_type,
                "service-type": service_type,
                "instance": instance_name,
            },
            "finalizers": ["resources-finalizer.argocd.argoproj.io"],
        },
        "spec": {
            "project": project,
            "source": {
                "repoURL": gitops_repo_path,
                "targetRevision": "HEAD",
                "path": get_argocd_app_path(instance_name, service_type),
            },
            "destination": {"server": cluster_url, "namespace": namespace},
            "syncPolicy": {
                "automated": {"prune": True, "selfHeal": True},
                "syncOptions": ["CreateNamespace=true"],
            },
        },
    }

    # Add cluster identifier to labels if provided
    # Sanitize cluster_name to be a valid Kubernetes label value
    if cluster_name:
        # Convert URL to valid label: remove protocol, replace special chars with hyphens
        # Valid label: alphanumeric, '-', '_', '.', max 63 chars, start/end with alphanumeric
        sanitized_name = re.sub(r"^https?://", "", cluster_name)  # Remove protocol
        sanitized_name = re.sub(r"[^a-zA-Z0-9._-]", "-", sanitized_name)  # Replace invalid chars
        sanitized_name = re.sub(r"-+", "-", sanitized_name)  # Collapse multiple hyphens
        sanitized_name = sanitized_name.strip("-._")  # Remove leading/trailing special chars
        sanitized_name = sanitized_name[:63]  # Truncate to max length

        if sanitized_name:  # Only add if we have a valid result
            application["metadata"]["labels"]["cluster"] = sanitized_name
            # Also add as annotation for reference (annotations allow full URL)
            if "annotations" not in application["metadata"]:
                application["metadata"]["annotations"] = {}
            application["metadata"]["annotations"]["cluster-url"] = cluster_url

    return application


def write_yaml_file(filepath: Path, data: dict[str, Any]) -> None:
    """Write YAML data to file.

    Args:
        filepath: Path to output file
        data: Data to write as YAML

    Example:
        >>> write_yaml_file(Path('test.yaml'), {'key': 'value'})  # doctest: +SKIP
    """
    # Ensure parent directory exists
    filepath.parent.mkdir(parents=True, exist_ok=True)

    with open(filepath, "w") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    logger.info(f"Created file: {filepath}")


def validate_instance_name(instance_name: str) -> None:
    """Validate instance name for Kubernetes compatibility.

    Args:
        instance_name: Name to validate

    Raises:
        SystemExit: If instance name is invalid

    Example:
        >>> validate_instance_name('test-001')
        >>> validate_instance_name('Test-001')  # doctest: +SKIP
        Traceback (most recent call last):
        ...
        SystemExit: 1
    """
    # Kubernetes resource names must match: [a-z0-9]([-a-z0-9]*[a-z0-9])?
    if not re.match(r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?$", instance_name):
        error_msg = (
            f"Invalid instance name '{instance_name}'. "
            "Kubernetes resource names must: "
            "(1) contain only lowercase letters, numbers, and hyphens; "
            "(2) start with a letter or number; "
            "(3) end with a letter or number; "
            "(4) NOT contain dots or other special characters. "
            "Valid examples: dev-001, prod-02, mysql-instance-1. "
            "Invalid examples: 02.01 (dot), Dev-001 (uppercase), -test (starts with hyphen)"
        )
        logger.error(error_msg)
        raise ValueError(error_msg)


def _resolve_cluster_url(
    cluster_name: str | None, cluster_url: str | None
) -> tuple[str | None, int]:
    """Resolve cluster URL from cluster name if needed.

    Args:
        cluster_name: Name of the cluster
        cluster_url: Explicit cluster URL (takes precedence)

    Returns:
        Tuple of (resolved_cluster_url, exit_code)
        exit_code is 0 for success, 1 for failure
    """
    if not cluster_name or cluster_url:
        return cluster_url, 0

    logger.info(f"Looking up cluster URL for {cluster_name}")
    resolved_url = get_cluster_server_url(cluster_name)
    if not resolved_url:
        logger.error(f"Cluster '{cluster_name}' not found in ArgoCD")
        try:
            result = subprocess.run(
                [
                    "oc",
                    "--context",
                    "k3s-cluster-1",
                    "get",
                    "secrets",
                    "-n",
                    "argocd",
                    "-l",
                    "argocd.argoproj.io/secret-type=cluster",
                ],
                capture_output=True,
                text=True,
                check=True,
            )
            logger.debug(f"Available clusters:\n{result.stdout}")
        except subprocess.CalledProcessError:
            logger.debug("Could not list available clusters")
        logger.error("Make sure the cluster is registered with ArgoCD on k3s-cluster-1")
        return None, 1
    logger.info(f"Found cluster URL: {resolved_url}")
    return resolved_url, 0


def _setup_git_operations() -> tuple[GitOperations | None, int]:
    """Initialize and setup Git operations.

    Returns:
        Tuple of (GitOperations instance, exit_code)
        exit_code is 0 for success, 1 for failure
    """
    logger.info("Initializing Git operations")
    try:
        GitConfig.validate_config()
        git_ops = GitOperations()
        git_ops.ensure_repo_cloned()
        git_ops.pull_latest()
        logger.info("Git repository ready")
        return git_ops, 0
    except GitOperationsError as e:
        logger.error(f"Git operations failed: {e}")
        logger.error(
            "Please check: (1) GITOPS_REPO_URL is set correctly; "
            "(2) Authentication is configured (SSH key or PAT); "
            "(3) Repository exists and is accessible"
        )
        return None, 1
    except Exception as e:
        logger.error(f"Unexpected error during Git setup: {e}")
        return None, 1


def _create_instance_files(
    instance_name: str,
    namespace: str,
    replicas: int,
    storage_size: str,
    service_type: str,
    service_version: str = "latest",
    image_pull_secret_name: str | None = None,
    registry_server: str | None = None,
    registry_username: str | None = None,
    registry_password: str | None = None,
    registry_email: str | None = None,
    instance_id: str | None = None,
    cluster_name: str | None = None,
    cluster_url: str | None = None,
    environment: str = "dev",
    deployment_registry: str | None = None,
    parameters_spec: dict[str, Any] | None = None,
    context: dict[str, Any] | None = None,
    broker_plan_id: str | None = None,
) -> Path:
    """Create instance directory and generate manifests.

    This function supports two provisioning approaches:
    1. Pure Kustomize with Helm rendering (if helm_config present in catalog)
    2. Template-based provisioning (standard approach)

    Args:
        instance_name: Name of the service instance
        namespace: Kubernetes namespace
        replicas: Number of replicas
        storage_size: Storage size for PVC
        service_type: Type of service (e.g., 'mysql', 'mariadb')
        service_version: Service version to use (e.g., 'v1', 'v2', or 'latest')
        image_pull_secret_name: Optional image pull secret name
        registry_server: Optional registry server hostname (unused, kept for compatibility)
        registry_username: Optional registry username (unused, kept for compatibility)
        registry_password: Optional registry password (unused, kept for compatibility)
        registry_email: Optional registry email (unused, kept for compatibility)
        instance_id: Unique instance ID
        cluster_name: Target cluster name
        cluster_url: Target cluster URL
        environment: Environment (dev/staging/prod)
        deployment_registry: Deployment registry path
        parameters_spec: User-provided service-specific parameters
        context: Additional context from OSB API
        broker_plan_id: Broker plan ID

    Returns:
        Path to instance directory

    Raises:
        ValueError: If templates are not found for the service
    """
    from broker.gitops.provision_templates import (
        check_template_support,
        create_instance_files_from_templates,
        create_instance_files_with_kustomize,
    )

    if not check_template_support(service_type, service_version):
        raise ValueError(
            f"No templates found for service '{service_type}' version '{service_version}'. "
            f"Please ensure service templates are published to the GitOps repository."
        )

    # Load catalog to check for helm_config
    repo_dir = GitConfig.get_repo_dir()
    catalog_file = (
        repo_dir / "services" / service_type / service_version / "catalog" / "catalog.yaml"
    )
    helm_config = None

    if catalog_file.exists():
        try:
            with open(catalog_file, encoding="utf-8") as f:
                catalog_data = yaml.safe_load(f)
                if isinstance(catalog_data, dict):
                    helm_config = catalog_data.get("helm_config")
        except Exception as e:
            logger.warning(f"Failed to load catalog.yaml from {catalog_file}: {e}")

    # Choose provisioning approach based on helm_config presence
    if helm_config:
        logger.info(f"Using pure Kustomize provisioning with Helm rendering for {service_type}")
        instance_dir, _ = create_instance_files_with_kustomize(
            instance_name=instance_name,
            instance_id=instance_id or instance_name,
            namespace=namespace,
            service_type=service_type,
            service_version=service_version,
            cluster_name=cluster_name or "default",
            cluster_url=cluster_url,
            environment=environment,
            replicas=replicas,
            storage_size=storage_size,
            deployment_registry=deployment_registry,
            image_pull_secret_name=image_pull_secret_name,
            parameters_spec=parameters_spec,
            context=context,
            broker_plan_id=broker_plan_id,
            helm_config=helm_config,
        )
    else:
        logger.info(f"Using template-based provisioning for {service_type}")
        instance_dir, _ = create_instance_files_from_templates(
            instance_name=instance_name,
            instance_id=instance_id or instance_name,
            namespace=namespace,
            service_type=service_type,
            service_version=service_version,
            cluster_name=cluster_name or "default",
            cluster_url=cluster_url,
            environment=environment,
            replicas=replicas,
            storage_size=storage_size,
            deployment_registry=deployment_registry,
            image_pull_secret_name=image_pull_secret_name,
            parameters_spec=parameters_spec,
            context=context,
            broker_plan_id=broker_plan_id,
        )

    return instance_dir


def _commit_changes(
    git_ops: GitOperations, instance_name: str, service_type: str, dry_run: bool = False
) -> None:
    """Commit and push changes to Git repository.

    Args:
        git_ops: GitOperations instance
        instance_name: Name of the service instance
        service_type: Type of service (e.g., 'mysql', 'mariadb')
        dry_run: If True, skip Git push (dry-run mode)
    """
    if dry_run:
        logger.info("Dry-run mode: Skipping Git commit and push")
        return

    logger.info("Committing changes to Git")
    try:
        git_ops.commit_and_push(
            message=f"Add {service_type} instance: {instance_name}",
            author_name="GitOps Orchestrator",
            author_email="gitops@example.com",
        )
        logger.info("Changes committed and pushed to Git repository")
    except GitOperationsError as e:
        logger.warning(f"Git operation failed: {e}")
        logger.warning(
            "Instance files created but not pushed to remote - manual commit may be needed"
        )
    except Exception as e:
        logger.warning(f"Git operation failed: {e}")


def _copy_sbom_from_service(
    instance_name: str, service_type: str, service_version: str, instance_dir: Path
) -> None:
    """Copy SBOM files from services-ci published service.

    Args:
        instance_name: Name of the service instance
        service_type: Type of service (e.g., 'mysql', 'mariadb')
        service_version: Service version (e.g., 'v1', 'v2', or 'latest')
        instance_dir: Path to instance directory
    """
    logger.info(f"Copying SBOM from published service {service_type}/{service_version}")
    try:
        # Get the GitOps repo directory
        repo_dir = GitConfig.get_repo_dir()

        # Source SBOM directory from published service
        service_sbom_dir = repo_dir / "services" / service_type / service_version / "sbom"

        if not service_sbom_dir.exists():
            logger.warning(
                f"SBOM not found in service {service_type}/{service_version} - "
                "service may not have been published with SBOM. Continuing without SBOM (non-critical)"
            )
            return

        # Create instance sbom subdirectory
        instance_sbom_dir = instance_dir / "sbom"
        instance_sbom_dir.mkdir(parents=True, exist_ok=True)

        # Copy all SBOM files from service to instance
        import shutil

        copied_files = []
        for sbom_file in service_sbom_dir.glob("*"):
            if sbom_file.is_file():
                dest_file = instance_sbom_dir / sbom_file.name
                shutil.copy2(sbom_file, dest_file)
                copied_files.append(sbom_file.name)

        if copied_files:
            logger.info(f"Copied SBOM files from service: {', '.join(copied_files)}")
        else:
            logger.warning("No SBOM files found in service directory")

    except Exception as e:
        logger.warning(f"Failed to copy SBOM: {e}. Continuing without SBOM (non-critical)")


def _has_subdirectory_structure(instance_dir: Path) -> bool:
    """Check if instance uses subdirectory structure.

    Returns True if main/ subdirectory exists with files.
    This indicates the instance uses subdirectory-based organization
    (e.g., main/, auth/, cdi-clone/) rather than flat structure.

    Args:
        instance_dir: Path to instance directory

    Returns:
        True if subdirectory structure detected, False otherwise
    """
    main_dir = instance_dir / "main"
    return main_dir.exists() and main_dir.is_dir() and any(main_dir.iterdir())


def _create_metadata(
    instance_dir: Path,
    instance_name: str,
    namespace: str,
    environment: str,
    replicas: int,
    storage_size: str,
    cluster_url: str | None,
    cluster_name: str | None,
    service_type: str,
    image: str,
    image_pull_secret_name: str | None = None,
    registry_server: str | None = None,
    deployment_registry: str | None = None,
    broker_service_id: str | None = None,
    broker_plan_id: str | None = None,
) -> None:
    """Create metadata file(s) for the instance.

    If instance uses subdirectory structure (main/, auth/, etc.),
    creates metadata.yaml in each subdirectory for ArgoCD ApplicationSet
    discovery. Otherwise, creates metadata.yaml at instance root for
    backward compatibility with flat structures.

    Args:
        instance_dir: Path to instance directory
        instance_name: Name of the service instance
        namespace: Kubernetes namespace
        environment: Environment name
        replicas: Number of replicas
        storage_size: Storage size
        cluster_url: Target cluster URL
        cluster_name: Target cluster name
        service_type: Type of service (mysql, mariadb, etc.)
        image: Container image reference
        image_pull_secret_name: Optional image pull secret name
        registry_server: Optional registry server hostname
        deployment_registry: Optional deployment registry path
        broker_service_id: Optional broker service ID
        broker_plan_id: Optional broker plan ID
    """
    logger.info("Creating instance metadata")
    try:
        # Ensure instance directory exists (it should, but verify)
        instance_dir.mkdir(parents=True, exist_ok=True)

        # Build metadata dictionary
        metadata: dict[str, Any] = {
            "instance_name": instance_name,
            "namespace": namespace,
            "service_type": service_type,
            "environment": environment,
            "replicas": replicas,
            "storage_size": storage_size,
            "image": image,
            "created_at": datetime.now().isoformat(),
            "status": "provisioned",
            "sbom_available": (instance_dir / "sbom").exists(),
        }
        if broker_service_id:
            metadata["service_id"] = broker_service_id
        if broker_plan_id:
            metadata["plan_id"] = broker_plan_id
        if image_pull_secret_name:
            metadata["image_pull_secret_name"] = image_pull_secret_name
        if registry_server:
            metadata["registry_server"] = registry_server
        if deployment_registry:
            metadata["deployment_registry"] = deployment_registry
        if cluster_url:
            metadata["cluster_url"] = cluster_url
        if cluster_name:
            metadata["cluster_name"] = cluster_name

        # Check if using subdirectory structure
        if _has_subdirectory_structure(instance_dir):
            # Create metadata in each subdirectory for ApplicationSet discovery
            subdirs_created = []
            for subdir in instance_dir.iterdir():
                if subdir.is_dir() and not subdir.name.startswith("."):
                    metadata_file = subdir / "metadata.yaml"
                    write_yaml_file(metadata_file, metadata)
                    subdirs_created.append(subdir.name)
            logger.info(f"Created metadata in subdirectories: {', '.join(subdirs_created)}")
        else:
            # Backward compatible: create at root for flat structures
            metadata_file = instance_dir / "metadata.yaml"
            write_yaml_file(metadata_file, metadata)
            logger.info("Created metadata at instance root (flat structure)")

    except Exception as e:
        # Metadata creation is non-critical - log warning but don't fail provisioning
        logger.warning(
            f"Could not create metadata file: {e}. Provisioning succeeded, but metadata tracking unavailable"
        )


def _get_next_steps_info(
    instance_name: str, namespace: str, service_type: str, cluster_name: str | None
) -> dict[str, Any]:
    """Get next steps information for the provisioned instance.

    This function returns structured data that can be formatted by the CLI or API.
    Replaces the old _print_next_steps function.

    Args:
        instance_name: Name of the service instance
        namespace: Kubernetes namespace
        service_type: Type of service (e.g., 'mysql', 'mariadb')
        cluster_name: Target cluster name

    Returns:
        Dictionary containing next steps information
    """
    target_context = (
        cluster_name if cluster_name and cluster_name != "k3s-cluster-1" else "k3s-cluster-1"
    )

    return {
        "success": True,
        "instance_name": instance_name,
        "namespace": namespace,
        "service_type": service_type,
        "cluster_name": cluster_name or "k3s-cluster-1",
        "next_steps": [
            "Hub ArgoCD will automatically detect and deploy the application",
            f"Check ArgoCD status: oc --context=k3s-cluster-1 get application {service_type}-{instance_name} -n argocd",
            f"Check service pods: oc --context={target_context} get pods -n {instance_name}",
            f"Get credentials: oc --context={target_context} get secret {service_type}-secret -n {instance_name} -o yaml",
        ],
    }


# Made with Bob
