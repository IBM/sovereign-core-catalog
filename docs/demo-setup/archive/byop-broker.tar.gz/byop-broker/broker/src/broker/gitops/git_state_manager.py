"""
Git-based state manager for stateless broker operation.

This module provides a GitStateManager class that uses the Git repository
as the single source of truth for all broker state, with in-memory caching
for performance.
"""

import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from broker.logging_config import get_logger


logger = get_logger(__name__)


@dataclass
class CacheEntry:
    """Cache entry with data, timestamp, and commit hash for optimistic locking."""

    data: Any
    timestamp: float
    commit_hash: str


class GitStateManagerError(Exception):
    """Custom exception for GitStateManager errors."""

    pass


class GitStateManager:
    """
    Git-based state manager with in-memory caching.

    This class provides stateless broker operation by using the Git repository
    as the single source of truth. Multiple broker instances can run concurrently
    without state conflicts.

    Features:
    - In-memory caching with TTL
    - Optimistic locking for concurrent writes
    - Automatic retry with exponential backoff
    - Thread-safe cache operations
    """

    def __init__(
        self,
        git_ops: Any,
        cache_ttl: int = 30,
        cache_enabled: bool = True,
        max_retries: int = 3,
        retry_backoff: float = 1.0,
    ) -> None:
        """
        Initialize GitStateManager.

        Args:
            git_ops: GitOperations instance for Git interactions
            cache_ttl: Cache time-to-live in seconds (default: 30)
            cache_enabled: Enable/disable caching (default: True)
            max_retries: Maximum retry attempts for write operations (default: 3)
            retry_backoff: Initial backoff time in seconds for retries (default: 1.0)
        """
        self.git_ops = git_ops
        self.cache_ttl = cache_ttl
        self.cache_enabled = cache_enabled
        self.max_retries = max_retries
        self.retry_backoff = retry_backoff

        # Thread-safe cache
        self.cache: dict[str, CacheEntry] = {}
        self.cache_lock = threading.Lock()

        logger.info(
            "GitStateManager initialized",
            extra={
                "cache_ttl": cache_ttl,
                "cache_enabled": cache_enabled,
                "max_retries": max_retries,
            },
        )

    def _get_cache_key(self, key_type: str, identifier: str | None = None) -> str:
        """Generate cache key.

        Args:
            key_type: Type of cache entry (instance, instances_list, catalog, clusters)
            identifier: Optional identifier (e.g., instance_id)

        Returns:
            Cache key string
        """
        if identifier:
            return f"{key_type}:{identifier}"
        return key_type

    def _is_cache_valid(self, entry: CacheEntry) -> bool:
        """Check if cache entry is still valid.

        Args:
            entry: Cache entry to check

        Returns:
            True if cache entry is valid (not expired)
        """
        if not self.cache_enabled:
            return False
        age = time.time() - entry.timestamp
        return age < self.cache_ttl

    def _get_from_cache(self, cache_key: str) -> Any | None:
        """Get data from cache if valid.

        Args:
            cache_key: Cache key to lookup

        Returns:
            Cached data or None if not found/expired
        """
        with self.cache_lock:
            entry = self.cache.get(cache_key)
            if entry and self._is_cache_valid(entry):
                logger.info(
                    "Cache hit",
                    extra={"cache_key": cache_key, "age": time.time() - entry.timestamp},
                )
                return entry.data
            if entry:
                logger.info(
                    "Cache expired",
                    extra={"cache_key": cache_key, "age": time.time() - entry.timestamp},
                )
            return None

    def _put_in_cache(self, cache_key: str, data: Any, commit_hash: str) -> None:
        """Store data in cache.

        Args:
            cache_key: Cache key
            data: Data to cache
            commit_hash: Current Git commit hash for optimistic locking
        """
        if not self.cache_enabled:
            return

        with self.cache_lock:
            self.cache[cache_key] = CacheEntry(
                data=data, timestamp=time.time(), commit_hash=commit_hash
            )
            logger.info(
                "Cache updated", extra={"cache_key": cache_key, "commit_hash": commit_hash[:8]}
            )

    def _invalidate_cache(self, cache_key: str | None = None) -> None:
        """Invalidate cache entry or entire cache.

        Args:
            cache_key: Specific cache key to invalidate, or None to clear all
        """
        with self.cache_lock:
            if cache_key:
                if cache_key in self.cache:
                    del self.cache[cache_key]
                    logger.info("Cache invalidated", extra={"cache_key": cache_key})
            else:
                self.cache.clear()
                logger.info("Cache cleared")

    def _get_repo_dir(self) -> Path:
        """Get Git repository directory.

        Returns:
            Path to Git repository working directory
        """
        repo_dir: Path = self.git_ops.repo_dir
        return repo_dir

    def _find_metadata_file(self, instance_dir: Path) -> Path | None:
        """Find metadata.yaml file in instance directory.

        Supports both subdirectory structure (main/metadata.yaml) and
        flat structure (metadata.yaml) for backward compatibility.

        Args:
            instance_dir: Path to instance directory

        Returns:
            Path to metadata.yaml file or None if not found
        """
        # Try subdirectory structure first (new pattern)
        # Check for main/metadata.yaml (most common subdirectory)
        main_metadata = instance_dir / "main" / "metadata.yaml"
        if main_metadata.exists():
            logger.debug(
                "Found metadata in subdirectory structure",
                extra={"metadata_file": str(main_metadata)},
            )
            return main_metadata

        # Fall back to flat structure (old pattern)
        root_metadata = instance_dir / "metadata.yaml"
        if root_metadata.exists():
            logger.debug(
                "Found metadata in flat structure",
                extra={"metadata_file": str(root_metadata)},
            )
            return root_metadata

        # Not found in either location
        return None

    def _read_instance_from_git(self, instance_id: str) -> dict[str, Any] | None:
        """Read instance metadata from Git repository.

        Supports both subdirectory structure (main/metadata.yaml) and
        flat structure (metadata.yaml) for backward compatibility.

        Args:
            instance_id: Instance identifier

        Returns:
            Instance metadata dictionary or None if not found
        """

        repo_dir = self._get_repo_dir()

        # Try to find instance by scanning service type directories
        instances_dir = repo_dir / "instances"
        if not instances_dir.exists():
            return None

        # Search for instance across all service type directories
        metadata_file = None
        for service_dir in instances_dir.iterdir():
            if not service_dir.is_dir():
                continue

            instance_dir = service_dir / instance_id
            if not instance_dir.exists():
                continue

            # Try to find metadata file (subdirectory or flat structure)
            metadata_file = self._find_metadata_file(instance_dir)
            if metadata_file:
                # Found the instance
                break
        else:
            # Instance not found in any service directory
            return None

        try:
            with open(metadata_file, encoding="utf-8") as f:
                metadata = yaml.safe_load(f)

            service_id = metadata.get("service_id")
            if service_id is None:
                service_type = metadata.get("service_type")
                if service_type:
                    service_id = service_type
                else:
                    # No service_type in metadata - this is a data integrity issue
                    logger.warning(
                        "Missing service_type in metadata, using 'unknown'",
                        extra={"metadata_file": str(metadata_file)},
                    )
                    service_id = "unknown"

            plan_id = metadata.get("plan_id")
            if plan_id is None:
                plan_id = metadata.get("environment", "dev")

            # Build Git repository URL for description
            # Convert git URL to web URL pointing to instance directory
            # TODO: Implement Git URL conversion when repo_url and branch are available
            # if hasattr(self.git_ops, 'repo_url') and hasattr(self.git_ops, 'branch'):
            #     repo_url = self.git_ops.repo_url
            #     branch = self.git_ops.branch
            #
            #     # Convert Git URL to web URL
            #     if repo_url.startswith("https://") or repo_url.startswith("http://"):
            #         # HTTP(S) URL - remove .git suffix if present
            #         web_url = repo_url.rstrip("/")
            #         if web_url.endswith(".git"):
            #             web_url = web_url[:-4]
            #         git_url = f"{web_url}/tree/{branch}/instances/{instance_id}"
            #     elif repo_url.startswith("git@") or repo_ur.startswith("ssh://"):
            #         # SSH URL - convert to HTTPS
            #         # git@github.com:org/repo.git -> https://github.com/org/repo
            #         parts = repo_url.replace("git@", "").replace(":", "/").rstrip("/")
            #         if parts.endswith(".git"):
            #             parts = parts[:-4]
            #         git_url = f"https://{parts}/tree/{branch}/instances/{instance_id}"

            instance_data = {
                "instance_id": instance_id,
                "service_id": service_id,
                "plan_id": plan_id,
                "parameters": {
                    "cluster_name": metadata.get("cluster_name"),
                    "replicas": metadata.get("replicas", 1),
                    "storage_size": metadata.get("storage_size", "10Gi"),
                    "environment": metadata.get("environment", "dev"),
                },
                "state": "succeeded",
                "description": f"{service_id} instance successfully provisioned to Git",
                "created_at": metadata.get("created_at", datetime.now(timezone.utc).isoformat()),
                "updated_at": metadata.get("updated_at", datetime.now(timezone.utc).isoformat()),
            }

            return instance_data

        except Exception as e:
            logger.error(
                "Failed to read instance from Git",
                extra={"instance_id": instance_id, "error": str(e)},
            )
            return None

    def _write_instance_to_git(self, instance_id: str, data: dict[str, Any]) -> None:
        """Write instance metadata to Git repository.

        Args:
            instance_id: Instance identifier
            data: Instance data to write
        """
        from broker.gitops.path_utils import get_instance_path

        repo_dir = self._get_repo_dir()

        # Extract service_type from data
        service_type = data.get("service_type")
        if not service_type:
            # Derive service_type from service_id by removing -service suffix
            # This handles backward compatibility with old instances that have
            # service_id with -service suffix but service_type without it
            service_id = data.get("service_id", "")
            service_type = service_id.removesuffix("-service") if service_id else "unknown"

        instance_dir = get_instance_path(repo_dir, instance_id, service_type)
        instance_dir.mkdir(parents=True, exist_ok=True)

        metadata_file = instance_dir / "metadata.yaml"

        # Convert from broker format to Git format
        metadata = {
            "service_id": data.get("service_id"),
            "plan_id": data.get("plan_id"),
            "service_type": service_type,
            "plan": data.get("plan", data.get("plan_id")),
            "cluster_name": data.get("parameters", {}).get("cluster_name"),
            "replicas": data.get("parameters", {}).get("replicas", 1),
            "storage_size": data.get("parameters", {}).get("storage_size", "10Gi"),
            "environment": data.get("parameters", {}).get("environment", "dev"),
            "created_at": data.get("created_at", datetime.now(timezone.utc).isoformat()),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }

        with open(metadata_file, "w", encoding="utf-8") as f:
            yaml.dump(metadata, f, default_flow_style=False)

        logger.info(
            "Instance written to Git",
            extra={"instance_id": instance_id, "path": str(metadata_file)},
        )

    def _delete_instance_from_git(self, instance_id: str) -> None:
        """Delete instance from Git repository.

        Args:
            instance_id: Instance identifier
        """
        repo_dir = self._get_repo_dir()

        # Search for instance across all service type directories
        instances_dir = repo_dir / "instances"
        if not instances_dir.exists():
            return

        for service_dir in instances_dir.iterdir():
            if not service_dir.is_dir():
                continue

            instance_dir = service_dir / instance_id
            if instance_dir.exists():
                import shutil

                shutil.rmtree(instance_dir)
                logger.info(
                    "Instance deleted from Git",
                    extra={"instance_id": instance_id, "path": str(instance_dir)},
                )
                return

        logger.warning("Instance not found for deletion", extra={"instance_id": instance_id})

    def get_instance(self, instance_id: str) -> dict[str, Any] | None:
        """
        Get instance metadata from Git (with caching).

        Args:
            instance_id: Instance identifier

        Returns:
            Instance metadata or None if not found
        """
        cache_key = self._get_cache_key("instance", instance_id)

        # Try cache first
        cached_data = self._get_from_cache(cache_key)
        if cached_data is not None:
            result: dict[str, Any] | None = cached_data
            return result

        # Pull latest from Git
        try:
            self.git_ops.pull_latest()
        except Exception as e:
            logger.warning("Failed to pull latest from Git", extra={"error": str(e)})
            # Continue with existing repo state

        # Read from Git
        instance_data = self._read_instance_from_git(instance_id)

        # Cache the result
        if instance_data:
            commit_hash = self.git_ops.get_current_commit()
            self._put_in_cache(cache_key, instance_data, commit_hash)

        return instance_data

    def list_instances(self) -> list[dict[str, Any]]:
        """
        List all instances from Git (with caching).

        Returns:
            List of instance metadata dictionaries
        """
        cache_key = self._get_cache_key("instances_list")

        # Try cache first
        cached_data = self._get_from_cache(cache_key)
        if cached_data is not None:
            result: list[dict[str, Any]] = cached_data
            return result

        # Pull latest from Git
        try:
            self.git_ops.pull_latest()
        except Exception as e:
            logger.warning("Failed to pull latest from Git", extra={"error": str(e)})

        # Read all instances from Git (now organized by service type)
        repo_dir = self._get_repo_dir()
        instances_dir = repo_dir / "instances"

        instances = []
        if instances_dir.exists():
            # Iterate through service type directories
            for service_dir in instances_dir.iterdir():
                if not service_dir.is_dir():
                    continue

                # Iterate through instances within each service type
                for instance_path in service_dir.iterdir():
                    if not instance_path.is_dir():
                        continue

                    instance_id = instance_path.name
                    instance_data = self._read_instance_from_git(instance_id)
                    if instance_data:
                        instances.append(instance_data)

        # Cache the result
        commit_hash = self.git_ops.get_current_commit()
        self._put_in_cache(cache_key, instances, commit_hash)

        logger.info("Listed instances from Git", extra={"count": len(instances)})
        return instances

    def create_instance(self, instance_id: str, data: dict[str, Any]) -> None:
        """
        Create instance in Git with optimistic locking.

        Args:
            instance_id: Instance identifier
            data: Instance data

        Raises:
            GitStateManagerError: If creation fails after retries
        """
        for attempt in range(self.max_retries):
            try:
                # Pull latest
                self.git_ops.pull_latest()

                # Check if already exists
                if self._read_instance_from_git(instance_id):
                    raise GitStateManagerError(f"Instance {instance_id} already exists")

                # Write to Git
                self._write_instance_to_git(instance_id, data)

                # Commit and push
                self.git_ops.commit_and_push(f"Create instance {instance_id}")

                # Invalidate cache
                self._invalidate_cache(self._get_cache_key("instance", instance_id))
                self._invalidate_cache(self._get_cache_key("instances_list"))

                logger.info("Instance created in Git", extra={"instance_id": instance_id})
                return

            except Exception as e:
                if attempt == self.max_retries - 1:
                    logger.error(
                        "Failed to create instance after retries",
                        extra={
                            "instance_id": instance_id,
                            "attempts": attempt + 1,
                            "error": str(e),
                        },
                    )
                    raise GitStateManagerError(f"Failed to create instance: {e}") from e

                # Exponential backoff
                backoff = self.retry_backoff * (2**attempt)
                logger.warning(
                    "Retrying instance creation",
                    extra={"instance_id": instance_id, "attempt": attempt + 1, "backoff": backoff},
                )
                time.sleep(backoff)

    def update_instance(self, instance_id: str, data: dict[str, Any]) -> None:
        """
        Update instance in Git with optimistic locking.

        Args:
            instance_id: Instance identifier
            data: Updated instance data

        Raises:
            GitStateManagerError: If update fails after retries
        """
        for attempt in range(self.max_retries):
            try:
                # Pull latest
                self.git_ops.pull_latest()

                # Check if exists
                existing = self._read_instance_from_git(instance_id)
                if not existing:
                    raise GitStateManagerError(f"Instance {instance_id} not found")

                # Merge with existing data
                merged_data = {**existing, **data}
                merged_data["updated_at"] = datetime.now(timezone.utc).isoformat()

                # Write to Git
                self._write_instance_to_git(instance_id, merged_data)

                # Commit and push
                self.git_ops.commit_and_push(f"Update instance {instance_id}")

                # Invalidate cache
                self._invalidate_cache(self._get_cache_key("instance", instance_id))
                self._invalidate_cache(self._get_cache_key("instances_list"))

                logger.info("Instance updated in Git", extra={"instance_id": instance_id})
                return

            except Exception as e:
                if attempt == self.max_retries - 1:
                    logger.error(
                        "Failed to update instance after retries",
                        extra={
                            "instance_id": instance_id,
                            "attempts": attempt + 1,
                            "error": str(e),
                        },
                    )
                    raise GitStateManagerError(f"Failed to update instance: {e}") from e

                # Exponential backoff
                backoff = self.retry_backoff * (2**attempt)
                logger.warning(
                    "Retrying instance update",
                    extra={"instance_id": instance_id, "attempt": attempt + 1, "backoff": backoff},
                )
                time.sleep(backoff)

    def delete_instance(self, instance_id: str) -> bool:
        """
        Delete instance from Git with optimistic locking.

        Args:
            instance_id: Instance identifier

        Returns:
            True if deleted, False if not found

        Raises:
            GitStateManagerError: If deletion fails after retries
        """
        for attempt in range(self.max_retries):
            try:
                # Pull latest
                self.git_ops.pull_latest()

                # Check if exists
                if not self._read_instance_from_git(instance_id):
                    logger.info(
                        "Instance not found for deletion", extra={"instance_id": instance_id}
                    )
                    return False

                # Delete from Git
                self._delete_instance_from_git(instance_id)

                # Commit and push
                self.git_ops.commit_and_push(f"Delete instance {instance_id}")

                # Invalidate cache
                self._invalidate_cache(self._get_cache_key("instance", instance_id))
                self._invalidate_cache(self._get_cache_key("instances_list"))

                logger.info("Instance deleted from Git", extra={"instance_id": instance_id})
                return True

            except Exception as e:
                if attempt == self.max_retries - 1:
                    logger.error(
                        "Failed to delete instance after retries",
                        extra={
                            "instance_id": instance_id,
                            "attempts": attempt + 1,
                            "error": str(e),
                        },
                    )
                    raise GitStateManagerError(f"Failed to delete instance: {e}") from e

                # Exponential backoff
                backoff = self.retry_backoff * (2**attempt)
                logger.warning(
                    "Retrying instance deletion",
                    extra={"instance_id": instance_id, "attempt": attempt + 1, "backoff": backoff},
                )
                time.sleep(backoff)

        return False

    def exists(self, instance_id: str) -> bool:
        """
        Check if instance exists in Git.

        Args:
            instance_id: Instance identifier

        Returns:
            True if instance exists
        """
        return self.get_instance(instance_id) is not None

    def clear_cache(self) -> None:
        """Clear all cache entries."""
        self._invalidate_cache()

    def get_cache_stats(self) -> dict[str, Any]:
        """
        Get cache statistics.

        Returns:
            Dictionary with cache statistics
        """
        with self.cache_lock:
            total_entries = len(self.cache)
            valid_entries = sum(1 for entry in self.cache.values() if self._is_cache_valid(entry))

            return {
                "enabled": self.cache_enabled,
                "ttl": self.cache_ttl,
                "total_entries": total_entries,
                "valid_entries": valid_entries,
                "expired_entries": total_entries - valid_entries,
            }


# Made with Bob
