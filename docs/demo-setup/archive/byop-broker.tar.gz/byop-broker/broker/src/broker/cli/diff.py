"""Diff utilities for comparing configuration files.

This module provides utilities for displaying differences between
configuration files (YAML/JSON) with syntax highlighting.
"""

import difflib
import json
from typing import Any

import yaml
from rich.console import Console
from rich.syntax import Syntax


console = Console()


def format_yaml(data: dict[str, Any]) -> str:
    """Format dictionary as YAML string.

    Args:
        data: Dictionary to format

    Returns:
        YAML formatted string
    """
    return yaml.dump(data, default_flow_style=False, sort_keys=False)


def format_json(data: dict[str, Any]) -> str:
    """Format dictionary as JSON string.

    Args:
        data: Dictionary to format

    Returns:
        JSON formatted string with indentation
    """
    return json.dumps(data, indent=2, sort_keys=False)


def generate_unified_diff(
    old_content: str,
    new_content: str,
    old_label: str = "before",
    new_label: str = "after",
    context_lines: int = 3,
) -> str:
    """Generate unified diff between two strings.

    Args:
        old_content: Original content
        new_content: Modified content
        old_label: Label for old content
        new_label: Label for new content
        context_lines: Number of context lines to show

    Returns:
        Unified diff as string
    """
    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)

    diff = difflib.unified_diff(
        old_lines,
        new_lines,
        fromfile=old_label,
        tofile=new_label,
        lineterm="",
        n=context_lines,
    )

    return "".join(diff)


def display_diff(
    old_content: str,
    new_content: str,
    filename: str,
    title: str | None = None,
) -> None:
    """Display a unified diff with syntax highlighting.

    Args:
        old_content: Original content
        new_content: Modified content
        filename: Name of file being compared
        title: Optional title for the diff display
    """
    if title:
        console.print(f"\n[bold cyan]{title}[/bold cyan]")

    diff_text = generate_unified_diff(
        old_content,
        new_content,
        old_label=f"{filename} (before)",
        new_label=f"{filename} (after)",
    )

    if not diff_text:
        console.print(f"[dim]No changes in {filename}[/dim]")
        return

    # Display with syntax highlighting
    syntax = Syntax(diff_text, "diff", theme="monokai", line_numbers=False)
    console.print(syntax)


def compare_dicts(
    old_data: dict[str, Any],
    new_data: dict[str, Any],
    format_type: str = "yaml",
) -> tuple[str, str]:
    """Compare two dictionaries and return formatted strings.

    Args:
        old_data: Original dictionary
        new_data: Modified dictionary
        format_type: Format to use ('yaml' or 'json')

    Returns:
        Tuple of (old_formatted, new_formatted)
    """
    if format_type == "json":
        old_str = format_json(old_data)
        new_str = format_json(new_data)
    else:
        old_str = format_yaml(old_data)
        new_str = format_yaml(new_data)

    return old_str, new_str


def display_parameter_changes(
    old_params: dict[str, Any],
    new_params: dict[str, Any],
) -> None:
    """Display parameter changes in a readable format.

    Args:
        old_params: Original parameters
        new_params: Modified parameters
    """
    console.print("\n[bold]Parameter Changes:[/bold]")

    # Find all keys
    all_keys = set(old_params.keys()) | set(new_params.keys())

    changes_found = False
    for key in sorted(all_keys):
        old_val = old_params.get(key)
        new_val = new_params.get(key)

        if old_val != new_val:
            changes_found = True
            if old_val is None:
                console.print(f"  [green]+ {key}: {new_val}[/green] (added)")
            elif new_val is None:
                console.print(f"  [red]- {key}: {old_val}[/red] (removed)")
            else:
                console.print(f"  [yellow]~ {key}: {old_val} → {new_val}[/yellow] (changed)")
        else:
            console.print(f"  [dim]  {key}: {old_val}[/dim] (unchanged)")

    if not changes_found:
        console.print("  [dim]No parameter changes[/dim]")


def display_file_diff(
    old_data: dict[str, Any],
    new_data: dict[str, Any],
    filename: str,
    format_type: str = "yaml",
) -> None:
    """Display diff for a configuration file.

    Args:
        old_data: Original data
        new_data: Modified data
        filename: Name of file
        format_type: Format to use ('yaml' or 'json')
    """
    old_str, new_str = compare_dicts(old_data, new_data, format_type)
    display_diff(old_str, new_str, filename, title=f"📄 {filename}")


# Made with Bob
