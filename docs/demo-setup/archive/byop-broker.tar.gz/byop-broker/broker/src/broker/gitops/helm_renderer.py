"""Helm chart rendering module for pure Kustomize approach.

This module provides functionality to render Helm charts to YAML manifests
using the `helm template` command. This is required for the pure Kustomize
approach where we need to patch Helm-rendered resources with Kustomize.

Key Features:
    - Render Helm charts to YAML manifests
    - Support for chart URLs and local charts
    - Configurable namespace and release name
    - Comprehensive error handling

Usage:
    from broker.gitops.helm_renderer import render_helm_chart_to_yaml

    render_helm_chart_to_yaml(
        chart_url="https://kubelauncher.github.io/charts/mariadb",
        chart_version="0.4.7",
        release_name="mariadb-sops-09",
        namespace="sops-09",
        values_file=Path("instances/mariadb/sops-09/values.yaml"),
        output_file=Path("instances/mariadb/sops-09/manifests/all.yaml")
    )
"""

import shutil
import subprocess
from pathlib import Path

from broker.logging_config import get_logger


logger = get_logger(__name__)


class HelmRenderError(Exception):
    """Raised when Helm chart rendering fails."""

    pass


def is_helm_available() -> bool:
    """Check if Helm binary is available in PATH.

    Returns:
        True if Helm is available, False otherwise

    Example:
        >>> if is_helm_available():
        ...     print("Helm is ready")
    """
    helm_path = shutil.which("helm")
    if helm_path:
        logger.debug(f"Helm binary found at: {helm_path}")
        return True
    logger.warning("Helm binary not found in PATH")
    return False


def render_helm_chart_to_yaml(
    chart_url: str,
    chart_version: str,
    release_name: str,
    namespace: str,
    values_file: Path,
    output_file: Path,
    timeout: int = 300,
) -> None:
    """Render a Helm chart to YAML manifests using helm template.

    This function uses `helm template` to render a Helm chart with the provided
    values file, then writes the rendered manifests to the output file.

    Args:
        chart_url: URL to Helm chart repository (e.g., "https://kubelauncher.github.io/charts/mariadb")
        chart_version: Chart version to render (e.g., "0.4.7")
        release_name: Helm release name (e.g., "mariadb-sops-09")
        namespace: Target namespace (e.g., "sops-09")
        values_file: Path to values.yaml file
        output_file: Path to write rendered manifests
        timeout: Command timeout in seconds (default: 300)

    Raises:
        HelmRenderError: If rendering fails
        FileNotFoundError: If values file doesn't exist

    Example:
        >>> render_helm_chart_to_yaml(
        ...     chart_url="https://kubelauncher.github.io/charts/mariadb",
        ...     chart_version="0.4.7",
        ...     release_name="mariadb-sops-09",
        ...     namespace="sops-09",
        ...     values_file=Path("instances/mariadb/sops-09/values.yaml"),
        ...     output_file=Path("instances/mariadb/sops-09/manifests/all.yaml")
        ... )
    """
    # Validate inputs
    if not values_file.exists():
        raise FileNotFoundError(f"Values file not found: {values_file}")

    if not is_helm_available():
        raise HelmRenderError(
            "Helm binary not found in PATH. Please install Helm: "
            "https://helm.sh/docs/intro/install/"
        )

    # Ensure output directory exists
    output_file.parent.mkdir(parents=True, exist_ok=True)

    # Build helm template command
    # Format: helm template <release-name> <chart-url>-<version>.tgz -f <values-file> --namespace <namespace>
    chart_reference = f"{chart_url}-{chart_version}.tgz"

    cmd = [
        "helm",
        "template",
        release_name,
        chart_reference,
        "-f",
        str(values_file),
        "--namespace",
        namespace,
    ]

    logger.info(
        "Rendering Helm chart to YAML",
        extra={
            "chart_url": chart_url,
            "chart_version": chart_version,
            "release_name": release_name,
            "namespace": namespace,
            "values_file": str(values_file),
            "output_file": str(output_file),
        },
    )

    try:
        # Run helm template and capture output
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=True,
        )

        # Write rendered manifests to file
        output_file.write_text(result.stdout)

        logger.info(
            "Successfully rendered Helm chart",
            extra={
                "output_file": str(output_file),
                "output_size": len(result.stdout),
                "line_count": result.stdout.count("\n"),
            },
        )

    except subprocess.TimeoutExpired as e:
        raise HelmRenderError(f"Helm template command timed out after {timeout} seconds") from e

    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.strip() if e.stderr else "Unknown error"
        raise HelmRenderError(
            f"Helm template command failed: {error_msg}\n"
            f"Command: {' '.join(cmd)}\n"
            f"Exit code: {e.returncode}"
        ) from e

    except Exception as e:
        raise HelmRenderError(f"Unexpected error during Helm rendering: {e}") from e


def validate_helm_chart(
    chart_url: str,
    chart_version: str,
    timeout: int = 60,
) -> bool:
    """Validate that a Helm chart exists and can be accessed.

    Args:
        chart_url: URL to Helm chart repository
        chart_version: Chart version to validate
        timeout: Command timeout in seconds (default: 60)

    Returns:
        True if chart is valid and accessible, False otherwise

    Example:
        >>> if validate_helm_chart("https://kubelauncher.github.io/charts/mariadb", "0.4.7"):
        ...     print("Chart is valid")
    """
    if not is_helm_available():
        logger.warning("Helm binary not available, cannot validate chart")
        return False

    chart_reference = f"{chart_url}-{chart_version}.tgz"

    cmd = [
        "helm",
        "show",
        "chart",
        chart_reference,
    ]

    try:
        subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=True,
        )
        logger.debug(f"Helm chart validation successful: {chart_url}:{chart_version}")
        return True

    except (subprocess.TimeoutExpired, subprocess.CalledProcessError) as e:
        logger.warning(
            f"Helm chart validation failed: {chart_url}:{chart_version}",
            extra={"error": str(e)},
        )
        return False

    except Exception as e:
        logger.error(f"Unexpected error validating Helm chart: {e}")
        return False


# Made with Bob
