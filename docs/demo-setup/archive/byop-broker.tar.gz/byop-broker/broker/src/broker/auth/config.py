"""Authentication configuration management."""

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


logger = logging.getLogger(__name__)


@dataclass
class AuthConfig:
    """JWT authentication configuration.

    Attributes:
        enabled: Enable/disable JWT authentication (default: True - ENABLED BY DEFAULT)
        jwks_url: JWKS endpoint URL for fetching public keys
        issuer: Expected token issuer (iss claim)
        audience: Expected token audience (aud claim)
        algorithms: List of allowed signing algorithms
        jwks_cache_ttl: JWKS cache time-to-live in seconds
        exempt_paths: List of paths that don't require authentication (health endpoints)
        verify_ssl: Verify SSL certificates when fetching JWKS (default: True)
        ca_cert_path: Path to CA certificate bundle for JWKS endpoint verification (optional)
    """

    enabled: bool = True  # ENABLED BY DEFAULT - can be disabled via Helm values
    jwks_url: str = ""
    issuer: str = ""
    audience: str = ""
    algorithms: list[str] = field(default_factory=lambda: ["RS256"])
    jwks_cache_ttl: int = 3600  # 1 hour
    verify_ssl: bool = True  # Verify SSL certificates by default
    ca_cert_path: str = ""  # Optional CA certificate bundle path
    exempt_paths: list[str] = field(
        default_factory=lambda: [
            "/health",  # Health check - NO AUTH REQUIRED
            "/health/git",  # Git health check - NO AUTH REQUIRED
            "/health/cache/clear",  # Cache clear - NO AUTH REQUIRED
        ]
    )

    def validate(self) -> None:
        """Validate authentication configuration.

        Raises:
            ValueError: If configuration is invalid
        """
        if not self.enabled:
            logger.info("JWT authentication is disabled")
            return

        if not self.jwks_url:
            raise ValueError("JWT_JWKS_URL is required when authentication is enabled")

        if not self.algorithms:
            raise ValueError("At least one algorithm must be specified")

        if self.jwks_cache_ttl < 0:
            raise ValueError("JWKS cache TTL must be non-negative")

        # Log warnings if issuer/audience not configured
        if not self.issuer:
            logger.warning(
                "JWT_ISSUER not configured - issuer validation will be DISABLED. "
                "Token issuer claims will be logged for debugging."
            )

        if not self.audience:
            logger.warning(
                "JWT_AUDIENCE not configured - audience validation will be DISABLED. "
                "Token audience claims will be logged for debugging."
            )

        logger.info(
            "JWT authentication enabled: issuer=%s, audience=%s, algorithms=%s",
            self.issuer or "NOT_CONFIGURED",
            self.audience or "NOT_CONFIGURED",
            self.algorithms,
        )


def load_auth_config(config_file: str | None = None) -> AuthConfig:
    """Load authentication configuration from environment and config file.

    Configuration precedence (highest to lowest):
    1. Environment variables
    2. Config file
    3. Default values

    Args:
        config_file: Optional path to configuration file

    Returns:
        AuthConfig instance with loaded configuration

    Raises:
        ValueError: If configuration is invalid
    """
    config_data: dict[str, Any] = {}

    # Load from config file if provided
    if config_file:
        config_path = Path(config_file)
        if config_path.exists():
            try:
                with open(config_path) as f:
                    file_config = json.load(f)
                    if "auth" in file_config:
                        config_data = file_config["auth"]
                        logger.info("Loaded auth config from file: %s", config_file)
            except (json.JSONDecodeError, OSError) as e:
                logger.warning("Failed to load auth config from file: %s", e)

    # Override with environment variables
    if "JWT_AUTH_ENABLED" in os.environ:
        enabled_str = os.environ["JWT_AUTH_ENABLED"].lower()
        config_data["enabled"] = enabled_str in ("true", "1", "yes")

    if "JWT_JWKS_URL" in os.environ:
        config_data["jwks_url"] = os.environ["JWT_JWKS_URL"]

    if "JWT_ISSUER" in os.environ:
        config_data["issuer"] = os.environ["JWT_ISSUER"]

    if "JWT_AUDIENCE" in os.environ:
        config_data["audience"] = os.environ["JWT_AUDIENCE"]

    if "JWT_ALGORITHMS" in os.environ:
        algorithms_str = os.environ["JWT_ALGORITHMS"]
        algorithms = [alg.strip() for alg in algorithms_str.split(",") if alg.strip()]
        # Only override if we got at least one algorithm
        if algorithms:
            config_data["algorithms"] = algorithms

    if "JWT_CACHE_TTL" in os.environ:
        try:
            config_data["jwks_cache_ttl"] = int(os.environ["JWT_CACHE_TTL"])
        except ValueError:
            logger.warning("Invalid JWT_CACHE_TTL value, using default")

    if "JWT_EXEMPT_PATHS" in os.environ:
        exempt_paths_str = os.environ["JWT_EXEMPT_PATHS"]
        exempt_paths = [path.strip() for path in exempt_paths_str.split(",") if path.strip()]
        # Only override if we got at least one path
        if exempt_paths:
            config_data["exempt_paths"] = exempt_paths
            logger.info("Loaded exempt paths from environment: %s", exempt_paths)

    if "JWT_VERIFY_SSL" in os.environ:
        verify_ssl_str = os.environ["JWT_VERIFY_SSL"].lower()
        config_data["verify_ssl"] = verify_ssl_str in ("true", "1", "yes")
        if not config_data["verify_ssl"]:
            logger.warning(
                "SSL verification DISABLED for JWKS endpoint - "
                "this should only be used in development/testing environments"
            )

    if "JWT_CA_CERT_PATH" in os.environ:
        ca_cert_path = os.environ["JWT_CA_CERT_PATH"]
        if ca_cert_path:
            config_data["ca_cert_path"] = ca_cert_path
            logger.info("Using custom CA certificate for JWKS endpoint: %s", ca_cert_path)

    # Create config instance
    auth_config = AuthConfig(**config_data)

    # Validate configuration
    auth_config.validate()

    return auth_config


# Made with Bob
