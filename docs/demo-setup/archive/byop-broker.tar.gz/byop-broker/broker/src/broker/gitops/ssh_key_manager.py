"""SSH Key Manager for GitOps orchestrator.

Handles SSH key injection from environment variables or files.

This module allows SSH keys to be provided via:
1. Environment variable (SSH_PRIVATE_KEY) - for CI/CD
2. File path (SSH_PRIVATE_KEY_PATH) - for local development
3. Default location (~/.ssh/gitops_deploy_key)

Usage:
    from ssh_key_manager import SSHKeyManager

    # Setup SSH key from environment
    ssh_manager = SSHKeyManager()
    ssh_manager.setup_ssh_key()

    # Cleanup when done
    ssh_manager.cleanup()
"""

import base64
import contextlib
import os
import stat
import tempfile
from pathlib import Path


class SSHKeyManager:
    """Manage SSH keys from environment variables or files."""

    def __init__(self) -> None:
        """Initialize SSH key manager."""
        self.temp_key_file: str | None = None
        self.ssh_config_file: str | None = None
        self.cleanup_needed: bool = False

    def setup_ssh_key(self) -> str:
        """Setup SSH key for Git operations.

        Priority:
        1. SSH_PRIVATE_KEY environment variable (base64 or raw)
        2. SSH_PRIVATE_KEY_PATH environment variable
        3. Default path: ~/.ssh/gitops_deploy_key

        Returns:
            Path to SSH private key file

        Raises:
            ValueError: If no SSH key is found

        Example:
            >>> manager = SSHKeyManager()
            >>> key_path = manager.setup_ssh_key()  # doctest: +SKIP
        """
        # Check for SSH key in environment variable
        ssh_key_content = os.getenv("SSH_PRIVATE_KEY")
        if ssh_key_content:
            return self._setup_key_from_env(ssh_key_content)

        # Check for SSH key path in environment
        ssh_key_path = os.getenv("SSH_PRIVATE_KEY_PATH")
        if ssh_key_path:
            key_path = Path(ssh_key_path)

            # Expand ~ for home directory
            if str(key_path).startswith("~"):
                key_path = key_path.expanduser()
            # If relative path, resolve relative to gitops directory
            elif not key_path.is_absolute():
                # Find gitops directory (parent of orchestrator directory)
                gitops_dir = Path(__file__).parent.parent
                key_path = gitops_dir / key_path

            # Resolve to absolute path
            key_path = key_path.resolve()

            if key_path.exists():
                return str(key_path)
            raise ValueError(
                f"SSH key file not found: {ssh_key_path}\n"
                f"Resolved to: {key_path}\n"
                f"GitOps directory: {Path(__file__).parent.parent.resolve()}"
            )

        # Check default location
        default_key = Path.home() / ".ssh" / "gitops_deploy_key"
        if default_key.exists():
            return str(default_key)

        raise ValueError(
            "No SSH key found. Please provide one of:\n"
            "  1. SSH_PRIVATE_KEY environment variable (key content)\n"
            "  2. SSH_PRIVATE_KEY_PATH environment variable (path to key)\n"
            "  3. Key file at ~/.ssh/gitops_deploy_key"
        )

    def _setup_key_from_env(self, key_content: str) -> str:
        """Setup SSH key from environment variable content.

        Args:
            key_content: SSH private key content (may be base64 encoded)

        Returns:
            Path to temporary key file

        Example:
            >>> manager = SSHKeyManager()
            >>> path = manager._setup_key_from_env("-----BEGIN...")  # doctest: +SKIP
        """
        # Decode if base64 encoded
        if not key_content.startswith("-----BEGIN"):
            with contextlib.suppress(Exception):
                key_content = base64.b64decode(key_content).decode("utf-8")

        # Create temporary file for SSH key
        fd, temp_path = tempfile.mkstemp(prefix="gitops_ssh_", suffix=".key")
        self.temp_key_file = temp_path
        self.cleanup_needed = True

        # Write key to temporary file
        with os.fdopen(fd, "w") as f:
            f.write(key_content)
            if not key_content.endswith("\n"):
                f.write("\n")

        # Set correct permissions (600)
        os.chmod(temp_path, stat.S_IRUSR | stat.S_IWUSR)

        # Setup SSH config to use this key
        self._setup_ssh_config(temp_path)

        return temp_path

    def _setup_ssh_config(self, key_path: str) -> None:
        """Setup SSH config to use the specified key.

        Args:
            key_path: Path to SSH private key

        Example:
            >>> manager = SSHKeyManager()
            >>> manager._setup_ssh_config("/path/to/key")  # doctest: +SKIP
        """
        ssh_dir = Path.home() / ".ssh"
        ssh_dir.mkdir(mode=0o700, exist_ok=True)

        config_path = ssh_dir / "config"

        # Read existing config
        existing_config = ""
        if config_path.exists():
            with open(config_path) as f:
                existing_config = f.read()

        # Check if github.com entry already exists
        if "Host github.com" in existing_config:
            # Update existing entry
            lines = existing_config.split("\n")
            new_lines = []
            in_github_block = False

            for line in lines:
                if line.strip().startswith("Host github.com"):
                    in_github_block = True
                    new_lines.append(line)
                elif in_github_block and line.strip().startswith("Host "):
                    in_github_block = False
                    new_lines.append(line)
                elif in_github_block and "IdentityFile" in line:
                    new_lines.append(f"    IdentityFile {key_path}")
                else:
                    new_lines.append(line)

            config_content = "\n".join(new_lines)
        else:
            # Add new entry
            config_entry = f"""
# GitOps SSH Configuration (auto-generated)
Host github.com
    HostName github.com
    User git
    IdentityFile {key_path}
    StrictHostKeyChecking no
"""
            config_content = existing_config + config_entry

        # Write updated config
        with open(config_path, "w") as f:
            f.write(config_content)

        os.chmod(config_path, 0o600)
        self.ssh_config_file = str(config_path)

    def setup_git_ssh_command(self, key_path: str) -> None:
        """Setup GIT_SSH_COMMAND environment variable.

        This is an alternative to modifying SSH config.
        Useful for isolated Git operations.

        Args:
            key_path: Path to SSH private key

        Example:
            >>> manager = SSHKeyManager()
            >>> manager.setup_git_ssh_command("/path/to/key")
            >>> os.environ['GIT_SSH_COMMAND']  # doctest: +SKIP
            'ssh -i /path/to/key -o StrictHostKeyChecking=no'
        """
        os.environ["GIT_SSH_COMMAND"] = f"ssh -i {key_path} -o StrictHostKeyChecking=no"

    def cleanup(self) -> None:
        """Cleanup temporary files.

        Example:
            >>> manager = SSHKeyManager()
            >>> manager.cleanup()
        """
        if self.cleanup_needed and self.temp_key_file:
            try:
                if os.path.exists(self.temp_key_file):
                    os.remove(self.temp_key_file)
            except Exception as e:
                # Log warning but don't fail - cleanup is best-effort
                import logging

                logger = logging.getLogger(__name__)
                logger.warning(f"Failed to cleanup temporary key file: {e}")

    def __enter__(self) -> "SSHKeyManager":
        """Context manager entry.

        Returns:
            Self for context manager usage

        Example:
            >>> with SSHKeyManager() as manager:  # doctest: +SKIP
            ...     key_path = manager.setup_ssh_key()
        """
        return self

    def __exit__(self, exc_type: type | None, exc_val: Exception | None, exc_tb: object) -> None:
        """Context manager exit - cleanup.

        Args:
            exc_type: Exception type if raised
            exc_val: Exception value if raised
            exc_tb: Exception traceback if raised
        """
        self.cleanup()


# Convenience function
def setup_ssh_from_env() -> SSHKeyManager:
    """Setup SSH key from environment and return manager.

    Returns:
        SSHKeyManager instance (call cleanup() when done)

    Example:
        manager = setup_ssh_from_env()
        try:
            # Do Git operations
            pass
        finally:
            manager.cleanup()
    """
    manager = SSHKeyManager()
    manager.setup_ssh_key()
    return manager


# Made with Bob
