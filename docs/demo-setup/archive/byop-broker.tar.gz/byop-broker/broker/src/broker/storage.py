"""
Storage interface for CSB broker.

Defines the abstract interface that all storage implementations must follow.
This matches the updated CSB storage interface with init() method support.
"""

from typing import Any

from broker.logging_config import get_logger


logger = get_logger(__name__)


class StorageInterface:
    """Abstract interface for storage operations."""

    def init(self, config: dict[str, Any]) -> None:
        """
        Initialize storage with JSON configuration.

        Args:
            config: JSON configuration dictionary specific to storage implementation

        Raises:
            NotImplementedError: Must be implemented by subclass
        """
        raise NotImplementedError

    def create(self, instance_id: str, data: dict[str, Any]) -> None:
        """Create a new service instance.

        Args:
            instance_id: Unique identifier for the instance
            data: Instance data to store

        Raises:
            NotImplementedError: Must be implemented by subclass
        """
        raise NotImplementedError

    def get(self, instance_id: str) -> dict[str, Any] | None:
        """Retrieve a service instance.

        Args:
            instance_id: Unique identifier for the instance

        Returns:
            Instance data if found, None otherwise

        Raises:
            NotImplementedError: Must be implemented by subclass
        """
        raise NotImplementedError

    def update(self, instance_id: str, data: dict[str, Any]) -> None:
        """Update an existing service instance.

        Args:
            instance_id: Unique identifier for the instance
            data: Updated instance data

        Raises:
            NotImplementedError: Must be implemented by subclass
        """
        raise NotImplementedError

    def delete(self, instance_id: str) -> bool:
        """Delete a service instance.

        Args:
            instance_id: Unique identifier for the instance

        Returns:
            True if deleted, False if not found

        Raises:
            NotImplementedError: Must be implemented by subclass
        """
        raise NotImplementedError

    def exists(self, instance_id: str) -> bool:
        """Check if a service instance exists.

        Args:
            instance_id: Unique identifier for the instance

        Returns:
            True if exists, False otherwise

        Raises:
            NotImplementedError: Must be implemented by subclass
        """
        raise NotImplementedError

    def list_all(self) -> list[dict[str, Any]]:
        """List all service instances.

        Returns:
            List of instance data dictionaries

        Raises:
            NotImplementedError: Must be implemented by subclass
        """
        raise NotImplementedError

    def dump_provision_variables(self, instance_id: str, variables: dict[str, Any]) -> None:
        """
        Dump provisioning variables to file (optional).

        This method is called after successful provisioning to dump all variables
        used during the provisioning process. This aids in debugging, auditing,
        and understanding the exact configuration used for each service instance.

        Args:
            instance_id: Service instance ID
            variables: Dictionary of all provisioning variables

        Note:
            Implementation is optional. Default is no-op.
            Implementations should:
            - Sanitize sensitive data (passwords, tokens, secrets)
            - Write to instance directory as provision-variables.json
            - Handle errors gracefully (non-blocking)
            - Log success/failure
        """
        pass  # Default: do nothing


def create_storage(storage_type: str, config: dict[str, Any]) -> StorageInterface:
    """
    Factory function to create and initialize storage instance.
    Automatically instantiates the storage class based on the type string.

    Type naming convention:
      - "gitops" -> GitOpsStorage
      - "file" -> FileStorage
      - "dummy" -> DummyStorage

    Args:
        storage_type: Storage type string (e.g., "gitops", "file", "dummy")
        config: Configuration dictionary for storage initialization

    Returns:
        Initialized storage instance

    Raises:
        ValueError: If storage class cannot be found
    """
    # Lazy import to avoid circular dependency
    storage_class: type[StorageInterface]
    if storage_type == "gitops":
        from broker.gitops_storage import GitopsStorage

        storage_class = GitopsStorage
        class_name = "GitopsStorage"
    elif storage_type == "file":
        from broker.file_storage import FileStorage

        storage_class = FileStorage
        class_name = "FileStorage"
    else:
        # For other storage types, try to import dynamically
        class_name = f"{storage_type.capitalize()}Storage"
        try:
            module = __import__(f"broker.{storage_type}_storage", fromlist=[class_name])
            storage_class = getattr(module, class_name)
        except (ImportError, AttributeError) as e:
            raise ValueError(
                f"Storage class '{class_name}' not found. "
                f"Expected module 'broker.{storage_type}_storage.py' with class '{class_name}'. "
                f"Error: {e}"
            ) from e

    # Instantiate and initialize
    storage = storage_class()
    storage.init(config)
    logger.info(
        "Storage created", extra={"storage_type": storage_type, "storage_class": class_name}
    )
    return storage


# Made with Bob
