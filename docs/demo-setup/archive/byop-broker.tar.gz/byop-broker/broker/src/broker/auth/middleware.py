"""Flask authentication middleware for JWT validation."""

import logging
from typing import Any

from flask import Request, Response, g, jsonify, request

from broker.auth.config import AuthConfig
from broker.auth.exceptions import (
    AuthenticationError,
    InvalidAuthorizationFormatError,
    MissingAuthorizationError,
)
from broker.auth.jwt_validator import JWTValidator


logger = logging.getLogger(__name__)


def extract_bearer_token(req: Request) -> str:
    """Extract Bearer token from Authorization header.

    Args:
        req: Flask request object

    Returns:
        JWT token string

    Raises:
        MissingAuthorizationError: If Authorization header is missing
        InvalidAuthorizationFormatError: If Authorization header format is invalid
    """
    auth_header = req.headers.get("Authorization")

    if not auth_header:
        raise MissingAuthorizationError("Missing Authorization header")

    # Check for Bearer token format
    parts = auth_header.split()

    if len(parts) != 2:
        raise InvalidAuthorizationFormatError(
            "Invalid Authorization header format. Expected: 'Bearer <token>'"
        )

    scheme, token = parts

    if scheme.lower() != "bearer":
        raise InvalidAuthorizationFormatError(
            f"Invalid authentication scheme: {scheme}. Expected: Bearer"
        )

    return token


def require_jwt_auth(
    jwt_validator: JWTValidator,
    config: AuthConfig,
) -> Response | None:
    """Flask before_request handler for JWT authentication.

    This function validates JWT tokens for all requests except exempt paths.
    It should be registered as a before_request handler in Flask.

    Args:
        jwt_validator: JWT validator instance
        config: Authentication configuration

    Returns:
        None if authentication succeeds, error Response if it fails
    """
    # Check if authentication is enabled
    if not config.enabled:
        logger.debug("JWT authentication is disabled")
        return None

    # Check if path is exempt from authentication
    request_path = request.path
    logger.debug(
        "Checking authentication for path: %s, exempt_paths: %s", request_path, config.exempt_paths
    )

    if request_path in config.exempt_paths:
        logger.debug("Path %s is exempt from authentication", request_path)
        return None

    # Extract and validate token
    try:
        token = extract_bearer_token(request)

        # Validate token
        payload = jwt_validator.validate_token(token)

        # Attach user context to request
        g.jwt_payload = payload
        g.authenticated = True

        # Extract common claims for logging
        subject = payload.get("sub", "unknown")
        logger.info(
            "Authenticated request: path=%s, subject=%s",
            request_path,
            subject,
        )

        return None

    except MissingAuthorizationError as e:
        logger.warning("Authentication failed: %s", e)
        return handle_auth_error(e, 401)

    except InvalidAuthorizationFormatError as e:
        logger.warning("Authentication failed: %s", e)
        return handle_auth_error(e, 401)

    except AuthenticationError as e:
        logger.warning("Authentication failed: %s", e)
        return handle_auth_error(e, 401)

    except Exception as e:
        logger.error("Unexpected authentication error: %s", e)
        return handle_auth_error(
            AuthenticationError("Authentication failed"),
            500,
        )


def handle_auth_error(error: Exception, status_code: int = 401) -> Response:
    """Convert authentication error to HTTP response.

    Args:
        error: Authentication error
        status_code: HTTP status code (default: 401)

    Returns:
        Flask JSON response with error details
    """
    error_response: dict[str, Any] = {
        "error": error.__class__.__name__,
        "message": str(error),
    }

    # Add WWW-Authenticate header for 401 responses
    response = jsonify(error_response)
    response.status_code = status_code

    if status_code == 401:
        response.headers["WWW-Authenticate"] = 'Bearer realm="GitOps Broker"'

    return response


def get_authenticated_user() -> dict[str, Any] | None:
    """Get authenticated user information from request context.

    Returns:
        JWT payload if authenticated, None otherwise
    """
    return getattr(g, "jwt_payload", None)


def is_authenticated() -> bool:
    """Check if current request is authenticated.

    Returns:
        True if authenticated, False otherwise
    """
    return getattr(g, "authenticated", False)


# Made with Bob
