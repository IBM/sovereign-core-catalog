"""
Template-Based Provisioning Functions

This module provides template-based provisioning functions that use the
template system (TemplateLoader, SchemaValidator, TemplateRenderer) to
generate service instance manifests.

This replaces hardcoded service-specific logic with declarative templates.
"""

import logging
from fnmatch import fnmatch
from pathlib import Path
from typing import Any

from broker.gitops.config import Config
from broker.gitops.git_config import GitConfig
from broker.gitops.schema_validator import SchemaValidator
from broker.gitops.schema_validator import ValidationError as SchemaValidationError
from broker.gitops.sops_encryption import (
    SOPSEncryptionError,
    encrypt_file,
    is_sops_available,
)
from broker.gitops.template_loader import TemplateLoader, TemplateLoadError
from broker.gitops.template_renderer import RenderError, TemplateRenderer


logger = logging.getLogger(__name__)


class TemplateProvisioningError(Exception):
    """Raised when template-based provisioning fails."""

    pass


def _merge_plan_metadata(
    user_params: dict[str, Any], plan_metadata: dict[str, Any]
) -> dict[str, Any]:
    """Merge plan metadata into user parameters.

    Plan metadata is merged into nested parameter structures based on common
    conventions. For QRadar, plan metadata like 'cpu', 'memory', 'version' are
    distributed to appropriate nested objects.

    IMPORTANT: This function preserves ALL fields from user_params (including 'plan')
    and only adds/merges plan metadata fields into nested structures.

    Args:
        user_params: User-provided parameters (already validated and with defaults)
        plan_metadata: Plan metadata from catalog.yaml

    Returns:
        Merged parameters dictionary with all user_params fields preserved

    Example:
        >>> user_params = {'plan': 'small', 'vm': {'name': 'qradar-01'}, 'qradar': {'hostname': 'qradar.local'}}
        >>> plan_metadata = {'version': '7.5.0', 'cpu': 8, 'memory': 32}
        >>> result = _merge_plan_metadata(user_params, plan_metadata)
        >>> print(result)
        {'plan': 'small', 'vm': {'name': 'qradar-01', 'cpu': 8, 'memory': 32},
         'qradar': {'hostname': 'qradar.local', 'version': '7.5.0'}}
    """
    import copy

    # Deep copy to avoid modifying original - this preserves ALL user_params fields
    merged = copy.deepcopy(user_params)

    # Define mapping of plan metadata fields to parameter paths
    # This maps plan metadata keys to where they should be placed in the params structure
    field_mappings = {
        # VM-related fields
        "cpu": ["vm", "cpu"],
        "memory": ["vm", "memory"],
        "storage": ["vm", "storage"],
        "template": ["vm", "template"],
        # Service-specific fields (try to place in service object if it exists)
        "version": None,  # Will be determined dynamically
        "setup": None,  # Usually not needed in params
    }

    for key, value in plan_metadata.items():
        path = field_mappings.get(key)

        if path is None:
            # For 'version' and other unmapped fields, try to place in the first nested object
            # that looks like a service configuration (not 'vm')
            if key == "version":
                # Find first non-vm nested dict
                for param_key, param_value in merged.items():
                    if isinstance(param_value, dict) and param_key != "vm":
                        # Place version in this object if not already present
                        if key not in param_value:
                            param_value[key] = value
                            logger.debug(f"Placed plan metadata '{key}' in '{param_key}.{key}'")
                        break
            # Skip 'type' and 'setup' as they're usually not needed in templates
            continue

        # Navigate to the target location and set the value
        target = merged
        for segment in path[:-1]:
            if segment not in target:
                target[segment] = {}
            elif not isinstance(target[segment], dict):
                logger.warning(
                    f"Cannot merge plan metadata '{key}': path segment '{segment}' is not a dict"
                )
                break
            target = target[segment]
        else:
            # Only set if not already present (user params take precedence)
            final_key = path[-1]
            if final_key not in target:
                target[final_key] = value
                logger.debug(f"Merged plan metadata: {'.'.join(path)} = {value}")
            else:
                logger.debug(
                    f"Skipping plan metadata '{key}': user provided value takes precedence"
                )

    return merged


def _is_secrets_file(filename: str) -> bool:
    """Check if filename is a secrets file that should be encrypted.

    Args:
        filename: Filename to check (e.g., "secrets.yaml", "secret.yaml")

    Returns:
        True if file should be encrypted, False otherwise

    Example:
        >>> _is_secrets_file("secrets.yaml")
        True
        >>> _is_secrets_file("values.yaml")
        False
        >>> _is_secrets_file("mariadb-secret.yaml")
        True
    """
    secrets_patterns = [
        "secret.yaml",
        "secrets.yaml",
        "*-secret.yaml",
        "*-secrets.yaml",
    ]
    filename_lower = filename.lower()
    return any(fnmatch(filename_lower, pattern) for pattern in secrets_patterns)


def create_instance_files_from_templates(
    instance_name: str,
    instance_id: str,
    namespace: str,
    service_type: str,
    service_version: str,
    cluster_name: str,
    cluster_url: str | None,
    environment: str,
    replicas: int,
    storage_size: str,
    deployment_registry: str | None,
    image_pull_secret_name: str | None,
    parameters_spec: dict[str, Any] | None = None,
    context: dict[str, Any] | None = None,
    broker_plan_id: str | None = None,
) -> tuple[Path, dict[str, str]]:
    """Create instance files using template system.

    This function replaces the hardcoded generate_secret_manifest() and
    generate_kustomization() with template-based rendering.

    Args:
        instance_name: Name of the service instance
        instance_id: Unique ID for the instance
        namespace: Kubernetes namespace
        service_type: Type of service (e.g., 'mysql', 'mariadb')
        service_version: Service version (e.g., 'v1', 'latest')
        cluster_name: Target cluster name
        cluster_url: Target cluster API URL
        environment: Environment (dev, staging, prod)
        replicas: Number of replicas
        storage_size: Storage size (e.g., '10Gi')
        deployment_registry: Deployment registry path
        image_pull_secret_name: Optional image pull secret name
        parameters_spec: User-provided service-specific parameters
        context: Additional context from OSB API
        broker_plan_id: Plan ID from broker for loading plan metadata

    Returns:
        Tuple of (instance_dir, rendered_files_dict)

    Raises:
        TemplateProvisioningError: If template operations fail
    """
    logger.info(f"Creating instance files from templates for {instance_name}")

    # Get repository directory - templates are in the GitOps repo itself
    repo_dir = GitConfig.get_repo_dir()

    # Initialize template system using GitOps repo directory
    # Templates are located at: repo_dir/services/{service_type}/template/
    try:
        template_loader = TemplateLoader(repo_dir)
        schema_validator = SchemaValidator(repo_dir)
        template_renderer = TemplateRenderer(repo_dir)
    except Exception as e:
        raise TemplateProvisioningError(f"Failed to initialize template system: {e}") from e

    # Validate parameters against schema
    if parameters_spec is None:
        parameters_spec = {}

    logger.info(f"Validating parameters for service type: {service_type}")
    try:
        # validate() raises ValidationError if invalid, returns None if valid
        schema_validator.validate(service_type, parameters_spec, service_version)
    except SchemaValidationError as e:
        raise TemplateProvisioningError(f"{e}") from e
    except Exception as e:
        raise TemplateProvisioningError(f"{e}") from e

    # Apply defaults and auto-generate missing values
    logger.info("Applying defaults and auto-generating values")
    logger.debug(f"Parameters before validation: {list(parameters_spec.keys())}")
    try:
        validated_params: dict[str, Any] = schema_validator.validate_with_defaults(
            service_type, parameters_spec, service_version
        )
        logger.debug(f"Parameters after validation: {list(validated_params.keys())}")
    except Exception as e:
        raise TemplateProvisioningError(f"Failed to apply defaults: {e}") from e

    # Load and merge plan metadata if broker_plan_id is provided
    if broker_plan_id:
        logger.info(f"Loading plan metadata for plan: {broker_plan_id}")
        try:
            plan_metadata = template_loader.load_plan_metadata(
                service_type, broker_plan_id, service_version
            )
            if plan_metadata:
                # Deep merge plan metadata into validated_params
                # Plan metadata should not override user-provided parameters
                validated_params = _merge_plan_metadata(validated_params, plan_metadata)
                logger.info(
                    "Merged plan metadata into parameters",
                    extra={"plan_metadata_keys": list(plan_metadata.keys())},
                )
        except Exception as e:
            # Log warning but don't fail - plan metadata is optional
            logger.warning(f"Failed to load plan metadata for {broker_plan_id}: {e}")

    # Build template context
    template_context = {
        # System variables
        "instance_name": instance_name,
        "instance_id": instance_id,
        "namespace": namespace,
        "service_type": service_type,
        "service_version": service_version,
        "cluster_name": cluster_name,
        "cluster_url": cluster_url or "",
        "environment": environment,
        "replicas": replicas,
        "storage_size": storage_size,
        "deployment_registry": deployment_registry or "",
        "image_pull_secret_name": image_pull_secret_name,
        # User-provided parameters
        "spec": validated_params,
        # Additional context
        "context": context or {},
    }
    # Type assertion for mypy - we know spec is a dict
    spec_dict: dict[str, Any] = template_context["spec"]  # type: ignore[assignment]
    logger.debug(f"Template context 'spec' keys: {list(spec_dict.keys())}")

    # Validate templates exist (renderer will load them)
    logger.info(f"Validating templates for {service_type}")
    try:
        template_loader.load_templates(service_type, service_version)
    except TemplateLoadError as e:
        raise TemplateProvisioningError(f"Failed to load templates: {e}") from e

    # Render templates
    logger.info("Rendering templates")
    try:
        rendered_files = template_renderer.render_templates(
            service_type, template_context, service_version
        )
    except RenderError as e:
        raise TemplateProvisioningError(f"Failed to render templates: {e}") from e

    # Create instance directory using path_utils
    from broker.gitops.path_utils import get_instance_path

    instance_dir = get_instance_path(repo_dir, instance_name, service_type)
    instance_dir.mkdir(parents=True, exist_ok=True)
    logger.info(f"Created instance directory: {instance_dir}")

    # Write rendered files and build output dictionary with correct filenames
    from broker.gitops.provision import write_yaml_file

    output_files: dict[str, str] = {}

    # Check if SOPS encryption is enabled
    sops_enabled = Config.SOPS_ENABLED and Config.SOPS_ENCRYPT_SECRETS
    if sops_enabled:
        if not is_sops_available():
            raise TemplateProvisioningError(
                "SOPS encryption is enabled but SOPS binary not found in PATH. "
                "Please install SOPS: https://github.com/mozilla/sops#download"
            )
        if not Config.SOPS_AGE_RECIPIENT:
            raise TemplateProvisioningError(
                "SOPS encryption is enabled but SOPS_AGE_RECIPIENT is not configured"
            )
        logger.info(
            "SOPS encryption enabled",
            extra={"age_recipient": Config.SOPS_AGE_RECIPIENT[:10] + "..."},
        )

    for filename, content in rendered_files.items():
        # Remove .tmpl extension from filename when writing
        output_filename = filename.replace(".tmpl", "") if filename.endswith(".tmpl") else filename
        file_path = instance_dir / output_filename

        # Create parent directories if needed (for subdirectory templates)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Parse YAML content
        import yaml

        try:
            manifest = yaml.safe_load(content)
        except yaml.YAMLError as e:
            raise TemplateProvisioningError(f"Invalid YAML in {output_filename}: {e}") from e

        # Check if this is a secrets file that should be encrypted
        if sops_enabled and _is_secrets_file(output_filename):
            logger.info(f"Encrypting secrets file: {output_filename}")

            # Write plaintext to temporary file
            temp_path = file_path.with_suffix(".tmp")
            try:
                write_yaml_file(temp_path, manifest)

                # Encrypt with SOPS
                # Keep original filename (e.g., secrets.yaml stays as secrets.yaml)
                # SOPS encryption is transparent - file content indicates it's encrypted
                encrypted_path = file_path
                encrypt_file(temp_path, encrypted_path, Config.SOPS_AGE_RECIPIENT)

                # Remove temporary plaintext file
                temp_path.unlink()

                logger.info(
                    f"Successfully encrypted {output_filename} → {encrypted_path.name}",
                    extra={
                        "plaintext_file": output_filename,
                        "encrypted_file": encrypted_path.name,
                    },
                )

                # Store encrypted filename in output
                output_files[encrypted_path.name] = content

            except SOPSEncryptionError as e:
                # Clean up temporary file if it exists
                if temp_path.exists():
                    temp_path.unlink()
                raise TemplateProvisioningError(f"Failed to encrypt {output_filename}: {e}") from e
            except Exception as e:
                # Clean up temporary file if it exists
                if temp_path.exists():
                    temp_path.unlink()
                raise TemplateProvisioningError(
                    f"Unexpected error encrypting {output_filename}: {e}"
                ) from e
        else:
            # Write non-secret files normally (or secrets if SOPS disabled)
            logger.info(f"Writing {output_filename}")
            write_yaml_file(file_path, manifest)
            output_files[output_filename] = content

    logger.info(f"Successfully created {len(output_files)} files from templates")
    return instance_dir, output_files


def validate_service_parameters(
    service_type: str,
    parameters_spec: dict[str, Any],
    service_version: str = "latest",
) -> bool:
    """Validate service parameters against schema.

    This is a standalone validation function that can be called before
    provisioning to check if parameters are valid.

    Args:
        service_type: Type of service (e.g., 'mysql', 'mariadb')
        parameters_spec: User-provided service-specific parameters
        service_version: Service version (default: 'latest')

    Returns:
        True if valid, False otherwise

    Example:
        >>> if validate_service_parameters('mysql', {'database_name': 'myapp'}):
        ...     print("Parameters are valid")
    """
    # Get repository directory - schemas are in the GitOps repo
    repo_dir = GitConfig.get_repo_dir()

    # Initialize validator using GitOps repo directory
    # Schemas are located at: repo_dir/services/{service_type}/catalog/schema.json
    validator = SchemaValidator(repo_dir)

    # Validate parameters - raises ValidationError if invalid
    try:
        validator.validate(service_type, parameters_spec, service_version)
        return True
    except SchemaValidationError:
        return False


def check_template_support(service_type: str, service_version: str = "latest") -> bool:
    """Check if a service type has template support.

    Args:
        service_type: Type of service (e.g., 'mysql', 'mariadb')
        service_version: Service version (default: 'latest')

    Returns:
        True if templates exist, False otherwise

    Example:
        >>> if check_template_support('mysql'):
        ...     print("MySQL has template support")
    """
    try:
        repo_dir = GitConfig.get_repo_dir()
        # Templates are in the GitOps repo at services/{service_type}/template/
        loader = TemplateLoader(repo_dir)
        loader.load_templates(service_type, service_version)
        return True
    except TemplateLoadError:
        return False
    except Exception:
        return False


def create_instance_files_with_kustomize(
    instance_name: str,
    instance_id: str,
    namespace: str,
    service_type: str,
    service_version: str,
    cluster_name: str,
    cluster_url: str | None,
    environment: str,
    replicas: int,
    storage_size: str,
    deployment_registry: str | None,
    image_pull_secret_name: str | None,
    parameters_spec: dict[str, Any] | None = None,
    context: dict[str, Any] | None = None,
    broker_plan_id: str | None = None,
    helm_config: dict[str, Any] | None = None,
) -> tuple[Path, dict[str, str]]:
    """Create instance files using pure Kustomize approach with Helm rendering.

    This function implements the pure Kustomize approach for services that require
    Helm chart rendering followed by Kustomize patching (e.g., for OpenShift SCC).

    Workflow:
        1. Render templates (values.yaml, secrets.yaml)
        2. Render Helm chart to YAML manifests
        3. Generate Kustomize configuration files
        4. Encrypt secrets with SOPS

    Args:
        instance_name: Name of the service instance
        instance_id: Unique ID for the instance
        namespace: Kubernetes namespace
        service_type: Type of service (e.g., 'mariadb')
        service_version: Service version (e.g., 'v2')
        cluster_name: Target cluster name
        cluster_url: Target cluster API URL
        environment: Environment (dev, staging, prod)
        replicas: Number of replicas
        storage_size: Storage size (e.g., '10Gi')
        deployment_registry: Deployment registry path
        image_pull_secret_name: Optional image pull secret name
        parameters_spec: User-provided service-specific parameters
        context: Additional context from OSB API
        broker_plan_id: Plan ID from broker for loading plan metadata
        helm_config: Helm chart configuration with keys:
            - chart_url: Helm chart repository URL
            - chart_version: Chart version
            - container_name: Main container name (for patches)
            - requires_patch: Whether to generate SCC patch

    Returns:
        Tuple of (instance_dir, rendered_files_dict)

    Raises:
        TemplateProvisioningError: If provisioning fails

    Example:
        >>> create_instance_files_with_kustomize(
        ...     instance_name="mariadb-sops-09",
        ...     instance_id="sops-09",
        ...     namespace="sops-09",
        ...     service_type="mariadb",
        ...     service_version="v2",
        ...     cluster_name="k3s-cluster-1",
        ...     cluster_url="https://cluster.local:6443",
        ...     environment="dev",
        ...     replicas=1,
        ...     storage_size="10Gi",
        ...     deployment_registry=None,
        ...     image_pull_secret_name=None,
        ...     parameters_spec={"database": "myapp"},
        ...     helm_config={
        ...         "chart_url": "https://kubelauncher.github.io/charts/mariadb",
        ...         "chart_version": "0.4.7",
        ...         "container_name": "mariadb",
        ...         "requires_patch": True
        ...     }
        ... )
    """
    from broker.gitops.helm_renderer import HelmRenderError, render_helm_chart_to_yaml

    logger.info(f"Creating instance files with pure Kustomize approach for {instance_name}")

    if helm_config is None:
        raise TemplateProvisioningError("helm_config is required for pure Kustomize approach")

    # Step 1: Create instance files from templates (values.yaml, secrets.yaml)
    instance_dir, rendered_files = create_instance_files_from_templates(
        instance_name=instance_name,
        instance_id=instance_id,
        namespace=namespace,
        service_type=service_type,
        service_version=service_version,
        cluster_name=cluster_name,
        cluster_url=cluster_url,
        environment=environment,
        replicas=replicas,
        storage_size=storage_size,
        deployment_registry=deployment_registry,
        image_pull_secret_name=image_pull_secret_name,
        parameters_spec=parameters_spec,
        context=context,
        broker_plan_id=broker_plan_id,
    )

    # Step 2: Render Helm chart to YAML manifests
    values_file = instance_dir / "values.yaml"
    manifests_dir = instance_dir / "manifests"
    manifests_file = manifests_dir / "all.yaml"

    try:
        render_helm_chart_to_yaml(
            chart_url=helm_config["chart_url"],
            chart_version=helm_config["chart_version"],
            release_name=instance_name,
            namespace=namespace,
            values_file=values_file,
            output_file=manifests_file,
        )
        logger.info(f"Rendered Helm chart to {manifests_file}")
    except HelmRenderError as e:
        raise TemplateProvisioningError(f"Failed to render Helm chart: {e}") from e

    # Step 3: Verify Kustomize files were rendered from templates
    # All Kustomize files (kustomization.yaml, ksops-generator.yaml, patches)
    # come from service templates, not programmatic generation
    kustomization_file = instance_dir / "kustomization.yaml"
    ksops_file = instance_dir / "ksops-generator.yaml"

    if not kustomization_file.exists():
        raise TemplateProvisioningError(
            f"kustomization.yaml not found in {instance_dir}. "
            "Service template must include kustomization.yaml.tmpl"
        )

    # KSOPS is optional - only required if service has encrypted secrets
    # Check if any .enc files exist (encrypted secrets)
    encrypted_files = list(instance_dir.glob("**/*.enc"))
    if encrypted_files and not ksops_file.exists():
        raise TemplateProvisioningError(
            f"ksops-generator.yaml not found in {instance_dir}. "
            f"Service has encrypted secrets ({len(encrypted_files)} .enc files) but no ksops-generator.yaml.tmpl. "
            "Either add ksops-generator.yaml.tmpl or disable secret encryption for this service."
        )

    log_extra = {
        "instance_dir": str(instance_dir),
        "kustomization": str(kustomization_file),
    }
    if ksops_file.exists():
        log_extra["ksops_generator"] = str(ksops_file)

    logger.info(
        "Verified Kustomize files from templates",
        extra=log_extra,
    )

    logger.info(
        f"Successfully created instance files with pure Kustomize approach for {instance_name}"
    )

    return instance_dir, rendered_files


# Made with Bob
