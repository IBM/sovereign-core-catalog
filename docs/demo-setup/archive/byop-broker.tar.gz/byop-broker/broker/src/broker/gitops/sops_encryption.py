"""SOPS encryption module for securing secrets in GitOps repositories.

This module provides functionality to encrypt sensitive files using SOPS (Secrets OPerationS)
with AGE encryption. It ensures secrets are encrypted before being committed to Git.

Key Features:
    - Encrypt files using SOPS with AGE public keys
    - Validate SOPS binary availability
    - Validate AGE key format
    - Comprehensive error handling

Usage:
    from broker.gitops.sops_encryption import encrypt_file, is_sops_available

    if is_sops_available():
        encrypt_file(
            input_path=Path("secrets.yaml"),
            output_path=Path("secrets.enc.yaml"),
            age_recipient="age1..."
        )

Environment Variables:
    SOPS_ENABLED: Enable/disable SOPS encryption (default: false)
    SOPS_AGE_RECIPIENT: AGE public key for encryption
    SOPS_ENCRYPT_SECRETS: Encrypt secrets files (default: true if SOPS enabled)
"""

import os
import re
import shutil
import subprocess
from pathlib import Path

from broker.logging_config import get_logger


logger = get_logger(__name__)


class SOPSEncryptionError(Exception):
    """Raised when SOPS encryption operations fail."""

    pass


class SOPSConfigurationError(Exception):
    """Raised when SOPS configuration is invalid."""

    pass


def is_sops_available() -> bool:
    """Check if SOPS binary is available in PATH.

    Returns:
        True if SOPS is available, False otherwise

    Example:
        >>> if is_sops_available():
        ...     print("SOPS is ready")
    """
    sops_path = shutil.which("sops")
    if sops_path:
        logger.debug(f"SOPS binary found at: {sops_path}")
        return True
    logger.warning("SOPS binary not found in PATH")
    return False


def validate_age_key(age_recipient: str) -> bool:
    """Validate AGE public key format.

    AGE public keys must start with 'age1' and be 62 characters long.

    Args:
        age_recipient: AGE public key to validate

    Returns:
        True if valid, False otherwise

    Example:
        >>> validate_age_key("age1example1234567890abcdefghijklmnopqrstuvwxyz1234567890abc")
        True
        >>> validate_age_key("invalid-key")
        False
    """
    if not age_recipient:
        logger.error("AGE recipient is empty")
        return False

    # AGE public keys start with 'age1' and are 62 characters long
    age_key_pattern = r"^age1[a-z0-9]{58}$"
    if not re.match(age_key_pattern, age_recipient):
        logger.error(
            f"Invalid AGE key format: {age_recipient[:10]}... "
            "(must start with 'age1' and be 62 characters)"
        )
        return False

    logger.debug("AGE key format validated successfully")
    return True


def get_sops_config() -> dict[str, str]:
    """Load SOPS configuration from environment variables.

    Returns:
        Dictionary containing SOPS configuration:
        - enabled: Whether SOPS is enabled (bool as string)
        - age_recipient: AGE public key for encryption
        - encrypt_secrets: Whether to encrypt secrets files (bool as string)

    Raises:
        SOPSConfigurationError: If SOPS is enabled but AGE recipient is missing

    Example:
        >>> config = get_sops_config()
        >>> print(config['enabled'])
        'true'
    """
    enabled = os.getenv("SOPS_ENABLED", "false").lower()
    age_recipient = os.getenv("SOPS_AGE_RECIPIENT", "")
    encrypt_secrets = os.getenv("SOPS_ENCRYPT_SECRETS", "true").lower()

    config = {
        "enabled": enabled,
        "age_recipient": age_recipient,
        "encrypt_secrets": encrypt_secrets,
    }

    # Validate configuration if SOPS is enabled
    if enabled == "true":
        if not age_recipient:
            raise SOPSConfigurationError(
                "SOPS_AGE_RECIPIENT environment variable is required when SOPS_ENABLED=true"
            )
        if not validate_age_key(age_recipient):
            raise SOPSConfigurationError(
                f"Invalid AGE key format in SOPS_AGE_RECIPIENT: {age_recipient[:10]}..."
            )

    logger.debug(f"SOPS configuration loaded: enabled={enabled}, encrypt_secrets={encrypt_secrets}")
    return config


def encrypt_file(
    input_path: Path,
    output_path: Path,
    age_recipient: str,
    timeout: int = 30,
) -> None:
    """Encrypt a file using SOPS with AGE encryption.

    Args:
        input_path: Path to plaintext input file
        output_path: Path to encrypted output file
        age_recipient: AGE public key for encryption
        timeout: Command timeout in seconds (default: 30)

    Raises:
        SOPSEncryptionError: If encryption fails
        FileNotFoundError: If input file doesn't exist

    Example:
        >>> encrypt_file(
        ...     input_path=Path("secrets.yaml"),
        ...     output_path=Path("secrets.enc.yaml"),
        ...     age_recipient="age1example1234567890abcdefghijklmnopqrstuvwxyz1234567890abc"
        ... )
    """
    # Validate inputs
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    if not is_sops_available():
        raise SOPSEncryptionError(
            "SOPS binary not found in PATH. Please install SOPS: "
            "https://github.com/mozilla/sops#download"
        )

    if not validate_age_key(age_recipient):
        raise SOPSEncryptionError(f"Invalid AGE key format: {age_recipient[:10]}...")

    # Ensure output directory exists
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Build SOPS command
    # -e: encrypt
    # -a: AGE encryption
    # --input-type yaml: input format
    # --output-type yaml: output format
    cmd = [
        "sops",
        "-e",
        "-a",
        age_recipient,
        "--input-type",
        "yaml",
        "--output-type",
        "yaml",
        str(input_path),
    ]

    logger.info(
        "Encrypting file with SOPS",
        extra={
            "input_file": str(input_path),
            "output_file": str(output_path),
            "age_recipient": age_recipient[:10] + "...",
        },
    )

    try:
        # Run SOPS encryption
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=True,
        )

        # Write encrypted content to output file
        output_path.write_text(result.stdout)

        logger.info(
            "Successfully encrypted file",
            extra={
                "input_file": str(input_path),
                "output_file": str(output_path),
                "output_size": len(result.stdout),
            },
        )

    except subprocess.TimeoutExpired as e:
        raise SOPSEncryptionError(f"SOPS encryption timed out after {timeout} seconds") from e

    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.strip() if e.stderr else "Unknown error"
        raise SOPSEncryptionError(
            f"SOPS encryption failed: {error_msg}\n"
            f"Command: {' '.join(cmd)}\n"
            f"Exit code: {e.returncode}"
        ) from e

    except Exception as e:
        raise SOPSEncryptionError(f"Unexpected error during SOPS encryption: {e}") from e


def decrypt_file(
    input_path: Path,
    output_path: Path | None = None,
    timeout: int = 30,
) -> str:
    """Decrypt a SOPS-encrypted file.

    Note: This requires the AGE private key to be available in the environment.
    This function is primarily for testing and validation.

    Args:
        input_path: Path to encrypted input file
        output_path: Optional path to write decrypted output (if None, returns content)
        timeout: Command timeout in seconds (default: 30)

    Returns:
        Decrypted file content as string

    Raises:
        SOPSEncryptionError: If decryption fails
        FileNotFoundError: If input file doesn't exist

    Example:
        >>> content = decrypt_file(Path("secrets.enc.yaml"))
        >>> print(content)
    """
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    if not is_sops_available():
        raise SOPSEncryptionError("SOPS binary not found in PATH")

    # Build SOPS command
    cmd = [
        "sops",
        "-d",
        str(input_path),
    ]

    logger.debug(f"Decrypting file with SOPS: {input_path}")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=True,
        )

        decrypted_content = result.stdout

        # Write to output file if specified
        if output_path:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(decrypted_content)
            logger.debug(f"Decrypted content written to: {output_path}")

        return decrypted_content

    except subprocess.TimeoutExpired as e:
        raise SOPSEncryptionError(f"SOPS decryption timed out after {timeout} seconds") from e

    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.strip() if e.stderr else "Unknown error"
        raise SOPSEncryptionError(
            f"SOPS decryption failed: {error_msg}\n"
            f"This may indicate missing AGE private key or corrupted file"
        ) from e

    except Exception as e:
        raise SOPSEncryptionError(f"Unexpected error during SOPS decryption: {e}") from e


def is_file_encrypted(file_path: Path) -> bool:
    """Check if a file is SOPS-encrypted.

    SOPS-encrypted files contain a 'sops' metadata section.

    Args:
        file_path: Path to file to check

    Returns:
        True if file is SOPS-encrypted, False otherwise

    Example:
        >>> is_file_encrypted(Path("secrets.enc.yaml"))
        True
        >>> is_file_encrypted(Path("secrets.yaml"))
        False
    """
    if not file_path.exists():
        return False

    try:
        content = file_path.read_text()
        # SOPS-encrypted files contain 'sops:' metadata section
        return "sops:" in content and "mac:" in content
    except Exception as e:
        logger.warning(f"Could not read file {file_path}: {e}")
        return False


# Made with Bob
