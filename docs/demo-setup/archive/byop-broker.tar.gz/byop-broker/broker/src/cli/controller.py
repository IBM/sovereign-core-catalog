"""CLI Controller - Business logic for CLI commands.

This module contains the CLIController class which orchestrates CLI operations
by calling the appropriate broker functions and managing storage backends.
"""

import json
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

from broker.gitops_storage import GitopsStorage
from broker.logging_config import get_logger
from broker.storage import StorageInterface


logger = get_logger(__name__)


class CLIController:
    """Controller for CLI operations.

    This class manages the interaction between CLI commands and the broker's
    core provisioning logic. It handles storage backend selection (FileStorage
    for dry-run, GitopsStorage for real provisioning) and orchestrates the
    provisioning workflow.

    Attributes:
        dry_run: Whether to use dry-run mode (FileStorage)
        output_dir: Directory for dry-run output
        config_file: Optional configuration file path
        verbose: Enable verbose logging
        quiet: Suppress non-error output
        storage: Storage backend instance
    """

    def __init__(
        self,
        dry_run: bool = False,
        output_dir: Path | None = None,
        config_file: Path | None = None,
        verbose: bool = False,
        quiet: bool = False,
    ):
        """Initialize CLI controller.

        Args:
            dry_run: Use dry-run mode (FileStorage)
            output_dir: Output directory for dry-run mode
            config_file: Optional configuration file
            verbose: Enable verbose logging
            quiet: Suppress non-error output
        """
        self.dry_run = dry_run
        # Create timestamped output directory for dry-run mode
        if dry_run:
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            base_dir = output_dir or Path("./dry-run-output")
            self.output_dir = base_dir / timestamp
        else:
            self.output_dir = output_dir or Path("./dry-run-output")
        self.config_file = config_file
        self.verbose = verbose
        self.quiet = quiet

        # Load configuration FIRST (before initializing storage)
        self.config: dict[str, Any] = {}
        if config_file and config_file.exists():
            try:
                with open(config_file) as f:
                    self.config = json.load(f)
            except json.JSONDecodeError as e:
                raise ValueError(
                    f"Invalid JSON in config file: {config_file}\n"
                    f"Error: {e.msg} at line {e.lineno} column {e.colno}"
                ) from e
            except Exception as e:
                raise ValueError(f"Failed to load config file: {config_file}\nError: {e}") from e

        # Apply environment variables from config file (if present)
        self._apply_env_vars()

        # Initialize storage backend (needs config for GitOps mode)
        self.storage = self._init_storage()

    def _apply_env_vars(self) -> None:
        """Apply environment variables from config file.

        If the config file contains an 'env' section, set those environment
        variables. This allows users to define environment variables in the
        config file instead of exporting them in their shell.

        Example config:
        {
            "cluster_name": "k3s-1",
            "gitops": {...},
            "env": {
                "GITOPS_REPO_URL": "git@github.com:user/repo.git",
                "SSH_PRIVATE_KEY_PATH": "~/.ssh/id_rsa"
            }
        }
        """
        if "env" not in self.config:
            return

        env_vars = self.config["env"]
        if not isinstance(env_vars, dict):
            logger.warning("Config 'env' section must be a dictionary, ignoring")
            return

        for key, value in env_vars.items():
            if not isinstance(key, str):
                logger.warning(f"Skipping non-string env var key: {key}")
                continue

            # Convert value to string
            str_value = str(value) if value is not None else ""

            # Expand ~ in paths
            if "PATH" in key.upper() and str_value.startswith("~"):
                str_value = os.path.expanduser(str_value)

            # Set environment variable
            os.environ[key] = str_value
            logger.debug(f"Set environment variable from config: {key}")

    def _init_storage(self) -> StorageInterface:
        """Initialize storage backend based on mode.

        Returns:
            Storage backend instance (GitopsStorage in all cases)

        Raises:
            ValueError: If config file is not provided
        """
        storage: StorageInterface

        # Always use GitopsStorage (even in dry-run mode)
        # Dry-run mode will skip Git push and output files locally
        logger.info(
            f"Using GitopsStorage ({'dry-run' if self.dry_run else 'real provisioning'} mode)"
        )

        # Validate config is loaded
        if not self.config:
            raise ValueError(
                "Configuration file required. "
                "Use --config flag or ensure config.gitops.json exists."
            )

        # Validate required config sections
        # CLI uses simpler format: just cluster_name + gitops (no storage section)
        if "gitops" not in self.config:
            raise ValueError(
                "Configuration file must contain 'gitops' section. "
                "See docs/cli-configuration.md for format."
            )

        storage = GitopsStorage()

        # Build storage config from CLI format
        # CLI format: {cluster_name, gitops: {...}}
        # GitopsStorage.init() expects: {cluster_name, gitops_config: {...}}
        storage_config = {
            "cluster_name": self.config.get("cluster_name", "k3s-cluster-1"),
            "gitops_config": self.config["gitops"],
            # CLI uses synchronous mode by default (wait for completion)
            # This ensures Git push completes before CLI exits
            "async_enabled": False,
            # Pass dry-run mode to GitopsStorage
            "dry_run": self.dry_run,
            "dry_run_output_dir": str(self.output_dir) if self.dry_run else None,
        }

        # Add optional storage_dir if provided
        if "storage_dir" in self.config:
            storage_config["storage_dir"] = self.config["storage_dir"]

        storage.init(storage_config)

        logger.info(f"GitopsStorage initialized with cluster: {storage_config.get('cluster_name')}")

        return storage

    def provision(
        self,
        service_type: str,
        instance_name: str,
        plan_id: str = "default",
        cluster_name: str | None = None,
        environment: str = "dev",
        parameters: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Provision a service instance.

        Args:
            service_type: Type of service (e.g., mysql, mariadb)
            instance_name: Name for the instance
            plan_id: Service plan ID
            cluster_name: Target cluster name
            environment: Environment (dev/staging/prod)
            parameters: Service-specific parameters

        Returns:
            Result dictionary with success status and details
        """
        try:
            logger.info(
                f"Provisioning {service_type} instance '{instance_name}' "
                f"(plan: {plan_id}, env: {environment})"
            )

            # Merge parameters from config file and CLI
            merged_params = {**self.config.get("parameters", {}), **(parameters or {})}

            # Call broker's provision logic
            # Note: This is a simplified version - actual implementation would
            # call the broker's provision functions with proper error handling

            # Create instance metadata
            instance_data = {
                "instance_id": instance_name,
                "service_id": service_type,
                "plan_id": plan_id,
                "parameters": merged_params,
                "environment": environment,
                "cluster_name": cluster_name or "k3s-cluster-1",
            }
            self.storage.create(instance_name, instance_data)

            # Build response
            response: dict[str, Any] = {
                "success": True,
                "instance_name": instance_name,
                "service_type": service_type,
                "plan_id": plan_id,
                "environment": environment,
            }

            if self.dry_run:
                # List files created in dry-run mode
                instance_dir = self.output_dir / "instances" / instance_name
                if instance_dir.exists():
                    files = [
                        str(f.relative_to(self.output_dir))
                        for f in instance_dir.rglob("*")
                        if f.is_file()
                    ]
                    response["files_created"] = files
            else:
                # Add next steps for real provisioning
                response["next_steps"] = [
                    "1. Hub ArgoCD will automatically detect and deploy the application",
                    f"2. Check ArgoCD status: oc get application {service_type}-{instance_name} -n argocd",
                    f"3. Check service pods: oc get pods -n {instance_name}",
                    f"4. Get credentials: oc get secret {service_type}-secret -n {instance_name} -o yaml",
                ]

            return response

        except Exception as e:
            logger.error(f"Provisioning failed: {e}")
            return {
                "success": False,
                "error": str(e),
            }

    def clean(
        self,
        instance_name: str | None = None,
        clean_all: bool = False,
    ) -> dict[str, Any]:
        """Clean up dry-run artifacts.

        Args:
            instance_name: Specific instance to clean (optional)
            clean_all: Clean all artifacts

        Returns:
            Result dictionary with success status and details
        """
        try:
            if not self.dry_run:
                raise ValueError("Clean command only works with dry-run artifacts")

            files_deleted = 0

            if clean_all:
                logger.info(f"Cleaning all artifacts in {self.output_dir}")
                if self.output_dir.exists():
                    shutil.rmtree(self.output_dir)
                    files_deleted = 1  # Count directory as 1
                    logger.info(f"Deleted directory: {self.output_dir}")
            elif instance_name:
                logger.info(f"Cleaning artifacts for instance '{instance_name}'")
                instance_dir = self.output_dir / "instances" / instance_name
                if instance_dir.exists():
                    # Count files before deletion
                    files_deleted = sum(1 for _ in instance_dir.rglob("*") if _.is_file())
                    shutil.rmtree(instance_dir)
                    logger.info(f"Deleted {files_deleted} file(s) for instance '{instance_name}'")
                else:
                    logger.warning(f"Instance directory not found: {instance_dir}")

            return {
                "success": True,
                "files_deleted": files_deleted,
            }

        except Exception as e:
            logger.error(f"Clean failed: {e}")
            return {
                "success": False,
                "error": str(e),
            }

    def deprovision(
        self,
        instance_name: str,
    ) -> dict[str, Any]:
        """Deprovision a service instance.

        Args:
            instance_name: Name of the instance to deprovision

        Returns:
            Result dictionary with success status and details
        """
        try:
            logger.info(f"Deprovisioning instance '{instance_name}'")

            # Check if instance exists
            if not self.storage.exists(instance_name):
                raise ValueError(f"Instance '{instance_name}' not found")

            # Delete instance
            self.storage.delete(instance_name)

            response: dict[str, Any] = {
                "success": True,
                "instance_name": instance_name,
            }

            if not self.dry_run:
                response["next_steps"] = [
                    "1. ArgoCD will automatically remove the application",
                    f"2. Verify removal: oc get application {instance_name} -n argocd",
                    f"3. Check namespace deletion: oc get namespace {instance_name}",
                ]

            return response

        except Exception as e:
            logger.error(f"Deprovision failed: {e}")
            return {
                "success": False,
                "error": str(e),
            }

    def update(
        self,
        instance_name: str,
        parameters: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Update a service instance.

        Args:
            instance_name: Name of the instance to update
            parameters: New parameters to apply

        Returns:
            Result dictionary with success status and details including:
            - old_parameters: Original parameters before update
            - new_parameters: Parameters after update
            - old_instance_data: Complete instance data before update
            - new_instance_data: Complete instance data after update
        """
        try:
            logger.info(f"Updating instance '{instance_name}'")

            # Get existing instance
            instance_data = self.storage.get(instance_name)
            if not instance_data:
                raise ValueError(f"Instance '{instance_name}' not found")

            # Store old state for diff
            old_parameters = instance_data.get("parameters", {}).copy()
            old_instance_data = instance_data.copy()

            # Merge new parameters
            if parameters:
                instance_data["parameters"] = {
                    **instance_data.get("parameters", {}),
                    **parameters,
                }

            new_parameters = instance_data.get("parameters", {})
            new_instance_data = instance_data.copy()

            # Update instance
            self.storage.update(instance_name, instance_data)

            response: dict[str, Any] = {
                "success": True,
                "instance_name": instance_name,
                "updated_parameters": parameters or {},
                "old_parameters": old_parameters,
                "new_parameters": new_parameters,
                "old_instance_data": old_instance_data,
                "new_instance_data": new_instance_data,
            }

            if not self.dry_run:
                response["next_steps"] = [
                    "1. ArgoCD will detect changes and sync automatically",
                    f"2. Monitor sync status: oc get application {instance_name} -n argocd",
                    f"3. Check pod status: oc get pods -n {instance_name}",
                ]

            return response

        except Exception as e:
            logger.error(f"Update failed: {e}")
            return {
                "success": False,
                "error": str(e),
            }

    def get(
        self,
        instance_name: str,
    ) -> dict[str, Any]:
        """Get details of a service instance.

        Args:
            instance_name: Name of the instance

        Returns:
            Result dictionary with success status and instance details
        """
        try:
            logger.info(f"Getting instance '{instance_name}'")

            # Get instance data
            instance_data = self.storage.get(instance_name)
            if not instance_data:
                raise ValueError(f"Instance '{instance_name}' not found")

            return {
                "success": True,
                "instance": instance_data,
            }

        except Exception as e:
            logger.error(f"Get failed: {e}")
            return {
                "success": False,
                "error": str(e),
            }

    def list_instances(self) -> dict[str, Any]:
        """List all service instances.

        Returns:
            Result dictionary with success status and list of instances
        """
        try:
            logger.info("Listing all instances")

            # Get all instances
            instances = self.storage.list_all()

            return {
                "success": True,
                "instances": instances,
                "count": len(instances),
            }

        except Exception as e:
            logger.error(f"List failed: {e}")
            return {
                "success": False,
                "error": str(e),
            }

    def catalog_list(self) -> dict[str, Any]:
        """List all available services from GitOps repository.

        Returns:
            Result dictionary with success status and list of services
        """
        try:
            logger.info("Listing available services from catalog")

            # Import catalog discovery
            from broker.catalog_discovery import discover_services

            # Get GitOps repo directory from storage
            gitops_repo_dir = None
            if hasattr(self.storage, "state_manager"):
                from broker.gitops.git_config import GitConfig

                gitops_repo_dir = str(GitConfig.get_repo_dir())
                logger.info(f"Using GitOps repository: {gitops_repo_dir}")

            # Discover services
            catalog_data = discover_services(gitops_repo_dir)
            services = catalog_data.get("services", [])

            return {
                "success": True,
                "services": services,
                "count": len(services),
            }

        except Exception as e:
            logger.error(f"Catalog list failed: {e}")
            return {
                "success": False,
                "error": str(e),
            }

    def catalog_show(
        self, service_name: str, show_schema: bool = False, show_example: bool = False
    ) -> dict[str, Any]:
        """Show details of a specific service.

        Args:
            service_name: Name of the service to show.
                         Can be either the short name (e.g., 'mariadb')
                         or the full service ID (e.g., 'mariadb-service')
            show_schema: Whether to include the parameter schema
            show_example: Whether to include an example payload generated from schema

        Returns:
            Result dictionary with success status and service details
        """
        try:
            logger.info(f"Getting details for service '{service_name}'")

            # Import catalog discovery
            from broker.catalog_discovery import discover_services

            # Get GitOps repo directory from storage
            gitops_repo_dir = None
            if hasattr(self.storage, "state_manager"):
                from broker.gitops.git_config import GitConfig

                gitops_repo_dir = str(GitConfig.get_repo_dir())

            # Discover all services
            catalog_data = discover_services(gitops_repo_dir)
            services = catalog_data.get("services", [])

            # Use service_name directly as service_id
            service_id = service_name

            # Find the requested service
            service_data = None

            # Try exact match on ID
            for service in services:
                if service.get("id") == service_id:
                    service_data = service
                    break

            if not service_data:
                # Try case-insensitive match
                for service in services:
                    service_id_lower = service.get("id", "").lower()
                    if (
                        service_id_lower == service_id.lower()
                        or service.get("name", "").lower() == service_name.lower()
                    ):
                        service_data = service
                        break

            if not service_data:
                # Build list of available services
                available_services = []
                for s in services:
                    svc_id = s.get("id", "")
                    available_services.append(svc_id)

                raise ValueError(
                    f"Service '{service_name}' not found. "
                    f"Available services: {', '.join(available_services)}"
                )

            # Load schema if requested (needed for both --show-schema and --show-example)
            schema = None
            if (show_schema or show_example) and gitops_repo_dir:
                try:
                    from pathlib import Path

                    from broker.gitops.template_loader import TemplateLoader

                    loader = TemplateLoader(Path(gitops_repo_dir))
                    schema = loader.load_schema(service_id, "latest")
                    logger.info(f"Loaded schema for service '{service_id}'")
                except Exception as schema_error:
                    logger.warning(f"Could not load schema for '{service_id}': {schema_error}")
                    # Don't fail the whole command if schema loading fails
                    schema = {"error": f"Schema not available: {str(schema_error)}"}

            result: dict[str, Any] = {
                "success": True,
                "service": service_data,
            }

            if show_schema:
                result["schema"] = schema

            if show_example and schema and "error" not in schema:
                result["example"] = self._generate_example_from_schema(schema)

            return result

        except Exception as e:
            logger.error(f"Catalog show failed: {e}")
            return {
                "success": False,
                "error": str(e),
            }

    def _generate_example_from_schema(self, schema: dict[str, Any]) -> dict[str, Any]:
        """Generate an example payload from a JSON schema.

        Uses the 'examples', 'default', and 'enum' fields from the schema to
        create a realistic example payload.

        Args:
            schema: JSON schema dictionary

        Returns:
            Example payload dictionary
        """
        example: dict[str, Any] = {}
        properties = schema.get("properties", {})

        for prop_name, prop_schema in properties.items():
            # Priority: examples > default > enum > type-based
            if "examples" in prop_schema and prop_schema["examples"]:
                # Use first example
                example[prop_name] = prop_schema["examples"][0]
            elif "default" in prop_schema:
                # Use default value
                example[prop_name] = prop_schema["default"]
            elif "enum" in prop_schema and prop_schema["enum"]:
                # Use first enum value
                example[prop_name] = prop_schema["enum"][0]
            elif prop_schema.get("type") == "string":
                # Generate placeholder based on description or name
                if "password" in prop_name.lower():
                    example[prop_name] = "example-password"
                elif "url" in prop_name.lower():
                    example[prop_name] = "https://example.com"
                elif "name" in prop_name.lower():
                    example[prop_name] = f"example-{prop_name.replace('_', '-')}"
                else:
                    example[prop_name] = f"<{prop_name}>"
            elif prop_schema.get("type") in ("number", "integer"):
                example[prop_name] = 0
            elif prop_schema.get("type") == "boolean":
                example[prop_name] = False
            elif prop_schema.get("type") == "array":
                example[prop_name] = []
            elif prop_schema.get("type") == "object":
                example[prop_name] = {}

        return example


# Made with Bob
