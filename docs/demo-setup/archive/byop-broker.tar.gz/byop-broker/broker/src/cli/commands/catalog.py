"""Service catalog discovery commands.

This module contains all commands for discovering and viewing available services
from the GitOps repository.
"""

import json
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table


console = Console()


def get_default_output_format(
    config_path: str | None, valid_formats: list[str] | None = None
) -> str:
    """Get default output format from config file.

    Args:
        config_path: Path to config file
        valid_formats: List of valid formats for the command (default: ["table", "json", "text", "yaml"])

    Returns:
        Default output format from config, or "text" if not set/invalid
    """
    if valid_formats is None:
        valid_formats = ["table", "json", "text", "yaml"]

    if config_path and Path(config_path).exists():
        try:
            with open(config_path) as f:
                config_data = json.load(f)

            if "default_output" in config_data:
                output = str(config_data["default_output"])
                # Return if valid for this command
                if output in valid_formats:
                    return output
        except Exception:
            pass

    # Default to "text" for clean, parseable output
    return "text"


@click.group()
def catalog_group() -> None:
    """Discover available services.

    Commands for discovering and viewing available services from the GitOps repository.

    Examples:
        broker-cli catalog list
        broker-cli catalog show mariadb
    """
    pass


@catalog_group.command(name="list")
@click.option(
    "--output",
    "-o",
    type=click.Choice(["table", "json", "yaml", "text"], case_sensitive=False),
    default=None,
    help="Output format: table, json, yaml, or text (default from config or text)",
)
@click.pass_context
def catalog_list(ctx: click.Context, output: str | None) -> None:
    """List all available services.

    This command lists all services available for provisioning from the GitOps repository.

    The output format can be set in the config file using "default_output" key,
    or overridden with the --output flag.

    Examples:

    \b
    # List services (default format from config)
    broker-cli catalog list

    \b
    # List services (JSON format)
    broker-cli catalog list --output json

    \b
    # List services (plain text format)
    broker-cli catalog list --output text
    """
    from cli.controller import CLIController
    from cli.output import print_error, print_info

    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)
    global_config = ctx.obj.get("config")

    # Determine output format: CLI flag > config file > default (table)
    if output is None:
        output = get_default_output_format(
            global_config, valid_formats=["table", "json", "yaml", "text"]
        )

    # Create controller
    controller = CLIController(
        dry_run=False,  # Catalog discovery needs GitOps repo
        output_dir=None,
        config_file=Path(global_config) if global_config else None,
        verbose=verbose,
        quiet=quiet,
    )

    # Execute catalog list
    try:
        result = controller.catalog_list()

        if result["success"]:
            services = result["services"]
            count = result["count"]

            if count == 0:
                if not quiet:
                    print_info("No services found in GitOps repository")
                return

            if output == "json":
                console.print_json(data=services)
            elif output == "yaml":
                import yaml

                console.print(yaml.dump(services, default_flow_style=False))
            elif output == "text":
                # Plain text columnar output (like kubectl get or docker ps)
                # Calculate column widths
                services_list = list(services)
                max_service = max(len(svc.get("id", "N/A")) for svc in services_list)
                max_name = max(len(svc.get("name", "N/A")) for svc in services_list)
                max_desc = max(
                    len(svc.get("description", "")[:50]) for svc in services_list
                )  # Truncate long descriptions

                # Calculate max plans width
                max_plans = 0
                for svc in services_list:
                    plans = svc.get("plans", [])
                    plan_names = ", ".join([p.get("id", "") for p in plans])
                    max_plans = max(max_plans, len(plan_names))

                # Ensure minimum widths for headers
                max_service = max(max_service, len("SERVICE"))
                max_name = max(max_name, len("NAME"))
                max_desc = max(max_desc, len("DESCRIPTION"))
                max_plans = max(max_plans, len("PLANS"))

                # Print header
                print(
                    f"{'SERVICE':<{max_service}}  {'NAME':<{max_name}}  {'DESCRIPTION':<{max_desc}}  {'PLANS':<{max_plans}}"
                )

                # Print services
                for service in services_list:
                    service_id = service.get("id", "N/A")
                    name = service.get("name", "N/A")
                    description = service.get("description", "")[:50]  # Truncate long descriptions
                    plans = service.get("plans", [])
                    plan_names = ", ".join([p.get("id", "") for p in plans])
                    print(
                        f"{service_id:<{max_service}}  {name:<{max_name}}  {description:<{max_desc}}  {plan_names:<{max_plans}}"
                    )
            else:  # table format
                table = Table(title=f"Available Services ({count} total)")
                table.add_column("Service", style="cyan")
                table.add_column("Name", style="green")
                table.add_column("Description", style="dim")
                table.add_column("Plans", style="yellow")

                for service in services:
                    service_id = service.get("id", "N/A")
                    name = service.get("name", "N/A")
                    description = service.get("description", "")
                    plans = service.get("plans", [])
                    plan_names = ", ".join([p.get("id", "") for p in plans])

                    table.add_row(service_id, name, description, plan_names)

                console.print(table)
        else:
            print_error(f"Catalog list failed: {result.get('error', 'Unknown error')}")
            sys.exit(1)

    except Exception as e:
        print_error(f"Catalog list failed: {e}")
        if verbose:
            console.print_exception()
        sys.exit(1)


@catalog_group.command(name="show")
@click.argument("service")
@click.option(
    "--output",
    "-o",
    type=click.Choice(["table", "json", "yaml", "text"], case_sensitive=False),
    default=None,
    help="Output format: table, json, yaml, or text (default from config or table)",
)
@click.option(
    "--show-schema",
    is_flag=True,
    help="Include parameter schema (provision payload requirements)",
)
@click.option(
    "--show-example",
    is_flag=True,
    help="Include example payload generated from schema",
)
@click.pass_context
def catalog_show(
    ctx: click.Context, service: str, output: str | None, show_schema: bool, show_example: bool
) -> None:
    """Show details of a specific service.

    This command displays detailed information about a service including all available plans,
    optionally the parameter schema, and/or an example payload.

    The output format can be set in the config file using "default_output" key,
    or overridden with the --output flag.

    Examples:

    \b
    # Show service details (default format from config)
    broker-cli catalog show mariadb

    \b
    # Show service details with parameter schema
    broker-cli catalog show mariadb --show-schema

    \b
    # Show service details with example payload
    broker-cli catalog show mariadb --show-example

    \b
    # Show service details (JSON format with schema and example)
    broker-cli catalog show mariadb --output json --show-schema --show-example

    \b
    # Show service details (plain text format)
    broker-cli catalog show mariadb --output text
    """
    from cli.controller import CLIController
    from cli.output import print_error

    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)
    global_config = ctx.obj.get("config")

    # Determine output format: CLI flag > config file > default (table)
    if output is None:
        output = get_default_output_format(
            global_config, valid_formats=["table", "json", "yaml", "text"]
        )

    # Create controller
    controller = CLIController(
        dry_run=False,  # Catalog discovery needs GitOps repo
        output_dir=None,
        config_file=Path(global_config) if global_config else None,
        verbose=verbose,
        quiet=quiet,
    )

    # Execute catalog show
    try:
        result = controller.catalog_show(
            service_name=service, show_schema=show_schema, show_example=show_example
        )

        if result["success"]:
            service_data = result["service"]
            schema_data = result.get("schema")
            example_data = result.get("example")

            if output == "json":
                output_data = {"service": service_data}
                if show_schema and schema_data:
                    output_data["schema"] = schema_data
                if show_example and example_data:
                    output_data["example"] = example_data
                console.print_json(data=output_data)
            elif output == "yaml":
                import yaml

                output_data = {"service": service_data}
                if show_schema and schema_data:
                    output_data["schema"] = schema_data
                if show_example and example_data:
                    output_data["example"] = example_data
                console.print(yaml.dump(output_data, default_flow_style=False))
            elif output == "text":
                # Plain text output (no colors, no formatting)
                print("Service Details")
                print(f"Name: {service_data.get('name', 'N/A')}")
                print(f"ID: {service_data.get('id', 'N/A')}")
                print(f"Description: {service_data.get('description', 'N/A')}")
                print(f"Bindable: {service_data.get('bindable', False)}")
                print()

                # Plans
                plans = service_data.get("plans", [])
                if plans:
                    print("Available Plans")
                    for plan in plans:
                        print(f"  Plan ID: {plan.get('id', 'N/A')}")
                        print(f"  Name: {plan.get('name', 'N/A')}")
                        print(f"  Description: {plan.get('description', '')}")
                        print()

                # Schema (if requested)
                if show_schema and schema_data:
                    print("Parameter Schema")
                    if "error" in schema_data:
                        print(f"  Error: {schema_data['error']}")
                    else:
                        schema_json = json.dumps(schema_data, indent=2)
                        print(schema_json)
                    print()

                # Example (if requested)
                if show_example and example_data:
                    print("Example Provision Payload")
                    example_json = json.dumps(example_data, indent=2)
                    print(example_json)
                    print()
            else:  # table format
                # Service info panel
                info_text = f"[cyan]Name:[/cyan] {service_data.get('name', 'N/A')}\n"
                info_text += f"[cyan]ID:[/cyan] {service_data.get('id', 'N/A')}\n"
                info_text += f"[cyan]Description:[/cyan] {service_data.get('description', 'N/A')}\n"
                info_text += f"[cyan]Bindable:[/cyan] {service_data.get('bindable', False)}"

                console.print(Panel(info_text, title="Service Details", border_style="green"))

                # Plans table
                plans = service_data.get("plans", [])
                if plans:
                    console.print()  # Blank line
                    table = Table(title="Available Plans")
                    table.add_column("Plan ID", style="cyan")
                    table.add_column("Name", style="green")
                    table.add_column("Description", style="dim")

                    for plan in plans:
                        table.add_row(
                            plan.get("id", "N/A"),
                            plan.get("name", "N/A"),
                            plan.get("description", ""),
                        )

                    console.print(table)

                # Schema panel (if requested)
                if show_schema and schema_data:
                    console.print()  # Blank line
                    if "error" in schema_data:
                        console.print(
                            Panel(
                                f"[yellow]{schema_data['error']}[/yellow]",
                                title="Parameter Schema",
                                border_style="yellow",
                            )
                        )
                    else:
                        schema_json = json.dumps(schema_data, indent=2)
                        syntax = Syntax(schema_json, "json", theme="monokai", line_numbers=True)
                        console.print(
                            Panel(
                                syntax,
                                title="Parameter Schema (Provision Payload Requirements)",
                                border_style="blue",
                            )
                        )

                # Example panel (if requested)
                if show_example and example_data:
                    console.print()  # Blank line
                    example_json = json.dumps(example_data, indent=2)
                    syntax = Syntax(example_json, "json", theme="monokai", line_numbers=True)
                    console.print(
                        Panel(syntax, title="Example Provision Payload", border_style="green")
                    )
        else:
            print_error(f"Catalog show failed: {result.get('error', 'Unknown error')}")
            sys.exit(1)

    except Exception as e:
        print_error(f"Catalog show failed: {e}")
        if verbose:
            console.print_exception()
        sys.exit(1)


# Made with Bob
