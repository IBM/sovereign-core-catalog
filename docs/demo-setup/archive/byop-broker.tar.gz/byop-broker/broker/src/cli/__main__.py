"""CLI entry point for broker-cli command.

This module provides the main entry point for the broker-cli command-line tool.
It sets up the Click command group and registers all available commands.

Usage:
    python -m cli [COMMAND] [OPTIONS]

    Or after installation:
    broker-cli [COMMAND] [OPTIONS]

Command Groups:
    config       - Manage configuration profiles
    catalog      - Discover available services
    instance     - Manage service instances

Examples:
    broker-cli config init
    broker-cli catalog list
    broker-cli instance provision --service mysql --instance dev-001 --dry-run
    broker-cli instance list
"""

import sys
from pathlib import Path

import click
from rich.console import Console

from cli import __version__
from cli.commands import catalog_group, config_group, instance_group


console = Console()


def find_default_config() -> str | None:
    """Find default config file in standard locations.

    Search order:
    1. ./config.gitops.json (current directory)
    2. ~/.broker-cli/config (user config directory)

    Returns:
        Path to config file or None if not found
    """
    # Check current directory first (project-specific config)
    local_config = Path("config.gitops.json")
    if local_config.exists():
        return str(local_config)

    # Check user config directory
    user_config = Path.home() / ".broker-cli" / "config"
    if user_config.exists():
        return str(user_config)

    return None


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(version=__version__, prog_name="broker-cli")
@click.option(
    "--config",
    "-c",
    type=click.Path(dir_okay=False, readable=True),
    help="Path to configuration file",
    default=None,
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Enable verbose output (DEBUG level logging)",
)
@click.option(
    "--quiet",
    "-q",
    is_flag=True,
    help="Suppress all output except errors",
)
@click.pass_context
def cli(ctx: click.Context, config: str | None, verbose: bool, quiet: bool) -> None:
    """BYOP Service Provisioning CLI.

    A standalone command-line tool for testing and managing service instance
    provisioning without running the full broker server.

    Use --help with any command for detailed information.
    """
    # Store global options in context
    ctx.ensure_object(dict)

    # Resolve config path if not explicitly provided
    if config is None:
        config = find_default_config()
    elif config and not Path(config).exists():
        console.print(f"[red]Error: Config file not found: {config}[/red]")
        sys.exit(1)

    ctx.obj["config"] = config
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet

    # Configure logging based on verbosity
    # Default: ERROR (only show critical errors, suppress INFO/WARNING)
    # Verbose: INFO (show all messages including INFO/WARNING/ERROR)
    # Quiet: CRITICAL (only show critical errors)
    import os

    from broker.logging_config import configure_logging

    if verbose:
        configure_logging(level="INFO")
    elif quiet:
        configure_logging(level="CRITICAL")
    else:
        configure_logging(level="ERROR")

    # Disable ArgoCD Application file creation by default for CLI
    # App-of-Apps is managed externally by argocd-configure-repo.sh script
    # Users can override by setting CREATE_ARGOCD_APP=true in environment
    if "CREATE_ARGOCD_APP" not in os.environ:
        os.environ["CREATE_ARGOCD_APP"] = "false"


# Register command groups
cli.add_command(config_group, name="config")
cli.add_command(catalog_group, name="catalog")
cli.add_command(instance_group, name="instance")


def main() -> None:
    """Main entry point for the CLI."""
    try:
        cli(obj={})
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled by user[/yellow]")
        sys.exit(130)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()


# Made with Bob
