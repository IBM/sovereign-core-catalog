"""CLI command groups.

This package contains all CLI command groups organized by functionality:
- config: Configuration management commands
- catalog: Service discovery commands
- instance: Instance management commands
"""

from cli.commands.catalog import catalog_group
from cli.commands.config import config_group
from cli.commands.instance import instance_group


__all__ = ["config_group", "catalog_group", "instance_group"]

# Made with Bob
