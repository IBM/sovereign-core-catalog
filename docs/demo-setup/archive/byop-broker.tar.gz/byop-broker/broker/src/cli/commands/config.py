"""Configuration management commands.

This module contains all commands for managing CLI configuration profiles.
"""

import json
import os
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table


console = Console()


def get_default_output_format(
    config_path: str | None, valid_formats: list[str] | None = None
) -> str:
    """Get default output format from config file.

    Args:
        config_path: Path to config file
        valid_formats: List of valid formats for the command (default: ["table", "json", "text", "yaml"])

    Returns:
        Default output format from config, or "text" if not set/invalid
    """
    if valid_formats is None:
        valid_formats = ["table", "json", "text", "yaml"]

    if config_path and Path(config_path).exists():
        try:
            with open(config_path) as f:
                config_data = json.load(f)

            if "default_output" in config_data:
                output = str(config_data["default_output"])
                # Return if valid for this command
                if output in valid_formats:
                    return output
        except Exception:
            pass

    # Default to "text" for clean, parseable output
    return "text"


@click.group()
def config_group() -> None:
    """Manage configuration profiles.

    Commands for managing configuration files and profiles in ~/.broker-cli/.

    Configuration Search Order:
    1. --config /path/to/config.json (explicit CLI flag)
    2. ./config.gitops.json (project-specific config)
    3. ~/.broker-cli/config (user default profile)

    Examples:
        broker-cli config init
        broker-cli config list
        broker-cli config use prod
    """
    pass


@config_group.command()
@click.option(
    "--profile",
    "-p",
    default="default",
    help="Profile name (default: default)",
)
def init(profile: str) -> None:
    """Initialize user configuration directory.

    Creates ~/.broker-cli/ directory and example config file.

    Examples:
        broker-cli config init
        broker-cli config init --profile k3s
        broker-cli config init --profile prod
    """
    config_dir = Path.home() / ".broker-cli"
    config_dir.mkdir(exist_ok=True)

    config_file = config_dir / f"{profile}.json"

    if config_file.exists():
        console.print(f"[yellow]Config already exists: {config_file}[/yellow]")
        console.print("[dim]Edit it or use a different profile name[/dim]")
        return

    # Create example config
    example_config = {
        "cluster_name": "k3s-cluster-1",
        "gitops": {
            "repo_url": "git@github.com:your-org/gitops-repo.git",
            "branch": "main",
            "git_backend": "remote",
            "git_auth_method": "ssh",
            "ssh_private_key_path": "~/.ssh/gitops_deploy_key",
        },
    }

    with open(config_file, "w") as f:
        json.dump(example_config, f, indent=2)

    console.print(f"[green]✓[/green] Created config: [cyan]{config_file}[/cyan]")

    # Create symlink if this is the first profile
    config_link = config_dir / "config"
    if not config_link.exists():
        config_link.symlink_to(config_file.name)
        console.print("[green]✓[/green] Set as active profile")
        console.print(f"[dim]  {config_link} -> {config_file.name}[/dim]")
    else:
        console.print("\n[dim]To activate this profile:[/dim]")
        console.print(f"  broker-cli config use {profile}")


@config_group.command(name="list")
@click.option(
    "--output",
    "-o",
    type=click.Choice(["table", "json", "text"], case_sensitive=False),
    default=None,
    help="Output format: table, json, or text (default from config or text)",
)
@click.pass_context
def list_profiles(ctx: click.Context, output: str | None) -> None:
    """List available configuration profiles.

    Shows all profiles in ~/.broker-cli/ and indicates the active one.

    The output format can be set in the config file using "default_output" key,
    or overridden with the --output flag.

    Examples:

    \b
    # List profiles (default format from config)
    broker-cli config list

    \b
    # List profiles (text format)
    broker-cli config list --output text
    """
    config_dir = Path.home() / ".broker-cli"

    # Determine output format: CLI flag > config file > default (text)
    global_config = ctx.obj.get("config")
    if output is None:
        output = get_default_output_format(global_config, valid_formats=["table", "json", "text"])

    if not config_dir.exists():
        if output == "json":
            console.print_json(
                data={"profiles": [], "active_profile": None, "error": "No config directory found"}
            )
        elif output == "text":
            print("No config directory found.")
            print("Run 'broker-cli config init' to create one.")
        else:
            console.print("[yellow]No config directory found.[/yellow]")
            console.print("[dim]Run 'broker-cli config init' to create one.[/dim]")
        return

    # Find active profile
    config_link = config_dir / "config"
    active_profile = None
    if config_link.is_symlink():
        active_profile = config_link.readlink().name.replace(".json", "")

    # List all profiles
    profile_files = sorted(config_dir.glob("*.json"))

    if not profile_files:
        if output == "json":
            console.print_json(data={"profiles": [], "active_profile": active_profile})
        elif output == "text":
            print("No profiles found.")
            print("Run 'broker-cli config init' to create one.")
        else:
            console.print("[yellow]No profiles found.[/yellow]")
            console.print("[dim]Run 'broker-cli config init' to create one.[/dim]")
        return

    # Prepare profile data
    profiles = []
    for profile_file in profile_files:
        profile_name = profile_file.stem
        is_active = profile_name == active_profile
        profiles.append({"name": profile_name, "active": is_active, "path": str(profile_file)})

    if output == "json":
        console.print_json(data={"profiles": profiles, "active_profile": active_profile})
    elif output == "text":
        # Plain text columnar output
        max_name = max(len(str(p["name"])) for p in profiles)
        max_name = max(max_name, len("PROFILE"))

        print(f"{'PROFILE':<{max_name}}  STATUS   PATH")
        for profile in profiles:
            status = "active" if profile["active"] else ""
            print(f"{profile['name']:<{max_name}}  {status:<7}  {profile['path']}")
    else:  # table format
        table = Table(title="Configuration Profiles", show_header=True)
        table.add_column("Profile", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Path", style="dim")

        for profile in profiles:
            status = "→ active" if profile["active"] else ""
            table.add_row(str(profile["name"]), status, str(profile["path"]))

        console.print(table)

        if active_profile:
            console.print(f"\n[dim]Active profile: {active_profile}[/dim]")
        else:
            console.print("\n[yellow]No active profile set[/yellow]")
        console.print("[dim]Use 'broker-cli config use <profile>' to activate one[/dim]")


@config_group.command()
@click.argument("profile")
def use(profile: str) -> None:
    """Switch to a different configuration profile.

    Creates a symlink at ~/.broker-cli/config pointing to the specified profile.

    Examples:
        broker-cli config use k3s
        broker-cli config use prod
        broker-cli config use dev
    """
    config_dir = Path.home() / ".broker-cli"
    config_file = config_dir / f"{profile}.json"

    if not config_file.exists():
        console.print(f"[red]Profile not found: {profile}[/red]")

        # Show available profiles
        available = list(config_dir.glob("*.json"))
        if available:
            console.print("\n[dim]Available profiles:[/dim]")
            for p in available:
                console.print(f"  • {p.stem}")
        else:
            console.print(
                "[dim]No profiles found. Run 'broker-cli config init' to create one.[/dim]"
            )
        return

    config_link = config_dir / "config"
    if config_link.exists() or config_link.is_symlink():
        config_link.unlink()

    config_link.symlink_to(config_file.name)
    console.print(f"[green]✓[/green] Switched to profile: [cyan]{profile}[/cyan]")
    console.print(f"[dim]  {config_link} -> {config_file.name}[/dim]")


@config_group.command()
@click.option(
    "--output",
    "-o",
    type=click.Choice(["table", "json", "text"], case_sensitive=False),
    default=None,
    help="Output format: table, json, or text (default from config or text)",
)
@click.pass_context
def env(ctx: click.Context, output: str | None) -> None:
    """Display current environment variables and configuration.

    Shows all environment variables relevant to the broker, including GitOps
    configuration, authentication settings, and runtime options.

    The output format can be set in the config file using "default_output" key,
    or overridden with the --output flag.

    Examples:
        broker-cli config env
        broker-cli config env --output json
        broker-cli config env --output text
    """
    # Get config file path
    global_config = ctx.obj.get("config")

    # Load config file if available and apply env vars from it
    config_data = None
    if global_config and Path(global_config).exists():
        try:
            with open(global_config) as f:
                config_data = json.load(f)

            # Apply environment variables from config file (same logic as CLIController)
            if "env" in config_data and isinstance(config_data["env"], dict):
                for key, value in config_data["env"].items():
                    if not isinstance(key, str):
                        continue

                    # Convert value to string
                    str_value = str(value) if value is not None else ""

                    # Expand ~ in paths
                    if "PATH" in key.upper() and str_value.startswith("~"):
                        str_value = os.path.expanduser(str_value)

                    # Set environment variable
                    os.environ[key] = str_value
        except Exception:
            pass

    # Determine output format: CLI flag > config file > default (text)
    if output is None:
        output = get_default_output_format(global_config, valid_formats=["table", "json", "text"])

    # Collect environment variables (after applying from config)
    env_vars = {
        "GitOps Configuration": {
            "GITOPS_REPO_URL": os.getenv("GITOPS_REPO_URL", ""),
            "GITOPS_BRANCH": os.getenv("GITOPS_BRANCH", ""),
            "GIT_BACKEND": os.getenv("GIT_BACKEND", ""),
            "GIT_AUTH_METHOD": os.getenv("GIT_AUTH_METHOD", ""),
            "SSH_PRIVATE_KEY_PATH": os.getenv("SSH_PRIVATE_KEY_PATH", ""),
            "GIT_USERNAME": os.getenv("GIT_USERNAME", ""),
            "GIT_PASSWORD": "***" if os.getenv("GIT_PASSWORD") else "",
        },
        "Broker Configuration": {
            "CLUSTER_NAME": os.getenv("CLUSTER_NAME", ""),
            "DASHBOARD_URL": os.getenv("DASHBOARD_URL", ""),
            "CREATE_ARGOCD_APP": os.getenv("CREATE_ARGOCD_APP", ""),
            "DUMP_PROVISION_VARIABLES": os.getenv("DUMP_PROVISION_VARIABLES", ""),
        },
        "Authentication": {
            "AUTH_ENABLED": os.getenv("AUTH_ENABLED", ""),
            "AUTH_JWKS_URL": os.getenv("AUTH_JWKS_URL", ""),
            "AUTH_ISSUER": os.getenv("AUTH_ISSUER", ""),
            "AUTH_AUDIENCE": os.getenv("AUTH_AUDIENCE", ""),
        },
        "Runtime": {
            "PYTHONPATH": os.getenv("PYTHONPATH", ""),
            "LOG_LEVEL": os.getenv("LOG_LEVEL", ""),
        },
        "CLI Settings": {
            "Config File": global_config or "",
            "Verbose": str(ctx.obj.get("verbose", False)),
            "Quiet": str(ctx.obj.get("quiet", False)),
        },
    }

    if output == "json":
        output_data = {
            "environment_variables": env_vars,
            "config_file": global_config,
            "config_data": config_data,
        }
        console.print_json(data=output_data)
    elif output == "text":
        # Plain text output (no colors, no tables)
        if global_config:
            print(f"Config File: {global_config}")
            if Path(global_config).exists():
                print("Status: File exists")
            else:
                print("Status: File not found")
            print()

        # Display environment variables by category
        for category, vars_dict in env_vars.items():
            print(f"=== {category} ===")
            for var_name, var_value in vars_dict.items():
                print(f"{var_name}: {var_value}")
            print()

        # Display config file content if available
        if config_data:
            print("=== Config File Content ===")
            print(json.dumps(config_data, indent=2))
    else:  # table format
        # Display config file info
        if global_config:
            config_info = f"[cyan]Config File:[/cyan] {global_config}\n"
            if Path(global_config).exists():
                config_info += "[green]✓[/green] File exists"
            else:
                config_info += "[red]✗[/red] File not found"
            console.print(Panel(config_info, title="Configuration", border_style="blue"))
            console.print()

        # Display environment variables by category
        for category, vars_dict in env_vars.items():
            table = Table(title=category, show_header=True)
            table.add_column("Variable", style="cyan", no_wrap=True)
            table.add_column("Value", style="green")

            for var_name, var_value in vars_dict.items():
                # Highlight empty/unset variables with dim style
                if not var_value:
                    value_display = f"[dim]{var_value}[/dim]"
                elif var_name.endswith("PASSWORD") or var_name.endswith("KEY"):
                    value_display = f"[yellow]{var_value}[/yellow]"
                else:
                    value_display = var_value

                table.add_row(var_name, value_display)

            console.print(table)
            console.print()

        # Display config file content if available
        if config_data:
            console.print(
                Panel(
                    Syntax(json.dumps(config_data, indent=2), "json", theme="monokai"),
                    title="Config File Content",
                    border_style="green",
                )
            )


# Made with Bob
