"""
Gunicorn Configuration for GitOps CSB Broker

This configuration file defines production settings for the Gunicorn WSGI server.
All settings can be overridden via environment variables or command-line arguments.

Documentation: https://docs.gunicorn.org/en/stable/settings.html
"""

import json
import logging
import multiprocessing
import os
from datetime import datetime, timezone


class HealthCheckFilter(logging.Filter):
    """Filter out health check requests from access logs."""

    def filter(self, record: logging.LogRecord) -> bool:
        """Return False to filter out health check requests."""
        message = record.getMessage()
        # Filter out /health endpoint requests
        return "/health" not in message


class JSONFormatter(logging.Formatter):
    """Custom JSON formatter for Gunicorn logs."""

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        # Use record.name for logger name
        logger_name = record.name
        
        # Check if this is a log record with extra fields (from application code)
        extra_fields = {}
        for key, value in record.__dict__.items():
            # Skip standard logging attributes
            if key not in ['name', 'msg', 'args', 'created', 'filename', 'funcName',
                          'levelname', 'levelno', 'lineno', 'module', 'msecs',
                          'message', 'pathname', 'process', 'processName', 'relativeCreated',
                          'thread', 'threadName', 'exc_info', 'exc_text', 'stack_info',
                          'asctime', 'timestamp', 'level', 'logger']:
                extra_fields[key] = value
        
        log_data = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": logger_name,
            "message": record.getMessage(),
        }
        
        # Add extra fields from application logging
        log_data.update(extra_fields)

        # Add Gunicorn-specific fields if present
        if hasattr(record, "pid"):
            log_data["pid"] = getattr(record, "pid")
        if hasattr(record, "worker"):
            log_data["worker"] = getattr(record, "worker")

        return json.dumps(log_data)

# ----------------------------------------------------------------------------
# SERVER SOCKET
# ----------------------------------------------------------------------------

# Bind address - listen on all interfaces
bind = f"{os.getenv('HOST', '0.0.0.0')}:{os.getenv('PORT', '8080')}"

# Backlog - maximum number of pending connections
# Default: 2048
backlog = int(os.getenv("GUNICORN_BACKLOG", "2048"))

# ----------------------------------------------------------------------------
# WORKER PROCESSES
# ----------------------------------------------------------------------------

# Number of worker processes
# Default to a conservative value suitable for low-memory deployments.
# "auto" remains supported as an explicit opt-in override.
workers_env = os.getenv("GUNICORN_WORKERS", "2")
if workers_env.lower() == "auto":
    workers = (multiprocessing.cpu_count() * 2) + 1
else:
    workers = int(workers_env)

# Worker class - sync for Flask (no async needed)
worker_class = os.getenv("GUNICORN_WORKER_CLASS", "sync")

# Worker connections - max simultaneous clients per worker (for async workers)
# Not used for sync workers, but set for consistency
worker_connections = int(os.getenv("GUNICORN_WORKER_CONNECTIONS", "1000"))

# Max requests per worker before restart (prevents memory leaks)
# 0 = disabled (worker never restarts)
# Recommendation: 1000-10000 for long-running apps
max_requests = int(os.getenv("GUNICORN_MAX_REQUESTS", "5000"))

# Randomize max_requests to prevent all workers restarting simultaneously
max_requests_jitter = int(os.getenv("GUNICORN_MAX_REQUESTS_JITTER", "500"))

# Worker timeout - seconds before killing unresponsive worker
# Recommendation: 30-120 seconds for API servers
timeout = int(os.getenv("GUNICORN_TIMEOUT", "60"))

# Graceful timeout - seconds to wait for workers to finish during shutdown
# Recommendation: 30-60 seconds
graceful_timeout = int(os.getenv("GUNICORN_GRACEFUL_TIMEOUT", "30"))

# Keep-alive timeout - seconds to wait for next request on Keep-Alive connection
# Recommendation: 2-5 seconds
keepalive = int(os.getenv("GUNICORN_KEEPALIVE", "5"))

# ----------------------------------------------------------------------------
# SECURITY
# ----------------------------------------------------------------------------

# Limit request line size (prevents DoS attacks)
limit_request_line = int(os.getenv("GUNICORN_LIMIT_REQUEST_LINE", "4096"))

# Limit request header field size
limit_request_fields = int(os.getenv("GUNICORN_LIMIT_REQUEST_FIELDS", "100"))

# Limit request header field size
limit_request_field_size = int(os.getenv("GUNICORN_LIMIT_REQUEST_FIELD_SIZE", "8190"))

# ----------------------------------------------------------------------------
# TLS/SSL CONFIGURATION
# ----------------------------------------------------------------------------

# TLS certificate and key paths (if TLS enabled)
tls_enabled = os.getenv("TLS_ENABLED", "false").lower() == "true"

if tls_enabled:
    certfile = os.getenv("SERVER_CERT_PATH", "/app/certs/server.crt")
    keyfile = os.getenv("SERVER_KEY_PATH", "/app/certs/server.key")
    
    # mTLS - require client certificates
    mtls_enabled = os.getenv("MTLS_ENABLED", "false").lower() == "true"
    if mtls_enabled:
        ca_certs = os.getenv("CLIENT_CA_PATH", "/app/certs/ca.crt")
        cert_reqs = 2  # ssl.CERT_REQUIRED
    else:
        ca_certs = None
        cert_reqs = 0  # ssl.CERT_NONE
    
    # TLS version - minimum TLS 1.2
    ssl_version = 4  # ssl.PROTOCOL_TLS (auto-negotiate, minimum TLS 1.2)
    
    # Cipher suite - secure defaults
    ciphers = "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256"

# ----------------------------------------------------------------------------
# LOGGING
# ----------------------------------------------------------------------------

# Access log - requests log
# "-" = stdout (captured by container runtime)
# None = disable (Flask app handles request logging with structured logs)
accesslog = os.getenv("GUNICORN_ACCESS_LOG", None)

# Error log - application errors
# "-" = stderr (captured by container runtime)
errorlog = os.getenv("GUNICORN_ERROR_LOG", "-")

# Log level - debug, info, warning, error, critical
loglevel = os.getenv("GUNICORN_LOG_LEVEL", "info")

# Logging configuration dictionary
# Configure JSON formatting for Gunicorn's error log (lifecycle events)
logconfig_dict = {
    "version": 1,
    "disable_existing_loggers": False,
    "filters": {
        "health_check": {
            "()": HealthCheckFilter,
        },
    },
    "formatters": {
        "json": {
            "()": JSONFormatter,
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "json",
            "stream": "ext://sys.stderr",
        },
        "console_filtered": {
            "class": "logging.StreamHandler",
            "formatter": "json",
            "stream": "ext://sys.stderr",
            "filters": ["health_check"],
        },
    },
    "loggers": {
        "gunicorn.error": {
            "level": loglevel.upper(),
            "handlers": ["console"],
            "propagate": False,
        },
        "gunicorn.access": {
            "level": loglevel.upper(),
            "handlers": ["console_filtered"],  # Use filtered handler for access logs
            "propagate": False,
        },
    },
    "root": {
        "level": loglevel.upper(),
        "handlers": ["console"],
    },
}

# Access log format
# Default: %(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"
# Custom: Add response time and request ID
access_log_format = (
    '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" '
    'response_time=%(L)s request_id=%({X-Request-ID}i)s'
)

# Disable access log for health checks (reduces noise)
# Note: This requires custom middleware in Flask app
# access_log_filter = "broker.logging.HealthCheckFilter"

# ----------------------------------------------------------------------------
# PROCESS NAMING
# ----------------------------------------------------------------------------

# Process name prefix (visible in ps/top)
proc_name = "byop-broker"

# ----------------------------------------------------------------------------
# SERVER MECHANICS
# ----------------------------------------------------------------------------

# Daemon mode - run in background (not recommended in containers)
daemon = False

# PID file - not needed in containers
pidfile = None

# User/group - run as non-root (handled by Dockerfile)
# user = 1000
# group = 1000

# Temp directory for worker heartbeat
worker_tmp_dir = "/dev/shm"  # Use RAM for better performance

# Preload application code before forking workers
# Pros: Faster worker startup, shared memory
# Cons: Code changes require full restart
preload_app = True

# ----------------------------------------------------------------------------
# HOOKS
# ----------------------------------------------------------------------------

def on_starting(server):
    """Called just before the master process is initialized."""
    server.log.info("Gunicorn master process starting")

def on_reload(server):
    """Called to recycle workers during a reload via SIGHUP."""
    server.log.info("Gunicorn reloading configuration")

def when_ready(server):
    """Called just after the server is started."""
    server.log.info(f"Gunicorn ready - listening on {bind}")
    server.log.info(f"Workers: {workers}, Timeout: {timeout}s")

def pre_fork(server, worker):
    """Called just before a worker is forked."""
    pass

def post_fork(server, worker):
    """Called just after a worker has been forked."""
    server.log.info(f"Worker {worker.pid} spawned")

def pre_exec(server):
    """Called just before a new master process is forked."""
    server.log.info("Forking new master process")

def worker_int(worker):
    """Called when a worker receives the SIGINT or SIGQUIT signal."""
    worker.log.info(f"Worker {worker.pid} received interrupt signal")

def worker_abort(worker):
    """Called when a worker receives the SIGABRT signal."""
    worker.log.warning(f"Worker {worker.pid} aborted")

def worker_exit(server, worker):
    """Called just after a worker has been exited."""
    server.log.info(f"Worker {worker.pid} exited")

# Made with Bob
