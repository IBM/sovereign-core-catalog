# KSOPS Integration Setup Guide

Complete guide for setting up KSOPS (Kustomize Secrets OPerationS) integration with ArgoCD in a new cluster.

## Overview

This guide covers all steps required to enable SOPS-encrypted secrets management in ArgoCD using KSOPS plugin. The integration allows:
- Encrypted secrets stored in Git (using SOPS + AGE)
- Automatic decryption during ArgoCD sync (using KSOPS)
- OpenShift SCC compatibility (using Kustomize patches)

## Prerequisites

- Kubernetes/OpenShift cluster with ArgoCD installed
- Access to build and push custom ArgoCD images
- AGE key pair for SOPS encryption
- Git repository for GitOps manifests
- Docker or Podman for building images

## Architecture

```
Broker → Renders Templates → Encrypts with SOPS → Commits to Git
                                                         ↓
ArgoCD → Pulls from Git → KSOPS Decrypts → Kustomize Patches → Deploy
```

## Setup Steps

### 1. Generate AGE Key Pair

AGE is the encryption backend used by SOPS.

```bash
# Install age if not already installed
# macOS: brew install age
# Linux: apt-get install age
# alternatively it can be downloaded from https://github.com/FiloSottile/age/releases

# Generate key pair
age-keygen -o age-key.txt

# Output shows:
# Public key: age1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
# (Private key written to age-key.txt)

# Save the public key for broker configuration
export SOPS_AGE_RECIPIENT="age1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

# Keep age-key.txt secure - this is your private key
chmod 600 age-key.txt
```

**Security Note:** The private key (`age-key.txt`) must be kept secure and never committed to Git.

### 2. Build Custom ArgoCD Image with KSOPS

The custom image includes SOPS, AGE, KSOPS, and Kustomize.

**Dockerfile Location:** [`argocd/Dockerfile.argocd-sops`](../../../argocd/Dockerfile.argocd-sops)

```bash
# Navigate to project root
cd /Users/echalmer/git/github.com/your-org/byop-broker

# Build multi-architecture image (recommended)
docker buildx build \
  --platform linux/amd64,linux/arm64 \
  -f argocd/Dockerfile.argocd-sops \
  -t quay.io/your-org/argocd-ksops:v2.9.3-sops3.13 \
  --push \
  .

# Or build for single architecture
docker build \
  -f argocd/Dockerfile.argocd-sops \
  -t quay.io/your-org/argocd-ksops:v2.9.3-sops3.13 \
  .

docker push quay.io/your-org/argocd-ksops:v2.9.3-sops3.13
```

**Image Contents:**
- Base: `quay.io/argoproj/argocd:v2.9.3`
- SOPS: v3.13.1
- AGE: v1.1.1
- KSOPS: v4.3.2
- Kustomize: v5.0.3

**Key Features:**
- Multi-arch support (amd64 + arm64)
- KSOPS plugin wrapper created at build time
- Proper XDG_CONFIG_HOME configuration
- Plugin directory structure pre-configured

### 3. Create AGE Private Key Secret in ArgoCD

The private key must be available to ArgoCD repo-server for decryption.

```bash
# Create secret from age-key.txt
kubectl create secret generic sops-age-key \
  --from-file=keys.txt=age-key.txt \
  --namespace argocd

# Verify secret created
kubectl get secret sops-age-key -n argocd
```

**Important:** The secret must be named `sops-age-key` and the key must be named `keys.txt` to match the volume mount configuration.

### 4. Update ArgoCD repo-server Deployment

Update the repo-server to use the custom image and mount the AGE key.

```bash
# Update image
kubectl set image deployment/argocd-repo-server \
  argocd-repo-server=quay.io/your-org/argocd-ksops:v2.9.3-sops3.13 \
  -n argocd

# Patch deployment to add volume mounts
kubectl patch deployment argocd-repo-server -n argocd --type=json -p='[
  {
    "op": "add",
    "path": "/spec/template/spec/containers/0/env/-",
    "value": {
      "name": "SOPS_AGE_KEY_FILE",
      "value": "/home/argocd/.config/sops/age/keys.txt"
    }
  },
  {
    "op": "add",
    "path": "/spec/template/spec/containers/0/volumeMounts/-",
    "value": {
      "name": "sops-age-key",
      "mountPath": "/home/argocd/.config/sops/age",
      "readOnly": true
    }
  },
  {
    "op": "add",
    "path": "/spec/template/spec/volumes/-",
    "value": {
      "name": "sops-age-key",
      "secret": {
        "secretName": "sops-age-key",
        "defaultMode": 384
      }
    }
  }
]'

# Wait for rollout to complete
kubectl rollout status deployment/argocd-repo-server -n argocd
```

**Environment Variables Set:**
- `SOPS_AGE_KEY_FILE`: Path to AGE private key
- `XDG_CONFIG_HOME`: Kustomize plugin directory (set in Dockerfile)

### 5. Enable Kustomize Alpha Plugins in ArgoCD

KSOPS requires Kustomize alpha plugins to be enabled.

```bash
# Update argocd-cm ConfigMap
kubectl patch configmap argocd-cm -n argocd --type=merge -p='
data:
  kustomize.buildOptions: "--enable-alpha-plugins --enable-exec"
'

# Restart repo-server to pick up config change
kubectl rollout restart deployment/argocd-repo-server -n argocd
kubectl rollout status deployment/argocd-repo-server -n argocd
```

**What this enables:**
- `--enable-alpha-plugins`: Allows Kustomize to use generator plugins like KSOPS
- `--enable-exec`: Allows plugins to execute external binaries (SOPS)

### 6. Configure Broker with AGE Public Key

The broker needs the AGE public key to encrypt secrets.

**Environment Variable:**
```bash
export SOPS_AGE_RECIPIENT="age1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

**In Helm values or ConfigMap:**
```yaml
broker:
  env:
    - name: SOPS_AGE_RECIPIENT
      value: "age1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

**In broker deployment:**
```bash
# Update broker deployment
kubectl set env deployment/byop-broker \
  SOPS_AGE_RECIPIENT="age1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" \
  -n byop
```

### 7. Verify Installation

Test that KSOPS is working correctly.

```bash
# Check repo-server pod is running
kubectl get pods -n argocd -l app.kubernetes.io/name=argocd-repo-server

# Check SOPS is available
kubectl exec -n argocd deployment/argocd-repo-server -- sops --version

# Check AGE is available
kubectl exec -n argocd deployment/argocd-repo-server -- age --version

# Check KSOPS is available
kubectl exec -n argocd deployment/argocd-repo-server -- ksops --help

# Check Kustomize is available
kubectl exec -n argocd deployment/argocd-repo-server -- kustomize version

# Verify AGE key is mounted
kubectl exec -n argocd deployment/argocd-repo-server -- \
  ls -la /home/argocd/.config/sops/age/

# Check KSOPS plugin wrapper exists
kubectl exec -n argocd deployment/argocd-repo-server -- \
  ls -la /home/argocd/.config/kustomize/plugin/viaduct.ai/v1/ksops/
```

**Expected Output:**
- SOPS version: v3.13.1
- AGE version: v1.1.1
- KSOPS: Help text displayed
- Kustomize version: v5.0.3
- AGE key file: `/home/argocd/.config/sops/age/keys.txt` (400 permissions)
- KSOPS wrapper: `/home/argocd/.config/kustomize/plugin/viaduct.ai/v1/ksops/ksops` (executable)

## GitOps Repository Structure

Services using KSOPS must follow this structure:

```
instances/<service>/<instance-name>/
├── kustomization.yaml          # Kustomize config with KSOPS generator
├── ksops-generator.yaml        # KSOPS configuration
├── secrets.yaml                # SOPS-encrypted secrets
├── statefulset-patch.yaml      # OpenShift SCC patches (if needed)
├── values.yaml                 # Helm values (if Helm-based)
└── manifests/                  # Pre-rendered Helm manifests (if Helm-based)
    ├── configmap.yaml
    ├── service.yaml
    ├── statefulset.yaml
    └── ...
```

### Example Files

**kustomization.yaml:**
```yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

resources:
  - manifests/all.yaml

generators:
  - ksops-generator.yaml

patchesStrategicMerge:
  - statefulset-patch.yaml
```

**ksops-generator.yaml:**
```yaml
apiVersion: viaduct.ai/v1
kind: ksops
metadata:
  name: sops-secrets
  annotations:
    config.kubernetes.io/function: |
      exec:
        path: ksops
files:
  - secrets.yaml
```

**secrets.yaml (encrypted):**
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: mariadb-sops-25
  namespace: sops-25
type: Opaque
stringData:
  mariadb-root-password: ENC[AES256_GCM,data:...,iv:...,tag:...,type:str]
  mariadb-password: ENC[AES256_GCM,data:...,iv:...,tag:...,type:str]
sops:
  kms: []
  gcp_kms: []
  azure_kv: []
  hc_vault: []
  age:
    - recipient: age1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
      enc: |
        -----BEGIN AGE ENCRYPTED FILE-----
        ...
        -----END AGE ENCRYPTED FILE-----
  lastmodified: "2026-05-20T23:45:12Z"
  mac: ENC[AES256_GCM,data:...,iv:...,tag:...,type:str]
  pgp: []
  version: 3.8.1
```

**statefulset-patch.yaml (for OpenShift SCC):**
```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: sops-25-mariadb
spec:
  template:
    spec:
      securityContext: null
      initContainers: []
      containers:
        - name: mariadb
          securityContext: null
```

## ArgoCD Application Configuration

Applications must use Kustomize source (not directory or Helm).

**Single-source Application:**
```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: mariadb-sops-25
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/your-org/your-gitops-repo
    targetRevision: main
    path: instances/mariadb/sops-25
    # CRITICAL: Must use kustomize source for KSOPS
    kustomize:
      namePrefix: ""  # Non-empty to prevent ArgoCD from stripping
  destination:
    server: https://kubernetes.default.svc
    namespace: sops-25
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
```

**ApplicationSet Template:**
```yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: mariadb-app-set
  namespace: argocd
spec:
  generators:
    - git:
        repoURL: https://github.com/your-org/your-gitops-repo
        revision: main
        directories:
          - path: instances/mariadb/*
  template:
    metadata:
      name: 'mariadb-{{path.basename}}'
    spec:
      project: default
      source:
        repoURL: https://github.com/your-org/your-gitops-repo
        targetRevision: main
        path: '{{path}}'
        kustomize:
          namePrefix: ""  # Required to prevent stripping
      destination:
        server: https://kubernetes.default.svc
        namespace: '{{path.basename}}'
      syncPolicy:
        automated:
          prune: true
          selfHeal: true
        syncOptions:
          - CreateNamespace=true
```

## Broker Integration

The broker automatically handles KSOPS integration when `helm_config` is present in catalog.yaml.

**Service Catalog Configuration:**
```yaml
# services/mariadb/v2/catalog/catalog.yaml
helm_config:
  chart_url: https://kubelauncher.github.io/charts/mariadb
  chart_version: "0.4.7"
  container_name: mariadb
  requires_patch: true
```

**Broker Workflow:**
1. Detects `helm_config` in catalog.yaml
2. Renders Helm chart to YAML manifests using `helm template`
3. Generates Kustomize files (kustomization.yaml, ksops-generator.yaml)
4. Renders secrets template
5. Encrypts secrets with SOPS using AGE public key
6. Commits all files to GitOps repository
7. Creates ArgoCD Application with Kustomize source

**Broker Modules:**
- [`broker/src/broker/gitops/helm_renderer.py`](../../../broker/src/broker/gitops/helm_renderer.py) - Helm chart rendering
- [`broker/src/broker/gitops/kustomize_generator.py`](../../../broker/src/broker/gitops/kustomize_generator.py) - Kustomize file generation
- [`broker/src/broker/gitops/sops_encryption.py`](../../../broker/src/broker/gitops/sops_encryption.py) - SOPS encryption
- [`broker/src/broker/gitops/provision_templates.py`](../../../broker/src/broker/gitops/provision_templates.py) - Orchestration

## Testing the Integration

### 1. Manual Test with Existing Instance

```bash
# Navigate to test instance
cd /path/to/gitops-repo/instances/mariadb/sops-08

# Test KSOPS decryption locally
kustomize build --enable-alpha-plugins --enable-exec .

# Expected: Decrypted Secret manifest in output
```

### 2. Provision New Instance via Broker

```bash
# Provision new MariaDB instance
curl -X POST http://broker-url/provision \
  -H "Content-Type: application/json" \
  -d '{
    "service_name": "mariadb",
    "service_version": "v2",
    "instance_name": "sops-test",
    "namespace": "sops-test",
    "parameters": {
      "database_name": "testdb",
      "database_user": "testuser",
      "database_password": "testpass123",
      "root_password": "rootpass123"
    }
  }'
```

### 3. Verify Deployment

```bash
# Check Application created
kubectl get application mariadb-sops-test -n argocd

# Check Application synced
kubectl get application mariadb-sops-test -n argocd -o jsonpath='{.status.sync.status}'
# Expected: Synced

# Check Secret deployed (decrypted)
kubectl get secret -n sops-test

# Verify secret content
kubectl get secret mariadb-sops-test -n sops-test -o yaml

# Check pods running
kubectl get pods -n sops-test

# Verify no SCC errors in events
kubectl get events -n sops-test --sort-by='.lastTimestamp'
```

### 4. Verify Encryption in Git

```bash
# Check secrets file in GitOps repo
cat instances/mariadb/sops-test/secrets.yaml

# Should see SOPS metadata:
# sops:
#   age:
#     - recipient: age1...
#   lastmodified: "..."
#   version: 3.8.1
```

## Troubleshooting

### KSOPS Plugin Not Found

**Symptom:** ArgoCD logs show "ksops: command not found"

**Solution:**
```bash
# Verify KSOPS wrapper exists
kubectl exec -n argocd deployment/argocd-repo-server -- \
  ls -la /home/argocd/.config/kustomize/plugin/viaduct.ai/v1/ksops/

# Verify it's executable
kubectl exec -n argocd deployment/argocd-repo-server -- \
  /home/argocd/.config/kustomize/plugin/viaduct.ai/v1/ksops/ksops --help
```

### SOPS Decryption Fails

**Symptom:** ArgoCD logs show "failed to get the data key required to decrypt the SOPS file"

**Solution:**
```bash
# Verify AGE key is mounted
kubectl exec -n argocd deployment/argocd-repo-server -- \
  cat /home/argocd/.config/sops/age/keys.txt

# Verify SOPS_AGE_KEY_FILE environment variable
kubectl exec -n argocd deployment/argocd-repo-server -- \
  env | grep SOPS_AGE_KEY_FILE

# Test SOPS decryption manually
kubectl exec -n argocd deployment/argocd-repo-server -- \
  sops -d /path/to/secrets.yaml
```

### Kustomize Alpha Plugins Not Enabled

**Symptom:** ArgoCD logs show "alpha plugins are not enabled"

**Solution:**
```bash
# Check argocd-cm ConfigMap
kubectl get configmap argocd-cm -n argocd -o yaml | grep kustomize.buildOptions

# Should show: kustomize.buildOptions: "--enable-alpha-plugins --enable-exec"

# If missing, patch ConfigMap
kubectl patch configmap argocd-cm -n argocd --type=merge -p='
data:
  kustomize.buildOptions: "--enable-alpha-plugins --enable-exec"
'

# Restart repo-server
kubectl rollout restart deployment/argocd-repo-server -n argocd
```

### Manifest Cache Issues

**Symptom:** ArgoCD deploys old manifests despite successful kustomize build

**Solution:**
```bash
# Restart argocd-repo-server to clear cache
kubectl rollout restart deployment/argocd-repo-server -n argocd
kubectl rollout status deployment/argocd-repo-server -n argocd

# Force Application sync
kubectl patch application <app-name> -n argocd --type merge \
  -p '{"operation":{"initiatedBy":{"username":"admin"},"sync":{}}}'
```

### OpenShift SCC Errors

**Symptom:** Pods fail with "runAsUser: Invalid value: 0: must be in the ranges: [...]"

**Solution:**
Ensure `statefulset-patch.yaml` is present and referenced in `kustomization.yaml`:

```yaml
# statefulset-patch.yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: <instance-name>-mariadb
spec:
  template:
    spec:
      securityContext: null
      initContainers: []
      containers:
        - name: mariadb
          securityContext: null
```

## Security Best Practices

1. **AGE Key Management:**
   - Store private key securely (never commit to Git)
   - Use separate keys for different environments
   - Rotate keys periodically
   - Backup keys securely

2. **Secret Encryption:**
   - Always encrypt secrets before committing
   - Verify encryption with `sops -d secrets.yaml`
   - Use `.gitignore` to prevent plaintext secrets

3. **Access Control:**
   - Limit access to AGE private key
   - Use Kubernetes RBAC for ArgoCD namespace
   - Audit secret access regularly

4. **Monitoring:**
   - Monitor ArgoCD sync failures
   - Alert on decryption errors
   - Track secret rotation

## Summary

**Setup Checklist:**
- [ ] Generate AGE key pair
- [ ] Build custom ArgoCD image with KSOPS
- [ ] Create AGE private key secret in ArgoCD namespace
- [ ] Update argocd-repo-server deployment
- [ ] Enable Kustomize alpha plugins in argocd-cm
- [ ] Configure broker with AGE public key
- [ ] Verify installation
- [ ] Test with sample instance
- [ ] Document for team

**Key Files:**
- [`argocd/Dockerfile.argocd-sops`](../../../argocd/Dockerfile.argocd-sops) - Custom ArgoCD image
- [`broker/src/broker/gitops/sops_encryption.py`](../../../broker/src/broker/gitops/sops_encryption.py) - SOPS encryption
- [`broker/src/broker/gitops/kustomize_generator.py`](../../../broker/src/broker/gitops/kustomize_generator.py) - Kustomize generation

**Related Documentation:**
- [Strategic Pivot Analysis](strategic-pivot-analysis.md) - Long-term KSOPS strategy
- [Phase 4: Ready for E2E Testing](phase4-ready-for-e2e-testing.md) - Implementation status
- [Phase 3: KSOPS Deployment Complete](phase3-ksops-deployment-complete.md) - Deployment details

---

*Last Updated: 2026-05-21*
*Status: Production-ready KSOPS setup guide*