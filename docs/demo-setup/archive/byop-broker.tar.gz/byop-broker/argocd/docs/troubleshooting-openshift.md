# Troubleshooting ArgoCD on OpenShift

## Common Issues and Solutions

### CreateContainerConfigError - Pods Not Starting

**Symptoms:**
```
pod/argocd-application-controller-0    0/1  CreateContainerConfigError
pod/argocd-repo-server-*               0/1  CreateContainerConfigError
pod/argocd-server-*                    0/1  CreateContainerConfigError
pod/argocd-dex-server-*                0/1  Error
```

This typically indicates issues with:
1. Security Context Constraints (SCCs) on OpenShift
2. Missing or invalid secrets
3. Volume mount issues
4. Service account permissions

## Diagnostic Steps

### Step 1: Check Pod Events and Logs

```bash
# Check pod events for specific error messages
oc --context=hub describe pod -n argocd argocd-application-controller-0
oc --context=hub describe pod -n argocd argocd-repo-server-<pod-name>
oc --context=hub describe pod -n argocd argocd-server-<pod-name>
oc --context=hub describe pod -n argocd argocd-dex-server-<pod-name>

# Check logs (if container started)
oc --context=hub logs -n argocd argocd-dex-server-<pod-name>
```

**Look for:**
- Secret mounting errors
- Permission denied errors
- Volume mount failures
- SCC violations

### Step 2: Check Secrets

ArgoCD requires several secrets to be present:

```bash
# List all secrets in argocd namespace
oc --context=hub get secrets -n argocd

# Check if required secrets exist
oc --context=hub get secret argocd-secret -n argocd
oc --context=hub get secret argocd-initial-admin-secret -n argocd

# Describe secrets to check they have data
oc --context=hub describe secret argocd-secret -n argocd
oc --context=hub describe secret argocd-initial-admin-secret -n argocd
```

**Required secrets:**
- `argocd-secret` - ArgoCD server secret and admin password hash storage
- `argocd-notifications-secret` - Notifications configuration

**Bootstrap secret:**
- `argocd-initial-admin-secret` - Created by ArgoCD during bootstrap to expose the initial admin password
- This secret may not exist immediately after installation
- Do not create this secret manually unless you are intentionally following an ArgoCD-supported password reset/bootstrap workflow

### Step 3: Check Security Context Constraints (OpenShift-specific)

OpenShift has stricter security policies than vanilla Kubernetes:

```bash
# Check which SCC is being used
oc --context=hub get pod -n argocd argocd-server-<pod-name> -o yaml | grep scc

# Check service account
oc --context=hub get sa -n argocd

# Check if service accounts have proper SCCs
oc --context=hub describe sa argocd-server -n argocd
oc --context=hub describe sa argocd-application-controller -n argocd
oc --context=hub describe sa argocd-repo-server -n argocd
```

### Step 4: Check Volume Mounts

```bash
# Check if volumes are properly mounted
oc --context=hub get pod -n argocd argocd-application-controller-0 -o yaml | grep -A 10 volumes
oc --context=hub get pod -n argocd argocd-server-<pod-name> -o yaml | grep -A 10 volumes
```

### Step 5: Check Redis Deployment

Redis is critical for ArgoCD:

```bash
# Check redis status
oc --context=hub get deployment argocd-redis -n argocd
oc --context=hub get pods -n argocd -l app.kubernetes.io/name=argocd-redis

# Check redis logs
oc --context=hub logs -n argocd deployment/argocd-redis
```

## Common Solutions

### Solution 1: Fix Security Context Constraints

ArgoCD pods may need elevated permissions on OpenShift:

```bash
# Grant anyuid SCC to ArgoCD service accounts
oc --context=hub adm policy add-scc-to-user anyuid -z argocd-server -n argocd
oc --context=hub adm policy add-scc-to-user anyuid -z argocd-application-controller -n argocd
oc --context=hub adm policy add-scc-to-user anyuid -z argocd-repo-server -n argocd
oc --context=hub adm policy add-scc-to-user anyuid -z argocd-dex-server -n argocd
oc --context=hub adm policy add-scc-to-user anyuid -z argocd-redis -n argocd

# Restart deployments to pick up new permissions
oc --context=hub rollout restart deployment -n argocd argocd-server
oc --context=hub rollout restart deployment -n argocd argocd-repo-server
oc --context=hub rollout restart deployment -n argocd argocd-dex-server
oc --context=hub rollout restart deployment -n argocd argocd-redis
oc --context=hub rollout restart statefulset -n argocd argocd-application-controller
```

### Solution 2: Recreate Missing Secrets

If secrets are missing or corrupted:

```bash
# Delete and recreate the namespace (WARNING: destructive)
oc --context=hub delete namespace argocd
oc --context=hub create namespace argocd

# Reinstall ArgoCD
./argocd/scripts/argocd-install.sh --context hub
```

### Solution 3: Use OpenShift-Specific ArgoCD Installation

Consider using the OpenShift GitOps Operator instead:

```bash
# Install OpenShift GitOps Operator
oc --context=hub apply -f - <<EOF
apiVersion: operators.coreos.com/v1alpha1
kind: Subscription
metadata:
  name: openshift-gitops-operator
  namespace: openshift-operators
spec:
  channel: latest
  name: openshift-gitops-operator
  source: redhat-operators
  sourceNamespace: openshift-marketplace
EOF

# Wait for operator to install
oc --context=hub get pods -n openshift-gitops

# The operator creates an ArgoCD instance automatically
oc --context=hub get argocd -n openshift-gitops
```

### Solution 4: Check Network Policies

OpenShift may have network policies blocking communication:

```bash
# Check network policies
oc --context=hub get networkpolicies -n argocd

# Temporarily disable network policies for testing
oc --context=hub delete networkpolicies --all -n argocd

# If this fixes it, recreate with proper rules
```

### Solution 5: Check Resource Quotas

```bash
# Check if namespace has resource quotas
oc --context=hub get resourcequota -n argocd
oc --context=hub describe resourcequota -n argocd

# Check if pods are being limited
oc --context=hub get limitrange -n argocd
```

## Detailed Debugging Commands

### Get Full Pod Description

```bash
# Application controller
oc --context=hub describe pod -n argocd argocd-application-controller-0 > app-controller.txt

# Repo server
oc --context=hub describe pod -n argocd $(oc --context=hub get pods -n argocd -l app.kubernetes.io/name=argocd-repo-server -o name | head -1) > repo-server.txt

# Server
oc --context=hub describe pod -n argocd $(oc --context=hub get pods -n argocd -l app.kubernetes.io/name=argocd-server -o name | head -1) > server.txt

# Dex server
oc --context=hub describe pod -n argocd $(oc --context=hub get pods -n argocd -l app.kubernetes.io/name=argocd-dex-server -o name | head -1) > dex-server.txt

# Review the files for error messages
cat app-controller.txt repo-server.txt server.txt dex-server.txt | grep -i error
```

### Check All Events

```bash
# Get all events in argocd namespace
oc --context=hub get events -n argocd --sort-by='.lastTimestamp'

# Filter for errors and warnings
oc --context=hub get events -n argocd --field-selector type=Warning
oc --context=hub get events -n argocd --field-selector type=Error
```

### Export Full State

```bash
# Export all resources for analysis
oc --context=hub get all -n argocd -o yaml > argocd-state.yaml
oc --context=hub get secrets -n argocd -o yaml > argocd-secrets.yaml
oc --context=hub get configmaps -n argocd -o yaml > argocd-configmaps.yaml
oc --context=hub get sa -n argocd -o yaml > argocd-serviceaccounts.yaml
```

## OpenShift-Specific Considerations

### 1. Security Context Constraints

OpenShift enforces stricter security by default:
- Pods run as non-root by default
- Volume mounts have restricted permissions
- Network policies are more restrictive

**Solution:** Grant appropriate SCCs to service accounts (see Solution 1 above)

### 2. Routes vs Ingress

OpenShift uses Routes instead of Ingress:

```bash
# Create a route for ArgoCD server
oc --context=hub create route passthrough argocd-server \
  --service=argocd-server \
  --port=https \
  -n argocd

# Get the route URL
oc --context=hub get route argocd-server -n argocd
```

### 3. Image Pull Policies

OpenShift may have different image pull policies:

```bash
# Check if images are being pulled
oc --context=hub get events -n argocd | grep -i pull

# Check image pull secrets
oc --context=hub get secrets -n argocd | grep pull
```

## Next Steps Based on Error Type

### If "CreateContainerConfigError"
1. Check secrets exist and have data
2. Check volume mounts
3. Check SCCs (most common on OpenShift)
4. Review pod events for specific error

### If "Error" or "CrashLoopBackOff"
1. Check pod logs
2. Check resource limits
3. Check dependencies (Redis, etc.)
4. Review application-specific errors

### If "ImagePullBackOff"
1. Check image registry access
2. Check image pull secrets
3. Verify image names and tags
4. Check network connectivity to registry

## Getting Help

If issues persist, collect diagnostic information:

```bash
# Create diagnostic bundle
mkdir -p argocd-diagnostics
oc --context=hub get all -n argocd -o yaml > argocd-diagnostics/resources.yaml
oc --context=hub get events -n argocd > argocd-diagnostics/events.txt
oc --context=hub describe pods -n argocd > argocd-diagnostics/pods.txt
oc --context=hub get secrets -n argocd > argocd-diagnostics/secrets-list.txt

# Collect logs from all pods
for pod in $(oc --context=hub get pods -n argocd -o name); do
  oc --context=hub logs -n argocd $pod > argocd-diagnostics/$(basename $pod).log 2>&1 || true
done

# Create tarball
tar -czf argocd-diagnostics.tar.gz argocd-diagnostics/
```

---

*Last Updated: 2026-04-08*