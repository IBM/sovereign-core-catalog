# Troubleshooting ApplicationSet CRD Errors

## Status: RESOLVED ✅

**As of 2026-04-24**, the `argocd-install.sh` script now uses `--server-side` apply, which resolves annotation size errors and allows ApplicationSet CRDs to be installed.

**If you installed ArgoCD before this date**, you may still see ApplicationSet errors. See solutions below.

---

## Legacy Issue (Pre-2026-04-24 Installations)

### Symptom

ArgoCD server logs show repeated errors about ApplicationSet CRDs:

```
{"error":"failed to list *v1alpha1.ApplicationSet: the server could not find the requested resource (get applicationsets.argoproj.io)","level":"error","logger":"UnhandledError","msg":"Failed to watch"...}
```

### Root Cause

Older versions of `argocd-install.sh` filtered out ApplicationSet CRDs to avoid annotation size errors. The ArgoCD server still tried to watch for these resources, causing harmless but noisy error logs.

## Impact

- **Severity:** Low - cosmetic only
- **Functionality:** No impact on ArgoCD core functionality
- **Performance:** Minimal - just log noise and failed watch attempts
- **Applications:** Work normally
- **Sync:** Works normally

## Solutions

### Option 1: Reinstall with Updated Script (Recommended) ✅

The latest `argocd-install.sh` script uses `--server-side` apply and includes ApplicationSet support:

```bash
# Uninstall old ArgoCD
./argocd-uninstall.sh --context k3s-1 --force

# Reinstall with updated script (includes ApplicationSet)
./argocd-install.sh --context k3s-1
```

**Benefits:**
- ✅ Full ApplicationSet support
- ✅ No annotation size errors
- ✅ No log noise
- ✅ All ArgoCD features available

### Option 2: Ignore the Errors (If ApplicationSet Not Needed)

If you don't need ApplicationSet functionality and don't want to reinstall:

These errors are harmless and can be safely ignored. ArgoCD will continue to function normally without ApplicationSet support.

### Option 3: Manual ApplicationSet CRD Installation

If you can't reinstall but need ApplicationSet functionality:

```bash
# Download ArgoCD manifest
VERSION="stable"  # or specific version like v2.9.3
curl -sL "https://raw.githubusercontent.com/argoproj/argo-cd/${VERSION}/manifests/install.yaml" -o /tmp/argocd-full.yaml

# Apply ApplicationSet CRD with server-side apply
kubectl apply --server-side -f - <<EOF
$(grep -A 1000 "kind: CustomResourceDefinition" /tmp/argocd-full.yaml | grep -B 1000 "applicationsets.argoproj.io" | grep -A 1000 "kind: CustomResourceDefinition" | head -n $(grep -n "^---$" /tmp/argocd-full.yaml | head -2 | tail -1 | cut -d: -f1))
EOF

# Restart argocd-server to pick up the CRD
kubectl rollout restart deployment argocd-server -n argocd
```

## Port-Forward Connection Loop

If you see many "Handling connection" messages during port-forward:

```
Handling connection for 8443
Handling connection for 8443
Handling connection for 8443
```

This is **normal behavior** and unrelated to the ApplicationSet errors. These are:
- Health check probes from Kubernetes
- ArgoCD UI polling for updates
- Application sync status checks
- Webhook callbacks

**This is expected and not a problem.**

## Verification

Check that ArgoCD is working despite the errors:

```bash
# Check applications
oc --context k3s-1 -n argocd get applications

# Check application sync status
oc --context k3s-1 -n argocd get application byop-app-of-apps -o jsonpath='{.status.sync.status}'

# Check application health
oc --context k3s-1 -n argocd get application byop-app-of-apps -o jsonpath='{.status.health.status}'
```

If applications show "Synced" and "Healthy", ArgoCD is working correctly.

## Related Documentation

- [ArgoCD Installation Guide](../README.md)
- [ApplicationSet CRD Fix](applicationset-crd-fix.md)
- [Troubleshooting OpenShift](troubleshooting-openshift.md)

---

*Last Updated: 2026-04-24*