# ArgoCD Scripts Consolidation Plan

**Date:** 2026-04-21  
**Purpose:** Consolidate redundant cleanup scripts

## Analysis

### Current Situation

Two cleanup scripts exist:
1. **argocd-uninstall.sh** (388 lines) - Simple uninstall
2. **argocd-cleanup-complete.sh** (330 lines) - Complete cleanup with spoke detection

### Key Finding

**`argocd-cleanup-complete.sh` already auto-detects spoke clusters!**

Lines 172-185:
```bash
# Find spoke clusters
log_info "Discovering spoke clusters..."
SPOKE_CLUSTERS=$(${OC_CMD} -n "${NAMESPACE}" get secrets \
    -l argocd.argoproj.io/secret-type=cluster -o name 2>/dev/null | \
    grep -v "in-cluster" | sed 's/secret\/cluster-//' || true)

if [ -n "$SPOKE_CLUSTERS" ]; then
    # Remove spokes
else
    echo "No spoke clusters registered"
fi
```

**This means:**
- If no spokes exist → skips spoke removal, just uninstalls ArgoCD
- If spokes exist → removes spokes first, then uninstalls ArgoCD

**Conclusion:** `argocd-cleanup-complete.sh` handles both scenarios automatically!

## Recommendation

### Delete Redundant Script

**Delete:** `argocd-uninstall.sh` (388 lines)

**Reason:**
- `argocd-cleanup-complete.sh` does everything `argocd-uninstall.sh` does
- Plus it auto-detects and handles spoke clusters
- No need for two scripts

### Rename for Clarity

**Rename:** `argocd-cleanup-complete.sh` → `argocd-uninstall.sh`

**Reason:**
- Simpler, more intuitive name
- Users don't need to know about "complete cleanup" vs "simple uninstall"
- The script automatically does the right thing

## Implementation Steps

### 1. Delete Redundant Script

```bash
cd argocd/scripts
rm argocd-uninstall.sh
```

### 2. Rename Cleanup Script

```bash
cd argocd/scripts
mv argocd-cleanup-complete.sh argocd-uninstall.sh
```

### 3. Add Context Logging

Add prominent context logging to all scripts. After parsing arguments, display:

```bash
# Determine actual context being used
if [ -n "$CONTEXT" ]; then
    ACTUAL_CONTEXT="$CONTEXT"
else
    ACTUAL_CONTEXT=$(kubectl config current-context)
fi

# Display configuration with prominent context
echo "============================================================"
echo "ArgoCD [Operation Name]"
echo "============================================================"
echo ""
echo "Configuration:"
echo "  ⚠️  Kubernetes Context: ${ACTUAL_CONTEXT}"
if [ -n "$CONTEXT" ]; then
    echo "      (specified via --context)"
else
    echo "      (using current context)"
fi
echo "  Namespace:         ${NAMESPACE}"
# ... other config
echo ""
```

**For dry-run mode, make it even more prominent:**

```bash
if [ "$DRY_RUN" = true ]; then
    echo "============================================================"
    echo "🔍 DRY RUN MODE - No changes will be made"
    echo "============================================================"
    echo ""
    echo "⚠️  Target Kubernetes Context: ${ACTUAL_CONTEXT}"
    if [ -n "$CONTEXT" ]; then
        echo "    (specified via --context)"
    else
        echo "    (using current context)"
    fi
    echo ""
    echo "The following operations would be performed:"
    echo ""
fi
```

### 4. Apply Context Logging to All Scripts

Update these scripts to include prominent context logging:
- `argocd-install.sh`
- `argocd-uninstall.sh` (renamed from cleanup-complete)
- `argocd-configure-repo.sh`
- `argocd-add-spoke.sh`
- `argocd-remove-spoke.sh`
- `argocd-describe.sh`

**Standard pattern for all scripts:**
```bash
# After argument parsing, before operations
if [ -n "$CONTEXT" ]; then
    ACTUAL_CONTEXT="$CONTEXT"
else
    ACTUAL_CONTEXT=$(kubectl config current-context)
fi

echo "Configuration:"
echo "  ⚠️  Kubernetes Context: ${ACTUAL_CONTEXT}"
if [ -n "$CONTEXT" ]; then
    echo "      (specified via --context)"
else
    echo "      (using current context)"
fi
```

### 5. Update Script Help Text

Update the help text in the renamed script to reflect its new purpose:

**Current (argocd-cleanup-complete.sh):**
```
Complete ArgoCD cleanup - removes spoke clusters and uninstalls ArgoCD from hub.
```

**Updated (argocd-uninstall.sh):**
```
Uninstall ArgoCD from a Kubernetes cluster.
Automatically detects and removes spoke clusters before uninstalling.
```

### 4. Update README.md

**Remove references to:**
- `argocd-cleanup-complete.sh`

**Update cleanup section:**
```markdown
## Cleanup

### Uninstall ArgoCD

```bash
# Uninstall ArgoCD (automatically handles spoke clusters)
./scripts/argocd-uninstall.sh --context my-cluster

# Auto-confirm all steps
./scripts/argocd-uninstall.sh --context my-cluster -y

# Keep CRDs for future reinstall
./scripts/argocd-uninstall.sh --context my-cluster --keep-crds
```

**What it does:**
1. Automatically detects registered spoke clusters
2. Removes spoke cluster registrations (if any)
3. Deletes applications on spoke clusters (if any)
4. Uninstalls ArgoCD from hub cluster
5. Cleans up all resources and CRDs
```

### 5. Update Script References

Update any documentation that references `argocd-cleanup-complete.sh` to use `argocd-uninstall.sh`.

## Benefits

### For Users
- ✅ **Simpler** - One uninstall script instead of two
- ✅ **Intuitive** - Named `argocd-uninstall.sh` (obvious purpose)
- ✅ **Automatic** - No need to choose between scripts
- ✅ **Safer** - Always handles spokes correctly

### For Maintainers
- ✅ **Less code** - 388 fewer lines to maintain
- ✅ **No duplication** - Single source of truth
- ✅ **Clearer** - One way to uninstall

## Testing Plan

After consolidation, test:

1. **Hub-only uninstall:**
   ```bash
   # Install ArgoCD on hub
   ./scripts/argocd-install.sh --context hub
   
   # Uninstall (should work without spokes)
   ./scripts/argocd-uninstall.sh --context hub
   ```

2. **Hub + spokes uninstall:**
   ```bash
   # Install ArgoCD on hub
   ./scripts/argocd-install.sh --context hub
   
   # Add spoke
   ./scripts/argocd-add-spoke.sh --hub-context hub --spoke-context spoke1
   
   # Uninstall (should remove spoke first)
   ./scripts/argocd-uninstall.sh --context hub
   ```

## Summary

**Action:** Delete `argocd-uninstall.sh`, rename `argocd-cleanup-complete.sh` to `argocd-uninstall.sh`

**Rationale:** The "complete" script already handles both scenarios automatically via spoke detection

**Impact:**
- Removes 388 lines of redundant code
- Simplifies user experience
- Maintains all functionality

**Estimated Time:** 15 minutes (delete, rename, update docs)

---

**Status:** Ready to implement  
**Next Step:** Execute consolidation
## Summary

**Actions:**
1. Delete `argocd-uninstall.sh` (redundant - 388 lines)
2. Rename `argocd-cleanup-complete.sh` → `argocd-uninstall.sh`
3. Add prominent context logging to all 6 scripts
4. Update README.md documentation

**Rationale:** 
- The "complete" script already handles both scenarios automatically via spoke detection
- Context logging prevents accidental operations on wrong clusters
- Simpler naming and clearer user experience

**Impact:**
- Removes 388 lines of redundant code
- Adds safety through prominent context display
- Simplifies user experience
- Maintains all functionality

**Estimated Time:** 
- Script consolidation: 15 minutes
- Context logging updates: 45 minutes (6 scripts)
- Documentation updates: 30 minutes
- **Total:** ~90 minutes

---

**Status:** Plan complete, ready to implement  
**Next Step:** Execute consolidation and context logging updates