# ArgoCD Scripts Cleanup Analysis

**Date:** 2026-04-21  
**Purpose:** Identify redundant scripts and outdated documentation

## Issues Found

### 1. Redundant Cleanup Scripts

**Problem:** Two scripts with overlapping functionality:
- `argocd-uninstall.sh` (388 lines) - Uninstalls ArgoCD from a cluster
- `argocd-cleanup-complete.sh` (330 lines) - Orchestrates spoke removal + uninstall

**Analysis:**
- `argocd-cleanup-complete.sh` calls `argocd-uninstall.sh` internally
- `argocd-cleanup-complete.sh` adds spoke cluster removal before uninstall
- Both scripts do essentially the same thing for single-cluster setups

**Recommendation:** **Keep both scripts** - they serve different purposes:
- `argocd-uninstall.sh` - Simple uninstall (single cluster or hub-only)
- `argocd-cleanup-complete.sh` - Complete cleanup (hub + all spokes)

**Rationale:**
- Users with only hub cluster should use `argocd-uninstall.sh` (simpler)
- Users with hub+spokes should use `argocd-cleanup-complete.sh` (comprehensive)
- Having both provides flexibility

### 2. Documentation Out of Sync with Scripts

**Problem:** README.md shows outdated script usage

**Issues Found:**

#### Issue A: `--context` is now optional
**README.md (line 79):**
```bash
./scripts/install-argocd.sh --context "${HUB_CONTEXT}"
```

**Actual script (argocd-install.sh line 57):**
```
--context CONTEXT       Kubernetes context (optional; uses current context if omitted)
```

**Fix:** Update README to show `--context` as optional

#### Issue B: Script names don't match
**README.md (line 79):**
```bash
./scripts/install-argocd.sh
```

**Actual script name:**
```bash
./scripts/argocd-install.sh
```

**Fix:** Update all script references to use correct names with `argocd-` prefix

#### Issue C: Missing script documentation
**README.md** doesn't document:
- `argocd-describe.sh`
- `argocd-remove-spoke.sh`
- `argocd-uninstall.sh`
- `argocd-cleanup-complete.sh`

**Fix:** Add documentation for all scripts

## Recommended Changes

### 1. Keep All Scripts (No Deletions)

All scripts serve distinct purposes:
- ✅ `argocd-install.sh` - Install ArgoCD
- ✅ `argocd-configure-repo.sh` - Configure Git repository
- ✅ `argocd-add-spoke.sh` - Add spoke cluster
- ✅ `argocd-remove-spoke.sh` - Remove spoke cluster
- ✅ `argocd-create-pull-secret.sh` - Create registry pull secrets
- ✅ `argocd-describe.sh` - Describe ArgoCD installation
- ✅ `argocd-uninstall.sh` - Uninstall ArgoCD (simple)
- ✅ `argocd-cleanup-complete.sh` - Complete cleanup (hub + spokes)

### 2. Update README.md

#### Fix Script Names
Change all references from:
- `install-argocd.sh` → `argocd-install.sh`
- `configure-git-repo.sh` → `argocd-configure-repo.sh`
- `add-spoke-cluster.sh` → `argocd-add-spoke.sh`

#### Make `--context` Optional in Examples
```bash
# Before (implies required)
./scripts/argocd-install.sh --context "${HUB_CONTEXT}"

# After (show it's optional)
./scripts/argocd-install.sh --context "${HUB_CONTEXT}"  # or omit to use current context
```

#### Add Missing Script Documentation

Add sections for:

**argocd-describe.sh:**
```bash
./scripts/argocd-describe.sh [OPTIONS]

Options:
  --context CONTEXT       Kubernetes context (optional)
  --namespace NAMESPACE   ArgoCD namespace (default: argocd)
  -h, --help             Show help message

Examples:
  # Describe ArgoCD installation
  ./scripts/argocd-describe.sh --context my-cluster
```

**argocd-remove-spoke.sh:**
```bash
./scripts/argocd-remove-spoke.sh [OPTIONS]

Options:
  --hub-context CONTEXT    Hub cluster context (optional)
  --spoke-context CONTEXT  Spoke cluster context (required)
  --namespace NAMESPACE    ArgoCD namespace (default: argocd)
  -y, --yes               Skip confirmation
  -h, --help              Show help message

Examples:
  # Remove spoke cluster
  ./scripts/argocd-remove-spoke.sh \
    --hub-context hub-cluster \
    --spoke-context spoke-cluster-1
```

**argocd-uninstall.sh:**
```bash
./scripts/argocd-uninstall.sh [OPTIONS]

Options:
  --context CONTEXT       Kubernetes context (optional)
  --namespace NAMESPACE   ArgoCD namespace (default: argocd)
  --keep-crds            Keep ArgoCD CRDs
  --skip-finalizers      Skip finalizer removal
  -y, --yes              Skip confirmation
  -h, --help             Show help message

Examples:
  # Uninstall ArgoCD
  ./scripts/argocd-uninstall.sh --context my-cluster

  # Uninstall and keep CRDs
  ./scripts/argocd-uninstall.sh --context my-cluster --keep-crds
```

**argocd-cleanup-complete.sh:**
```bash
./scripts/argocd-cleanup-complete.sh [OPTIONS]

Options:
  --hub-context CONTEXT   Hub cluster context (optional)
  --namespace NAMESPACE   ArgoCD namespace (default: argocd)
  --keep-crds            Keep ArgoCD CRDs
  -y, --yes              Skip all confirmations
  -h, --help             Show help message

Examples:
  # Complete cleanup (removes spokes + uninstalls hub)
  ./scripts/argocd-cleanup-complete.sh --hub-context hub-cluster

  # Auto-confirm all steps
  ./scripts/argocd-cleanup-complete.sh --hub-context hub-cluster -y
```

### 3. Update Quick Start Section

**Current (line 72-80):**
```bash
# Set your hub cluster context
export HUB_CONTEXT="my-hub-cluster"

# Install ArgoCD
./scripts/install-argocd.sh --context "${HUB_CONTEXT}"
```

**Updated:**
```bash
# Option 1: Use specific context
./scripts/argocd-install.sh --context my-hub-cluster

# Option 2: Use current context
kubectl config use-context my-hub-cluster
./scripts/argocd-install.sh
```

### 4. Add Cleanup Section

Add new section after "Scripts Reference":

```markdown
## Cleanup

### Uninstall ArgoCD (Hub Only)

For simple hub-only installations:

```bash
./scripts/argocd-uninstall.sh --context my-cluster
```

### Complete Cleanup (Hub + Spokes)

For hub-and-spoke installations:

```bash
# Removes all spoke clusters and uninstalls ArgoCD from hub
./scripts/argocd-cleanup-complete.sh --hub-context my-hub-cluster
```

This will:
1. Remove all spoke cluster registrations
2. Delete applications on spoke clusters
3. Uninstall ArgoCD from hub cluster
4. Clean up all resources and CRDs
```

## Summary of Changes Needed

### Scripts
- ✅ No script deletions needed
- ✅ All scripts serve distinct purposes
- ✅ Script naming is consistent (all have `argocd-` prefix)

### Documentation (README.md)
- [ ] Fix script name references (add `argocd-` prefix)
- [ ] Show `--context` as optional in examples
- [ ] Add documentation for missing scripts:
  - argocd-describe.sh
  - argocd-remove-spoke.sh
  - argocd-uninstall.sh
  - argocd-cleanup-complete.sh
- [ ] Add "Cleanup" section
- [ ] Update Quick Start examples

### Estimated Time
- Documentation updates: ~30 minutes
- Testing updated examples: ~15 minutes
- **Total:** ~45 minutes

## Conclusion

**No scripts need to be removed.** All scripts serve distinct purposes:
- Installation and configuration scripts
- Spoke management scripts (add/remove)
- Cleanup scripts (simple vs complete)
- Utility scripts (describe, create-pull-secret)

**Only documentation needs updating** to match current script behavior and naming.

---

**Status:** Analysis Complete  
**Next Step:** Update README.md with corrections