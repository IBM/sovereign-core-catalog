# ArgoCD Cleanup Guide

Complete guide for safely removing ArgoCD from your Kubernetes environment.

## Overview

This guide covers the proper sequence for cleaning up ArgoCD installations, especially in hub-and-spoke architectures where the order of operations matters.

## Cleanup Order

**IMPORTANT:** Always follow this sequence to avoid orphaned resources:

1. **Remove spoke clusters** from hub ArgoCD
2. **Delete applications** on spoke clusters
3. **Uninstall ArgoCD** from hub cluster

## Quick Start

### Complete Cleanup (Recommended)

Use the master cleanup script that handles everything in the correct order:

```bash
# Interactive cleanup with prompts
./argocd/scripts/argocd-cleanup-complete.sh --hub-context k3s-cluster-1

# Auto-confirm all steps (for automation)
./argocd/scripts/argocd-cleanup-complete.sh --hub-context k3s-cluster-1 -y

# Keep CRDs for future reinstall
./argocd/scripts/argocd-cleanup-complete.sh --hub-context k3s-cluster-1 --keep-crds
```

### Manual Step-by-Step Cleanup

If you prefer manual control over each step:

#### Step 1: Remove Spoke Clusters

```bash
# List registered spoke clusters
oc --context=k3s-cluster-1 get secrets -n argocd \
  -l argocd.argoproj.io/secret-type=cluster

# Remove each spoke cluster
./argocd/scripts/remove-spoke-cluster.sh \
  --hub-context k3s-cluster-1 \
  --spoke-context k3s-cluster-2

./argocd/scripts/remove-spoke-cluster.sh \
  --hub-context k3s-cluster-1 \
  --spoke-context k3s-cluster-3
```

#### Step 2: Uninstall ArgoCD from Hub

```bash
# Uninstall ArgoCD
./argocd/scripts/uninstall-argocd.sh --context k3s-cluster-1

# Or keep CRDs for faster reinstall
./argocd/scripts/uninstall-argocd.sh --context k3s-cluster-1 --keep-crds
```

## Scripts Reference

### cleanup-argocd-complete.sh

Master orchestration script that performs complete cleanup in the correct order.

**Usage:**
```bash
./argocd/scripts/cleanup-argocd-complete.sh [OPTIONS]

Options:
  --hub-context CONTEXT   Hub cluster context (required)
  --namespace NAMESPACE   ArgoCD namespace (default: argocd)
  --keep-crds            Keep ArgoCD CRDs (don't delete)
  -y, --yes              Skip all confirmation prompts
  -h, --help             Show help message
```

**What it does:**
1. Discovers all registered spoke clusters
2. Removes each spoke cluster registration
3. Deletes applications on spoke clusters
4. Uninstalls ArgoCD from hub
5. Optionally removes CRDs

**Example output:**
```
============================================================
Complete ArgoCD Cleanup
============================================================

Configuration:
  Hub Context:  k3s-cluster-1
  Namespace:    argocd
  Keep CRDs:    false
  Auto-confirm: false

[INFO] Checking prerequisites...
[✓] oc is installed
[✓] Hub context 'k3s-cluster-1' found
[✓] ArgoCD namespace exists
[✓] All prerequisites met

============================================================
Cleanup Plan
============================================================

Found 2 spoke cluster(s):
  - k3s-cluster-2
  - k3s-cluster-3

Found 5 ArgoCD application(s)

This will perform the following actions:

Phase 1: Spoke Cluster Cleanup
  ✓ Remove 2 spoke cluster registration(s)
  ✓ Delete applications on spoke clusters

Phase 2: Hub ArgoCD Cleanup
  ✓ Delete all 5 ArgoCD application(s)
  ✓ Remove all ArgoCD resources
  ✓ Delete ArgoCD namespace: argocd
  ✓ Remove ArgoCD CRDs
```

### remove-spoke-cluster.sh

Remove a single spoke cluster from hub ArgoCD.

**Usage:**
```bash
./argocd/scripts/remove-spoke-cluster.sh [OPTIONS]

Options:
  --hub-context CONTEXT    Hub cluster context (required)
  --spoke-context CONTEXT  Spoke cluster context to remove (required)
  --namespace NAMESPACE    ArgoCD namespace (default: argocd)
  --keep-apps             Keep applications targeting this spoke
  -y, --yes               Skip confirmation prompt
  -h, --help              Show help message
```

**What it does:**
1. Finds all applications targeting the spoke cluster
2. Removes finalizers from applications
3. Deletes applications (unless --keep-apps specified)
4. Removes cluster registration secret

**Examples:**
```bash
# Remove spoke with prompts
./argocd/scripts/remove-spoke-cluster.sh \
  --hub-context k3s-cluster-1 \
  --spoke-context k3s-cluster-2

# Keep applications (they will fail to sync)
./argocd/scripts/remove-spoke-cluster.sh \
  --hub-context k3s-cluster-1 \
  --spoke-context k3s-cluster-2 \
  --keep-apps

# Auto-confirm
./argocd/scripts/remove-spoke-cluster.sh \
  --hub-context k3s-cluster-1 \
  --spoke-context k3s-cluster-2 -y
```

### uninstall-argocd.sh

Uninstall ArgoCD from a Kubernetes cluster.

**Usage:**
```bash
./argocd/scripts/uninstall-argocd.sh [OPTIONS]

Options:
  --context CONTEXT       Kubernetes context (required)
  --namespace NAMESPACE   ArgoCD namespace (default: argocd)
  --keep-crds            Keep ArgoCD CRDs (don't delete)
  --skip-finalizers      Skip finalizer removal (faster but may leave resources)
  -y, --yes              Skip confirmation prompt
  -h, --help             Show help message
```

**What it does:**
1. Removes all ArgoCD applications
2. Removes all ArgoCD AppProjects
3. Deletes all ArgoCD resources (deployments, services, etc.)
4. Removes ConfigMaps and Secrets
5. Deletes ServiceAccounts and RBAC
6. Removes ArgoCD namespace
7. Optionally removes CRDs

**Examples:**
```bash
# Standard uninstall
./argocd/scripts/uninstall-argocd.sh --context k3s-cluster-1

# Keep CRDs for faster reinstall
./argocd/scripts/uninstall-argocd.sh --context k3s-cluster-1 --keep-crds

# Auto-confirm
./argocd/scripts/uninstall-argocd.sh --context k3s-cluster-1 -y
```

## Common Scenarios

### Scenario 1: Complete Teardown

You want to completely remove ArgoCD and all related resources.

```bash
# One command does it all
./argocd/scripts/cleanup-argocd-complete.sh --hub-context k3s-cluster-1 -y
```

### Scenario 2: Remove One Spoke Cluster

You want to remove a specific spoke cluster but keep ArgoCD running.

```bash
# Remove just one spoke
./argocd/scripts/remove-spoke-cluster.sh \
  --hub-context k3s-cluster-1 \
  --spoke-context k3s-cluster-2 -y
```

### Scenario 3: Reinstall ArgoCD

You want to uninstall and reinstall ArgoCD quickly.

```bash
# Uninstall but keep CRDs
./argocd/scripts/uninstall-argocd.sh --context k3s-cluster-1 --keep-crds -y

# Reinstall
./argocd/scripts/install-argocd.sh --context k3s-cluster-1
```

### Scenario 4: Remove Spoke, Keep Applications

You want to unregister a spoke but keep the application definitions.

```bash
# Remove spoke but keep apps
./argocd/scripts/remove-spoke-cluster.sh \
  --hub-context k3s-cluster-1 \
  --spoke-context k3s-cluster-2 \
  --keep-apps -y

# Note: Applications will show as "Unknown" status after this
```

## Troubleshooting

### Namespace Won't Delete

If the ArgoCD namespace gets stuck in "Terminating" state:

```bash
# Check for resources with finalizers
oc --context=k3s-cluster-1 get all -n argocd -o json | \
  jq '.items[] | select(.metadata.finalizers != null) | {kind: .kind, name: .metadata.name, finalizers: .metadata.finalizers}'

# Force remove finalizers
oc --context=k3s-cluster-1 patch namespace argocd \
  -p '{"metadata":{"finalizers":[]}}' --type=merge

# Force delete namespace
oc --context=k3s-cluster-1 delete namespace argocd --grace-period=0 --force
```

### Applications Won't Delete

If applications are stuck deleting:

```bash
# Remove finalizers from all applications
oc --context=k3s-cluster-1 -n argocd get applications -o name | \
  xargs -I {} oc --context=k3s-cluster-1 -n argocd patch {} \
  --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]'

# Force delete
oc --context=k3s-cluster-1 delete applications --all -n argocd --grace-period=0 --force
```

### CRDs Won't Delete

If CRDs are stuck:

```bash
# List ArgoCD CRDs
oc --context=k3s-cluster-1 get crds | grep argoproj.io

# Remove finalizers from CRDs
oc --context=k3s-cluster-1 get crds -o name | grep argoproj.io | \
  xargs -I {} oc --context=k3s-cluster-1 patch {} \
  --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]'

# Force delete
oc --context=k3s-cluster-1 delete crds -l app.kubernetes.io/part-of=argocd --grace-period=0 --force
```

### Spoke Cluster Secret Won't Delete

If a spoke cluster secret is stuck:

```bash
# Remove finalizers
oc --context=k3s-cluster-1 -n argocd patch secret cluster-k3s-cluster-2 \
  --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]'

# Force delete
oc --context=k3s-cluster-1 -n argocd delete secret cluster-k3s-cluster-2 --grace-period=0 --force
```

## Verification

After cleanup, verify complete removal:

```bash
# Check namespace
oc --context=k3s-cluster-1 get namespace argocd
# Should return: Error from server (NotFound)

# Check CRDs (if removed)
oc --context=k3s-cluster-1 get crds | grep argoproj.io
# Should return nothing

# Check cluster contexts (spoke clusters may still exist)
oc config get-contexts | grep k3s-cluster
# Hub and spoke contexts may still exist (that's OK)
```

## Best Practices

1. **Always use the complete cleanup script** unless you have specific reasons to do manual cleanup
2. **Remove spoke clusters first** before uninstalling hub ArgoCD
3. **Keep CRDs if planning to reinstall** - saves time and avoids CRD version issues
4. **Use auto-confirm (-y) in automation** but be careful in production
5. **Backup important application manifests** before cleanup
6. **Document custom configurations** before removal
7. **Test cleanup in dev environment** before production

## Cleanup Checklist

Before running cleanup:

- [ ] Backup important application manifests
- [ ] Document custom ArgoCD configurations
- [ ] Verify you have the correct hub context
- [ ] List all spoke clusters to be removed
- [ ] Check for applications that need manual backup
- [ ] Confirm with team if in shared environment
- [ ] Test in dev environment first (if production)

After cleanup:

- [ ] Verify namespace is removed
- [ ] Check CRDs are removed (if intended)
- [ ] Confirm no orphaned resources
- [ ] Update documentation
- [ ] Remove oc contexts if no longer needed
- [ ] Clean up any external resources (Git repos, secrets, etc.)

## Related Documentation

- [Installation Guide](../README.md) - How to install ArgoCD
- [Multi-Cluster Patterns](multi-cluster-patterns.md) - Hub-and-spoke architecture
- [Repository Structure](repository-structure.md) - GitOps repository organization

---

**Last Updated:** 2026-04-03

*Made with Bob*