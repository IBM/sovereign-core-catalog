# Multi-Cluster Deployment Patterns

This document describes common patterns for deploying applications across multiple clusters using ArgoCD's hub-and-spoke architecture.

## Table of Contents

- [Overview](#overview)
- [Pattern 1: Single Application, Multiple Clusters](#pattern-1-single-application-multiple-clusters)
- [Pattern 2: Environment-Based Deployment](#pattern-2-environment-based-deployment)
- [Pattern 3: Tenant-Based Multi-Cluster](#pattern-3-tenant-based-multi-cluster)
- [Pattern 4: ApplicationSet for Multi-Cluster](#pattern-4-applicationset-for-multi-cluster)
- [Best Practices](#best-practices)

## Overview

ArgoCD's hub-and-spoke model allows a single ArgoCD instance (hub) to manage deployments across multiple Kubernetes clusters (spokes). This provides:

- **Centralized Management**: Single control plane for all clusters
- **Consistent Deployments**: Same application definitions across environments
- **Simplified Operations**: One place to monitor and troubleshoot
- **Cost Efficiency**: No ArgoCD overhead on spoke clusters

## Pattern 1: Single Application, Multiple Clusters

Deploy the same application to multiple clusters with cluster-specific configurations.

### Repository Structure

```
gitops-repo/
├── apps/
│   └── my-app/
│       ├── base/
│       │   ├── deployment.yaml
│       │   ├── service.yaml
│       │   └── kustomization.yaml
│       └── overlays/
│           ├── cluster-1/
│           │   ├── kustomization.yaml
│           │   └── patches.yaml
│           └── cluster-2/
│               ├── kustomization.yaml
│               └── patches.yaml
└── argocd-apps/
    ├── my-app-cluster-1.yaml
    └── my-app-cluster-2.yaml
```

### Application Definitions

**Cluster 1 Application:**
```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: my-app-cluster-1
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/org/gitops-repo.git
    targetRevision: main
    path: apps/my-app/overlays/cluster-1
  destination:
    server: https://kubernetes.default.svc  # Hub cluster
    namespace: my-app
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

**Cluster 2 Application:**
```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: my-app-cluster-2
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/org/gitops-repo.git
    targetRevision: main
    path: apps/my-app/overlays/cluster-2
  destination:
    name: spoke-cluster-1  # Spoke cluster
    namespace: my-app
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

## Pattern 2: Environment-Based Deployment

Organize clusters by environment (dev, staging, production) with environment-specific configurations.

### Repository Structure

```
gitops-repo/
├── apps/
│   └── my-app/
│       ├── base/
│       │   └── ...
│       └── environments/
│           ├── dev/
│           │   ├── kustomization.yaml
│           │   └── values.yaml
│           ├── staging/
│           │   ├── kustomization.yaml
│           │   └── values.yaml
│           └── production/
│               ├── kustomization.yaml
│               └── values.yaml
└── argocd-apps/
    ├── environments/
    │   ├── dev.yaml
    │   ├── staging.yaml
    │   └── production.yaml
```

### AppProject for Environment Isolation

```yaml
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: production
  namespace: argocd
spec:
  description: Production environment applications
  sourceRepos:
    - 'https://github.com/org/gitops-repo.git'
  destinations:
    - name: prod-cluster-east
      namespace: '*'
    - name: prod-cluster-west
      namespace: '*'
  clusterResourceWhitelist:
    - group: '*'
      kind: '*'
  roles:
    - name: admin
      policies:
        - p, proj:production:admin, applications, *, production/*, allow
      groups:
        - prod-admins
```

### Environment Application

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: my-app-production
  namespace: argocd
spec:
  project: production
  source:
    repoURL: https://github.com/org/gitops-repo.git
    targetRevision: main
    path: apps/my-app/environments/production
  destination:
    name: prod-cluster-east
    namespace: my-app
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
```

## Pattern 3: Tenant-Based Multi-Cluster

Isolate tenants with dedicated clusters and AppProjects for multi-tenancy.

### Repository Structure

```
gitops-repo/
├── tenants/
│   ├── tenant-a/
│   │   ├── apps/
│   │   │   ├── app1/
│   │   │   └── app2/
│   │   └── clusters/
│   │       ├── cluster-1.yaml
│   │       └── cluster-2.yaml
│   └── tenant-b/
│       ├── apps/
│       │   └── app1/
│       └── clusters/
│           └── cluster-1.yaml
└── argocd-projects/
    ├── tenant-a.yaml
    └── tenant-b.yaml
```

### Tenant AppProject

```yaml
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: tenant-a
  namespace: argocd
spec:
  description: Tenant A applications
  sourceRepos:
    - 'https://github.com/org/gitops-repo.git'
  destinations:
    - name: tenant-a-cluster-1
      namespace: 'tenant-a-*'
    - name: tenant-a-cluster-2
      namespace: 'tenant-a-*'
  namespaceResourceWhitelist:
    - group: '*'
      kind: '*'
  roles:
    - name: tenant-admin
      policies:
        - p, proj:tenant-a:tenant-admin, applications, *, tenant-a/*, allow
      groups:
        - tenant-a-admins
```

### Tenant Application

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: tenant-a-app1
  namespace: argocd
spec:
  project: tenant-a
  source:
    repoURL: https://github.com/org/gitops-repo.git
    targetRevision: main
    path: tenants/tenant-a/apps/app1
  destination:
    name: tenant-a-cluster-1
    namespace: tenant-a-app1
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

## Pattern 4: ApplicationSet for Multi-Cluster

Use ApplicationSet to automatically generate Applications for multiple clusters.

### Cluster Generator

```yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: my-app-all-clusters
  namespace: argocd
spec:
  generators:
    - clusters:
        selector:
          matchLabels:
            environment: production
  template:
    metadata:
      name: 'my-app-{{name}}'
    spec:
      project: default
      source:
        repoURL: https://github.com/org/gitops-repo.git
        targetRevision: main
        path: 'apps/my-app/overlays/{{name}}'
      destination:
        name: '{{name}}'
        namespace: my-app
      syncPolicy:
        automated:
          prune: true
          selfHeal: true
```

### Git Generator

```yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: my-apps
  namespace: argocd
spec:
  generators:
    - git:
        repoURL: https://github.com/org/gitops-repo.git
        revision: main
        directories:
          - path: apps/*
  template:
    metadata:
      name: '{{path.basename}}'
    spec:
      project: default
      source:
        repoURL: https://github.com/org/gitops-repo.git
        targetRevision: main
        path: '{{path}}'
      destination:
        server: https://kubernetes.default.svc
        namespace: '{{path.basename}}'
      syncPolicy:
        automated:
          prune: true
          selfHeal: true
```

### Matrix Generator (Clusters × Environments)

```yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: apps-matrix
  namespace: argocd
spec:
  generators:
    - matrix:
        generators:
          - clusters:
              selector:
                matchLabels:
                  argocd.argoproj.io/secret-type: cluster
          - list:
              elements:
                - app: app1
                  path: apps/app1
                - app: app2
                  path: apps/app2
  template:
    metadata:
      name: '{{app}}-{{name}}'
    spec:
      project: default
      source:
        repoURL: https://github.com/org/gitops-repo.git
        targetRevision: main
        path: '{{path}}'
      destination:
        name: '{{name}}'
        namespace: '{{app}}'
      syncPolicy:
        automated:
          prune: true
          selfHeal: true
```

## Best Practices

### 1. Cluster Labeling

Label clusters for easy selection:

```bash
oc label secret cluster-prod-east \
  -n argocd \
  environment=production \
  region=east \
  tier=critical
```

### 2. Progressive Rollouts

Deploy to clusters progressively:

```yaml
# Deploy to dev first
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: my-app-dev
spec:
  # ... dev cluster config

---
# Then staging (manual sync)
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: my-app-staging
spec:
  syncPolicy:
    automated: null  # Manual sync required
  # ... staging cluster config

---
# Finally production (manual sync with approval)
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: my-app-prod
spec:
  syncPolicy:
    automated: null
  # ... production cluster config
```

### 3. Health Checks

Configure custom health checks for multi-cluster deployments:

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: argocd-cm
  namespace: argocd
data:
  resource.customizations: |
    networking.k8s.io/Ingress:
      health.lua: |
        hs = {}
        hs.status = "Healthy"
        return hs
```

### 4. Sync Waves

Control deployment order across clusters:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: database
  annotations:
    argocd.argoproj.io/sync-wave: "1"  # Deploy first
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: backend
  annotations:
    argocd.argoproj.io/sync-wave: "2"  # Deploy second
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: frontend
  annotations:
    argocd.argoproj.io/sync-wave: "3"  # Deploy last
```

### 5. Monitoring and Alerts

Monitor multi-cluster deployments:

```bash
# Check all applications across clusters
oc get applications -n argocd

# Check specific cluster applications
oc get applications -n argocd -l cluster=prod-east

# Monitor sync status
oc get applications -n argocd -o json | \
  jq '.items[] | {name: .metadata.name, status: .status.sync.status}'
```

### 6. Disaster Recovery

Backup ArgoCD configuration:

```bash
# Backup all applications
oc get applications -n argocd -o yaml > applications-backup.yaml

# Backup all projects
oc get appprojects -n argocd -o yaml > projects-backup.yaml

# Backup cluster secrets
oc get secrets -n argocd -l argocd.argoproj.io/secret-type=cluster -o yaml > clusters-backup.yaml
```

## Troubleshooting

### Application Not Syncing to Spoke Cluster

```bash
# Check cluster secret
oc get secret cluster-spoke-1 -n argocd -o yaml

# Test connectivity from hub to spoke
oc run test-pod --rm -it --image=curlimages/curl -- sh
# Inside pod: curl -k https://spoke-api-server:6443
```

### Different Versions Across Clusters

Use ApplicationSet with cluster-specific values:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: versioned-app
spec:
  generators:
    - list:
        elements:
          - cluster: dev
            version: v1.0.0
          - cluster: staging
            version: v1.0.0
          - cluster: prod
            version: v0.9.5  # Older stable version
  template:
    metadata:
      name: 'my-app-{{cluster}}'
    spec:
      source:
        helm:
          parameters:
            - name: image.tag
              value: '{{version}}'
```

---

*Last Updated: 2026-04-03*