# GitOps Repository Structure

Best practices for organizing your GitOps repository for ArgoCD deployments.

## Table of Contents

- [Overview](#overview)
- [Basic Structure](#basic-structure)
- [Kustomize-Based Structure](#kustomize-based-structure)
- [Helm-Based Structure](#helm-based-structure)
- [Hybrid Structure](#hybrid-structure)
- [App of Apps Pattern](#app-of-apps-pattern)
- [Best Practices](#best-practices)

## Overview

A well-organized GitOps repository is crucial for maintainability, scalability, and team collaboration. This guide presents common patterns for structuring your repository.

## Basic Structure

Simple structure for small projects or getting started:

```
gitops-repo/
├── README.md
├── apps/
│   ├── app1/
│   │   ├── deployment.yaml
│   │   ├── service.yaml
│   │   └── configmap.yaml
│   └── app2/
│       ├── deployment.yaml
│       └── service.yaml
├── infrastructure/
│   ├── namespaces/
│   │   ├── dev.yaml
│   │   ├── staging.yaml
│   │   └── prod.yaml
│   └── rbac/
│       ├── roles.yaml
│       └── rolebindings.yaml
└── argocd/
    ├── applications/
    │   ├── app1.yaml
    │   └── app2.yaml
    └── projects/
        └── default.yaml
```

### Pros
- Simple and easy to understand
- Good for small teams or projects
- Minimal overhead

### Cons
- Limited reusability
- Difficult to manage environment-specific configs
- Doesn't scale well

## Kustomize-Based Structure

Recommended for most use cases - provides good balance of simplicity and flexibility:

```
gitops-repo/
├── README.md
├── apps/
│   ├── app1/
│   │   ├── base/
│   │   │   ├── deployment.yaml
│   │   │   ├── service.yaml
│   │   │   ├── configmap.yaml
│   │   │   └── kustomization.yaml
│   │   └── overlays/
│   │       ├── dev/
│   │       │   ├── kustomization.yaml
│   │       │   ├── replica-patch.yaml
│   │       │   └── configmap-patch.yaml
│   │       ├── staging/
│   │       │   ├── kustomization.yaml
│   │       │   └── replica-patch.yaml
│   │       └── production/
│   │           ├── kustomization.yaml
│   │           ├── replica-patch.yaml
│   │           └── hpa.yaml
│   └── app2/
│       ├── base/
│       │   └── ...
│       └── overlays/
│           └── ...
├── infrastructure/
│   ├── base/
│   │   ├── namespaces.yaml
│   │   ├── rbac.yaml
│   │   └── kustomization.yaml
│   └── overlays/
│       ├── dev/
│       ├── staging/
│       └── production/
└── argocd/
    ├── applications/
    │   ├── app1-dev.yaml
    │   ├── app1-staging.yaml
    │   ├── app1-production.yaml
    │   └── ...
    └── projects/
        └── default.yaml
```

### Base Kustomization Example

```yaml
# apps/app1/base/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

resources:
  - deployment.yaml
  - service.yaml
  - configmap.yaml

commonLabels:
  app: app1
  managed-by: argocd

namespace: app1
```

### Overlay Kustomization Example

```yaml
# apps/app1/overlays/production/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

bases:
  - ../../base

namespace: app1-prod

replicas:
  - name: app1
    count: 3

patchesStrategicMerge:
  - replica-patch.yaml

resources:
  - hpa.yaml

images:
  - name: app1
    newTag: v1.2.3
```

### Pros
- Native Kubernetes tool
- Good for environment-specific configurations
- Reusable base configurations
- No templating complexity

### Cons
- Limited logic capabilities
- Can become complex with many overlays

## Helm-Based Structure

Best for applications with complex configurations or when using existing Helm charts:

```
gitops-repo/
├── README.md
├── charts/
│   ├── app1/
│   │   ├── Chart.yaml
│   │   ├── values.yaml
│   │   ├── templates/
│   │   │   ├── deployment.yaml
│   │   │   ├── service.yaml
│   │   │   └── _helpers.tpl
│   │   └── values/
│   │       ├── dev.yaml
│   │       ├── staging.yaml
│   │       └── production.yaml
│   └── app2/
│       └── ...
├── infrastructure/
│   └── charts/
│       ├── cert-manager/
│       └── ingress-nginx/
└── argocd/
    ├── applications/
    │   ├── app1-dev.yaml
    │   ├── app1-staging.yaml
    │   └── app1-production.yaml
    └── projects/
        └── default.yaml
```

### Helm Values Structure

```yaml
# charts/app1/values.yaml (defaults)
replicaCount: 1

image:
  repository: myapp
  tag: latest
  pullPolicy: IfNotPresent

service:
  type: ClusterIP
  port: 80

resources:
  limits:
    cpu: 100m
    memory: 128Mi
  requests:
    cpu: 50m
    memory: 64Mi
```

```yaml
# charts/app1/values/production.yaml (overrides)
replicaCount: 3

image:
  tag: v1.2.3
  pullPolicy: Always

service:
  type: LoadBalancer

resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 250m
    memory: 256Mi

autoscaling:
  enabled: true
  minReplicas: 3
  maxReplicas: 10
```

### ArgoCD Application with Helm

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: app1-production
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/org/gitops-repo.git
    targetRevision: main
    path: charts/app1
    helm:
      valueFiles:
        - values.yaml
        - values/production.yaml
      parameters:
        - name: image.tag
          value: v1.2.3
  destination:
    server: https://kubernetes.default.svc
    namespace: app1-prod
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

### Pros
- Powerful templating
- Reusable charts
- Large ecosystem of existing charts
- Good for complex applications

### Cons
- Steeper learning curve
- Can become overly complex
- Debugging template issues can be difficult

## Hybrid Structure

Combine Kustomize and Helm for maximum flexibility:

```
gitops-repo/
├── README.md
├── apps/
│   ├── custom-apps/          # Kustomize-based apps
│   │   ├── app1/
│   │   │   ├── base/
│   │   │   └── overlays/
│   │   └── app2/
│   │       └── ...
│   └── helm-apps/            # Helm-based apps
│       ├── app3/
│       │   ├── Chart.yaml
│       │   └── values/
│       └── app4/
│           └── ...
├── infrastructure/
│   ├── kustomize/            # Infrastructure as Kustomize
│   │   ├── base/
│   │   └── overlays/
│   └── helm/                 # Infrastructure as Helm
│       ├── cert-manager/
│       └── ingress-nginx/
└── argocd/
    ├── applications/
    │   ├── kustomize/
    │   │   ├── app1-dev.yaml
    │   │   └── app2-prod.yaml
    │   └── helm/
    │       ├── app3-dev.yaml
    │       └── app4-prod.yaml
    └── projects/
        └── default.yaml
```

### Pros
- Use the right tool for each job
- Maximum flexibility
- Can leverage existing Helm charts

### Cons
- More complex to maintain
- Team needs to know both tools
- Potential for inconsistency

## App of Apps Pattern

Manage multiple applications with a single "app of apps":

```
gitops-repo/
├── README.md
├── apps/
│   ├── app1/
│   ├── app2/
│   └── app3/
├── argocd/
│   ├── root-app.yaml         # The "app of apps"
│   ├── projects/
│   │   ├── team-a.yaml
│   │   └── team-b.yaml
│   └── applications/
│       ├── team-a/
│       │   ├── app1.yaml
│       │   └── app2.yaml
│       └── team-b/
│           └── app3.yaml
└── bootstrap/
    └── root-app.yaml         # Bootstrap the root app
```

### Root Application

```yaml
# argocd/root-app.yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: root-app
  namespace: argocd
  finalizers:
    - resources-finalizer.argocd.argoproj.io
spec:
  project: default
  source:
    repoURL: https://github.com/org/gitops-repo.git
    targetRevision: main
    path: argocd/applications
    directory:
      recurse: true
  destination:
    server: https://kubernetes.default.svc
    namespace: argocd
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

### Child Application

```yaml
# argocd/applications/team-a/app1.yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: app1
  namespace: argocd
spec:
  project: team-a
  source:
    repoURL: https://github.com/org/gitops-repo.git
    targetRevision: main
    path: apps/app1/overlays/production
  destination:
    server: https://kubernetes.default.svc
    namespace: app1
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

### Bootstrap

```bash
# Bootstrap the entire system with one command
oc apply -f bootstrap/root-app.yaml
```

### Pros
- Single source of truth
- Easy to bootstrap entire system
- Hierarchical organization
- Self-managing ArgoCD applications

### Cons
- Can be complex to debug
- Circular dependencies possible
- Requires careful planning

## Best Practices

### 1. Separate Concerns

```
gitops-repo/
├── apps/              # Application code
├── infrastructure/    # Cluster infrastructure
├── platform/          # Platform services (monitoring, logging)
└── argocd/           # ArgoCD configuration
```

### 2. Use Meaningful Names

```
# Good
apps/payment-service/overlays/production/
apps/user-api/overlays/staging/

# Bad
apps/app1/env1/
apps/svc2/e2/
```

### 3. Version Control Everything

```yaml
# Include version in metadata
apiVersion: apps/v1
kind: Deployment
metadata:
  name: myapp
  labels:
    version: v1.2.3
    git-commit: abc123def
```

### 4. Document Your Structure

```markdown
# README.md in each directory
## apps/payment-service/

This directory contains the payment service application.

### Structure
- `base/`: Base Kubernetes manifests
- `overlays/dev/`: Development environment configuration
- `overlays/production/`: Production environment configuration

### Deployment
Applications are automatically deployed via ArgoCD when changes are merged to main.
```

### 5. Use .gitignore

```gitignore
# .gitignore
*.swp
*.swo
*~
.DS_Store
secrets/
*.secret.yaml
helm-charts/*/charts/
```

### 6. Validate Before Commit

```bash
# Pre-commit hook
#!/bin/bash
# Validate Kubernetes manifests
oc apply --dry-run=client -f apps/

# Validate Kustomize
kustomize build apps/app1/overlays/production

# Validate Helm
helm lint charts/app1
```

### 7. Use Consistent Naming

```yaml
# Consistent naming convention
metadata:
  name: ${APP_NAME}-${ENVIRONMENT}
  labels:
    app: ${APP_NAME}
    environment: ${ENVIRONMENT}
    managed-by: argocd
```

### 8. Implement RBAC

```
argocd/
├── projects/
│   ├── team-a.yaml      # Team A can only access their apps
│   ├── team-b.yaml      # Team B can only access their apps
│   └── platform.yaml    # Platform team has broader access
```

### 9. Use Sync Waves

```yaml
# Deploy in order: namespace → rbac → app
apiVersion: v1
kind: Namespace
metadata:
  name: myapp
  annotations:
    argocd.argoproj.io/sync-wave: "1"
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: myapp-role
  annotations:
    argocd.argoproj.io/sync-wave: "2"
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: myapp
  annotations:
    argocd.argoproj.io/sync-wave: "3"
```

### 10. Monitor Repository Size

```bash
# Keep repository lean
# Use Git LFS for large files
# Don't commit binaries or images
# Archive old branches regularly
```

## Migration Strategies

### From Monorepo to Multi-Repo

```
# Before (monorepo)
gitops-repo/
├── team-a/
├── team-b/
└── platform/

# After (multi-repo)
team-a-gitops/
team-b-gitops/
platform-gitops/
```

### From Helm to Kustomize

```bash
# 1. Generate manifests from Helm
helm template myapp charts/myapp > base/all.yaml

# 2. Split into individual files
# 3. Create kustomization.yaml
# 4. Create overlays for environments
```

---

*Last Updated: 2026-04-03*