# ApplicationSet CRD Annotation Size Fix

## Problem

When installing ArgoCD using the standard manifest, you may encounter this error:

```
The CustomResourceDefinition "applicationsets.argoproj.io" is invalid: metadata.annotations: Too long: may not be more than 262144 bytes
```

## Root Cause

This is a known upstream ArgoCD issue where the ApplicationSet CRD's `oc.kubernetes.io/last-applied-configuration` annotation exceeds Kubernetes' 262144 byte (256KB) limit for annotations.

**References:**
- Upstream issue: https://github.com/argoproj/argo-cd/issues/9525
- Kubernetes annotation limits: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/

## Our Solution

The `argocd-install.sh` script automatically filters out ApplicationSet components before applying the manifest:

1. **Downloads** the ArgoCD manifest from upstream
2. **Filters** the manifest using Python to remove:
   - ApplicationSet CRD (`applicationsets.argoproj.io`)
   - ApplicationSet controller deployment
   - ApplicationSet service
   - ApplicationSet RBAC resources
   - ApplicationSet network policies
3. **Applies** the filtered manifest to the cluster

## Why This Works

- **We don't use ApplicationSets**: Our GitOps workflow uses Application CRDs directly
- **ApplicationSet is optional**: It's only needed for advanced templating features
- **Core functionality unaffected**: All essential ArgoCD components install normally

## What You'll See

After installation, you'll see 6 ArgoCD pods (not 7):

```bash
oc --context hub get pods -n argocd

# Expected output (no applicationset-controller):
NAME                                               READY   STATUS
argocd-application-controller-0                    1/1     Running
argocd-dex-server-*                                1/1     Running
argocd-notifications-controller-*                  1/1     Running
argocd-redis-*                                     1/1     Running
argocd-repo-server-*                               1/1     Running
argocd-server-*                                    1/1     Running
```

## Implementation Details

The filtering is done using a Python script embedded in the installation script:

```python
# Read manifest
with open(input_file, 'r') as f:
    content = f.read()

# Split on YAML document separator
documents = content.split('\n---\n')
filtered_docs = []

for doc in documents:
    # Skip ApplicationSet CRD
    if 'kind: CustomResourceDefinition' in doc and 'applicationsets.argoproj.io' in doc:
        continue
    # Skip ApplicationSet controller
    if 'kind: Deployment' in doc and 'argocd-applicationset-controller' in doc:
        continue
    # Skip other ApplicationSet resources...
    filtered_docs.append(doc)

# Write filtered manifest
with open(output_file, 'w') as f:
    f.write('\n---\n'.join(filtered_docs))
```

## If You Need ApplicationSet

If you specifically need ApplicationSet features (most users don't), you can manually install it after setup:

```bash
# Install ApplicationSet CRD from a specific version
oc apply -f https://raw.githubusercontent.com/argoproj/argo-cd/v2.9.3/manifests/crds/applicationset-crd.yaml

# Install ApplicationSet controller
oc apply -f https://raw.githubusercontent.com/argoproj/argo-cd/v2.9.3/manifests/base/applicationset-controller/
```

**Note:** This may still trigger the annotation size error depending on the ArgoCD version.

## Alternative Solutions

If you prefer not to filter the manifest, other options include:

1. **Use server-side apply** (requires oc 1.22+):
   ```bash
   oc apply --server-side -f install.yaml
   ```

2. **Use oc replace** instead of apply:
   ```bash
   oc create -f install.yaml || oc replace -f install.yaml
   ```

3. **Install from Helm chart** (doesn't have this issue):
   ```bash
   helm repo add argo https://argoproj.github.io/argo-helm
   helm install argocd argo/argo-cd -n argocd --create-namespace
   ```

## Verification

After installation, verify the fix worked:

```bash
# Check that ArgoCD is running without ApplicationSet
oc --context hub get pods -n argocd
oc --context hub get crd | grep argoproj

# You should see:
# - applications.argoproj.io
# - appprojects.argoproj.io
# But NOT:
# - applicationsets.argoproj.io
```

## Status

✅ **RESOLVED** - The installation script automatically handles this issue.

---

*Last Updated: 2026-04-08*