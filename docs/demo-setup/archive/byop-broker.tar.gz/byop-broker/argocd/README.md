# ArgoCD Deployment

Generic ArgoCD deployment scripts for Kubernetes clusters - platform-agnostic and production-ready.

## Overview

This directory provides clean, minimal scripts to deploy ArgoCD in a hub-and-spoke architecture on **any** Kubernetes cluster (EKS, GKE, AKS, on-premises, k3s, etc.).

**Key Features:**
- ✅ Platform-agnostic (works on any Kubernetes cluster)
- ✅ Hub-and-spoke architecture support
- ✅ Minimal dependencies (oc only)
- ✅ Git repository integration (SSH/HTTPS)
- ✅ Production-ready configuration
- ✅ No vendor lock-in

## Architecture

### Hub-and-Spoke Model

```
┌─────────────────────────────────────────────────────────┐
│  Git Repository (GitHub/GitLab/Bitbucket)               │
│  ├── apps/                  (Application manifests)     │
│  ├── services/              (Service definitions)       │
│  └── clusters/              (Cluster-specific configs)  │
└────────────┬────────────────────────────┬───────────────┘
             │                            │
             ↓                            ↓
┌────────────────────────┐   ┌────────────────────────┐
│  Hub Cluster           │   │  Spoke Cluster 1       │
│  ┌──────────────────┐  │   │                        │
│  │ ArgoCD           │──┼───┼─▶ Applications         │
│  └──────────────────┘  │   │                        │
│  Applications          │   └────────────────────────┘
└────────────────────────┘   
                             ┌────────────────────────┐
                             │  Spoke Cluster 2       │
                             │                        │
                             │  Applications          │
                             └────────────────────────┘
```

**Benefits:**
- Single ArgoCD instance manages all clusters
- Centralized monitoring and control
- Lower resource overhead on spoke clusters
- Simplified operations and troubleshooting

## Prerequisites

### Required Tools
- `oc` or `oc` (configured with cluster access)
- `bash` (for running scripts)
- Git repository (GitHub, GitLab, Bitbucket, etc.)

**Note:** All scripts use `oc` by default for OpenShift compatibility. `oc` is a superset of `oc` and works on any Kubernetes cluster.

### Cluster Requirements
- Kubernetes 1.19+ (any distribution)
- Cluster admin access
- Network connectivity between hub and spoke clusters
- Sufficient resources (2 CPU, 4GB RAM minimum for ArgoCD)

### Git Repository Setup
1. Create a Git repository for your GitOps manifests
2. Generate SSH deploy key or personal access token
3. Add deploy key to repository settings

## Quick Start

### 1. Install ArgoCD on Hub Cluster

```bash
# Set your hub cluster context
export HUB_CONTEXT="my-hub-cluster"

# Install ArgoCD
./scripts/argocd-install.sh --context "${HUB_CONTEXT}"
```

### 2. Configure Git Repository Access

```bash
# Option A: SSH authentication (recommended)
./scripts/argocd-configure-repo.sh \
  --context "${HUB_CONTEXT}" \
  --repo-url "git@github.com:org/repo.git" \
  --ssh-key-path ~/.ssh/gitops_deploy_key

# Option B: HTTPS authentication
./scripts/argocd-configure-repo.sh \
  --context "${HUB_CONTEXT}" \
  --repo-url "https://github.com/org/repo.git" \
  --token "${GITHUB_TOKEN}"
```

### 3. Add Spoke Clusters (Optional)

```bash
# Add spoke cluster to hub ArgoCD
./scripts/argocd-add-spoke.sh \
  --hub-context "${HUB_CONTEXT}" \
  --spoke-context "my-spoke-cluster"
```

### 4. Access ArgoCD UI

```bash
# Get admin password after ArgoCD creates the initial admin secret
oc --context "${HUB_CONTEXT}" -n argocd get secret argocd-initial-admin-secret \
  -o jsonpath="{.data.password}" | base64 -d && echo

# Note:
# - The initial admin secret is created by ArgoCD during bootstrap
# - It may not exist immediately after installation
# - If the command fails, wait briefly and try again

# Port forward to access UI
oc --context "${HUB_CONTEXT}" port-forward svc/argocd-server -n argocd 8080:443

# Open browser to https://localhost:8080
# Username: admin
# Password: (from command above, once the secret exists)
```

## Scripts Reference

### argocd-install.sh

Install ArgoCD on a Kubernetes cluster.

```bash
./scripts/argocd-install.sh [OPTIONS]

Options:
  --context CONTEXT       Kubernetes context (optional; uses current context if omitted)
  --namespace NAMESPACE   ArgoCD namespace (default: argocd)
  --version VERSION       ArgoCD version (default: stable)
  --insecure             Disable TLS verification (not recommended)
  --dry-run              Show what would be done without making changes
  -h, --help             Show help message

Examples:
  # Dry run to see what would be installed
  ./scripts/argocd-install.sh --context my-cluster --dry-run

  # Install on specific cluster context
  ./scripts/argocd-install.sh --context my-cluster

  # Install specific version
  ./scripts/argocd-install.sh --context my-cluster --version v2.9.3

  # Install in custom namespace
  ./scripts/argocd-install.sh --context my-cluster --namespace gitops
```

### argocd-configure-repo.sh

Configure ArgoCD to access a Git repository.

```bash
./scripts/argocd-configure-repo.sh [OPTIONS]

Options:
  --context CONTEXT       Kubernetes context (optional; uses current context if omitted)
  --repo-url URL          Git repository URL (required)
  --ssh-key-path PATH     Path to SSH private key (for SSH URLs)
  --token TOKEN           Personal access token (for HTTPS URLs)
  --repo-name NAME        Repository name (default: derived from URL)
  --namespace NAMESPACE   ArgoCD namespace (default: argocd)
  --dry-run              Show what would be done without making changes
  -h, --help             Show help message

Examples:
  # Dry run to see what would be configured
  ./scripts/argocd-configure-repo.sh \
    --context my-cluster \
    --repo-url git@github.com:org/repo.git \
    --ssh-key-path ~/.ssh/deploy_key \
    --dry-run

  # SSH authentication
  ./scripts/argocd-configure-repo.sh \
    --context my-cluster \
    --repo-url git@github.com:org/repo.git \
    --ssh-key-path ~/.ssh/deploy_key

  # HTTPS authentication
  ./scripts/argocd-configure-repo.sh \
    --context my-cluster \
    --repo-url https://github.com/org/repo.git \
    --token ghp_xxxxxxxxxxxx
```

### argocd-add-spoke.sh

Register a spoke cluster with hub ArgoCD.

```bash
./scripts/argocd-add-spoke.sh [OPTIONS]

Options:
  --hub-context CONTEXT    Hub cluster context (required)
  --spoke-context CONTEXT  Spoke cluster context (required)
  --spoke-name NAME        Friendly name for spoke (default: context name)
  --namespace NAMESPACE    ArgoCD namespace (default: argocd)
  --dry-run               Show what would be done without making changes
  -h, --help              Show help message

Examples:
  # Dry run to see what would be configured
  ./scripts/argocd-add-spoke.sh \
    --hub-context hub-cluster \
    --spoke-context spoke-cluster-1 \
    --dry-run

  # Add spoke cluster
  ./scripts/argocd-add-spoke.sh \
    --hub-context hub-cluster \
    --spoke-context spoke-cluster-1

  # Add with custom name
  ./scripts/argocd-add-spoke.sh \
    --hub-context hub-cluster \
    --spoke-context prod-east-1 \
    --spoke-name "Production East"
```

### argocd-remove-spoke.sh

Remove a spoke cluster from ArgoCD hub.

```bash
./scripts/argocd-remove-spoke.sh [OPTIONS]

Options:
  --hub-context CONTEXT    Hub cluster context (required)
  --spoke-context CONTEXT  Spoke cluster context to remove (required)
  --namespace NAMESPACE    ArgoCD namespace (default: argocd)
  --keep-apps             Keep applications targeting this spoke (don't delete)
  -f, --force             Skip confirmation prompt
  -h, --help              Show help message

Examples:
  # Remove spoke cluster
  ./scripts/argocd-remove-spoke.sh \
    --hub-context k3s-cluster-1 \
    --spoke-context k3s-cluster-2

  # Remove spoke but keep applications
  ./scripts/argocd-remove-spoke.sh \
    --hub-context k3s-cluster-1 \
    --spoke-context k3s-cluster-2 \
    --keep-apps

  # Auto-confirm removal (long form)
  ./scripts/argocd-remove-spoke.sh \
    --hub-context k3s-cluster-1 \
    --spoke-context k3s-cluster-2 \
    --force
  
  # Auto-confirm removal (short form)
  ./scripts/argocd-remove-spoke.sh \
    --hub-context k3s-cluster-1 \
    --spoke-context k3s-cluster-2 \
    -f
```

### argocd-uninstall.sh

Complete ArgoCD cleanup - removes spoke clusters and uninstalls ArgoCD from hub.

```bash
./scripts/argocd-uninstall.sh [OPTIONS]

Options:
  --hub-context CONTEXT   Hub cluster context (optional; uses current context if omitted)
  --namespace NAMESPACE   ArgoCD namespace (default: argocd)
  --keep-crds            Keep ArgoCD CRDs (don't delete)
  -f, --force            Skip all confirmation prompts
  -h, --help             Show help message

Examples:
  # Complete cleanup with prompts
  ./scripts/argocd-uninstall.sh --hub-context k3s-cluster-1

  # Auto-confirm all steps (long form)
  ./scripts/argocd-uninstall.sh --hub-context k3s-cluster-1 --force
  
  # Auto-confirm all steps (short form)
  ./scripts/argocd-uninstall.sh --hub-context k3s-cluster-1 -f

  # Keep CRDs for future reinstall
  ./scripts/argocd-uninstall.sh --hub-context k3s-cluster-1 --keep-crds
```

### argocd-describe.sh

Display ArgoCD information including credentials, access commands, and topology.

```bash
./scripts/argocd-describe.sh [OPTIONS]

Options:
  --context CONTEXT       Kubernetes context (optional; uses current context if omitted)
  --namespace NAMESPACE   ArgoCD namespace (default: argocd)
  -h, --help             Show help message

Examples:
  # Show ArgoCD info for hub cluster
  ./scripts/argocd-describe.sh --context hub

  # Show info for custom namespace
  ./scripts/argocd-describe.sh --context my-cluster --namespace gitops
```

### argocd-create-pull-secret.sh

Create pull secrets for private container registries in ArgoCD-managed clusters.

**Note:** Only required if your service images are in private registries. Public registries (e.g., Docker Hub public images) don't need pull secrets.

```bash
./scripts/argocd-create-pull-secret.sh [OPTIONS]

Options:
  --cluster CLUSTER       Target cluster name (kubectl context) (required)
  --registry REGISTRY     Registry server (e.g., quay.io, docker.io) (required)
  --username USER         Registry username (required)
  --password PASS         Registry password or token (required)
  --namespace NAMESPACE   Kubernetes namespace (default: argocd)
  --secret-name NAME      Secret name (default: services-pull-secret)
  -h, --help             Show help message

Examples:
  # Create pull secret for Quay.io
  ./scripts/argocd-create-pull-secret.sh \
    --cluster k3s-cluster-2 \
    --registry quay.io \
    --username myuser \
    --password mytoken

  # Create pull secret in custom namespace
  ./scripts/argocd-create-pull-secret.sh \
    --cluster prod-cluster \
    --registry docker.io \
    --username myuser \
    --password mypass \
    --namespace default

  # Create pull secret with custom name
  ./scripts/argocd-create-pull-secret.sh \
    --cluster dev-cluster \
    --registry ghcr.io \
    --username myuser \
    --password ghp_token \
    --secret-name github-pull-secret
```

**What it does:**
1. Validates credentials against the registry
2. Switches to the target cluster context
3. Creates namespace if it doesn't exist
4. Creates docker-registry secret
5. Displays usage instructions for ArgoCD applications

**Use in ArgoCD applications:**
```yaml
spec:
  template:
    spec:
      imagePullSecrets:
      - name: services-pull-secret
```

## Configuration

### Environment Variables

```bash
# Optional: Set default values
export ARGOCD_NAMESPACE="argocd"
export ARGOCD_VERSION="stable"
export GIT_REPO_URL="git@github.com:org/repo.git"
export SSH_KEY_PATH="~/.ssh/gitops_deploy_key"
```

### Configuration Files

Example configuration files are available in `docs/examples/`.

For custom ArgoCD settings, create `argocd-config.yaml`:

```yaml
# ArgoCD ConfigMap customizations
data:
  # Sync interval (default: 3m)
  timeout.reconciliation: "30s"
  
  # Application sync settings
  application.instanceLabelKey: "argocd.argoproj.io/instance"
  
  # Resource tracking method
  application.resourceTrackingMethod: "annotation"
```

## Usage Examples

### Deploy Application to Hub Cluster

```yaml
# apps/my-app.yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: my-app
  namespace: argocd
spec:
  project: default
  source:
    repoURL: git@github.com:org/repo.git
    targetRevision: main
    path: apps/my-app
  destination:
    server: https://kubernetes.default.svc
    namespace: my-app
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

### Deploy Application to Spoke Cluster

```yaml
# apps/spoke-app.yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: spoke-app
  namespace: argocd
spec:
  project: default
  source:
    repoURL: git@github.com:org/repo.git
    targetRevision: main
    path: apps/spoke-app
  destination:
    name: spoke-cluster-1  # Spoke cluster name
    namespace: spoke-app
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

## Platform-Specific Notes

### Amazon EKS

```bash
# Get cluster context
aws eks update-kubeconfig --name my-cluster --region us-east-1

# Install ArgoCD
./scripts/argocd-install.sh --context arn:aws:eks:us-east-1:123456789012:cluster/my-cluster
```

### Google GKE

```bash
# Get cluster credentials
gcloud container clusters get-credentials my-cluster --region us-central1

# Install ArgoCD
./scripts/argocd-install.sh --context gke_project_us-central1_my-cluster
```

### Azure AKS

```bash
# Get cluster credentials
az aks get-credentials --resource-group my-rg --name my-cluster

# Install ArgoCD
./scripts/argocd-install.sh --context my-cluster
```

### On-Premises / Bare Metal

```bash
# Ensure oc is configured
oc config use-context my-cluster

# Install ArgoCD
./scripts/argocd-install.sh --context my-cluster
```

### k3s / k8s

```bash
# Use existing kubeconfig
export KUBECONFIG=~/.kube/config

# Install ArgoCD
./scripts/argocd-install.sh --context k3s-cluster-1
```

## Known Issues

### ApplicationSet CRD Annotation Size Error (RESOLVED)

The installation script automatically handles the known ArgoCD issue where the ApplicationSet CRD exceeds Kubernetes' annotation size limit. The script filters out ApplicationSet components, which are not needed for basic ArgoCD functionality.

**For details, see:** [ApplicationSet CRD Fix Documentation](docs/applicationset-crd-fix.md)

**What you'll see:**
- Installation completes successfully without annotation errors
- 6 ArgoCD pods running (ApplicationSet controller is excluded)
- All core ArgoCD functionality works normally

## Troubleshooting

### ArgoCD Pods Not Starting

```bash
# Check pod status
oc --context "${HUB_CONTEXT}" get pods -n argocd

# Check pod logs
oc --context "${HUB_CONTEXT}" logs -n argocd deployment/argocd-server

# Check events
oc --context "${HUB_CONTEXT}" get events -n argocd --sort-by='.lastTimestamp'
```

### Git Repository Connection Issues

```bash
# Test SSH connection
ssh -T git@github.com

# Verify SSH key in cluster
oc --context "${HUB_CONTEXT}" -n argocd get secret argocd-repo-creds -o yaml

# Check ArgoCD repo-server logs
oc --context "${HUB_CONTEXT}" logs -n argocd deployment/argocd-repo-server
```

### Spoke Cluster Not Accessible

```bash
# Verify spoke cluster secret
oc --context "${HUB_CONTEXT}" -n argocd get secret cluster-spoke-cluster-1

# Test connectivity from hub to spoke
oc --context "${HUB_CONTEXT}" run test-pod --rm -it --image=curlimages/curl -- sh
# Inside pod: curl -k https://spoke-api-server:6443
```

### Application Not Syncing

```bash
# Check application status
oc --context "${HUB_CONTEXT}" -n argocd get application my-app -o yaml

# Force sync
oc --context "${HUB_CONTEXT}" -n argocd patch application my-app \
  --type merge -p '{"operation":{"initiatedBy":{"username":"admin"},"sync":{}}}'

# Check application controller logs
oc --context "${HUB_CONTEXT}" logs -n argocd statefulset/argocd-application-controller
```

## Security Best Practices

1. **Use SSH Keys**: Prefer SSH authentication over HTTPS tokens
2. **Rotate Credentials**: Regularly rotate SSH keys and tokens
3. **Limit Permissions**: Use deploy keys with read-only access
4. **Network Policies**: Restrict ArgoCD network access
5. **RBAC**: Configure proper Kubernetes RBAC for ArgoCD
6. **TLS**: Always use TLS for ArgoCD UI (disable --insecure in production)
7. **Secrets Management**: Consider using sealed-secrets or external secrets operator

## Comparison with gitops/ Directory

| Feature | argocd/ (This Directory) | gitops/ (Legacy) |
|---------|-------------------------|------------------|
| Platform | Any Kubernetes/OpenShift | k3s/Multipass only |
| Dependencies | oc/oc only | multipass, docker, k3s-specific tools |
| Cluster Setup | Bring your own | Creates k3s VMs |
| Production Ready | Yes | Development/testing |
| Complexity | Minimal | High (full stack) |
| Use Case | ArgoCD deployment only | Complete dev environment |

**When to use argocd/:**
- Deploying to existing clusters (EKS, GKE, AKS, on-prem)
- Production environments
- CI/CD pipelines
- Minimal, focused ArgoCD setup

**When to use gitops/:**
- Local development with k3s
- Complete testing environment
- Learning GitOps concepts
- Multipass-based workflows

## Advanced Topics

See documentation in `docs/`:
- [Multi-Cluster Patterns](docs/multi-cluster-patterns.md)
- [GitOps Repository Structure](docs/repository-structure.md)
- [High Availability Setup](docs/high-availability.md)
- [Disaster Recovery](docs/disaster-recovery.md)
- [Monitoring and Observability](docs/monitoring.md)

## Contributing

Contributions welcome! Please ensure:
- Scripts remain platform-agnostic
- No hardcoded cluster-specific values
- Comprehensive error handling
- Clear documentation

## License

This is a prototype for demonstration purposes.

---

**Status:** ✅ Production-Ready ArgoCD Deployment Scripts

*Last Updated: 2026-04-03*