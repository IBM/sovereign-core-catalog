#!/bin/bash
#
# Complete ArgoCD Cleanup Script
# Orchestrates the full cleanup process in the correct order:
# 1. Remove spoke clusters from hub
# 2. Uninstall ArgoCD from hub
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE=""  # Will be set to current namespace if not specified
HUB_CONTEXT=""
FORCE=false
DELETE_CRDS=false  # Changed: Keep CRDs by default

# Build oc command with context if specified
oc_cmd() {
    if [ -n "$HUB_CONTEXT" ]; then
        oc --context="${HUB_CONTEXT}" "$@"
    else
        oc "$@"
    fi
}

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Complete ArgoCD cleanup - removes spoke clusters and uninstalls ArgoCD from hub.

This script performs cleanup in the correct order:
  1. Removes all spoke cluster registrations from hub
  2. Deletes applications on spoke clusters
  3. Uninstalls ArgoCD from hub cluster

Options:
  --hub-context CONTEXT   Hub cluster context (optional; uses current context if omitted)
  --namespace NAMESPACE   ArgoCD namespace (required)
  --delete-crds          Delete ArgoCD CRDs (default: keep CRDs for future use)
  -f, --force            Skip all confirmation prompts
  -h, --help             Show this help message

Examples:
  # Complete cleanup with prompts
  $0 --hub-context k3s-cluster-1 --namespace argocd

  # Auto-confirm all steps
  $0 --hub-context k3s-cluster-1 --namespace argocd --force
  
  # Short form
  $0 --hub-context k3s-cluster-1 --namespace argocd -f

  # Delete CRDs (not recommended - makes reinstall harder)
  $0 --hub-context k3s-cluster-1 --namespace argocd --delete-crds

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --hub-context)
            HUB_CONTEXT="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --delete-crds)
            DELETE_CRDS=true
            shift
            ;;
        -f|--force)
            FORCE=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Determine and display the actual Kubernetes context being used
if [ -n "$HUB_CONTEXT" ]; then
    ACTUAL_CONTEXT="$HUB_CONTEXT"
    CONTEXT_SOURCE="specified via --hub-context"
else
    ACTUAL_CONTEXT=$(kubectl config current-context 2>/dev/null || echo "unknown")
    CONTEXT_SOURCE="using current context"
fi

# Namespace is required
if [ -z "$NAMESPACE" ]; then
    log_error "Namespace is required"
    echo ""
    echo "Specify a namespace explicitly:"
    echo "  $0 --namespace YOUR_NAMESPACE"
    exit 1
fi

echo "============================================================"
echo "Complete ArgoCD Cleanup"
echo "============================================================"
echo ""
echo "⚠️  KUBERNETES CONTEXT: ${ACTUAL_CONTEXT}"
echo "    (${CONTEXT_SOURCE})"
echo ""
echo "Configuration:"
if [ -n "$HUB_CONTEXT" ]; then
    echo "  Hub Context:  ${HUB_CONTEXT}"
else
    echo "  Hub Context:  current oc context"
fi
echo "  Namespace:    ${NAMESPACE} (${NAMESPACE_SOURCE})"
echo "  Delete CRDs:  ${DELETE_CRDS}"
echo "  Force:        ${FORCE}"
echo ""

# Check prerequisites
log_info "Checking prerequisites..."

# Check oc
if ! command -v oc &> /dev/null; then
    log_error "oc is not installed"
    exit 1
fi
log_success "oc is installed"

# Check hub context
if [ -n "$HUB_CONTEXT" ]; then
    if ! oc config get-contexts "${HUB_CONTEXT}" &> /dev/null; then
        log_error "Hub context '${HUB_CONTEXT}' not found"
        exit 1
    fi
    log_success "Hub context '${HUB_CONTEXT}' found"
else
    log_info "Using current oc context"
fi

# Check if ArgoCD namespace exists
if ! oc_cmd get namespace "${NAMESPACE}" &> /dev/null; then
    log_warning "ArgoCD namespace '${NAMESPACE}' not found"
    echo ""
    echo "ArgoCD may not be installed or already removed."
    exit 0
fi
log_success "ArgoCD namespace exists"

echo ""
log_success "All prerequisites met"
echo ""

# Show cleanup plan
echo "============================================================"
echo "Cleanup Plan"
echo "============================================================"
echo ""

# Find spoke clusters
log_info "Discovering spoke clusters..."
SPOKE_CLUSTERS=$(oc_cmd -n "${NAMESPACE}" get secrets \
    -l argocd.argoproj.io/secret-type=cluster -o name 2>/dev/null | \
    grep -v "in-cluster" | sed 's/secret\/cluster-//' || true)

if [ -n "$SPOKE_CLUSTERS" ]; then
    SPOKE_COUNT=$(echo "$SPOKE_CLUSTERS" | wc -l | tr -d ' ')
    echo "Found ${SPOKE_COUNT} spoke cluster(s):"
    # shellcheck disable=SC2001  # sed is appropriate for adding prefix to each line
    echo "$SPOKE_CLUSTERS" | sed 's/^/  - /'
    echo ""
else
    echo "No spoke clusters registered"
    echo ""
fi

# Count applications
APP_COUNT=$(oc_cmd -n "${NAMESPACE}" get applications --no-headers 2>/dev/null | wc -l | tr -d ' ')
echo "Found ${APP_COUNT} ArgoCD application(s)"
echo ""

echo "This will perform the following actions:"
echo ""
echo "Phase 1: Spoke Cluster Cleanup"
if [ -n "$SPOKE_CLUSTERS" ]; then
echo "  ✓ Remove ${SPOKE_COUNT} spoke cluster registration(s)"
echo "  ✓ Delete applications on spoke clusters"
else
echo "  ✓ No spoke clusters to remove"
fi
echo ""
echo "Phase 2: Hub ArgoCD Cleanup"
echo "  ✓ Delete all ${APP_COUNT} ArgoCD application(s)"
echo "  ✓ Remove all ArgoCD resources from namespace: ${NAMESPACE}"
echo "  ✓ Keep namespace: ${NAMESPACE} (preserved for future use)"
if [ "$DELETE_CRDS" = true ]; then
echo "  ✓ Delete ArgoCD CRDs (--delete-crds specified)"
else
echo "  ✓ Keep ArgoCD CRDs (default - for future reinstall)"
fi
echo ""

# Confirm cleanup
if [ "$FORCE" = false ]; then
    echo "⚠️  WARNING: This is a destructive operation!"
    echo ""
    read -p "Are you sure you want to proceed with complete ArgoCD cleanup? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log_info "Cleanup cancelled"
        exit 0
    fi
    echo ""
fi

echo "============================================================"
echo "Phase 1: Spoke Cluster Cleanup"
echo "============================================================"
echo ""

if [ -n "$SPOKE_CLUSTERS" ]; then
    for SPOKE in $SPOKE_CLUSTERS; do
        echo "----------------------------------------"
        echo "Removing spoke cluster: ${SPOKE}"
        echo "----------------------------------------"
        echo ""
        
        # Build command - handle empty HUB_CONTEXT
        if [ -n "$HUB_CONTEXT" ]; then
            CMD="${SCRIPT_DIR}/argocd-remove-spoke.sh --hub-context ${HUB_CONTEXT} --spoke-context ${SPOKE}"
        else
            # Get current context for hub
            CURRENT_CONTEXT=$(kubectl config current-context 2>/dev/null || echo "")
            if [ -z "$CURRENT_CONTEXT" ]; then
                log_error "Cannot determine current context"
                exit 1
            fi
            CMD="${SCRIPT_DIR}/argocd-remove-spoke.sh --hub-context ${CURRENT_CONTEXT} --spoke-context ${SPOKE}"
        fi
        
        # Pass force flag to remove-spoke script if set
        if [ "$FORCE" = true ]; then
            CMD="${CMD} --force"
        fi
        
        # Execute removal
        if bash -c "$CMD"; then
            log_success "Spoke cluster '${SPOKE}' removed"
        else
            log_warning "Failed to remove spoke cluster '${SPOKE}'"
            echo ""
            read -p "Continue with remaining cleanup? (y/N): " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                log_error "Cleanup aborted"
                exit 1
            fi
        fi
        echo ""
    done
    
    log_success "All spoke clusters removed"
else
    log_info "No spoke clusters to remove"
fi

echo ""
echo "============================================================"
echo "Phase 2: Hub ArgoCD Cleanup"
echo "============================================================"
echo ""

# Delete all ArgoCD applications
if [ "$APP_COUNT" -gt 0 ]; then
    log_info "Deleting ${APP_COUNT} ArgoCD application(s)..."
    oc_cmd -n "${NAMESPACE}" delete applications --all --wait=false 2>/dev/null || true
    log_success "Applications deleted"
else
    log_info "No applications to delete"
fi

echo ""

# Delete all ArgoCD resources from namespace (but keep the namespace itself)
log_info "Removing all ArgoCD resources from namespace '${NAMESPACE}'..."

# Delete ArgoCD ApplicationSets
log_info "Deleting ApplicationSets..."
oc_cmd -n "${NAMESPACE}" delete applicationsets --all --wait=false 2>/dev/null || true

# Delete ArgoCD AppProjects
log_info "Deleting AppProjects..."
oc_cmd -n "${NAMESPACE}" delete appprojects --all --wait=false 2>/dev/null || true

# Delete ArgoCD server and related deployments
log_info "Deleting ArgoCD deployments..."
oc_cmd -n "${NAMESPACE}" delete deployment --all --wait=false 2>/dev/null || true

# Delete ArgoCD StatefulSets
log_info "Deleting ArgoCD StatefulSets..."
oc_cmd -n "${NAMESPACE}" delete statefulset --all --wait=false 2>/dev/null || true

# Delete ArgoCD ReplicaSets
log_info "Deleting ArgoCD ReplicaSets..."
oc_cmd -n "${NAMESPACE}" delete replicaset --all --wait=false 2>/dev/null || true

# Delete ArgoCD Services
log_info "Deleting ArgoCD Services..."
oc_cmd -n "${NAMESPACE}" delete service --all --wait=false 2>/dev/null || true

# Delete ArgoCD ConfigMaps (preserve system ConfigMaps)
log_info "Deleting ArgoCD ConfigMaps..."
oc_cmd -n "${NAMESPACE}" get configmap -o name 2>/dev/null | \
    grep -v "kube-root-ca.crt\|openshift-service-ca.crt\|odh-" | \
    while read -r resource; do
        [ -n "$resource" ] && oc_cmd -n "${NAMESPACE}" delete "$resource" --wait=false 2>/dev/null || true
    done

# Delete ArgoCD Secrets (preserve system secrets and tokens)
log_info "Deleting ArgoCD Secrets..."
oc_cmd -n "${NAMESPACE}" get secret -o name 2>/dev/null | \
    grep -v "default-token\|builder-token\|deployer-token\|default-dockercfg\|builder-dockercfg\|deployer-dockercfg" | \
    while read -r resource; do
        [ -n "$resource" ] && oc_cmd -n "${NAMESPACE}" delete "$resource" --wait=false 2>/dev/null || true
    done

# Delete ArgoCD ServiceAccounts (preserve default system accounts)
log_info "Deleting ArgoCD ServiceAccounts..."
oc_cmd -n "${NAMESPACE}" get serviceaccount -o name 2>/dev/null | \
    grep -v "^serviceaccount/default$\|^serviceaccount/builder$\|^serviceaccount/deployer$" | \
    while read -r resource; do
        [ -n "$resource" ] && oc_cmd -n "${NAMESPACE}" delete "$resource" --wait=false 2>/dev/null || true
    done

# Delete ArgoCD Roles and RoleBindings (namespace-scoped, but preserve namespace-admin)
log_info "Deleting ArgoCD Roles and RoleBindings..."
# Delete only ArgoCD-specific roles
oc_cmd -n "${NAMESPACE}" get role -o name 2>/dev/null | \
    grep "argocd-" | \
    while read -r resource; do
        [ -n "$resource" ] && oc_cmd -n "${NAMESPACE}" delete "$resource" --wait=false 2>/dev/null || true
    done

# Delete only ArgoCD-specific rolebindings (preserve namespace-admin and system bindings)
oc_cmd -n "${NAMESPACE}" get rolebinding -o name 2>/dev/null | \
    grep -E "argocd-" | \
    grep -v "namespace-admin" | \
    while read -r resource; do
        [ -n "$resource" ] && oc_cmd -n "${NAMESPACE}" delete "$resource" --wait=false 2>/dev/null || true
    done

# Delete cluster-scoped RoleBindings for ArgoCD ServiceAccounts in this namespace
log_info "Deleting cluster-scoped RoleBindings for ArgoCD ServiceAccounts..."
# Find and delete RoleBindings that reference ServiceAccounts in this namespace
oc_cmd get rolebinding --all-namespaces -o json 2>/dev/null | \
    jq -r --arg ns "${NAMESPACE}" '.items[] | select(.subjects[]? | select(.kind=="ServiceAccount" and .namespace==$ns and (.name | startswith("argocd-")))) | .metadata.namespace + "/" + .metadata.name' 2>/dev/null | \
    while IFS='/' read -r rb_ns rb_name; do
        if [ -n "$rb_ns" ] && [ -n "$rb_name" ]; then
            log_info "  Deleting RoleBinding ${rb_name} in namespace ${rb_ns}..."
            oc_cmd -n "${rb_ns}" delete rolebinding "${rb_name}" --wait=false 2>/dev/null || true
        fi
    done

# Delete ClusterRoleBindings for ArgoCD ServiceAccounts in this namespace
log_info "Deleting ClusterRoleBindings for ArgoCD ServiceAccounts..."
oc_cmd get clusterrolebinding -o json 2>/dev/null | \
    jq -r --arg ns "${NAMESPACE}" '.items[] | select(.subjects[]? | select(.kind=="ServiceAccount" and .namespace==$ns and (.name | startswith("argocd-")))) | .metadata.name' 2>/dev/null | \
    while read -r crb_name; do
        if [ -n "$crb_name" ]; then
            log_info "  Deleting ClusterRoleBinding ${crb_name}..."
            oc_cmd delete clusterrolebinding "${crb_name}" --wait=false 2>/dev/null || true
        fi
    done

# Delete ArgoCD NetworkPolicies
log_info "Deleting ArgoCD NetworkPolicies..."
oc_cmd -n "${NAMESPACE}" delete networkpolicy --all --wait=false 2>/dev/null || true

# Delete ArgoCD PVCs
log_info "Deleting ArgoCD PersistentVolumeClaims..."
oc_cmd -n "${NAMESPACE}" delete pvc --all --wait=false 2>/dev/null || true

# Delete any remaining pods (except those managed by system)
log_info "Deleting ArgoCD pods..."
oc_cmd -n "${NAMESPACE}" get pod -o name 2>/dev/null | \
    while read -r resource; do
        [ -n "$resource" ] && oc_cmd -n "${NAMESPACE}" delete "$resource" --wait=false 2>/dev/null || true
    done

log_success "All ArgoCD resources removed from namespace '${NAMESPACE}'"
log_info "Namespace '${NAMESPACE}' preserved for future use"

echo ""

# Remove ArgoCD CRDs if requested
if [ "$DELETE_CRDS" = true ]; then
    log_info "Deleting ArgoCD CRDs (--delete-crds specified)..."
    oc_cmd get crd -o name | grep argoproj.io | \
        while read -r resource; do
            [ -n "$resource" ] && oc_cmd delete "$resource" --wait=false 2>/dev/null || true
        done
    log_success "ArgoCD CRDs deletion initiated (may take time to complete)"
else
    log_info "Keeping ArgoCD CRDs (default - for future reinstall)"
fi

echo ""
echo "============================================================"
echo "✅ Complete ArgoCD Cleanup Finished!"
echo "============================================================"
echo ""

# Final verification
log_info "Final verification..."
if oc_cmd get namespace "${NAMESPACE}" &> /dev/null; then
    log_success "Namespace '${NAMESPACE}' preserved"
    # Check if any ArgoCD resources remain
    REMAINING_APPS=$(oc_cmd -n "${NAMESPACE}" get applications --no-headers 2>/dev/null | wc -l | tr -d ' ')
    REMAINING_PODS=$(oc_cmd -n "${NAMESPACE}" get pods --no-headers 2>/dev/null | wc -l | tr -d ' ')
    if [ "$REMAINING_APPS" -eq 0 ] && [ "$REMAINING_PODS" -eq 0 ]; then
        log_success "All ArgoCD resources cleaned up"
    else
        log_warning "Some resources may still be terminating (${REMAINING_APPS} apps, ${REMAINING_PODS} pods)"
    fi
else
    log_error "Namespace '${NAMESPACE}' was unexpectedly deleted"
fi

echo ""
echo "Summary:"
if [ -n "$SPOKE_CLUSTERS" ]; then
echo "  ✓ Removed ${SPOKE_COUNT} spoke cluster(s)"
fi
echo "  ✓ Deleted all ArgoCD applications"
echo "  ✓ Uninstalled ArgoCD from hub"
echo "  ✓ Cleaned up all resources in namespace '${NAMESPACE}'"
echo "  ✓ Preserved namespace '${NAMESPACE}' for future use"
if [ "$DELETE_CRDS" = true ]; then
echo "  ✓ Deleted ArgoCD CRDs"
else
echo "  ✓ Kept ArgoCD CRDs for future reinstall"
fi
echo ""

log_success "Cleanup complete!"
echo ""
echo "To reinstall ArgoCD:"
if [ -n "$HUB_CONTEXT" ]; then
    echo "  ${SCRIPT_DIR}/argocd-install.sh --context ${HUB_CONTEXT}"
else
    echo "  ${SCRIPT_DIR}/argocd-install.sh"
fi
echo ""

# Made with Bob