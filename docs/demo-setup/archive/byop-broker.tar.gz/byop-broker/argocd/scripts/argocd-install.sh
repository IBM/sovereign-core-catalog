#!/bin/bash
#
# ArgoCD Namespace-Only Installation Script
# This script installs only namespace-scoped ArgoCD resources
# Requires cluster-scoped resources to be pre-installed by cluster admin
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE=""  # Will be set to current namespace if not specified
INSECURE=false
CONTEXT=""
DRY_RUN=false
IMAGE_REPOSITORY=""  # Custom image repository (e.g., my-registry.example.com/argocd)

# Build oc command with context if specified
oc_cmd() {
    if [ -n "$CONTEXT" ]; then
        oc --context="${CONTEXT}" "$@"
    else
        oc "$@"
    fi
}

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Install ArgoCD namespace-scoped resources only.
Requires cluster-scoped resources (CRDs, ClusterRoles) to be pre-installed by cluster admin.

Options:
  --context CONTEXT             Kubernetes context (optional; uses current context if omitted)
  --namespace NAMESPACE         ArgoCD namespace (required)
  --image-repository REPOSITORY Custom image repository to replace default registries
                                (e.g., my-registry.example.com)
  --insecure                    Disable TLS verification (not recommended for production)
  --dry-run                     Show what would be done without making changes
  -h, --help                    Show this help message

Prerequisites:
  Cluster admin must first run:
    ./argocd-install-cluster-prereqs.sh --namespace NAMESPACE

Examples:
  # Dry run to see what would be installed
  $0 --namespace sccat-byop-5 --dry-run

  # Install namespace-scoped resources
  $0 --namespace sccat-byop-5

  # Install with specific context
  $0 --context my-cluster --namespace argocd

  # Install with custom image repository (e.g., air-gapped environment)
  $0 --namespace argocd --image-repository my-registry.example.com

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --context)
            CONTEXT="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --image-repository)
            IMAGE_REPOSITORY="$2"
            shift 2
            ;;
        --insecure)
            INSECURE=true
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Determine actual context
if [ -n "$CONTEXT" ]; then
    ACTUAL_CONTEXT="$CONTEXT"
    CONTEXT_SOURCE="specified via --context"
else
    ACTUAL_CONTEXT=$(kubectl config current-context 2>/dev/null || echo "unknown")
    CONTEXT_SOURCE="using current context"
fi

# Namespace is required
if [ -z "$NAMESPACE" ]; then
    log_error "Namespace is required"
    echo ""
    echo "Specify a namespace explicitly:"
    echo "  $0 --namespace YOUR_NAMESPACE"
    exit 1
fi

echo "============================================================"
echo "ArgoCD Namespace-Only Installation"
echo "============================================================"
echo ""
echo "⚠️  KUBERNETES CONTEXT: ${ACTUAL_CONTEXT}"
echo "    (${CONTEXT_SOURCE})"
echo ""
echo "Configuration:"
echo "  Namespace:        ${NAMESPACE}"
if [ -n "$IMAGE_REPOSITORY" ]; then
echo "  Image Repository: ${IMAGE_REPOSITORY} (replacing default registries)"
else
echo "  Image Repository: quay.io, ghcr.io, public.ecr.aws (default)"
fi
echo "  Insecure:         ${INSECURE}"
echo "  Dry Run:          ${DRY_RUN}"
echo ""

if [ "$DRY_RUN" = true ]; then
    log_info "DRY RUN MODE - No changes will be made"
    echo ""
fi

# Check prerequisites
log_info "Checking prerequisites..."

# Check oc
if ! command -v oc &> /dev/null; then
    log_error "oc is not installed"
    exit 1
fi
log_success "oc is installed"

# Check cluster connectivity
if ! oc_cmd whoami &> /dev/null; then
    log_error "Cannot connect to cluster"
    exit 1
fi
log_success "Cluster is accessible"

# Note: We cannot verify CRDs and ClusterRoles exist because namespace admins
# typically don't have permission to list cluster-scoped resources in locked-down environments.
# We trust that the cluster admin has run the prerequisite scripts.
log_info "Assuming cluster prerequisites are installed (cluster admin responsibility)"
log_info "If installation fails, ask cluster admin to run:"
log_info "  cd admin/"
log_info "  ./argocd-install-cluster-resources.sh"
log_info "  ./argocd-configure-namespace.sh --namespace ${NAMESPACE}"
echo ""
log_success "All prerequisites met"
echo ""

# Determine manifest path - use local manifest file
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANIFEST_SOURCE="${SCRIPT_DIR}/manifests/namespace-install.yaml"

if [ ! -f "${MANIFEST_SOURCE}" ]; then
    log_error "Manifest file not found: ${MANIFEST_SOURCE}"
    log_info "Expected location: argocd/scripts/manifests/namespace-install.yaml"
    exit 1
fi

if [ "$DRY_RUN" = true ]; then
    echo "============================================================"
    echo "DRY RUN - Installation Steps"
    echo "============================================================"
    echo ""
    echo "The following namespace-scoped resources would be installed:"
    echo ""
    echo "1. Create namespace '${NAMESPACE}' (if not exists)"
    echo "2. ServiceAccounts"
    echo "3. Roles and RoleBindings"
    echo "4. ConfigMaps"
    echo "5. Secrets (with generated passwords)"
    echo "6. Services"
    echo "7. Deployments and StatefulSets"
    echo "8. NetworkPolicies"
    echo "9. OpenShift Route (if on OpenShift)"
    echo ""
    log_success "Dry run complete - no changes made"
    exit 0
fi

echo ""
echo "============================================================"
echo "Step 1: Creating namespace"
echo "============================================================"
echo ""

log_info "Checking namespace '${NAMESPACE}'..."
if oc_cmd get namespace "${NAMESPACE}" &> /dev/null; then
    log_success "Namespace '${NAMESPACE}' already exists"
else
    log_info "Creating namespace '${NAMESPACE}'..."
    if oc_cmd create namespace "${NAMESPACE}"; then
        log_success "Namespace '${NAMESPACE}' created"
    else
        log_error "Failed to create namespace '${NAMESPACE}'"
        exit 1
    fi
fi

echo ""
echo "============================================================"
echo "Step 2: Installing namespace-scoped resources"
echo "============================================================"
echo ""

log_info "Using local ArgoCD manifest: ${MANIFEST_SOURCE}"

# Create a unique temporary file for the manifest
MANIFEST_FILE=$(mktemp /tmp/argocd-namespace-install.XXXXXX.yaml)

# Copy the local manifest to temp location for modification
if ! cp "${MANIFEST_SOURCE}" "${MANIFEST_FILE}"; then
    log_error "Failed to copy manifest file"
    rm -f "${MANIFEST_FILE}"
    exit 1
fi
log_success "Manifest loaded to: ${MANIFEST_FILE}"

# Replace image repository if custom repository specified
if [ -n "$IMAGE_REPOSITORY" ]; then
    log_info "Replacing image repositories with: ${IMAGE_REPOSITORY}"
    
    # Create a backup
    cp "${MANIFEST_FILE}" "${MANIFEST_FILE}.bak"
    
    # Replace all image repositories with custom repository
    # This handles: quay.io/argoproj/argocd, ghcr.io/dexidp/dex, public.ecr.aws/docker/library/redis
    sed -i.tmp \
        -e "s|quay\.io/argoproj/argocd:|${IMAGE_REPOSITORY}/argocd:|g" \
        -e "s|ghcr\.io/dexidp/dex:|${IMAGE_REPOSITORY}/dex:|g" \
        -e "s|public\.ecr\.aws/docker/library/redis:|${IMAGE_REPOSITORY}/redis:|g" \
        "${MANIFEST_FILE}"
    
    rm -f "${MANIFEST_FILE}.tmp"
    
    # Verify replacement was successful
    if grep -q "${IMAGE_REPOSITORY}" "${MANIFEST_FILE}"; then
        log_success "Image repositories replaced successfully"
        
        # Show all unique images that will be used
        log_info "Images that will be used:"
        grep "image:" "${MANIFEST_FILE}" | sed 's/.*image: //' | sort -u | sed 's/^/  /'
    else
        log_error "Failed to replace image repositories"
        log_info "Restoring original manifest..."
        mv "${MANIFEST_FILE}.bak" "${MANIFEST_FILE}"
        exit 1
    fi
    
    rm -f "${MANIFEST_FILE}.bak"
else
    log_info "Using default image repositories (quay.io, ghcr.io, public.ecr.aws)"
fi

log_info "Applying namespace-scoped resources..."
log_info "Skipping cluster-scoped resources (CRDs, ClusterRoles, ClusterRoleBindings)"

# Apply only namespace-scoped resources
# Filter out cluster-scoped resources using kubectl apply with --prune-allowlist
if oc_cmd apply -n "${NAMESPACE}" -f "${MANIFEST_FILE}" 2>&1 | grep -v "Forbidden\|forbidden"; then
    log_success "Namespace-scoped resources applied"
else
    log_warning "Some resources may have failed (cluster-scoped resources are expected to fail)"
fi

# Clean up manifest file
rm -f "${MANIFEST_FILE}"

echo ""
echo "============================================================"
echo "Step 3: Populating ArgoCD secrets"
echo "============================================================"
echo ""

# Generate random passwords and tokens
REDIS_PASSWORD=$(openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64)
SERVER_SECRET=$(openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64)

log_info "Creating/updating argocd-redis secret..."
oc_cmd create secret generic argocd-redis \
    --from-literal=auth="${REDIS_PASSWORD}" \
    -n "${NAMESPACE}" \
    --dry-run=client -o yaml | oc_cmd apply -f - || {
    log_error "Failed to create Redis secret"
    exit 1
}
log_success "Redis secret ready"

log_info "Creating/updating argocd-secret..."
oc_cmd create secret generic argocd-secret \
    --from-literal=server.secretkey="${SERVER_SECRET}" \
    -n "${NAMESPACE}" \
    --dry-run=client -o yaml | oc_cmd apply -f - || {
    log_error "Failed to create argocd-secret"
    exit 1
}
log_success "ArgoCD secret ready"

log_info "Waiting for ArgoCD to create argocd-initial-admin-secret..."
INITIAL_ADMIN_SECRET_READY=false
for _ in {1..60}; do
    if oc_cmd get secret argocd-initial-admin-secret -n "${NAMESPACE}" &> /dev/null; then
        INITIAL_ADMIN_SECRET_READY=true
        break
    fi
    sleep 2
done

if [ "${INITIAL_ADMIN_SECRET_READY}" = true ]; then
    log_success "Initial admin secret created by ArgoCD"
else
    log_warning "argocd-initial-admin-secret was not created yet"
    log_info "ArgoCD may still be starting; retrieve the password later once the secret exists"
fi

echo ""
echo "============================================================"
echo "Step 4: Applying OpenShift-specific fixes"
echo "============================================================"
echo ""

# Check if we're on OpenShift
IS_OPENSHIFT=false
if command -v oc &> /dev/null; then
    if oc_cmd api-resources | grep -q "securitycontextconstraints"; then
        IS_OPENSHIFT=true
    fi
fi

if [ "$IS_OPENSHIFT" = true ]; then
    log_info "OpenShift detected - applying Redis deployment fixes..."
    
    # Wait for deployment to be created
    log_info "Waiting for Redis deployment to be created..."
    for _ in {1..30}; do
        if oc_cmd get deployment argocd-redis -n "${NAMESPACE}" &> /dev/null; then
            break
        fi
        sleep 2
    done
    
    # Remove seccomp profiles from Redis deployment
    log_info "Removing seccomp profiles from Redis deployment..."
    
    cat > /tmp/redis-openshift-fix.json << 'EOF'
[
  {
    "op": "remove",
    "path": "/spec/template/spec/securityContext/seccompProfile"
  },
  {
    "op": "remove",
    "path": "/spec/template/spec/securityContext/runAsUser"
  },
  {
    "op": "remove",
    "path": "/spec/template/spec/securityContext/runAsNonRoot"
  },
  {
    "op": "remove",
    "path": "/spec/template/spec/initContainers/0/securityContext/seccompProfile"
  }
]
EOF
    
    if oc_cmd patch deployment argocd-redis -n "${NAMESPACE}" \
        --type=json --patch-file /tmp/redis-openshift-fix.json 2>/dev/null; then
        log_success "Redis deployment patched for OpenShift compatibility"
    else
        log_warning "Could not patch Redis deployment"
    fi
    
    rm -f /tmp/redis-openshift-fix.json
    
    log_info "Note: Cluster admin should have granted anyuid SCC to service accounts"
    log_info "If Redis fails to start, ask cluster admin to run:"
    echo "  oc adm policy add-scc-to-user anyuid -z argocd-redis -n ${NAMESPACE}"
    echo "  oc adm policy add-scc-to-user anyuid -z argocd-application-controller -n ${NAMESPACE}"
else
    log_info "Not running on OpenShift - skipping OpenShift-specific fixes"
fi

echo ""
echo "============================================================"
echo "Step 5: Adding resource limits (for ResourceQuota compliance)"
echo "============================================================"
echo ""

# Check if namespace has a ResourceQuota
HAS_QUOTA=false
if oc_cmd get resourcequota -n "${NAMESPACE}" &> /dev/null; then
    QUOTA_COUNT=$(oc_cmd get resourcequota -n "${NAMESPACE}" --no-headers 2>/dev/null | wc -l)
    if [ "$QUOTA_COUNT" -gt 0 ]; then
        HAS_QUOTA=true
        log_info "ResourceQuota detected in namespace - adding resource limits to deployments"
    fi
fi

if [ "$HAS_QUOTA" = true ]; then
    # Define resource limits for each component
    # These are conservative values that should work in most environments
    # Adjust based on your cluster's ResourceQuota limits
    
    log_info "Patching argocd-server deployment..."
    oc_cmd set resources deployment/argocd-server -n "${NAMESPACE}" \
        --requests=cpu=100m,memory=128Mi \
        --limits=cpu=500m,memory=512Mi || log_warning "Failed to patch argocd-server"
    
    log_info "Patching argocd-repo-server deployment..."
    oc_cmd set resources deployment/argocd-repo-server -n "${NAMESPACE}" \
        --requests=cpu=100m,memory=128Mi \
        --limits=cpu=500m,memory=512Mi || log_warning "Failed to patch argocd-repo-server"
    
    log_info "Patching argocd-redis deployment..."
    oc_cmd set resources deployment/argocd-redis -n "${NAMESPACE}" \
        --requests=cpu=50m,memory=64Mi \
        --limits=cpu=200m,memory=256Mi || log_warning "Failed to patch argocd-redis"
    
    log_info "Patching argocd-dex-server deployment..."
    oc_cmd set resources deployment/argocd-dex-server -n "${NAMESPACE}" \
        --requests=cpu=50m,memory=64Mi \
        --limits=cpu=200m,memory=256Mi || log_warning "Failed to patch argocd-dex-server"
    
    log_info "Patching argocd-applicationset-controller deployment..."
    oc_cmd set resources deployment/argocd-applicationset-controller -n "${NAMESPACE}" \
        --requests=cpu=50m,memory=64Mi \
        --limits=cpu=200m,memory=256Mi || log_warning "Failed to patch argocd-applicationset-controller"
    
    log_info "Patching argocd-notifications-controller deployment..."
    oc_cmd set resources deployment/argocd-notifications-controller -n "${NAMESPACE}" \
        --requests=cpu=50m,memory=64Mi \
        --limits=cpu=200m,memory=256Mi || log_warning "Failed to patch argocd-notifications-controller"
    
    log_info "Patching argocd-application-controller statefulset..."
    oc_cmd set resources statefulset/argocd-application-controller -n "${NAMESPACE}" \
        --requests=cpu=50m,memory=64Mi \
        --limits=cpu=1,memory=2Gi || log_warning "Failed to patch argocd-application-controller"
    
    log_success "Resource limits added to all ArgoCD components"
    
    # Calculate total resources (before disabling optional components)
    log_info "Total resource allocation (all components):"
    echo "  Requests: ~450m CPU, ~576Mi memory"
    echo "  Limits:   ~2100m CPU, ~3904Mi memory"
    echo ""
    log_info "Note: Dex and Notifications will be disabled in Step 6"
    echo "  Final allocation: ~350m CPU, ~448Mi memory requests"
else
    log_info "No ResourceQuota detected - skipping resource limit configuration"
fi

echo ""
echo "============================================================"
echo "Step 6: Disabling Optional Components"
echo "============================================================"
echo ""

log_info "Disabling optional ArgoCD components to reduce resource usage..."

# Disable Dex server (SSO/OIDC - not needed if using local auth)
log_info "Scaling down argocd-dex-server to 0 replicas..."
oc_cmd scale deployment argocd-dex-server -n "${NAMESPACE}" --replicas=0 || {
    log_warning "Failed to scale down argocd-dex-server"
}
log_success "Dex server disabled (SSO/OIDC not available)"

# Disable notifications controller (not needed if not using notifications)
log_info "Scaling down argocd-notifications-controller to 0 replicas..."
oc_cmd scale deployment argocd-notifications-controller -n "${NAMESPACE}" --replicas=0 || {
    log_warning "Failed to scale down argocd-notifications-controller"
}
log_success "Notifications controller disabled"

log_info "Resource savings: ~100m CPU / ~128Mi memory requests freed"

# Calculate final resources (after disabling optional components)
log_info "Final resource allocation (active components only):"
echo "  Requests: ~350m CPU, ~448Mi memory"
echo "  Limits:   ~1900m CPU, ~3648Mi memory"
echo ""
log_info "Note: Application-controller uses 2Gi limit for improved performance"

echo ""
echo "============================================================"
echo "Step 7: Waiting for ArgoCD to be ready"
echo "============================================================"
echo ""

log_info "Waiting for ArgoCD server deployment..."
if oc_cmd wait --for=condition=available --timeout=300s \
    deployment/argocd-server -n "${NAMESPACE}"; then
    log_success "ArgoCD server is ready"
else
    log_warning "Timeout waiting for ArgoCD server"
    log_info "Checking pod status..."
    oc_cmd get pods -n "${NAMESPACE}"
fi

echo ""
log_info "Waiting for ArgoCD application controller..."
if oc_cmd wait --for=condition=ready --timeout=300s \
    pod -l app.kubernetes.io/name=argocd-application-controller -n "${NAMESPACE}"; then
    log_success "ArgoCD application controller is ready"
else
    log_warning "Timeout waiting for application controller"
fi

echo ""
log_info "Waiting for ArgoCD repo server..."
if oc_cmd wait --for=condition=ready --timeout=300s \
    pod -l app.kubernetes.io/name=argocd-repo-server -n "${NAMESPACE}"; then
    log_success "ArgoCD repo server is ready"
else
    log_warning "Timeout waiting for repo server"
fi

echo ""
echo "============================================================"
echo "Step 8: Configuring ArgoCD"
echo "============================================================"
echo ""

# Configure insecure mode if requested
if [ "$INSECURE" = true ]; then
    log_warning "Configuring insecure mode (not recommended for production)"
    oc_cmd patch configmap argocd-cmd-params-cm -n "${NAMESPACE}" \
        --type merge -p '{"data":{"server.insecure":"true"}}' || {
        log_warning "Failed to configure insecure mode"
    }
    
    log_info "Restarting ArgoCD server..."
    oc_cmd rollout restart deployment argocd-server -n "${NAMESPACE}"
    oc_cmd rollout status deployment argocd-server -n "${NAMESPACE}" --timeout=120s || {
        log_warning "Timeout waiting for server restart"
    }
fi

# Configure sync interval
log_info "Configuring sync interval to 30 seconds..."
oc_cmd patch configmap argocd-cm -n "${NAMESPACE}" \
    --type merge -p '{"data":{"timeout.reconciliation":"30s"}}' || {
    log_warning "Failed to configure sync interval"
}

log_info "Restarting ArgoCD application controller..."
oc_cmd rollout restart statefulset argocd-application-controller -n "${NAMESPACE}"
oc_cmd rollout status statefulset argocd-application-controller -n "${NAMESPACE}" --timeout=120s || {
    log_warning "Timeout waiting for controller restart"
}

echo ""
echo "============================================================"
echo "Step 8: Creating OpenShift Route"
echo "============================================================"
echo ""

if [ "$IS_OPENSHIFT" = true ]; then
    log_info "Creating OpenShift Route for ArgoCD server..."
    
    if oc_cmd apply -f - <<EOF
apiVersion: route.openshift.io/v1
kind: Route
metadata:
  name: argocd-server
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/name: argocd-server
    app.kubernetes.io/part-of: argocd
    app.kubernetes.io/component: server
spec:
  to:
    kind: Service
    name: argocd-server
    weight: 100
  port:
    targetPort: https
  tls:
    termination: passthrough
    insecureEdgeTerminationPolicy: Redirect
  wildcardPolicy: None
EOF
    then
        log_success "Route created successfully"
        
        ROUTE_HOST=$(oc_cmd get route argocd-server -n "${NAMESPACE}" \
            -o jsonpath='{.spec.host}' 2>/dev/null || echo "")
        
        if [ -n "$ROUTE_HOST" ]; then
            log_success "ArgoCD is accessible at: https://${ROUTE_HOST}"
        fi
    else
        log_warning "Failed to create route"
    fi
else
    log_info "Not running on OpenShift - skipping route creation"
fi

echo ""
echo "============================================================"
echo "✅ ArgoCD Installation Complete!"
echo "============================================================"
echo ""

# Get admin password if ArgoCD has created the initial secret
log_info "Retrieving admin password..."
ADMIN_PASSWORD=$(oc_cmd -n "${NAMESPACE}" get secret argocd-initial-admin-secret \
    -o jsonpath="{.data.password}" 2>/dev/null | base64 -d 2>/dev/null || echo "")

if [ -n "$ADMIN_PASSWORD" ]; then
    echo "ArgoCD Credentials:"
    echo "  Username: admin"
    echo "  Password: ${ADMIN_PASSWORD}"
    echo ""
else
    log_warning "Could not retrieve admin password from argocd-initial-admin-secret"
    echo "ArgoCD may not have created the initial secret yet."
    echo "To get the password manually once available:"
    echo "  oc -n ${NAMESPACE} get secret argocd-initial-admin-secret -o jsonpath='{.data.password}' | base64 -d"
    echo ""
fi

echo "Access ArgoCD UI:"

if [ "$IS_OPENSHIFT" = true ]; then
    ROUTE_HOST=$(oc_cmd get route argocd-server -n "${NAMESPACE}" \
        -o jsonpath='{.spec.host}' 2>/dev/null || echo "")
    
    if [ -n "$ROUTE_HOST" ]; then
        echo "  Via OpenShift Route:"
        echo "     https://${ROUTE_HOST}"
        echo ""
    fi
fi

echo "  Via port forward:"
echo "     oc port-forward svc/argocd-server -n ${NAMESPACE} 8080:443"
echo ""
if [ "$INSECURE" = true ]; then
    echo "     Then open: http://localhost:8080"
else
    echo "     Then open: https://localhost:8080"
fi
echo ""

echo "Verify Installation:"
echo "  oc get pods -n ${NAMESPACE}"
echo "  oc get applications -n ${NAMESPACE}"
echo ""

echo "Next Steps:"
echo "  1. Configure Git repository access"
echo "  2. Deploy applications via ArgoCD"
echo ""

log_success "Installation complete!"

# Made with Bob