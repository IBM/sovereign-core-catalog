#!/usr/bin/env bash
# argocd-configure-sops.sh
# Configure ArgoCD with SOPS support for encrypted secret management
#
# Usage:
#   ./argocd-configure-sops.sh [--age-key-file PATH] [--namespace NAMESPACE]
#
# Prerequisites:
#   - ArgoCD installed in cluster
#   - age key pair generated
#   - Custom ArgoCD image built and pushed to registry

set -euo pipefail

# Default values
NAMESPACE="${ARGOCD_NAMESPACE:-argocd}"
AGE_KEY_FILE="${SOPS_AGE_KEY_FILE:-$HOME/.config/sops/age/keys.txt}"
ARGOCD_IMAGE="quay.io/your-org/argocd-sops:v2.9.3"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

usage() {
    cat << EOF
Usage: $0 [OPTIONS]

Configure ArgoCD with SOPS support for encrypted secret management.

OPTIONS:
    --age-key-file PATH    Path to age private key file (default: ~/.config/sops/age/keys.txt)
    --namespace NAMESPACE  ArgoCD namespace (default: argocd)
    --image IMAGE          Custom ArgoCD image (default: quay.io/your-org/argocd-sops:v2.9.3)
    --help                 Show this help message

EXAMPLES:
    # Use default settings
    $0

    # Specify custom age key file
    $0 --age-key-file /path/to/keys.txt

    # Use different namespace
    $0 --namespace argocd-system

EOF
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --age-key-file)
            AGE_KEY_FILE="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --image)
            ARGOCD_IMAGE="$2"
            shift 2
            ;;
        --help)
            usage
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

# Validate prerequisites
log_info "Validating prerequisites..."

if [[ ! -f "$AGE_KEY_FILE" ]]; then
    log_error "Age key file not found: $AGE_KEY_FILE"
    log_info "Generate one with: age-keygen -o $AGE_KEY_FILE"
    exit 1
fi

if ! kubectl get namespace "$NAMESPACE" &>/dev/null; then
    log_error "Namespace not found: $NAMESPACE"
    log_info "Create it with: kubectl create namespace $NAMESPACE"
    exit 1
fi

if ! kubectl get deployment argocd-repo-server -n "$NAMESPACE" &>/dev/null; then
    log_error "ArgoCD repo-server deployment not found in namespace: $NAMESPACE"
    log_info "Install ArgoCD first: kubectl apply -n $NAMESPACE -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml"
    exit 1
fi

log_info "Prerequisites validated ✓"

# Step 1: Create age key secret
log_info "Creating age key secret..."

if kubectl get secret sops-age-key -n "$NAMESPACE" &>/dev/null; then
    log_warn "Secret 'sops-age-key' already exists. Deleting and recreating..."
    kubectl delete secret sops-age-key -n "$NAMESPACE"
fi

kubectl create secret generic sops-age-key \
    --from-file=keys.txt="$AGE_KEY_FILE" \
    --namespace "$NAMESPACE"

log_info "Age key secret created ✓"

# Step 2: Patch argocd-repo-server deployment
log_info "Patching argocd-repo-server deployment..."

kubectl patch deployment argocd-repo-server -n "$NAMESPACE" --type='json' -p='[
  {
    "op": "replace",
    "path": "/spec/template/spec/containers/0/image",
    "value": "'"$ARGOCD_IMAGE"'"
  },
  {
    "op": "add",
    "path": "/spec/template/spec/containers/0/env/-",
    "value": {
      "name": "SOPS_AGE_KEY_FILE",
      "value": "/sops/age/keys.txt"
    }
  },
  {
    "op": "add",
    "path": "/spec/template/spec/containers/0/env/-",
    "value": {
      "name": "HELM_PLUGINS",
      "value": "/home/argocd/.local/share/helm/plugins"
    }
  },
  {
    "op": "add",
    "path": "/spec/template/spec/containers/0/env/-",
    "value": {
      "name": "HELM_SECRETS_BACKEND",
      "value": "sops"
    }
  },
  {
    "op": "add",
    "path": "/spec/template/spec/containers/0/env/-",
    "value": {
      "name": "HELM_SECRETS_DRIVER",
      "value": "age"
    }
  },
  {
    "op": "add",
    "path": "/spec/template/spec/containers/0/volumeMounts/-",
    "value": {
      "name": "sops-age-key",
      "mountPath": "/sops/age",
      "readOnly": true
    }
  },
  {
    "op": "add",
    "path": "/spec/template/spec/volumes/-",
    "value": {
      "name": "sops-age-key",
      "secret": {
        "secretName": "sops-age-key",
        "defaultMode": 256
      }
    }
  }
]'

log_info "Deployment patched ✓"

# Step 3: Wait for rollout
log_info "Waiting for rollout to complete..."
kubectl rollout status deployment/argocd-repo-server -n "$NAMESPACE" --timeout=5m

log_info "Rollout complete ✓"

# Step 4: Verify installation
log_info "Verifying SOPS installation..."

POD=$(kubectl get pod -n "$NAMESPACE" -l app.kubernetes.io/name=argocd-repo-server -o jsonpath='{.items[0].metadata.name}')

if kubectl exec -n "$NAMESPACE" "$POD" -- sops --version &>/dev/null; then
    SOPS_VERSION=$(kubectl exec -n "$NAMESPACE" "$POD" -- sops --version 2>&1 | head -1)
    log_info "SOPS installed: $SOPS_VERSION ✓"
else
    log_error "SOPS not found in pod"
    exit 1
fi

if kubectl exec -n "$NAMESPACE" "$POD" -- age --version &>/dev/null; then
    AGE_VERSION=$(kubectl exec -n "$NAMESPACE" "$POD" -- age --version 2>&1)
    log_info "age installed: $AGE_VERSION ✓"
else
    log_error "age not found in pod"
    exit 1
fi

if kubectl exec -n "$NAMESPACE" "$POD" -- helm secrets --version &>/dev/null; then
    log_info "helm-secrets installed ✓"
else
    log_error "helm-secrets not found in pod"
    exit 1
fi

# Step 5: Verify age key mount
log_info "Verifying age key mount..."

if kubectl exec -n "$NAMESPACE" "$POD" -- test -f /sops/age/keys.txt; then
    log_info "Age key mounted successfully ✓"
else
    log_error "Age key not found at /sops/age/keys.txt"
    exit 1
fi

# Success
log_info ""
log_info "========================================="
log_info "ArgoCD SOPS configuration complete! ✓"
log_info "========================================="
log_info ""
log_info "Next steps:"
log_info "1. Commit encrypted secrets to your GitOps repository"
log_info "2. Create ArgoCD Application with helm-secrets enabled"
log_info "3. Verify secrets are decrypted during deployment"
log_info ""
log_info "Example Application:"
log_info "  apiVersion: argoproj.io/v1alpha1"
log_info "  kind: Application"
log_info "  spec:"
log_info "    source:"
log_info "      helm:"
log_info "        valueFiles:"
log_info "          - secrets://secrets.yaml  # helm-secrets will decrypt"
log_info ""

# Made with Bob
