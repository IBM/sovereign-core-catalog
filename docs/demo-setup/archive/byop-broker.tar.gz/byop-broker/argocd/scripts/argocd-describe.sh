#!/bin/bash
#
# ArgoCD Information Script
# Displays useful ArgoCD information including credentials, access commands, and topology
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Default values
NAMESPACE=""
CONTEXT=""

# Build oc command with context if specified
oc_cmd() {
    if [ -n "$CONTEXT" ]; then
        oc --context="${CONTEXT}" "$@"
    else
        oc "$@"
    fi
}

oc_example_cmd() {
    local args="$1"
    if [ -n "$CONTEXT" ]; then
        echo "oc --context=${CONTEXT} ${args}"
    else
        echo "oc ${args}"
    fi
}

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

section_header() {
    echo ""
    echo -e "${BOLD}${CYAN}============================================================${NC}"
    echo -e "${BOLD}${CYAN}$1${NC}"
    echo -e "${BOLD}${CYAN}============================================================${NC}"
    echo ""
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Display ArgoCD information including credentials, access commands, and topology.

Options:
  --context CONTEXT       Kubernetes context (optional; uses current context if omitted)
  --namespace NAMESPACE   ArgoCD namespace (required)
  -h, --help             Show this help message

Examples:
  # Show ArgoCD info for hub cluster
  $0 --context hub --namespace argocd

  # Show info for custom namespace
  $0 --context my-cluster --namespace gitops

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --context)
            CONTEXT="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Check if oc is available
if ! command -v oc &> /dev/null; then
    log_error "oc is not installed"
    exit 1
fi

# Namespace is required
if [ -z "$NAMESPACE" ]; then
    log_error "Namespace is required"
    echo ""
    echo "Specify a namespace explicitly:"
    echo "  $0 --namespace YOUR_NAMESPACE"
    exit 1
fi

# Check if context exists
if [ -n "$CONTEXT" ]; then
    if ! oc config get-contexts "${CONTEXT}" &> /dev/null; then
        log_error "Kubernetes context '${CONTEXT}' not found"
        exit 1
    fi
else
    log_info "Using current oc context"
fi

# Check if ArgoCD namespace exists
if ! oc_cmd get namespace "${NAMESPACE}" &> /dev/null; then
    log_error "ArgoCD namespace '${NAMESPACE}' not found"
    echo ""
    echo "ArgoCD may not be installed. Run:"
    if [ -n "$CONTEXT" ]; then
        echo "  ./argocd-install.sh --context ${CONTEXT}"
    else
        echo "  ./argocd-install.sh"
    fi
    exit 1
fi

# Determine and display the actual Kubernetes context being used
if [ -n "$CONTEXT" ]; then
    ACTUAL_CONTEXT="$CONTEXT"
    CONTEXT_SOURCE="specified via --context"
else
    ACTUAL_CONTEXT=$(kubectl config current-context 2>/dev/null || echo "unknown")
    CONTEXT_SOURCE="using current context"
fi

echo ""
echo -e "${BOLD}${GREEN}============================================================${NC}"
echo -e "${BOLD}${GREEN}ArgoCD Information${NC}"
echo -e "${BOLD}${GREEN}============================================================${NC}"
echo ""
echo -e "${YELLOW}⚠️  KUBERNETES CONTEXT: ${ACTUAL_CONTEXT}${NC}"
echo -e "${YELLOW}    (${CONTEXT_SOURCE})${NC}"
echo ""
if [ -n "$CONTEXT" ]; then
    echo "Context:   ${CONTEXT}"
else
    echo "Context:   current oc context"
fi
echo "Namespace: ${NAMESPACE}"
echo ""

# ============================================================
# Section 1: Credentials
# ============================================================
section_header "Credentials"

# Get admin password if ArgoCD has created the initial secret
ADMIN_PASSWORD=$(oc_cmd -n "${NAMESPACE}" get secret argocd-initial-admin-secret \
    -o jsonpath="{.data.password}" 2>/dev/null | base64 -d 2>/dev/null || echo "")

if [ -n "$ADMIN_PASSWORD" ]; then
    echo -e "${BOLD}Username:${NC} admin"
    echo -e "${BOLD}Password:${NC} ${ADMIN_PASSWORD}"
else
    log_warning "Could not retrieve admin password from argocd-initial-admin-secret"
    echo ""
    echo "ArgoCD may not have created the initial secret yet."
    echo "To get the password manually once available:"
    echo "  $(oc_example_cmd "-n ${NAMESPACE} get secret argocd-initial-admin-secret -o jsonpath='{.data.password}' | base64 -d")"
fi

# ============================================================
# Section 2: Access Commands
# ============================================================
section_header "Access Commands"

# Check if route exists (OpenShift)
ROUTE_HOST=$(oc_cmd -n "${NAMESPACE}" get route argocd-server \
    -o jsonpath="{.spec.host}" 2>/dev/null || echo "")

if [ -n "$ROUTE_HOST" ]; then
    echo -e "${BOLD}OpenShift Route:${NC}"
    echo "  https://${ROUTE_HOST}"
    echo ""
    echo -e "${BOLD}Login via CLI:${NC}"
    echo "  argocd login ${ROUTE_HOST} --username admin --password '${ADMIN_PASSWORD}'"
    echo ""
fi

echo -e "${BOLD}Port Forward (Local Access):${NC}"
echo "  $(oc_example_cmd "port-forward svc/argocd-server -n ${NAMESPACE} 8080:443")"
echo ""
echo -e "${BOLD}Access via Port Forward:${NC}"
echo "  https://localhost:8080"
echo ""
echo -e "${BOLD}Login via CLI (Port Forward):${NC}"
echo "  argocd login localhost:8080 --username admin --password '${ADMIN_PASSWORD}' --insecure"

# ============================================================
# Section 3: ArgoCD Topology
# ============================================================
section_header "ArgoCD Topology"

# Get ArgoCD server info
echo -e "${BOLD}ArgoCD Server:${NC}"
SERVER_POD=$(oc_cmd -n "${NAMESPACE}" get pods \
    -l app.kubernetes.io/name=argocd-server -o name 2>/dev/null | head -1)
if [ -n "$SERVER_POD" ]; then
    SERVER_STATUS=$(oc_cmd -n "${NAMESPACE}" get "${SERVER_POD}" \
        -o jsonpath="{.status.phase}" 2>/dev/null || echo "Unknown")
    echo "  Pod:    ${SERVER_POD##*/}"
    echo "  Status: ${SERVER_STATUS}"
else
    echo "  Status: Not found"
fi

# Get service info
SERVER_SERVICE=$(oc_cmd -n "${NAMESPACE}" get svc argocd-server \
    -o jsonpath="{.spec.clusterIP}:{.spec.ports[0].port}" 2>/dev/null || echo "Not found")
echo "  Service: ${SERVER_SERVICE}"

if [ -n "$ROUTE_HOST" ]; then
    echo "  Route:   https://${ROUTE_HOST}"
fi

echo ""

# Get registered clusters
echo -e "${BOLD}Registered Clusters:${NC}"
CLUSTERS=$(oc_cmd -n "${NAMESPACE}" get secrets \
    -l argocd.argoproj.io/secret-type=cluster -o name 2>/dev/null || echo "")

if [ -n "$CLUSTERS" ]; then
    CLUSTER_COUNT=0
    while IFS= read -r secret; do
        if [ -n "$secret" ]; then
            CLUSTER_COUNT=$((CLUSTER_COUNT + 1))
            CLUSTER_NAME=$(oc_cmd -n "${NAMESPACE}" get "${secret}" \
                -o jsonpath="{.metadata.labels.argocd\.argoproj\.io/secret-name}" 2>/dev/null || echo "unknown")
            CLUSTER_SERVER=$(oc_cmd -n "${NAMESPACE}" get "${secret}" \
                -o jsonpath="{.data.server}" 2>/dev/null | base64 -d 2>/dev/null || echo "unknown")
            
            echo "  ${CLUSTER_COUNT}. ${CLUSTER_NAME}"
            echo "     Server: ${CLUSTER_SERVER}"
        fi
    done <<< "$CLUSTERS"
    
    if [ $CLUSTER_COUNT -eq 0 ]; then
        echo "  (none - only managing local cluster)"
    fi
else
    echo "  (none - only managing local cluster)"
fi

echo ""

# Get applications
echo -e "${BOLD}Applications:${NC}"
APPS=$(oc_cmd -n "${NAMESPACE}" get applications \
    -o custom-columns=NAME:.metadata.name,SYNC:.status.sync.status,HEALTH:.status.health.status,DEST:.spec.destination.name \
    --no-headers 2>/dev/null || echo "")

if [ -n "$APPS" ]; then
    APP_COUNT=$(echo "$APPS" | wc -l | tr -d ' ')
    echo "  Total: ${APP_COUNT}"
    echo ""
    echo "  NAME                           SYNC        HEALTH      DESTINATION"
    echo "  ────────────────────────────── ─────────── ─────────── ───────────────"
    echo "$APPS" | while IFS= read -r line; do
        if [ -n "$line" ]; then
            echo "  $line"
        fi
    done
else
    echo "  (no applications deployed)"
fi

# ============================================================
# Section 4: Component Status
# ============================================================
section_header "Component Status"

# Get all ArgoCD pods
echo -e "${BOLD}Pods:${NC}"
oc_cmd -n "${NAMESPACE}" get pods \
    -l app.kubernetes.io/part-of=argocd \
    -o custom-columns=NAME:.metadata.name,READY:.status.containerStatuses[0].ready,STATUS:.status.phase,RESTARTS:.status.containerStatuses[0].restartCount,AGE:.metadata.creationTimestamp \
    --no-headers 2>/dev/null | while IFS= read -r line; do
    if [ -n "$line" ]; then
        echo "  $line"
    fi
done || echo "  (no pods found)"

echo ""

# Get services
echo -e "${BOLD}Services:${NC}"
oc_cmd -n "${NAMESPACE}" get svc \
    -l app.kubernetes.io/part-of=argocd \
    -o custom-columns=NAME:.metadata.name,TYPE:.spec.type,CLUSTER-IP:.spec.clusterIP,PORT:.spec.ports[0].port \
    --no-headers 2>/dev/null | while IFS= read -r line; do
    if [ -n "$line" ]; then
        echo "  $line"
    fi
done || echo "  (no services found)"

# ============================================================
# Section 5: Quick Actions
# ============================================================
section_header "Quick Actions"

echo "View logs:"
echo "  $(oc_example_cmd "logs -n ${NAMESPACE} -l app.kubernetes.io/name=argocd-server")"
echo "  $(oc_example_cmd "logs -n ${NAMESPACE} -l app.kubernetes.io/name=argocd-application-controller")"
echo ""
echo "Restart components:"
echo "  $(oc_example_cmd "rollout restart -n ${NAMESPACE} deployment/argocd-server")"
echo "  $(oc_example_cmd "rollout restart -n ${NAMESPACE} statefulset/argocd-application-controller")"
echo ""
echo "Access ArgoCD CLI:"
echo "  argocd app list --server localhost:8080 --insecure"
echo "  argocd app sync <app-name> --server localhost:8080 --insecure"
echo ""

log_success "ArgoCD information displayed successfully"
echo ""

# Made with Bob
