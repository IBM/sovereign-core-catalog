# ArgoCD Installation Scripts

Scripts for installing and managing ArgoCD in various environments.

## Quick Start

### Standard Installation (Cluster Admin)
```bash
cd admin/
./argocd-install.sh --namespace argocd
```

### Locked-Down Environment (Two-Phase)
```bash
# Phase 1: Cluster admin (run once per cluster)
cd admin/
./argocd-install-cluster-resources.sh
./argocd-configure-namespace.sh --namespace your-namespace

# Phase 2: Namespace admin
cd ..
./argocd-install.sh --namespace your-namespace
```

## Scripts Overview

| Script | Requires Cluster Admin | Run Frequency | Purpose |
|--------|----------------------|---------------|---------|
| `admin/argocd-install.sh` | ✅ Yes | Once per namespace | Full installation (single-step) |
| `admin/argocd-install-cluster-resources.sh` | ✅ Yes | **Once per cluster** | Install CRDs & ClusterRoles |
| `admin/argocd-configure-namespace.sh` | ✅ Yes | Once per namespace | Configure namespace RBAC & SCC |
| `admin/argocd-add-spoke.sh` | ✅ Yes | Per spoke cluster | Register spoke cluster with hub |
| `admin/argocd-remove-spoke.sh` | ✅ Yes | As needed | Unregister spoke cluster |
| `argocd-install.sh` | ❌ No | Once per namespace | Install namespace resources |
| `argocd-uninstall.sh` | ❌ No | As needed | Remove ArgoCD |
| `argocd-configure-repo.sh` | ❌ No | As needed | Configure Git repository |

## Installation Scenarios

### Multi-Namespace Setup (Recommended)
```bash
# Step 1: Install cluster resources (ONCE)
cd admin/
./argocd-install-cluster-resources.sh

# Step 2: Configure each namespace
./argocd-configure-namespace.sh --namespace team-a
./argocd-configure-namespace.sh --namespace team-b

# Step 3: Each namespace admin installs ArgoCD
cd ..
./argocd-install.sh --namespace team-a
./argocd-install.sh --namespace team-b
```

### Single Namespace (Quick Setup)
```bash
cd admin/
./argocd-install.sh --namespace argocd
```

### Locked-Down Environment with ResourceQuota
```bash
# Phase 1: Cluster admin
cd admin/
./argocd-install-cluster-resources.sh
./argocd-configure-namespace.sh --namespace sccat-byop-5

# Phase 2: Namespace admin
cd ..
./argocd-install.sh --namespace sccat-byop-5
```

## Common Options

All scripts support:
- `--dry-run` - Preview changes without executing
- `--help` - Show detailed usage information
- `--namespace NAMESPACE` - Target namespace (defaults to current)
- `--version VERSION` - ArgoCD version (defaults to stable)

## Accessing ArgoCD

```bash
# Get admin password after ArgoCD creates the initial admin secret
oc -n your-namespace get secret argocd-initial-admin-secret \
  -o jsonpath='{.data.password}' | base64 -d

# Note:
# - The initial admin secret is created by ArgoCD during bootstrap
# - It may not exist immediately after installation
# - If the command fails, wait briefly and try again

# Get route URL (OpenShift)
oc get route argocd-server -n your-namespace

# Or use port forwarding
oc port-forward svc/argocd-server -n your-namespace 8080:443
```

## Troubleshooting

### Permission Denied Errors
**Solution**: Use two-phase installation (cluster admin runs `admin/` scripts first)

### Pods Not Starting (OpenShift)
**Solution**: Handled automatically by `argocd-configure-namespace.sh` (grants anyuid SCC)

### ResourceQuota Violations
**Solution**: Handled automatically by `argocd-install.sh` (detects quota and adds resource limits)

### CRDs Not Found
**Solution**: Cluster admin must run `admin/argocd-install-cluster-resources.sh`

## Documentation

- **[Complete Installation Guide](../../docs/argocd-installation-guide.md)** - Detailed guide with all scenarios
- **[Admin Scripts README](admin/README.md)** - Cluster-admin script details

---

*Last Updated: 2026-04-27*