#!/bin/bash
# Create pull secret for services in ArgoCD-managed clusters
#
# This script validates registry credentials and creates a Kubernetes
# docker-registry secret that can be used by ArgoCD applications.
#
# Usage:
#   ./argocd-create-pull-secret.sh --cluster CLUSTER --registry REGISTRY \
#     --username USER --password PASS [OPTIONS]

set -euo pipefail

# Default values
CLUSTER_NAME=""
REGISTRY=""
USERNAME=""
PASSWORD=""
NAMESPACE=""
SECRET_NAME="services-pull-secret"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${GREEN}✓${NC} $*"
}

log_error() {
    echo -e "${RED}✗${NC} $*" >&2
}

log_warn() {
    echo -e "${YELLOW}⚠${NC} $*"
}

# Show usage information
show_usage() {
    cat << EOF
Usage: $0 --cluster CLUSTER --registry REGISTRY --username USER --password PASS [OPTIONS]

Create a pull secret for services in ArgoCD-managed clusters.

Required arguments:
  --cluster CLUSTER      Target cluster name (kubectl context)
  --registry REGISTRY    Registry server (e.g., quay.io, docker.io)
  --username USER        Registry username
  --password PASS        Registry password or token

Optional arguments:
  --namespace NS         Kubernetes namespace (default: argocd)
  --secret-name NAME     Secret name (default: services-pull-secret)
  -h, --help             Show this help message

Examples:
  # Create pull secret for Quay.io
  $0 --cluster k3s-cluster-2 --registry quay.io \\
    --username myuser --password mytoken

  # Create pull secret in custom namespace
  $0 --cluster prod-cluster --registry docker.io \\
    --username myuser --password mypass --namespace default

EOF
}

# Parse command-line arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --cluster)
                CLUSTER_NAME="$2"
                shift 2
                ;;
            --registry)
                REGISTRY="$2"
                shift 2
                ;;
            --username)
                USERNAME="$2"
                shift 2
                ;;
            --password)
                PASSWORD="$2"
                shift 2
                ;;
            --namespace)
                NAMESPACE="$2"
                shift 2
                ;;
            --secret-name)
                SECRET_NAME="$2"
                shift 2
                ;;
            -h|--help)
                show_usage
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                echo ""
                show_usage
                exit 1
                ;;
        esac
    done
}

# Validate required arguments

# Get current namespace if not specified
if [ -z "$NAMESPACE" ]; then
    if [ -n "$HUB_CONTEXT" ]; then
        NAMESPACE=$(oc --context="${HUB_CONTEXT}" project -q 2>/dev/null || oc --context="${HUB_CONTEXT}" config view --minify -o jsonpath='{..namespace}' 2>/dev/null)
    elif [ -n "$CONTEXT" ]; then
        NAMESPACE=$(oc --context="${CONTEXT}" project -q 2>/dev/null || oc --context="${CONTEXT}" config view --minify -o jsonpath='{..namespace}' 2>/dev/null)
    else
        NAMESPACE=$(oc project -q 2>/dev/null || oc config view --minify -o jsonpath='{..namespace}' 2>/dev/null)
    fi
    
    # If still empty, default to 'argocd'
    if [ -z "$NAMESPACE" ]; then
        NAMESPACE="argocd"
        log_info "No namespace specified and no current namespace set, defaulting to 'argocd'"
    else
        log_info "Using current namespace: ${NAMESPACE}"
    fi
fi
validate_args() {
    local missing_args=()

    if [[ -z "$CLUSTER_NAME" ]]; then
        missing_args+=("--cluster")
    fi
    if [[ -z "$REGISTRY" ]]; then
        missing_args+=("--registry")
    fi
    if [[ -z "$USERNAME" ]]; then
        missing_args+=("--username")
    fi
    if [[ -z "$PASSWORD" ]]; then
        missing_args+=("--password")
    fi

    if [[ ${#missing_args[@]} -gt 0 ]]; then
        log_error "Missing required arguments: ${missing_args[*]}"
        echo ""
        show_usage
        exit 1
    fi
}

# Validate registry credentials
validate_credentials() {
    echo "Step 1: Validating credentials for $REGISTRY..."
    
    # First, try Basic Auth
    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" \
        -u "$USERNAME:$PASSWORD" \
        "https://$REGISTRY/v2/" 2>/dev/null || echo "000")

    case "$http_code" in
        200)
            log_info "Credentials validated successfully (Basic Auth)"
            return 0
            ;;
        401)
            # Basic Auth failed, try Bearer token flow
            log_info "Basic Auth failed, trying Bearer token authentication..."
            
            # Get WWW-Authenticate header to extract realm and service
            local auth_header
            auth_header=$(curl -s -I "https://$REGISTRY/v2/" 2>/dev/null | grep -i "www-authenticate:" || echo "")
            
            if [[ "$auth_header" =~ Bearer.*realm=\"([^\"]+)\".*service=\"([^\"]+)\" ]]; then
                local realm="${BASH_REMATCH[1]}"
                local service="${BASH_REMATCH[2]}"
                
                log_info "Requesting Bearer token from $realm..."
                
                # Request Bearer token
                local token_response
                token_response=$(curl -s -u "$USERNAME:$PASSWORD" \
                    "${realm}?service=${service}&scope=repository:user/test:pull" 2>/dev/null || echo "")
                
                # Check if we got a token
                if echo "$token_response" | grep -q '"token"'; then
                    log_info "Credentials validated successfully (Bearer Token)"
                    return 0
                else
                    log_error "Invalid credentials for $REGISTRY"
                    log_warn "Bearer token request failed"
                    return 1
                fi
            else
                log_error "Invalid credentials for $REGISTRY"
                log_warn "Registry requires authentication but method is unclear"
                return 1
            fi
            ;;
        000)
            log_error "Cannot connect to $REGISTRY"
            log_warn "Check network connectivity and registry URL"
            return 1
            ;;
        *)
            log_error "Unexpected response from registry (HTTP $http_code)"
            return 1
            ;;
    esac
}

# Switch to target cluster context
switch_cluster_context() {
    echo ""
    echo "Step 2: Switching to cluster context..."
    
    if ! kubectl config use-context "$CLUSTER_NAME" &>/dev/null; then
        log_error "Cluster context '$CLUSTER_NAME' not found"
        echo ""
        echo "Available contexts:"
        kubectl config get-contexts -o name
        return 1
    fi
    
    log_info "Using cluster context: $CLUSTER_NAME"
    return 0
}

# Ensure namespace exists
ensure_namespace() {
    echo ""
    echo "Step 3: Ensuring namespace exists..."
    
    if kubectl get namespace "$NAMESPACE" &>/dev/null; then
        log_info "Namespace already exists: $NAMESPACE"
    else
        if kubectl create namespace "$NAMESPACE" &>/dev/null; then
            log_info "Created namespace: $NAMESPACE"
        else
            log_error "Failed to create namespace: $NAMESPACE"
            return 1
        fi
    fi
    
    return 0
}

# Create pull secret
create_pull_secret() {
    echo ""
    echo "Step 4: Creating pull secret..."
    
    if kubectl create secret docker-registry "$SECRET_NAME" \
        --docker-server="$REGISTRY" \
        --docker-username="$USERNAME" \
        --docker-password="$PASSWORD" \
        --namespace="$NAMESPACE" \
        --dry-run=client -o yaml | kubectl apply -f - &>/dev/null; then
        log_info "Pull secret created: $SECRET_NAME"
        return 0
    else
        log_error "Failed to create pull secret"
        return 1
    fi
}

# Display usage instructions
show_success_message() {
    cat << EOF

==========================================
Pull secret created successfully!
==========================================

Cluster:   $CLUSTER_NAME
Registry:  $REGISTRY
Namespace: $NAMESPACE
Secret:    $SECRET_NAME

To use this secret in your ArgoCD applications, add to your manifests:

  spec:
    template:
      spec:
        imagePullSecrets:
        - name: $SECRET_NAME

Or for Helm charts, add to values.yaml:

  imagePullSecrets:
    - name: $SECRET_NAME

EOF
}

# Main execution
main() {
    parse_args "$@"
    validate_args

    echo "Creating pull secret for ArgoCD-managed cluster"
    echo "Cluster:   $CLUSTER_NAME"
    echo "Registry:  $REGISTRY"
    echo "Namespace: $NAMESPACE"
    echo "Secret:    $SECRET_NAME"
    echo ""

    # Execute steps
    if ! validate_credentials; then
        exit 1
    fi

    if ! switch_cluster_context; then
        exit 1
    fi

    if ! ensure_namespace; then
        exit 1
    fi

    if ! create_pull_secret; then
        exit 1
    fi

    show_success_message
}

# Run main function
main "$@"

# Made with Bob
