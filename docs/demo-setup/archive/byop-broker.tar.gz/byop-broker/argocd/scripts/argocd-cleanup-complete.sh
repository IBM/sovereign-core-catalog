#!/bin/bash
#
# Complete ArgoCD Cleanup Script
# Orchestrates the full cleanup process in the correct order:
# 1. Remove spoke clusters from hub
# 2. Uninstall ArgoCD from hub
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE=""  # Required parameter
HUB_CONTEXT=""
AUTO_YES=false
KEEP_CRDS=false

build_oc_cmd() {
    local -a cmd=("oc")
    if [ -n "$HUB_CONTEXT" ]; then
        cmd+=("--context=${HUB_CONTEXT}")
    fi
    printf '%s\n' "${cmd[*]}"
}

OC_CMD="$(build_oc_cmd)"

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Complete ArgoCD cleanup - removes spoke clusters and uninstalls ArgoCD from hub.

This script performs cleanup in the correct order:
  1. Removes all spoke cluster registrations from hub
  2. Deletes applications on spoke clusters
  3. Uninstalls ArgoCD from hub cluster

Options:
  --hub-context CONTEXT   Hub cluster context (optional; uses current context if omitted)
  --namespace NAMESPACE   ArgoCD namespace (required)
  --keep-crds            Keep ArgoCD CRDs (don't delete)
  -y, --yes              Skip all confirmation prompts
  -h, --help             Show this help message

Examples:
  # Complete cleanup with prompts
  $0 --hub-context k3s-cluster-1 --namespace argocd

  # Auto-confirm all steps
  $0 --hub-context k3s-cluster-1 --namespace argocd -y

  # Keep CRDs for future reinstall
  $0 --hub-context k3s-cluster-1 --namespace argocd --keep-crds

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --hub-context)
            HUB_CONTEXT="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --keep-crds)
            KEEP_CRDS=true
            shift
            ;;
        -y|--yes)
            AUTO_YES=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Namespace is required
if [ -z "$NAMESPACE" ]; then
    log_error "Namespace is required"
    echo ""
    echo "Specify a namespace explicitly:"
    echo "  $0 --namespace YOUR_NAMESPACE"
    exit 1
fi

echo "============================================================"
echo "Complete ArgoCD Cleanup"
echo "============================================================"
echo ""
echo "Configuration:"
if [ -n "$HUB_CONTEXT" ]; then
    echo "  Hub Context:  ${HUB_CONTEXT}"
else
    echo "  Hub Context:  current oc context"
fi
echo "  Namespace:    ${NAMESPACE}"
echo "  Keep CRDs:    ${KEEP_CRDS}"
echo "  Auto-confirm: ${AUTO_YES}"
echo ""

# Check prerequisites
log_info "Checking prerequisites..."

# Check oc
if ! command -v oc &> /dev/null; then
    log_error "oc is not installed"
    exit 1
fi
log_success "oc is installed"

# Check hub context
if [ -n "$HUB_CONTEXT" ]; then
    if ! oc config get-contexts "${HUB_CONTEXT}" &> /dev/null; then
        log_error "Hub context '${HUB_CONTEXT}' not found"
        exit 1
    fi
    log_success "Hub context '${HUB_CONTEXT}' found"
else
    log_info "Using current oc context"
fi

# Check if ArgoCD namespace exists
if ! ${OC_CMD} get namespace "${NAMESPACE}" &> /dev/null; then
    log_warning "ArgoCD namespace '${NAMESPACE}' not found"
    echo ""
    echo "ArgoCD may not be installed or already removed."
    exit 0
fi
log_success "ArgoCD namespace exists"

echo ""
log_success "All prerequisites met"
echo ""

# Show cleanup plan
echo "============================================================"
echo "Cleanup Plan"
echo "============================================================"
echo ""

# Find spoke clusters
log_info "Discovering spoke clusters..."
SPOKE_CLUSTERS=$(${OC_CMD} -n "${NAMESPACE}" get secrets \
    -l argocd.argoproj.io/secret-type=cluster -o name 2>/dev/null | \
    grep -v "in-cluster" | sed 's/secret\/cluster-//' || true)

if [ -n "$SPOKE_CLUSTERS" ]; then
    SPOKE_COUNT=$(echo "$SPOKE_CLUSTERS" | wc -l | tr -d ' ')
    echo "Found ${SPOKE_COUNT} spoke cluster(s):"
    # shellcheck disable=SC2001  # sed is appropriate for adding prefix to each line
    echo "$SPOKE_CLUSTERS" | sed 's/^/  - /'
    echo ""
else
    echo "No spoke clusters registered"
    echo ""
fi

# Count applications
APP_COUNT=$(${OC_CMD} -n "${NAMESPACE}" get applications --no-headers 2>/dev/null | wc -l | tr -d ' ')
echo "Found ${APP_COUNT} ArgoCD application(s)"
echo ""

echo "This will perform the following actions:"
echo ""
echo "Phase 1: Spoke Cluster Cleanup"
if [ -n "$SPOKE_CLUSTERS" ]; then
echo "  ✓ Remove ${SPOKE_COUNT} spoke cluster registration(s)"
echo "  ✓ Delete applications on spoke clusters"
else
echo "  ✓ No spoke clusters to remove"
fi
echo ""
echo "Phase 2: Hub ArgoCD Cleanup"
echo "  ✓ Delete all ${APP_COUNT} ArgoCD application(s)"
echo "  ✓ Remove all ArgoCD resources"
echo "  ✓ Delete ArgoCD namespace: ${NAMESPACE}"
if [ "$KEEP_CRDS" = false ]; then
echo "  ✓ Remove ArgoCD CRDs"
else
echo "  ✓ Keep ArgoCD CRDs (--keep-crds specified)"
fi
echo ""

# Confirm cleanup
if [ "$AUTO_YES" = false ]; then
    echo "⚠️  WARNING: This is a destructive operation!"
    echo ""
    read -p "Are you sure you want to proceed with complete ArgoCD cleanup? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log_info "Cleanup cancelled"
        exit 0
    fi
    echo ""
fi

echo "============================================================"
echo "Phase 1: Spoke Cluster Cleanup"
echo "============================================================"
echo ""

if [ -n "$SPOKE_CLUSTERS" ]; then
    for SPOKE in $SPOKE_CLUSTERS; do
        echo "----------------------------------------"
        echo "Removing spoke cluster: ${SPOKE}"
        echo "----------------------------------------"
        echo ""
        
        # Build command
        CMD="${SCRIPT_DIR}/argocd-remove-spoke.sh --hub-context ${HUB_CONTEXT} --spoke-context ${SPOKE}"
        if [ "$AUTO_YES" = true ]; then
            CMD="${CMD} -y"
        fi
        
        # Execute removal
        if bash -c "$CMD"; then
            log_success "Spoke cluster '${SPOKE}' removed"
        else
            log_warning "Failed to remove spoke cluster '${SPOKE}'"
            echo ""
            read -p "Continue with remaining cleanup? (y/N): " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                log_error "Cleanup aborted"
                exit 1
            fi
        fi
        echo ""
    done
    
    log_success "All spoke clusters removed"
else
    log_info "No spoke clusters to remove"
fi

echo ""
echo "============================================================"
echo "Phase 2: Hub ArgoCD Cleanup"
echo "============================================================"
echo ""

# Build uninstall command
UNINSTALL_CMD="${SCRIPT_DIR}/argocd-uninstall.sh"
if [ -n "$HUB_CONTEXT" ]; then
    UNINSTALL_CMD="${UNINSTALL_CMD} --context ${HUB_CONTEXT}"
fi
if [ "$AUTO_YES" = true ]; then
    UNINSTALL_CMD="${UNINSTALL_CMD} -y"
fi
if [ "$KEEP_CRDS" = true ]; then
    UNINSTALL_CMD="${UNINSTALL_CMD} --keep-crds"
fi

# Execute uninstall
if bash -c "$UNINSTALL_CMD"; then
    log_success "ArgoCD uninstalled from hub"
else
    log_error "Failed to uninstall ArgoCD from hub"
    exit 1
fi

echo ""
echo "============================================================"
echo "✅ Complete ArgoCD Cleanup Finished!"
echo "============================================================"
echo ""

# Final verification
log_info "Final verification..."
if ${OC_CMD} get namespace "${NAMESPACE}" &> /dev/null; then
    log_warning "ArgoCD namespace still exists"
else
    log_success "ArgoCD namespace removed"
fi

echo ""
echo "Summary:"
if [ -n "$SPOKE_CLUSTERS" ]; then
echo "  ✓ Removed ${SPOKE_COUNT} spoke cluster(s)"
fi
echo "  ✓ Deleted all ArgoCD applications"
echo "  ✓ Uninstalled ArgoCD from hub"
echo "  ✓ Removed ArgoCD namespace"
if [ "$KEEP_CRDS" = false ]; then
echo "  ✓ Removed ArgoCD CRDs"
else
echo "  ✓ Kept ArgoCD CRDs for future use"
fi
echo ""

log_success "Cleanup complete!"
echo ""
echo "To reinstall ArgoCD:"
if [ -n "$HUB_CONTEXT" ]; then
    echo "  ${SCRIPT_DIR}/install-argocd.sh --context ${HUB_CONTEXT}"
else
    echo "  ${SCRIPT_DIR}/install-argocd.sh"
fi
echo ""

# Made with Bob