#!/bin/bash
#
# Add Spoke Cluster to Hub ArgoCD
# Register a spoke cluster with hub ArgoCD for multi-cluster management
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE=""
HUB_CONTEXT=""
SPOKE_CONTEXT=""
SPOKE_NAME=""
DRY_RUN=false

# Build oc command with context if specified
hub_oc_cmd() {
    oc --context="${HUB_CONTEXT}" "$@"
}

spoke_oc_cmd() {
    oc --context="${SPOKE_CONTEXT}" "$@"
}

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Register a spoke cluster with hub ArgoCD for multi-cluster management.

Options:
  --hub-context CONTEXT    Hub cluster context (required)
  --spoke-context CONTEXT  Spoke cluster context (required)
  --spoke-name NAME        Friendly name for spoke (default: context name)
  --namespace NAMESPACE    ArgoCD namespace (required)
  --dry-run               Show what would be done without making changes
  -h, --help              Show this help message

Examples:
  # Dry run to see what would be configured
  $0 --hub-context hub-cluster --spoke-context spoke-cluster-1 --namespace argocd --dry-run

  # Add spoke cluster with default name
  $0 --hub-context hub-cluster --spoke-context spoke-cluster-1 --namespace argocd

  # Add spoke cluster with custom name
  $0 --hub-context hub-cluster \\
     --spoke-context prod-east-1 \\
     --spoke-name "Production East" \\
     --namespace argocd

  # Add spoke in custom namespace
  $0 --hub-context hub-cluster \\
     --spoke-context spoke-cluster-1 \\
     --namespace gitops

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --hub-context)
            HUB_CONTEXT="$2"
            shift 2
            ;;
        --spoke-context)
            SPOKE_CONTEXT="$2"
            shift 2
            ;;
        --spoke-name)
            SPOKE_NAME="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Validate required arguments
if [ -z "$HUB_CONTEXT" ]; then
    log_error "Hub cluster context is required"
    echo ""
    show_help
    exit 1
fi

if [ -z "$SPOKE_CONTEXT" ]; then
    log_error "Spoke cluster context is required"
    echo ""
    show_help
    exit 1
fi

# Use spoke context as name if not provided
if [ -z "$SPOKE_NAME" ]; then
    SPOKE_NAME="$SPOKE_CONTEXT"
fi

# Determine and display the actual Kubernetes contexts being used
ACTUAL_HUB_CONTEXT="$HUB_CONTEXT"
ACTUAL_SPOKE_CONTEXT="$SPOKE_CONTEXT"

echo "============================================================"
echo "Add Spoke Cluster to Hub ArgoCD"
echo "============================================================"
echo ""
echo "⚠️  HUB KUBERNETES CONTEXT: ${ACTUAL_HUB_CONTEXT}"
echo "    (specified via --hub-context)"
echo ""
echo "⚠️  SPOKE KUBERNETES CONTEXT: ${ACTUAL_SPOKE_CONTEXT}"
echo "    (specified via --spoke-context)"
echo ""
echo "Configuration:"
echo "  Hub Context:    ${HUB_CONTEXT}"
echo "  Spoke Context:  ${SPOKE_CONTEXT}"
echo "  Spoke Name:     ${SPOKE_NAME}"
echo "  Namespace:      ${NAMESPACE}"
echo "  Dry Run:        ${DRY_RUN}"
echo ""

if [ "$DRY_RUN" = true ]; then
    log_info "DRY RUN MODE - No changes will be made"
    echo ""
fi

# Check prerequisites
log_info "Checking prerequisites..."

# Check oc
if ! command -v oc &> /dev/null; then
    log_error "oc is not installed"
    exit 1
fi
log_success "oc is installed"

# Check hub context exists
if ! oc config get-contexts "${HUB_CONTEXT}" &> /dev/null; then
    log_error "Hub context '${HUB_CONTEXT}' not found"
    echo ""
    echo "Available contexts:"
    oc config get-contexts
    exit 1
fi
log_success "Hub context '${HUB_CONTEXT}' found"

# Check spoke context exists
if ! oc config get-contexts "${SPOKE_CONTEXT}" &> /dev/null; then
    log_error "Spoke context '${SPOKE_CONTEXT}' not found"
    echo ""
    echo "Available contexts:"
    oc config get-contexts
    exit 1
fi
log_success "Spoke context '${SPOKE_CONTEXT}' found"

# Check hub cluster is accessible
if ! hub_oc_cmd whoami &> /dev/null; then
    log_error "Cannot connect to hub cluster '${HUB_CONTEXT}'"
    exit 1
fi
log_success "Hub cluster '${HUB_CONTEXT}' is accessible"

# Check spoke cluster is accessible
if ! spoke_oc_cmd whoami &> /dev/null; then
    log_error "Cannot connect to spoke cluster '${SPOKE_CONTEXT}'"
    exit 1
fi
log_success "Spoke cluster '${SPOKE_CONTEXT}' is accessible"

# Check ArgoCD is installed on hub
if ! hub_oc_cmd get namespace "${NAMESPACE}" &> /dev/null; then
    log_error "ArgoCD namespace '${NAMESPACE}' not found on hub cluster"
    echo ""
    echo "Please install ArgoCD on hub cluster first:"
    echo "  ./argocd-install.sh --context ${HUB_CONTEXT}"
    exit 1
fi
log_success "ArgoCD is installed on hub cluster"

echo ""
log_success "All prerequisites met"
echo ""

if [ "$DRY_RUN" = true ]; then
    echo "============================================================"
    echo "DRY RUN - Registration Steps"
    echo "============================================================"
    echo ""
    echo "The following actions would be performed:"
    echo ""
    echo "Step 1: Get spoke cluster details"
    echo "        - Extract server URL"
    echo "        - Extract CA certificate"
    echo ""
    echo "Step 2: Create service account on spoke cluster"
    echo "        - Create namespace '${NAMESPACE}'"
    echo "        - Create 'argocd-manager' service account"
    echo "        - Create service account token secret"
    echo "        - Create ClusterRole with full permissions"
    echo "        - Create ClusterRoleBinding"
    echo ""
    echo "Step 3: Register cluster with hub ArgoCD"
    echo "        - Extract service account token"
    echo "        - Create cluster secret on hub"
    echo "        - Label secret for ArgoCD"
    echo ""
    log_success "Dry run complete - no changes made"
    exit 0
fi

echo ""
echo "============================================================"
echo "Step 1: Getting spoke cluster details"
echo "============================================================"
echo ""

log_info "Extracting spoke cluster server URL..."
SPOKE_SERVER=$(spoke_oc_cmd config view --minify -o jsonpath='{.clusters[0].cluster.server}')
log_success "Server URL: ${SPOKE_SERVER}"

log_info "Extracting spoke cluster CA certificate..."
SPOKE_CA=$(spoke_oc_cmd config view --minify --raw -o jsonpath='{.clusters[0].cluster.certificate-authority-data}')
if [ -z "$SPOKE_CA" ]; then
    log_warning "No CA certificate found in kubeconfig"
    log_info "Attempting to extract from cluster..."
    SPOKE_CA=$(spoke_oc_cmd get configmap kube-root-ca.crt -n kube-system -o jsonpath='{.data.ca\.crt}' 2>/dev/null | base64 | tr -d '\n' || echo "")
fi

if [ -z "$SPOKE_CA" ]; then
    log_warning "Could not extract CA certificate"
    log_info "Will use insecure connection (not recommended for production)"
    USE_INSECURE=true
else
    log_success "CA certificate extracted"
    USE_INSECURE=false
fi

echo ""
echo "============================================================"
echo "Step 2: Creating service account on spoke cluster"
echo "============================================================"
echo ""

log_info "Creating ArgoCD namespace on spoke cluster..."
spoke_oc_cmd create namespace "${NAMESPACE}" --dry-run=client -o yaml | \
    spoke_oc_cmd apply -f -
log_success "Namespace created"

log_info "Creating ArgoCD manager service account..."
cat <<EOF | spoke_oc_cmd apply -f -
apiVersion: v1
kind: ServiceAccount
metadata:
  name: argocd-manager
  namespace: ${NAMESPACE}
---
apiVersion: v1
kind: Secret
metadata:
  name: argocd-manager-token
  namespace: ${NAMESPACE}
  annotations:
    kubernetes.io/service-account.name: argocd-manager
type: kubernetes.io/service-account-token
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: argocd-manager-role
rules:
- apiGroups:
  - '*'
  resources:
  - '*'
  verbs:
  - '*'
- nonResourceURLs:
  - '*'
  verbs:
  - '*'
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: argocd-manager-role-binding
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: argocd-manager-role
subjects:
- kind: ServiceAccount
  name: argocd-manager
  namespace: ${NAMESPACE}
EOF
log_success "Service account created"

echo ""
echo "============================================================"
echo "Step 3: Retrieving service account token"
echo "============================================================"
echo ""

log_info "Waiting for service account token..."
MAX_RETRIES=30
RETRY_COUNT=0
TOKEN=""

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
    TOKEN=$(spoke_oc_cmd -n "${NAMESPACE}" get secret argocd-manager-token \
        -o jsonpath='{.data.token}' 2>/dev/null | base64 -d 2>/dev/null || echo "")
    
    if [ -n "$TOKEN" ]; then
        log_success "Token retrieved"
        break
    fi
    
    RETRY_COUNT=$((RETRY_COUNT + 1))
    log_info "Waiting for token... (attempt ${RETRY_COUNT}/${MAX_RETRIES})"
    sleep 2
done

if [ -z "$TOKEN" ]; then
    log_error "Failed to retrieve service account token"
    echo ""
    echo "Please check:"
    echo "  oc --context=${SPOKE_CONTEXT} -n ${NAMESPACE} get secret argocd-manager-token"
    exit 1
fi

echo ""
echo "============================================================"
echo "Step 4: Registering cluster with hub ArgoCD"
echo "============================================================"
echo ""

log_info "Creating cluster secret on hub..."

# Sanitize spoke name for secret name
SECRET_NAME="cluster-$(echo "${SPOKE_NAME}" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9-]/-/g')"

if [ "$USE_INSECURE" = true ]; then
    # Create secret with insecure connection
    cat <<EOF | hub_oc_cmd apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: ${SECRET_NAME}
  namespace: ${NAMESPACE}
  labels:
    argocd.argoproj.io/secret-type: cluster
type: Opaque
stringData:
  name: ${SPOKE_NAME}
  server: "${SPOKE_SERVER}"
  config: |
    {
      "bearerToken": "${TOKEN}",
      "tlsClientConfig": {
        "insecure": true
      }
    }
EOF
else
    # Create secret with CA certificate
    cat <<EOF | hub_oc_cmd apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: ${SECRET_NAME}
  namespace: ${NAMESPACE}
  labels:
    argocd.argoproj.io/secret-type: cluster
type: Opaque
stringData:
  name: ${SPOKE_NAME}
  server: "${SPOKE_SERVER}"
  config: |
    {
      "bearerToken": "${TOKEN}",
      "tlsClientConfig": {
        "insecure": false,
        "caData": "${SPOKE_CA}"
      }
    }
EOF
fi

log_success "Cluster secret created"

echo ""
echo "============================================================"
echo "Step 5: Verifying registration"
echo "============================================================"
echo ""

log_info "Waiting for ArgoCD to recognize the cluster..."
sleep 3

if hub_oc_cmd -n "${NAMESPACE}" get secret "${SECRET_NAME}" &>/dev/null; then
    log_success "Cluster secret exists"
else
    log_error "Cluster secret not found"
    exit 1
fi

# Try to list clusters via ArgoCD (if argocd CLI is available)
if command -v argocd &> /dev/null; then
    log_info "Listing clusters via ArgoCD CLI..."
    argocd cluster list --grpc-web 2>/dev/null || log_info "ArgoCD CLI not configured or not accessible"
fi

echo ""
echo "============================================================"
echo "✅ Spoke Cluster Registered Successfully!"
echo "============================================================"
echo ""
echo "Cluster Details:"
echo "  Name:          ${SPOKE_NAME}"
echo "  Context:       ${SPOKE_CONTEXT}"
echo "  Server:        ${SPOKE_SERVER}"
echo "  Secret Name:   ${SECRET_NAME}"
echo ""
echo "Verify Registration:"
echo "  # List all registered clusters"
echo "  oc --context=${HUB_CONTEXT} -n ${NAMESPACE} get secrets -l argocd.argoproj.io/secret-type=cluster"
echo ""
echo "  # View cluster secret"
echo "  oc --context=${HUB_CONTEXT} -n ${NAMESPACE} get secret ${SECRET_NAME} -o yaml"
echo ""
echo "Deploy Application to Spoke:"
echo "  Create an Application CR with destination.name set to '${SPOKE_NAME}'"
echo ""
echo "Example Application:"
cat << EOF
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: my-spoke-app
  namespace: ${NAMESPACE}
spec:
  project: default
  source:
    repoURL: <YOUR_REPO_URL>
    targetRevision: main
    path: apps/my-app
  destination:
    name: ${SPOKE_NAME}
    namespace: my-app
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
EOF
echo ""
log_success "Registration complete!"

# Made with Bob
