#!/usr/bin/env bash
# argocd-configure-sops-sidecar.sh
# Configure ArgoCD with SOPS support using sidecar approach (non-invasive)
#
# This script:
# 1. Creates sops-age-key secret in ArgoCD namespace
# 2. Patches argocd-repo-server with init container to install SOPS tools
# 3. Verifies SOPS/age/helm-secrets installation
#
# Usage:
#   ./argocd/scripts/argocd-configure-sops-sidecar.sh
#
# Prerequisites:
# - kubectl configured with access to cluster
# - ArgoCD installed in 'argocd' namespace
# - age private key at ~/.config/sops/age/keys.txt

set -euo pipefail

# Configuration
ARGOCD_NAMESPACE="${ARGOCD_NAMESPACE:-argocd}"
AGE_KEY_FILE="${AGE_KEY_FILE:-$HOME/.config/sops/age/keys.txt}"
SECRET_NAME="sops-age-key"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Helper functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check kubectl
    if ! command -v kubectl &> /dev/null; then
        log_error "kubectl not found. Please install kubectl."
        exit 1
    fi
    
    # Check ArgoCD namespace
    if ! kubectl get namespace "$ARGOCD_NAMESPACE" &> /dev/null; then
        log_error "ArgoCD namespace '$ARGOCD_NAMESPACE' not found."
        exit 1
    fi
    
    # Check age key file
    if [ ! -f "$AGE_KEY_FILE" ]; then
        log_error "Age private key not found at: $AGE_KEY_FILE"
        log_error "Generate one with: age-keygen -o $AGE_KEY_FILE"
        exit 1
    fi
    
    log_info "Prerequisites check passed!"
}

create_age_secret() {
    log_info "Creating age key secret in ArgoCD namespace..."
    
    # Check if secret already exists
    if kubectl get secret "$SECRET_NAME" -n "$ARGOCD_NAMESPACE" &> /dev/null; then
        log_warn "Secret '$SECRET_NAME' already exists. Deleting and recreating..."
        kubectl delete secret "$SECRET_NAME" -n "$ARGOCD_NAMESPACE"
    fi
    
    # Create secret from age key file
    kubectl create secret generic "$SECRET_NAME" \
        --from-file=keys.txt="$AGE_KEY_FILE" \
        -n "$ARGOCD_NAMESPACE"
    
    log_info "Secret created successfully!"
}

patch_repo_server() {
    log_info "Patching argocd-repo-server deployment..."
    
    # Apply the sidecar patch
    if kubectl patch deployment argocd-repo-server \
        -n "$ARGOCD_NAMESPACE" \
        --patch-file "$(dirname "$0")/../argocd-repo-server-sops-sidecar.yaml"; then
        log_info "Deployment patched successfully!"
    else
        log_error "Failed to patch deployment. Check the patch file."
        exit 1
    fi
    
    # Wait for rollout
    log_info "Waiting for deployment rollout..."
    kubectl rollout status deployment/argocd-repo-server -n "$ARGOCD_NAMESPACE" --timeout=5m
    
    log_info "Rollout complete!"
}

verify_installation() {
    log_info "Verifying SOPS installation..."
    
    # Get pod name
    POD_NAME=$(kubectl get pods -n "$ARGOCD_NAMESPACE" -l app.kubernetes.io/name=argocd-repo-server -o jsonpath='{.items[0].metadata.name}')
    
    if [ -z "$POD_NAME" ]; then
        log_error "Could not find argocd-repo-server pod"
        exit 1
    fi
    
    log_info "Testing in pod: $POD_NAME"
    
    # Check SOPS
    if kubectl exec -n "$ARGOCD_NAMESPACE" "$POD_NAME" -- /custom-tools/sops --version &> /dev/null; then
        SOPS_VERSION=$(kubectl exec -n "$ARGOCD_NAMESPACE" "$POD_NAME" -- /custom-tools/sops --version 2>&1 | head -n1)
        log_info "✓ SOPS installed: $SOPS_VERSION"
    else
        log_error "✗ SOPS not found"
        exit 1
    fi
    
    # Check age
    if kubectl exec -n "$ARGOCD_NAMESPACE" "$POD_NAME" -- /custom-tools/age --version &> /dev/null; then
        AGE_VERSION=$(kubectl exec -n "$ARGOCD_NAMESPACE" "$POD_NAME" -- /custom-tools/age --version 2>&1)
        log_info "✓ age installed: $AGE_VERSION"
    else
        log_error "✗ age not found"
        exit 1
    fi
    
    # Check helm-secrets
    if kubectl exec -n "$ARGOCD_NAMESPACE" "$POD_NAME" -- test -d /custom-tools/helm-plugins/helm-secrets; then
        log_info "✓ helm-secrets plugin installed"
    else
        log_error "✗ helm-secrets plugin not found"
        exit 1
    fi
    
    # Check age key file
    if kubectl exec -n "$ARGOCD_NAMESPACE" "$POD_NAME" -- test -f /sops/age/keys.txt; then
        log_info "✓ Age private key mounted"
    else
        log_error "✗ Age private key not found"
        exit 1
    fi
    
    log_info "All verifications passed!"
}

main() {
    log_info "Starting ArgoCD SOPS configuration (sidecar approach)..."
    echo
    
    check_prerequisites
    echo
    
    create_age_secret
    echo
    
    patch_repo_server
    echo
    
    verify_installation
    echo
    
    log_info "ArgoCD SOPS configuration complete!"
    log_info ""
    log_info "Next steps:"
    log_info "1. Encrypt secrets in your GitOps repo: sops -e -i secrets.yaml"
    log_info "2. Commit encrypted secrets to Git"
    log_info "3. Create ArgoCD Application pointing to your repo"
    log_info "4. ArgoCD will automatically decrypt secrets during deployment"
}

main "$@"

# Made with Bob
