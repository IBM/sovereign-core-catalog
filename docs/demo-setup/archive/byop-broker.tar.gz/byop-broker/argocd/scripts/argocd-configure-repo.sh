#!/bin/bash
#
# Configure ArgoCD Git Repository Access
# Supports both SSH and HTTPS authentication
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE=""  # Required parameter
CONTEXT=""
REPO_URL=""
SSH_KEY_PATH=""
TOKEN=""
REPO_NAME=""
DRY_RUN=false

# Build oc command with context if specified
oc_cmd() {
    if [ -n "$CONTEXT" ]; then
        oc --context="${CONTEXT}" "$@"
    else
        oc "$@"
    fi
}

verify_command_example() {
    local args="$1"
    if [ -n "$CONTEXT" ]; then
        echo "oc --context=${CONTEXT} ${args}"
    else
        echo "oc ${args}"
    fi
}

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Configure ArgoCD to access a Git repository.

Options:
  --context CONTEXT       Kubernetes context (optional; uses current context if omitted)
  --repo-url URL          Git repository URL (required)
                         Accepts SSH (git@host:org/repo.git) or HTTPS (https://host/org/repo.git)
  --ssh-key-path PATH     Path to SSH private key (for SSH authentication)
  --token TOKEN           Personal access token (for HTTPS authentication)
  --repo-name NAME        Repository name (default: derived from URL)
  --namespace NAMESPACE   ArgoCD namespace (required)
  --dry-run              Show what would be done without making changes
  -h, --help             Show this help message

Authentication:
  Provide EITHER --ssh-key-path OR --token (not both)
  
  SSH Authentication:
    - Provide --ssh-key-path with path to private key
    - URL can be SSH format (git@github.com:org/repo.git) or HTTPS format
    - HTTPS URLs will be automatically transformed to SSH format
  
  HTTPS Authentication:
    - Provide --token with personal access token
    - URL must be HTTPS format (https://github.com/org/repo.git)

Examples:
  # SSH authentication with SSH URL
  $0 --context my-cluster \\
     --namespace argocd \\
     --repo-url git@github.com:org/repo.git \\
     --ssh-key-path ~/.ssh/deploy_key

  # SSH authentication with HTTPS URL (auto-transformed to SSH)
  $0 --context my-cluster \\
     --namespace argocd \\
     --repo-url https://github.com/org/repo.git \\
     --ssh-key-path ~/.ssh/deploy_key

  # HTTPS authentication with token
  $0 --context my-cluster \\
     --repo-url https://github.com/org/repo.git \\
     --token ghp_xxxxxxxxxxxx

  # Dry run to see what would be configured
  $0 --context my-cluster \\
     --repo-url https://github.com/org/repo.git \\
     --ssh-key-path ~/.ssh/deploy_key \\
     --dry-run

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --context)
            CONTEXT="$2"
            shift 2
            ;;
        --repo-url)
            REPO_URL="$2"
            shift 2
            ;;
        --ssh-key-path)
            SSH_KEY_PATH="$2"
            shift 2
            ;;
        --token)
            TOKEN="$2"
            shift 2
            ;;
        --repo-name)
            REPO_NAME="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Namespace is required
if [ -z "$NAMESPACE" ]; then
    log_error "Namespace is required"
    echo ""
    echo "Specify a namespace explicitly:"
    echo "  $0 --namespace YOUR_NAMESPACE --repo-url URL --ssh-key-path PATH"
    exit 1
fi

# Validate required arguments
if [ -z "$REPO_URL" ]; then
    log_error "Repository URL is required"
    echo ""
    show_help
    exit 1
fi

# Determine authentication method based on provided credentials
if [ -n "$SSH_KEY_PATH" ] && [ -n "$TOKEN" ]; then
    log_error "Cannot specify both SSH key and token - choose one authentication method"
    echo ""
    show_help
    exit 1
elif [ -n "$SSH_KEY_PATH" ]; then
    AUTH_METHOD="ssh"
    # Transform HTTPS URL to SSH format if needed
    if [[ "$REPO_URL" == https://* ]]; then
        log_info "Transforming HTTPS URL to SSH format for SSH key authentication..."
        # Extract host and path from HTTPS URL
        # https://github.com/org/repo.git -> git@github.com:org/repo.git
        REPO_URL=$(echo "$REPO_URL" | sed -E 's|https://([^/]+)/(.+)$|git@\1:\2|')
        log_info "Transformed URL: ${REPO_URL}"
    fi
    # Validate SSH URL format
    if [[ "$REPO_URL" != git@* ]] && [[ "$REPO_URL" != ssh://* ]]; then
        log_error "Invalid SSH URL format after transformation"
        echo "Expected format: git@host:org/repo.git"
        exit 1
    fi
elif [ -n "$TOKEN" ]; then
    AUTH_METHOD="https"
    # Ensure URL is HTTPS format for token authentication
    if [[ "$REPO_URL" == git@* ]]; then
        log_error "Cannot use token authentication with SSH URL format"
        echo "For token authentication, provide HTTPS URL: https://github.com/org/repo.git"
        exit 1
    elif [[ "$REPO_URL" != https://* ]]; then
        log_error "Invalid HTTPS URL format"
        echo "Expected format: https://github.com/org/repo.git"
        exit 1
    fi
else
    log_error "Authentication credentials required"
    echo "Provide either:"
    echo "  --ssh-key-path PATH    (for SSH authentication)"
    echo "  --token TOKEN          (for HTTPS authentication)"
    echo ""
    show_help
    exit 1
fi

# Derive repository name if not provided
if [ -z "$REPO_NAME" ]; then
    REPO_NAME=$(echo "$REPO_URL" | sed -E 's|.*/([^/]+)\.git$|\1|' | sed 's|[^a-zA-Z0-9-]|-|g')
    if [ -z "$REPO_NAME" ]; then
        REPO_NAME="gitops-repo"
    fi
fi

# Determine and display the actual Kubernetes context being used
if [ -n "$CONTEXT" ]; then
    ACTUAL_CONTEXT="$CONTEXT"
    CONTEXT_SOURCE="specified via --context"
else
    ACTUAL_CONTEXT=$(kubectl config current-context 2>/dev/null || echo "unknown")
    CONTEXT_SOURCE="using current context"
fi

echo "============================================================"
echo "Configure ArgoCD Git Repository"
echo "============================================================"
echo ""
echo "⚠️  KUBERNETES CONTEXT: ${ACTUAL_CONTEXT}"
echo "    (${CONTEXT_SOURCE})"
echo ""
echo "Configuration:"
if [ -n "$CONTEXT" ]; then
    echo "  Context:        ${CONTEXT}"
else
    echo "  Context:        current oc context"
fi
echo "  Namespace:      ${NAMESPACE}"
echo "  Repository URL: ${REPO_URL}"
echo "  Repository Name: ${REPO_NAME}"
echo "  Auth Method:    ${AUTH_METHOD}"
echo "  Dry Run:        ${DRY_RUN}"
echo ""

if [ "$DRY_RUN" = true ]; then
    log_info "DRY RUN MODE - No changes will be made"
    echo ""
fi

# Check prerequisites
log_info "Checking prerequisites..."

# Check oc
if ! command -v oc &> /dev/null; then
    log_error "oc is not installed"
    exit 1
fi
log_success "oc is installed"

# Check if context exists
if [ -n "$CONTEXT" ]; then
    if ! oc config get-contexts "${CONTEXT}" &> /dev/null; then
        log_error "Kubernetes context '${CONTEXT}' not found"
        exit 1
    fi
    log_success "Context '${CONTEXT}' found"
else
    log_info "Using current oc context"
fi

# Check if ArgoCD is installed
if ! oc_cmd get namespace "${NAMESPACE}" &> /dev/null; then
    log_error "ArgoCD namespace '${NAMESPACE}' not found"
    echo ""
    echo "Please install ArgoCD first:"
    if [ -n "$CONTEXT" ]; then
        echo "  ./argocd-install.sh --context ${CONTEXT}"
    else
        echo "  ./argocd-install.sh"
    fi
    exit 1
fi
log_success "ArgoCD namespace '${NAMESPACE}' exists"

# Validate SSH key if using SSH
if [ "$AUTH_METHOD" = "ssh" ]; then
    # Expand tilde in path
    SSH_KEY_PATH="${SSH_KEY_PATH/#\~/$HOME}"
    
    if [ ! -f "$SSH_KEY_PATH" ]; then
        log_error "SSH key not found: ${SSH_KEY_PATH}"
        exit 1
    fi
    log_success "SSH key found: ${SSH_KEY_PATH}"
    
    # Check key permissions
    KEY_PERMS=$(stat -f "%OLp" "$SSH_KEY_PATH" 2>/dev/null || stat -c "%a" "$SSH_KEY_PATH" 2>/dev/null)
    if [ "$KEY_PERMS" != "600" ] && [ "$KEY_PERMS" != "400" ]; then
        log_warning "SSH key has insecure permissions: ${KEY_PERMS}"
        log_info "Recommended: chmod 600 ${SSH_KEY_PATH}"
    fi
fi

echo ""
log_success "All prerequisites met"
echo ""

# Extract Git host from URL
if [ "$AUTH_METHOD" = "ssh" ]; then
    GIT_HOST=$(echo "$REPO_URL" | sed -E 's|git@([^:]+):.*|\1|')
elif [ "$AUTH_METHOD" = "https" ]; then
    GIT_HOST=$(echo "$REPO_URL" | sed -E 's|https://([^/]+)/.*|\1|')
fi

if [ "$DRY_RUN" = true ]; then
    echo "============================================================"
    echo "DRY RUN - Configuration Steps"
    echo "============================================================"
    echo ""
    echo "The following actions would be performed:"
    echo ""
    echo "Step 1: Configure SSH known hosts for ${GIT_HOST}"
    echo "        - Fetch SSH host keys"
    echo "        - Update argocd-ssh-known-hosts-cm ConfigMap"
    echo ""
    echo "Step 2: Create repository credentials"
    if [ "$AUTH_METHOD" = "ssh" ]; then
        echo "        - Create secret 'repo-${REPO_NAME}' with SSH private key"
    else
        echo "        - Create secret 'repo-${REPO_NAME}' with HTTPS token"
    fi
    echo "        - Label secret for ArgoCD recognition"
    echo ""
    echo "Step 3: Restart ArgoCD components"
    echo "        - Restart argocd-repo-server deployment"
    echo ""
    echo "Step 4: Create default AppProject"
    echo "        - Create default AppProject in namespace"
    echo ""
    echo "Step 5: Create application-sets Application"
    echo "        - Create Application to manage ApplicationSets"
    echo ""
    log_success "Dry run complete - no changes made"
    exit 0
fi

echo ""
echo "============================================================"
echo "Step 1: Configuring SSH known hosts"
echo "============================================================"
echo ""

log_info "Git host: ${GIT_HOST}"

# Get SSH host key
log_info "Fetching SSH host key for ${GIT_HOST}..."
SSH_KNOWN_HOSTS=$(ssh-keyscan -t rsa,ecdsa,ed25519 "${GIT_HOST}" 2>/dev/null || true)

if [ -z "$SSH_KNOWN_HOSTS" ]; then
    log_warning "Could not fetch SSH host key automatically"
    log_info "You may need to configure it manually later"
else
    log_success "SSH host key retrieved"
    
    # Update ArgoCD SSH known hosts ConfigMap
    log_info "Updating ArgoCD SSH known hosts..."
    
    # Create or update ConfigMap
    oc_cmd -n "${NAMESPACE}" create configmap argocd-ssh-known-hosts-cm \
        --from-literal="ssh_known_hosts=${SSH_KNOWN_HOSTS}" \
        --dry-run=client -o yaml | \
        oc_cmd apply -f -
    
    log_success "SSH known hosts configured"
fi

echo ""
echo "============================================================"
echo "Step 2: Creating repository credentials"
echo "============================================================"
echo ""

if [ "$AUTH_METHOD" = "ssh" ]; then
    log_info "Creating SSH credentials secret..."
    
    # Read SSH private key
    SSH_KEY_CONTENT=$(cat "$SSH_KEY_PATH")
    
    # Create repository credentials secret
    oc_cmd -n "${NAMESPACE}" create secret generic "repo-${REPO_NAME}" \
        --from-literal=type=git \
        --from-literal=url="${REPO_URL}" \
        --from-literal=sshPrivateKey="${SSH_KEY_CONTENT}" \
        --dry-run=client -o yaml | \
        oc_cmd apply -f -
    
    # Label the secret so ArgoCD recognizes it
    oc_cmd -n "${NAMESPACE}" label secret "repo-${REPO_NAME}" \
        argocd.argoproj.io/secret-type=repository --overwrite
    
    log_success "SSH credentials configured"
    
elif [ "$AUTH_METHOD" = "https" ]; then
    log_info "Creating HTTPS credentials secret..."
    
    # Extract username from URL if present
    USERNAME=$(echo "$REPO_URL" | sed -E 's|https://([^@:]+)[@:].*|\1|')
    if [ "$USERNAME" = "$REPO_URL" ]; then
        USERNAME="git"  # Default username for token-based auth
    fi
    
    # Create repository credentials secret
    oc_cmd -n "${NAMESPACE}" create secret generic "repo-${REPO_NAME}" \
        --from-literal=type=git \
        --from-literal=url="${REPO_URL}" \
        --from-literal=username="${USERNAME}" \
        --from-literal=password="${TOKEN}" \
        --dry-run=client -o yaml | \
        oc_cmd apply -f -
    
    # Label the secret so ArgoCD recognizes it
    oc_cmd -n "${NAMESPACE}" label secret "repo-${REPO_NAME}" \
        argocd.argoproj.io/secret-type=repository --overwrite
    
    log_success "HTTPS credentials configured"
fi

echo ""
echo "============================================================"
echo "Step 3: Restarting ArgoCD components"
echo "============================================================"
echo ""

log_info "Restarting ArgoCD repo server to pick up new credentials..."
oc_cmd -n "${NAMESPACE}" rollout restart deployment argocd-repo-server
oc_cmd -n "${NAMESPACE}" rollout status deployment argocd-repo-server --timeout=120s || {
    log_warning "Timeout waiting for repo server restart"
}
log_success "ArgoCD repo server restarted"

echo ""
echo "============================================================"
echo "Step 4: Creating Default AppProject"
echo "============================================================"
echo ""

# Always apply default AppProject to ensure it has correct spec
log_info "Configuring default AppProject..."

# Create/update default AppProject
cat <<EOF | oc_cmd apply -f -
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: default
  namespace: ${NAMESPACE}
spec:
  description: Default project
  sourceRepos:
  - '*'
  destinations:
  - namespace: '*'
    server: '*'
  clusterResourceWhitelist:
  - group: '*'
    kind: '*'
  namespaceResourceWhitelist:
  - group: '*'
    kind: '*'
EOF
log_success "Default AppProject configured"

echo ""
echo "============================================================"
echo "Step 5: Creating ApplicationSets Application"
echo "============================================================"
echo ""

# Check if application-sets application already exists
if oc_cmd -n "${NAMESPACE}" get application application-sets &> /dev/null; then
    log_info "Application-sets application already exists"
    
    # Check if it's configured for the correct repository
    EXISTING_REPO=$(oc_cmd -n "${NAMESPACE}" get application application-sets -o jsonpath='{.spec.source.repoURL}' 2>/dev/null || echo "")
    
    if [ "$EXISTING_REPO" = "$REPO_URL" ]; then
        log_info "Deleting existing application-sets application to recreate with updated configuration..."
        oc_cmd -n "${NAMESPACE}" delete application application-sets
        log_success "Existing application deleted"
    else
        log_warning "Application-sets application points to different repository: ${EXISTING_REPO}"
        log_info "Deleting and recreating application-sets application to use: ${REPO_URL}"
        oc_cmd -n "${NAMESPACE}" delete application application-sets
        log_success "Existing application deleted"
    fi
fi

# Create the application-sets application
log_info "Creating application-sets application to auto-manage service instances..."

cat <<EOF | oc_cmd apply -f -
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: application-sets
  namespace: ${NAMESPACE}
spec:
  destination:
    namespace: ${NAMESPACE}
    server: https://kubernetes.default.svc
  source:
    path: application-sets
    repoURL: ${REPO_URL}
    targetRevision: HEAD
    directory:
      recurse: true
  project: default
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
EOF

log_success "Application-sets application created"
log_info "The application-sets application will automatically create Applications from application-sets/ directory"

echo ""
echo "============================================================"
echo "✅ Git Repository Configuration Complete!"
echo "============================================================"
echo ""
echo "Repository Details:"
echo "  Name: ${REPO_NAME}"
echo "  URL:  ${REPO_URL}"
echo "  Auth: ${AUTH_METHOD}"
echo ""
echo "Verify Configuration:"
echo "  $(verify_command_example "-n ${NAMESPACE} get secret repo-${REPO_NAME}")"
echo ""

# Display application-sets application status
echo "Application-Sets Application Status:"
APP_STATUS=$(oc_cmd -n "${NAMESPACE}" get application application-sets -o jsonpath='{.status.sync.status}' 2>/dev/null || echo "Unknown")
APP_HEALTH=$(oc_cmd -n "${NAMESPACE}" get application application-sets -o jsonpath='{.status.health.status}' 2>/dev/null || echo "Unknown")
echo "  Name:   application-sets"
echo "  Sync:   ${APP_STATUS}"
echo "  Health: ${APP_HEALTH}"
echo ""
echo "The application-sets application will automatically:"
echo "  - Monitor application-sets/ directory in the GitOps repository"
echo "  - Create ArgoCD ApplicationSets for dynamic service provisioning"
echo "  - Keep ApplicationSets in sync with Git"
echo ""
echo "Note: The application-sets/ directory will be created when the broker"
echo "      provisions the first service instance."
echo ""

log_success "Configuration complete!"

# Made with Bob
