#!/bin/bash
#
# ArgoCD Cluster Resources Installation Script
# This script must be run by a cluster administrator with cluster-admin privileges
# It installs only the cluster-wide resources (CRDs and ClusterRoles)
# Run this ONCE per cluster, then use argocd-configure-namespace.sh for each namespace
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
DRY_RUN=false

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Install ArgoCD cluster-wide resources (CRDs and ClusterRoles).
This script requires cluster-admin privileges and should be run ONCE per cluster.

Options:
  --dry-run    Show what would be done without making changes
  -h, --help   Show this help message

Examples:
  # Dry run to see what would be installed
  $0 --dry-run

  # Install cluster resources
  $0

Note: This script only installs cluster-wide resources (CRDs and ClusterRoles).
      After running this, use argocd-configure-namespace.sh to configure
      each namespace where you want to install ArgoCD.

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

echo "============================================================"
echo "ArgoCD Cluster Resources Installation"
echo "============================================================"
echo ""
echo "Configuration:"
echo "  Dry Run: ${DRY_RUN}"
echo ""

if [ "$DRY_RUN" = true ]; then
    log_info "DRY RUN MODE - No changes will be made"
    echo ""
fi

# Check prerequisites
log_info "Checking prerequisites..."

# Check kubectl/oc
if ! command -v kubectl &> /dev/null && ! command -v oc &> /dev/null; then
    log_error "Neither kubectl nor oc is installed"
    exit 1
fi

# Prefer oc if available
if command -v oc &> /dev/null; then
    K8S_CMD="oc"
else
    K8S_CMD="kubectl"
fi
log_success "${K8S_CMD} is installed"

# Check cluster connectivity
if ! ${K8S_CMD} cluster-info &> /dev/null; then
    log_error "Cannot connect to cluster"
    exit 1
fi
log_success "Cluster is accessible"

# Check if user has cluster-admin privileges
log_info "Checking cluster-admin privileges..."
if ! ${K8S_CMD} auth can-i create customresourcedefinitions &> /dev/null; then
    log_error "Insufficient permissions - cluster-admin privileges required"
    echo ""
    echo "This script must be run by a user with cluster-admin privileges."
    echo "Current user cannot create CustomResourceDefinitions."
    exit 1
fi
log_success "User has cluster-admin privileges"

echo ""
log_success "All prerequisites met"
echo ""

# Resolve manifest path relative to this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CRD_MANIFEST="${SCRIPT_DIR}/../manifests/crds-install.yaml"

# Verify local manifest exists
if [ ! -f "${CRD_MANIFEST}" ]; then
    log_error "Required manifest not found: ${CRD_MANIFEST}"
    exit 1
fi

if [ "$DRY_RUN" = true ]; then
    echo "============================================================"
    echo "DRY RUN - Installation Steps"
    echo "============================================================"
    echo ""
    echo "The following cluster-wide resources would be installed"
    echo "from: ${CRD_MANIFEST}"
    echo ""
    echo "1. CustomResourceDefinitions (CRDs):"
    echo "   - applications.argoproj.io"
    echo "   - applicationsets.argoproj.io"
    echo "   - appprojects.argoproj.io"
    echo ""
    echo "2. ClusterRoles + ClusterRoleBindings:"
    echo "   - argocd-application-controller"
    echo "   - argocd-applicationset-controller"
    echo "   - argocd-server"
    echo ""
    log_success "Dry run complete - no changes made"
    exit 0
fi

echo ""
echo "============================================================"
echo "Step 1: Installing CustomResourceDefinitions"
echo "============================================================"
echo ""

log_info "Applying crds-install.yaml with server-side apply..."
if ! ${K8S_CMD} apply --server-side -f "${CRD_MANIFEST}"; then
    log_error "Failed to apply crds-install.yaml"
    exit 1
fi

# Verify CRDs were installed
log_info "Verifying CRD installation..."
CRDS_OK=true
for crd in applications.argoproj.io applicationsets.argoproj.io appprojects.argoproj.io; do
    if ${K8S_CMD} get crd "${crd}" &> /dev/null; then
        log_success "  ${crd}"
    else
        log_error "  Missing: ${crd}"
        CRDS_OK=false
    fi
done
if [ "$CRDS_OK" = false ]; then
    exit 1
fi
log_success "All 3 ArgoCD CRDs installed successfully"

echo ""
echo "============================================================"
echo "✅ Cluster Resources Installation Complete!"
echo "============================================================"
echo ""

echo "Installed Resources:"
echo "  ✓ CustomResourceDefinitions (CRDs)"
echo "  ✓ ClusterRoles"
echo ""

echo "Next Steps:"
echo "  1. For each namespace where you want to install ArgoCD, run:"
echo "     ./argocd-configure-namespace.sh --namespace <namespace-name>"
echo ""
echo "  2. Then namespace admin can install ArgoCD:"
echo "     cd .."
echo "     ./argocd-install.sh --namespace <namespace-name>"
echo ""

log_success "Cluster resources installation complete!"

# Made with Bob