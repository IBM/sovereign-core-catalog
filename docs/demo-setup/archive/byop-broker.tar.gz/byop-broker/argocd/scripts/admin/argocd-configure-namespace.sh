#!/bin/bash
#
# ArgoCD Namespace Configuration Script
# This script must be run by a cluster administrator with cluster-admin privileges
# It configures a specific namespace for ArgoCD installation by creating
# ClusterRoleBindings and OpenShift SCCs
#
# Prerequisites: argocd-install-cluster-resources.sh must be run first
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE=""
DRY_RUN=false

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 --namespace NAMESPACE [OPTIONS]

Configure a namespace for ArgoCD installation by creating ClusterRoleBindings
and OpenShift Security Context Constraints.

This script requires cluster-admin privileges.

Prerequisites:
  - argocd-install-cluster-resources.sh must be run first to install CRDs and ClusterRoles

Required:
  --namespace NAMESPACE   Target namespace for ArgoCD installation

Options:
  --dry-run              Show what would be done without making changes
  -h, --help             Show this help message

Examples:
  # Dry run to see what would be configured
  $0 --namespace argocd --dry-run

  # Configure namespace for ArgoCD
  $0 --namespace sccat-byop-5

Note: This script can be run multiple times for different namespaces.
      Each namespace will get its own set of ClusterRoleBindings.

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Validate required arguments
if [ -z "$NAMESPACE" ]; then
    log_error "Namespace is required"
    echo ""
    show_help
    exit 1
fi

echo "============================================================"
echo "ArgoCD Namespace Configuration"
echo "============================================================"
echo ""
echo "Configuration:"
echo "  Namespace:  ${NAMESPACE}"
echo "  Dry Run:    ${DRY_RUN}"
echo ""

if [ "$DRY_RUN" = true ]; then
    log_info "DRY RUN MODE - No changes will be made"
    echo ""
fi

# Check prerequisites
log_info "Checking prerequisites..."

# Check kubectl/oc
if ! command -v kubectl &> /dev/null && ! command -v oc &> /dev/null; then
    log_error "Neither kubectl nor oc is installed"
    exit 1
fi

# Prefer oc if available
if command -v oc &> /dev/null; then
    K8S_CMD="oc"
else
    K8S_CMD="kubectl"
fi
log_success "${K8S_CMD} is installed"

# Check cluster connectivity
if ! ${K8S_CMD} cluster-info &> /dev/null; then
    log_error "Cannot connect to cluster"
    exit 1
fi
log_success "Cluster is accessible"

# Check if user has cluster-admin privileges
log_info "Checking cluster-admin privileges..."
if ! ${K8S_CMD} auth can-i create clusterrolebindings &> /dev/null; then
    log_error "Insufficient permissions - cluster-admin privileges required"
    echo ""
    echo "This script must be run by a user with cluster-admin privileges."
    echo "Current user cannot create ClusterRoleBindings."
    exit 1
fi
log_success "User has cluster-admin privileges"

# Verify cluster resources are installed
log_info "Verifying cluster resources are installed..."
MISSING_RESOURCES=false

if ! ${K8S_CMD} get crd applications.argoproj.io &> /dev/null; then
    log_error "CRD applications.argoproj.io not found"
    MISSING_RESOURCES=true
fi

if ! ${K8S_CMD} get crd applicationsets.argoproj.io &> /dev/null; then
    log_error "CRD applicationsets.argoproj.io not found"
    MISSING_RESOURCES=true
fi

if ! ${K8S_CMD} get crd appprojects.argoproj.io &> /dev/null; then
    log_error "CRD appprojects.argoproj.io not found"
    MISSING_RESOURCES=true
fi

if ! ${K8S_CMD} get clusterrole argocd-application-controller &> /dev/null; then
    log_error "ClusterRole argocd-application-controller not found"
    MISSING_RESOURCES=true
fi

if ! ${K8S_CMD} get clusterrole argocd-server &> /dev/null; then
    log_error "ClusterRole argocd-server not found"
    MISSING_RESOURCES=true
fi

if [ "$MISSING_RESOURCES" = true ]; then
    echo ""
    log_error "Missing cluster resources"
    echo ""
    echo "Please run argocd-install-cluster-resources.sh first to install"
    echo "cluster-wide resources (CRDs and ClusterRoles)."
    exit 1
fi

log_success "All cluster resources are installed"

# Check if namespace exists
log_info "Checking if namespace ${NAMESPACE} exists..."
if ! ${K8S_CMD} get namespace "${NAMESPACE}" &> /dev/null; then
    log_warning "Namespace ${NAMESPACE} does not exist"
    log_info "Creating namespace ${NAMESPACE}..."
    if ${K8S_CMD} create namespace "${NAMESPACE}"; then
        log_success "Namespace ${NAMESPACE} created"
    else
        log_error "Failed to create namespace ${NAMESPACE}"
        exit 1
    fi
else
    log_success "Namespace ${NAMESPACE} exists"
fi

echo ""
log_success "All prerequisites met"
echo ""

if [ "$DRY_RUN" = true ]; then
    echo "============================================================"
    echo "DRY RUN - Configuration Steps"
    echo "============================================================"
    echo ""
    echo "The following resources would be created for namespace ${NAMESPACE}:"
    echo ""
    echo "1. ClusterRoleBindings:"
    echo "   - argocd-application-controller-${NAMESPACE}"
    echo "   - argocd-applicationset-controller-${NAMESPACE}"
    echo "   - argocd-server-${NAMESPACE}"
    echo ""
    echo "2. Namespace RoleBindings (to ClusterRoles):"
    echo "   - argocd-application-controller"
    echo "   - argocd-applicationset-controller"
    echo "   - argocd-notifications-controller"
    echo "   - argocd-server"
    echo ""
    echo "3. Namespace Roles and RoleBindings:"
    echo "   - argocd-server (ConfigMaps, Secrets, ArgoCD CRDs)"
    echo "   - argocd-application-controller (ConfigMaps, Secrets, ArgoCD CRDs)"
    echo "   - argocd-applicationset-controller (ConfigMaps, Secrets)"
    echo "   - argocd-notifications-controller (ConfigMaps, Secrets)"
    echo ""
    echo "4. namespace-admin ArgoCD Permissions:"
    echo "   - Role: namespace-admin-argocd (ArgoCD CRDs)"
    echo "   - RoleBinding: namespace-admin-argocd"
    echo ""
    if command -v oc &> /dev/null; then
        echo "5. OpenShift Security Context Constraints:"
        echo "   - Grant anyuid SCC to argocd-redis service account"
        echo "   - Grant anyuid SCC to argocd-application-controller service account"
        echo ""
    fi
    log_success "Dry run complete - no changes made"
    exit 0
fi

echo ""
echo "============================================================"
echo "Step 1: Creating ClusterRoleBindings"
echo "============================================================"
echo ""

log_info "Creating ClusterRoleBindings for namespace ${NAMESPACE}..."

# Create ClusterRoleBinding for application-controller
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: argocd-application-controller-${NAMESPACE}
  labels:
    app.kubernetes.io/component: application-controller
    app.kubernetes.io/name: argocd-application-controller
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: argocd-application-controller
subjects:
- kind: ServiceAccount
  name: argocd-application-controller
  namespace: ${NAMESPACE}
EOF
log_success "ClusterRoleBinding created: argocd-application-controller-${NAMESPACE}"

# Create ClusterRoleBinding for applicationset-controller
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: argocd-applicationset-controller-${NAMESPACE}
  labels:
    app.kubernetes.io/component: applicationset-controller
    app.kubernetes.io/name: argocd-applicationset-controller
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: argocd-applicationset-controller
subjects:
- kind: ServiceAccount
  name: argocd-applicationset-controller
  namespace: ${NAMESPACE}
EOF
log_success "ClusterRoleBinding created: argocd-applicationset-controller-${NAMESPACE}"

# Create ClusterRoleBinding for server
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: argocd-server-${NAMESPACE}
  labels:
    app.kubernetes.io/component: server
    app.kubernetes.io/name: argocd-server
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: argocd-server
subjects:
- kind: ServiceAccount
  name: argocd-server
  namespace: ${NAMESPACE}
EOF
log_success "ClusterRoleBinding created: argocd-server-${NAMESPACE}"

echo ""
echo "============================================================"
echo "Step 2: Creating Namespace RoleBindings"
echo "============================================================"
echo ""

log_info "Creating RoleBindings for namespace ${NAMESPACE}..."
log_info "These bind service accounts to ClusterRoles within the namespace scope"

# Create RoleBinding for application-controller (binds to ClusterRole)
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: argocd-application-controller
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: application-controller
    app.kubernetes.io/name: argocd-application-controller
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: argocd-application-controller
subjects:
- kind: ServiceAccount
  name: argocd-application-controller
  namespace: ${NAMESPACE}
EOF
log_success "RoleBinding created: argocd-application-controller"

# Create RoleBinding for applicationset-controller (binds to ClusterRole)
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: argocd-applicationset-controller
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: applicationset-controller
    app.kubernetes.io/name: argocd-applicationset-controller
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: argocd-applicationset-controller
subjects:
- kind: ServiceAccount
  name: argocd-applicationset-controller
  namespace: ${NAMESPACE}
EOF
log_success "RoleBinding created: argocd-applicationset-controller"

# Create RoleBinding for notifications-controller (binds to ClusterRole)
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: argocd-notifications-controller
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: notifications-controller
    app.kubernetes.io/name: argocd-notifications-controller
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: argocd-application-controller
subjects:
- kind: ServiceAccount
  name: argocd-notifications-controller
  namespace: ${NAMESPACE}
EOF
log_success "RoleBinding created: argocd-notifications-controller"

# Create RoleBinding for server (binds to ClusterRole)
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: argocd-server
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: server
    app.kubernetes.io/name: argocd-server
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: argocd-server
subjects:
- kind: ServiceAccount
  name: argocd-server
  namespace: ${NAMESPACE}
EOF
log_success "RoleBinding created: argocd-server"

echo ""
echo "============================================================"
echo "Step 3: Creating Namespace Roles for ConfigMaps and Secrets"
echo "============================================================"
echo ""

log_info "Creating Roles for namespace resource access..."
log_info "These provide permissions for ConfigMaps, Secrets, and other namespace resources"

# Create Role for argocd-server with permissions for ConfigMaps, Secrets, and ArgoCD CRDs
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: argocd-server
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: server
    app.kubernetes.io/name: argocd-server
    app.kubernetes.io/part-of: argocd
rules:
- apiGroups:
  - ""
  resources:
  - secrets
  - configmaps
  verbs:
  - get
  - list
  - watch
  - create
  - update
  - patch
  - delete
- apiGroups:
  - argoproj.io
  resources:
  - applications
  - applicationsets
  - appprojects
  verbs:
  - get
  - list
  - watch
  - create
  - update
  - patch
  - delete
EOF
log_success "Role created: argocd-server"

# Create RoleBinding for argocd-server to the namespace Role
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: argocd-server-namespace-resources
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: server
    app.kubernetes.io/name: argocd-server
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: argocd-server
subjects:
- kind: ServiceAccount
  name: argocd-server
  namespace: ${NAMESPACE}
EOF
log_success "RoleBinding created: argocd-server-namespace-resources"

# Create Role for argocd-application-controller
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: argocd-application-controller
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: application-controller
    app.kubernetes.io/name: argocd-application-controller
    app.kubernetes.io/part-of: argocd
rules:
- apiGroups:
  - ""
  resources:
  - secrets
  - configmaps
  verbs:
  - get
  - list
  - watch
  - create
  - update
  - patch
  - delete
- apiGroups:
  - argoproj.io
  resources:
  - applications
  - applicationsets
  - appprojects
  verbs:
  - get
  - list
  - watch
  - create
  - update
  - patch
  - delete
EOF
log_success "Role created: argocd-application-controller"

# Create RoleBinding for argocd-application-controller to the namespace Role
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: argocd-application-controller-namespace-resources
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: application-controller
    app.kubernetes.io/name: argocd-application-controller
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: argocd-application-controller
subjects:
- kind: ServiceAccount
  name: argocd-application-controller
  namespace: ${NAMESPACE}
EOF
log_success "RoleBinding created: argocd-application-controller-namespace-resources"

# Create Role for argocd-applicationset-controller
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: argocd-applicationset-controller
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: applicationset-controller
    app.kubernetes.io/name: argocd-applicationset-controller
    app.kubernetes.io/part-of: argocd
rules:
- apiGroups:
  - ""
  resources:
  - secrets
  - configmaps
  verbs:
  - get
  - list
  - watch
EOF
log_success "Role created: argocd-applicationset-controller"

# Create RoleBinding for argocd-applicationset-controller to the namespace Role
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: argocd-applicationset-controller-namespace-resources
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: applicationset-controller
    app.kubernetes.io/name: argocd-applicationset-controller
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: argocd-applicationset-controller
subjects:
- kind: ServiceAccount
  name: argocd-applicationset-controller
  namespace: ${NAMESPACE}
EOF
log_success "RoleBinding created: argocd-applicationset-controller-namespace-resources"

# Create Role for argocd-notifications-controller
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: argocd-notifications-controller
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: notifications-controller
    app.kubernetes.io/name: argocd-notifications-controller
    app.kubernetes.io/part-of: argocd
rules:
- apiGroups:
  - ""
  resources:
  - secrets
  - configmaps
  verbs:
  - get
  - list
  - watch
EOF
log_success "Role created: argocd-notifications-controller"

# Create RoleBinding for argocd-notifications-controller to the namespace Role
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: argocd-notifications-controller-namespace-resources
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/component: notifications-controller
    app.kubernetes.io/name: argocd-notifications-controller
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: argocd-notifications-controller
subjects:
- kind: ServiceAccount
  name: argocd-notifications-controller
  namespace: ${NAMESPACE}
EOF
log_success "RoleBinding created: argocd-notifications-controller-namespace-resources"

echo ""
echo "============================================================"
echo "Step 4: Granting namespace-admin Permissions for ArgoCD Resources"
echo "============================================================"
echo ""

log_info "Creating Role for namespace-admin to manage ArgoCD resources..."
log_info "This allows users with namespace-admin access to create/manage Applications"

# Create Role for namespace-admin with permissions for ArgoCD CRDs
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: namespace-admin-argocd
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/name: namespace-admin-argocd
    app.kubernetes.io/part-of: argocd
rules:
- apiGroups:
  - argoproj.io
  resources:
  - applications
  - applicationsets
  - appprojects
  verbs:
  - get
  - list
  - watch
  - create
  - update
  - patch
  - delete
EOF
log_success "Role created: namespace-admin-argocd"

# Create RoleBinding for namespace-admin service account to the ArgoCD Role
cat <<EOF | ${K8S_CMD} apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: namespace-admin-argocd
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/name: namespace-admin-argocd
    app.kubernetes.io/part-of: argocd
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: namespace-admin-argocd
subjects:
- kind: ServiceAccount
  name: namespace-admin
  namespace: ${NAMESPACE}
EOF
log_success "RoleBinding created: namespace-admin-argocd"

echo ""
echo "============================================================"
echo "Step 5: Configuring OpenShift Security Context Constraints"
echo "============================================================"
echo ""

# Check if we're on OpenShift
IS_OPENSHIFT=false
if command -v oc &> /dev/null; then
    if oc api-resources | grep -q "securitycontextconstraints"; then
        IS_OPENSHIFT=true
    fi
fi

if [ "$IS_OPENSHIFT" = true ]; then
    log_info "OpenShift detected - configuring Security Context Constraints..."
    
    # Check if namespace exists
    if ! oc get namespace "${NAMESPACE}" &> /dev/null; then
        log_warning "Namespace ${NAMESPACE} does not exist yet"
        log_info "SCC configuration will need to be applied after namespace and service accounts are created"
        log_info "Run these commands after namespace installation:"
        echo ""
        echo "  oc adm policy add-scc-to-user anyuid -z argocd-redis -n ${NAMESPACE}"
        echo "  oc adm policy add-scc-to-user anyuid -z argocd-application-controller -n ${NAMESPACE}"
        echo ""
    else
        # Grant anyuid SCC to argocd-redis service account
        log_info "Granting anyuid SCC to argocd-redis service account..."
        if oc adm policy add-scc-to-user anyuid -z argocd-redis -n "${NAMESPACE}"; then
            log_success "anyuid SCC granted to argocd-redis"
        else
            log_warning "Failed to grant anyuid SCC to argocd-redis"
            log_info "Service account may not exist yet. Run this after namespace installation:"
            echo "  oc adm policy add-scc-to-user anyuid -z argocd-redis -n ${NAMESPACE}"
        fi
        
        # Grant anyuid SCC to argocd-application-controller service account
        log_info "Granting anyuid SCC to argocd-application-controller service account..."
        if oc adm policy add-scc-to-user anyuid -z argocd-application-controller -n "${NAMESPACE}"; then
            log_success "anyuid SCC granted to argocd-application-controller"
        else
            log_warning "Failed to grant anyuid SCC to argocd-application-controller"
            log_info "Service account may not exist yet. Run this after namespace installation:"
            echo "  oc adm policy add-scc-to-user anyuid -z argocd-application-controller -n ${NAMESPACE}"
        fi
    fi
    
    log_success "OpenShift SCC configuration complete"
else
    log_info "Not running on OpenShift - skipping SCC configuration"
fi

echo ""
echo "============================================================"
echo "✅ Namespace Configuration Complete!"
echo "============================================================"
echo ""

echo "Configured Resources for namespace ${NAMESPACE}:"
echo "  ✓ ClusterRoleBindings (for cluster-wide permissions)"
echo "  ✓ RoleBindings (for namespace-scoped permissions)"
if [ "$IS_OPENSHIFT" = true ]; then
    echo "  ✓ OpenShift SCC configuration"
fi
echo ""

echo "Next Steps:"
echo "  1. Namespace admin should now install namespace-scoped resources:"
echo "     cd .."
echo "     ./argocd-install.sh --namespace ${NAMESPACE}"
echo ""
echo "  2. After installation, verify ArgoCD is running:"
echo "     ${K8S_CMD} get pods -n ${NAMESPACE}"
echo ""

log_success "Namespace configuration complete!"

# Made with Bob