# ArgoCD Admin Scripts

Scripts requiring **cluster-admin privileges**.

## Scripts

### argocd-install.sh
**Full installation (single-step)**

```bash
./argocd-install.sh --namespace argocd
```

- Installs CRDs, ClusterRoles, ClusterRoleBindings, and all namespace resources
- **Use when**: Single namespace, cluster-admin access

### argocd-install-cluster-resources.sh
**Install cluster resources (run ONCE per cluster)**

```bash
./argocd-install-cluster-resources.sh
```

- Installs CRDs and ClusterRoles
- **Run**: Once per cluster
- **After this**: Run `argocd-configure-namespace.sh` for each namespace

### argocd-configure-namespace.sh
**Configure namespace (run ONCE per namespace)**

```bash
./argocd-configure-namespace.sh --namespace your-namespace
```

- Creates ClusterRoleBindings, Roles, RoleBindings
- Grants OpenShift SCC permissions
- **Prerequisites**: `argocd-install-cluster-resources.sh` must be run first
- **After this**: Namespace admin runs `../argocd-install.sh`

### argocd-add-spoke.sh
**Register spoke cluster with hub ArgoCD**

```bash
./argocd-add-spoke.sh --hub-context hub-cluster --spoke-context spoke-cluster-1
```

- Creates ClusterRole and ClusterRoleBinding on spoke cluster
- Registers spoke cluster with hub ArgoCD for multi-cluster management
- **Requires**: Cluster-admin on spoke cluster

### argocd-remove-spoke.sh
**Unregister spoke cluster from hub ArgoCD**

```bash
./argocd-remove-spoke.sh --hub-context hub-cluster --spoke-context spoke-cluster-1
```

- Removes spoke cluster registration from hub
- Optionally removes applications targeting the spoke
- **Requires**: Cluster-admin on hub cluster

## Installation Workflows

### Single Namespace
```bash
./argocd-install.sh --namespace argocd
```

### Multi-Namespace
```bash
# Step 1: Install cluster resources (ONCE)
./argocd-install-cluster-resources.sh

# Step 2: Configure each namespace
./argocd-configure-namespace.sh --namespace team-a
./argocd-configure-namespace.sh --namespace team-b

# Step 3: Namespace admins install ArgoCD
cd ..
./argocd-install.sh --namespace team-a
./argocd-install.sh --namespace team-b
```

### Locked-Down Environment
```bash
# Phase 1: Cluster admin
./argocd-install-cluster-resources.sh
./argocd-configure-namespace.sh --namespace sccat-byop-5

# Phase 2: Namespace admin
cd ..
./argocd-install.sh --namespace sccat-byop-5
```

## Why Cluster Admin Required

| Resource | Scope | Why Needed |
|----------|-------|------------|
| CRDs | Cluster-wide | Define ArgoCD resource types |
| ClusterRoles | Cluster-wide | Define permissions for ArgoCD components |
| ClusterRoleBindings | Cluster-wide | Grant namespace service accounts permissions |
| SCC (OpenShift) | Cluster-wide | Allow pods to run with required security settings |

## Benefits of Separated Scripts

**Old approach** (single script per namespace):
```bash
./argocd-install-cluster-prereqs.sh --namespace team-a  # Reinstalls CRDs
./argocd-install-cluster-prereqs.sh --namespace team-b  # Reinstalls CRDs
./argocd-install-cluster-prereqs.sh --namespace team-c  # Reinstalls CRDs
```

**New approach** (separated scripts):
```bash
./argocd-install-cluster-resources.sh  # Install CRDs ONCE

./argocd-configure-namespace.sh --namespace team-a  # Lightweight
./argocd-configure-namespace.sh --namespace team-b  # Lightweight
./argocd-configure-namespace.sh --namespace team-c  # Lightweight
```

**Benefits**:
- Cluster resources installed once
- Namespace configuration is lightweight
- Clearer separation of concerns
- Better for multi-namespace deployments

---

*Last Updated: 2026-04-27*