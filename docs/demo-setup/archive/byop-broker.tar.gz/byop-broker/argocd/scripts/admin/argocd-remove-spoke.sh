#!/bin/bash
#
# Remove Spoke Cluster from ArgoCD Hub
# Safely removes a spoke cluster registration from hub ArgoCD
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE=""  # Required parameter
HUB_CONTEXT=""
SPOKE_CONTEXT=""
FORCE=false
REMOVE_APPS=true

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Remove a spoke cluster from ArgoCD hub.

Options:
  --hub-context CONTEXT    Hub cluster context (required)
  --spoke-context CONTEXT  Spoke cluster context to remove (required)
  --namespace NAMESPACE    ArgoCD namespace (required)
  --keep-apps             Keep applications targeting this spoke (don't delete)
  -f, --force             Skip confirmation prompt
  -h, --help              Show this help message

Examples:
  # Remove spoke cluster
  $0 --hub-context k3s-cluster-1 --spoke-context k3s-cluster-2 --namespace argocd

  # Remove spoke but keep applications
  $0 --hub-context k3s-cluster-1 --spoke-context k3s-cluster-2 --namespace argocd --keep-apps

  # Auto-confirm removal
  $0 --hub-context k3s-cluster-1 --spoke-context k3s-cluster-2 --namespace argocd --force
  
  # Short form
  $0 --hub-context k3s-cluster-1 --spoke-context k3s-cluster-2 --namespace argocd -f

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --hub-context)
            HUB_CONTEXT="$2"
            shift 2
            ;;
        --spoke-context)
            SPOKE_CONTEXT="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --keep-apps)
            REMOVE_APPS=false
            shift
            ;;
        -f|--force)
            FORCE=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Validate required arguments

# Get current namespace if not specified
if [ -z "$NAMESPACE" ]; then
    if [ -n "$HUB_CONTEXT" ]; then
        NAMESPACE=$(oc --context="${HUB_CONTEXT}" project -q 2>/dev/null || oc --context="${HUB_CONTEXT}" config view --minify -o jsonpath='{..namespace}' 2>/dev/null)
    elif [ -n "$CONTEXT" ]; then
        NAMESPACE=$(oc --context="${CONTEXT}" project -q 2>/dev/null || oc --context="${CONTEXT}" config view --minify -o jsonpath='{..namespace}' 2>/dev/null)
    else
        NAMESPACE=$(oc project -q 2>/dev/null || oc config view --minify -o jsonpath='{..namespace}' 2>/dev/null)
    fi
    
    # If still empty, default to 'argocd'
    if [ -z "$NAMESPACE" ]; then
        NAMESPACE="argocd"
        log_info "No namespace specified and no current namespace set, defaulting to 'argocd'"
    else
        log_info "Using current namespace: ${NAMESPACE}"
    fi
fi
if [ -z "$HUB_CONTEXT" ]; then
    log_error "Hub context is required"
    echo ""
    show_help
    exit 1
fi

if [ -z "$SPOKE_CONTEXT" ]; then
    log_error "Spoke context is required"
    echo ""
    show_help
    exit 1
fi

# Determine and display the actual Kubernetes contexts being used
ACTUAL_HUB_CONTEXT="$HUB_CONTEXT"
ACTUAL_SPOKE_CONTEXT="$SPOKE_CONTEXT"

echo "============================================================"
echo "Remove Spoke Cluster from ArgoCD Hub"
echo "============================================================"
echo ""
echo "⚠️  HUB KUBERNETES CONTEXT: ${ACTUAL_HUB_CONTEXT}"
echo "    (specified via --hub-context)"
echo ""
echo "⚠️  SPOKE KUBERNETES CONTEXT: ${ACTUAL_SPOKE_CONTEXT}"
echo "    (specified via --spoke-context)"
echo ""
echo "Configuration:"
echo "  Hub Context:    ${HUB_CONTEXT}"
echo "  Spoke Context:  ${SPOKE_CONTEXT}"
echo "  Namespace:      ${NAMESPACE}"
echo "  Remove Apps:    ${REMOVE_APPS}"
echo ""

# Check prerequisites
log_info "Checking prerequisites..."

# Check oc
if ! command -v oc &> /dev/null; then
    log_error "oc is not installed"
    exit 1
fi
log_success "oc is installed"

# Check hub context
if ! oc config get-contexts "${HUB_CONTEXT}" &> /dev/null; then
    log_error "Hub context '${HUB_CONTEXT}' not found"
    exit 1
fi
log_success "Hub context '${HUB_CONTEXT}' found"

# Check if ArgoCD namespace exists on hub
if ! oc --context="${HUB_CONTEXT}" get namespace "${NAMESPACE}" &> /dev/null; then
    log_error "ArgoCD namespace '${NAMESPACE}' not found on hub"
    exit 1
fi
log_success "ArgoCD namespace exists on hub"

# Check if spoke cluster is registered
CLUSTER_SECRET="cluster-${SPOKE_CONTEXT}"
if ! oc --context="${HUB_CONTEXT}" -n "${NAMESPACE}" get secret "${CLUSTER_SECRET}" &> /dev/null; then
    log_warning "Spoke cluster '${SPOKE_CONTEXT}' is not registered with hub"
    echo ""
    echo "Available registered clusters:"
    oc --context="${HUB_CONTEXT}" -n "${NAMESPACE}" get secrets -l argocd.argoproj.io/secret-type=cluster -o name | sed 's/secret\//  - /'
    exit 0
fi
log_success "Spoke cluster '${SPOKE_CONTEXT}' is registered"

echo ""
log_success "All prerequisites met"
echo ""

# Show what will be removed
echo "⚠️  WARNING: This will remove:"
echo ""
echo "  ✓ Spoke cluster registration: ${SPOKE_CONTEXT}"
echo "  ✓ Cluster secret: ${CLUSTER_SECRET}"
if [ "$REMOVE_APPS" = true ]; then
echo "  ✓ All applications targeting this spoke cluster"
fi
echo ""

# Confirm removal
if [ "$FORCE" = false ]; then
    read -p "Are you sure you want to remove spoke cluster '${SPOKE_CONTEXT}'? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log_info "Removal cancelled"
        exit 0
    fi
fi

echo ""
echo "============================================================"
echo "Step 1: Finding Applications on Spoke Cluster"
echo "============================================================"
echo ""

log_info "Searching for applications targeting spoke cluster..."
SPOKE_APPS=$(oc --context="${HUB_CONTEXT}" -n "${NAMESPACE}" get applications -o json 2>/dev/null | \
    jq -r ".items[] | select(.spec.destination.name == \"${SPOKE_CONTEXT}\" or .spec.destination.server | contains(\"${SPOKE_CONTEXT}\")) | .metadata.name" || true)

if [ -n "$SPOKE_APPS" ]; then
    echo "Found applications on spoke cluster:"
    # shellcheck disable=SC2001  # sed is appropriate for adding prefix to each line
    echo "$SPOKE_APPS" | sed 's/^/  - /'
    echo ""
    
    if [ "$REMOVE_APPS" = true ]; then
        log_info "Removing applications from spoke cluster..."
        for APP in $SPOKE_APPS; do
            log_info "Deleting application: $APP"
            # Remove finalizers first
            oc --context="${HUB_CONTEXT}" -n "${NAMESPACE}" patch application "$APP" \
                --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null || true
            # Delete application
            oc --context="${HUB_CONTEXT}" -n "${NAMESPACE}" delete application "$APP" --timeout=30s 2>/dev/null || {
                log_warning "Failed to delete application: $APP"
            }
        done
        log_success "Applications removed"
    else
        log_warning "Applications will remain (use --remove-apps to delete them)"
        echo ""
        echo "Note: These applications will fail to sync after spoke removal."
        echo "You may want to delete them manually or update their destination."
    fi
else
    log_info "No applications found on spoke cluster"
fi

echo ""
echo "============================================================"
echo "Step 2: Removing Spoke Cluster Registration"
echo "============================================================"
echo ""

log_info "Removing cluster secret: ${CLUSTER_SECRET}"
oc --context="${HUB_CONTEXT}" -n "${NAMESPACE}" delete secret "${CLUSTER_SECRET}" --timeout=30s 2>/dev/null || {
    log_error "Failed to delete cluster secret"
    exit 1
}
log_success "Cluster secret removed"

echo ""
echo "============================================================"
echo "✅ Spoke Cluster Removal Complete!"
echo "============================================================"
echo ""

# Verify removal
log_info "Verifying removal..."
if oc --context="${HUB_CONTEXT}" -n "${NAMESPACE}" get secret "${CLUSTER_SECRET}" &> /dev/null; then
    log_warning "Cluster secret still exists"
else
    log_success "Cluster secret successfully removed"
fi

echo ""
echo "Summary:"
echo "  ✓ Spoke cluster '${SPOKE_CONTEXT}' unregistered from hub"
if [ "$REMOVE_APPS" = true ] && [ -n "$SPOKE_APPS" ]; then
echo "  ✓ Applications removed from spoke cluster"
fi
echo ""

log_info "Remaining registered clusters:"
oc --context="${HUB_CONTEXT}" -n "${NAMESPACE}" get secrets -l argocd.argoproj.io/secret-type=cluster -o name | sed 's/secret\//  - /'

echo ""
log_success "Removal complete!"

# Made with Bob