#!/bin/bash
#
# Generic ArgoCD Installation Script
# Platform-agnostic installation for any Kubernetes cluster
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE=""
INSECURE=false
CONTEXT=""
DRY_RUN=false
IMAGE_REPOSITORY=""  # Custom image repository (e.g., my-registry.example.com/argocd)

# Build oc command with context if specified
oc_cmd() {
    if [ -n "$CONTEXT" ]; then
        oc --context="${CONTEXT}" "$@"
    else
        oc "$@"
    fi
}

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Install ArgoCD on a Kubernetes cluster.

Options:
  --context CONTEXT             Kubernetes context (optional; uses current context if omitted)
  --namespace NAMESPACE         ArgoCD namespace (required)
  --image-repository REPOSITORY Custom image repository to replace default registries
                                (e.g., my-registry.example.com)
  --insecure                    Disable TLS verification (not recommended for production)
  --dry-run                     Show what would be done without making changes
  -h, --help                    Show this help message

Examples:
  # Dry run to see what would be installed
  $0 --context my-cluster --namespace argocd --dry-run

  # Install on specific cluster context
  $0 --context my-cluster --namespace argocd

  # Install in custom namespace
  $0 --context my-cluster --namespace gitops

  # Install with insecure mode (development only)
  $0 --context my-cluster --namespace argocd --insecure

  # Install with custom image repository (e.g., air-gapped environment)
  $0 --context my-cluster --namespace argocd --image-repository my-registry.example.com

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --context)
            CONTEXT="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --image-repository)
            IMAGE_REPOSITORY="$2"
            shift 2
            ;;
        --insecure)
            INSECURE=true
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Determine and display the actual Kubernetes context being used
if [ -n "$CONTEXT" ]; then
    ACTUAL_CONTEXT="$CONTEXT"
    CONTEXT_SOURCE="specified via --context"
else
    ACTUAL_CONTEXT=$(kubectl config current-context 2>/dev/null || echo "unknown")
    CONTEXT_SOURCE="using current context"
fi

# Namespace is required
if [ -z "$NAMESPACE" ]; then
    log_error "Namespace is required"
    echo ""
    echo "Specify a namespace explicitly:"
    echo "  $0 --namespace YOUR_NAMESPACE"
    exit 1
fi

echo "============================================================"
echo "ArgoCD Installation"
echo "============================================================"
echo ""
echo "⚠️  KUBERNETES CONTEXT: ${ACTUAL_CONTEXT}"
echo "    (${CONTEXT_SOURCE})"
echo ""
echo "Configuration:"
if [ -n "$CONTEXT" ]; then
    echo "  Context:    ${CONTEXT}"
else
    echo "  Context:    current oc context"
fi
echo "  Namespace:  ${NAMESPACE}"
echo "  Version:    ${VERSION}"
if [ -n "$IMAGE_REPOSITORY" ]; then
    echo "  Image Repository: ${IMAGE_REPOSITORY} (replacing default registries)"
else
    echo "  Image Repository: quay.io, ghcr.io, public.ecr.aws (default)"
fi
echo "  Insecure:   ${INSECURE}"
echo "  Dry Run:    ${DRY_RUN}"
echo ""

if [ "$DRY_RUN" = true ]; then
    log_info "DRY RUN MODE - No changes will be made"
    echo ""
fi

# Check prerequisites
log_info "Checking prerequisites..."

# Check oc
if ! command -v oc &> /dev/null; then
    log_error "oc is not installed"
    echo ""
    echo "Please install oc:"
    echo "  https://kubernetes.io/docs/tasks/tools/"
    exit 1
fi
log_success "oc is installed"

# Check if context exists
if [ -n "$CONTEXT" ]; then
    if ! oc config get-contexts "${CONTEXT}" &> /dev/null; then
        log_error "Kubernetes context '${CONTEXT}' not found"
        echo ""
        echo "Available contexts:"
        oc config get-contexts
        exit 1
    fi
    log_success "Context '${CONTEXT}' found"
else
    log_info "Using current oc context"
fi

# Check cluster connectivity
# Use 'oc whoami' which works on OpenShift to verify connectivity
if ! oc_cmd whoami &> /dev/null; then
    if [ -n "$CONTEXT" ]; then
        log_error "Cannot connect to cluster '${CONTEXT}'"
    else
        log_error "Cannot connect to the current cluster context"
    fi
    echo ""
    echo "Please ensure the cluster is accessible and credentials are valid"
    exit 1
fi
if [ -n "$CONTEXT" ]; then
    log_success "Cluster '${CONTEXT}' is accessible"
else
    log_success "Current cluster context is accessible"
fi

# Check cluster version
CLUSTER_VERSION=$(oc_cmd version --short 2>/dev/null | grep "Server Version" | awk '{print $3}' || echo "unknown")
log_info "Cluster version: ${CLUSTER_VERSION}"

echo ""
log_success "All prerequisites met"
echo ""

# Resolve manifest path relative to this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANIFEST="${SCRIPT_DIR}/../manifests/install.yaml"

if [ ! -f "${MANIFEST}" ]; then
    log_error "Manifest not found: ${MANIFEST}"
    exit 1
fi

if [ "$DRY_RUN" = true ]; then
    echo "============================================================"
    echo "DRY RUN - Installation Steps"
    echo "============================================================"
    echo ""
    echo "The following actions would be performed:"
    echo ""
    echo "Step 1: Create namespace '${NAMESPACE}'"
    echo "Step 2: Apply ArgoCD manifest from:"
    echo "        ${MANIFEST}"
    echo "        Using --server-side to handle large CRDs (ApplicationSet)"
    echo "Step 3: Wait for ArgoCD components to be ready"
    echo "        - argocd-server deployment"
    echo "        - argocd-application-controller statefulset"
    echo "        - argocd-repo-server deployment"
    echo "        - argocd-applicationset-controller deployment"
    echo "Step 4: Configure ArgoCD settings"
    if [ "$INSECURE" = true ]; then
        echo "        - Enable insecure mode"
    fi
    echo "        - Set sync interval to 30 seconds"
    echo ""
    log_success "Dry run complete - no changes made"
    exit 0
fi

echo ""
echo "============================================================"
echo "Step 1: Creating namespace"
echo "============================================================"
echo ""

log_info "Checking namespace '${NAMESPACE}'..."
if oc_cmd get namespace "${NAMESPACE}" &> /dev/null; then
    log_success "Namespace '${NAMESPACE}' already exists"
else
    log_info "Creating namespace '${NAMESPACE}'..."
    if oc_cmd create namespace "${NAMESPACE}"; then
        log_success "Namespace '${NAMESPACE}' created"
    else
        log_error "Failed to create namespace '${NAMESPACE}'"
        exit 1
    fi
fi

echo ""
echo "============================================================"
echo "Step 2: Installing ArgoCD"
echo "============================================================"
echo ""

MANIFEST_FILE=$(mktemp /tmp/argocd-install.XXXXXX.yaml)

log_info "Using local ArgoCD manifest: ${MANIFEST}"
if ! cp "${MANIFEST}" "${MANIFEST_FILE}"; then
    log_error "Failed to copy manifest"
    rm -f "${MANIFEST_FILE}"
    exit 1
fi

# Rewrite hardcoded 'argocd' namespace in ClusterRoleBinding subjects
if [ "${NAMESPACE}" != "argocd" ]; then
    log_info "Rewriting namespace references from 'argocd' to '${NAMESPACE}'..."
    sed -i.tmp "s|namespace: argocd|namespace: ${NAMESPACE}|g" "${MANIFEST_FILE}"
    rm -f "${MANIFEST_FILE}.tmp"
fi
log_success "Manifest loaded"

# Replace image repository if custom repository specified
if [ -n "$IMAGE_REPOSITORY" ]; then
    log_info "Replacing image repositories with: ${IMAGE_REPOSITORY}"
    
    cp "${MANIFEST_FILE}" "${MANIFEST_FILE}.bak"
    
    sed -i.tmp \
        -e "s|quay\.io/argoproj/argocd:|${IMAGE_REPOSITORY}/argocd:|g" \
        -e "s|ghcr\.io/dexidp/dex:|${IMAGE_REPOSITORY}/dex:|g" \
        -e "s|public\.ecr\.aws/docker/library/redis:|${IMAGE_REPOSITORY}/redis:|g" \
        "${MANIFEST_FILE}"
    
    rm -f "${MANIFEST_FILE}.tmp"
    
    if grep -q "${IMAGE_REPOSITORY}" "${MANIFEST_FILE}"; then
        log_success "Image repositories replaced successfully"
        log_info "Images that will be used:"
        grep "image:" "${MANIFEST_FILE}" | sed 's/.*image: //' | sort -u | sed 's/^/  /'
    else
        log_error "Failed to replace image repositories"
        log_info "Restoring original manifest..."
        mv "${MANIFEST_FILE}.bak" "${MANIFEST_FILE}"
        exit 1
    fi
    
    rm -f "${MANIFEST_FILE}.bak"
else
    log_info "Using default image repositories (quay.io, ghcr.io, public.ecr.aws)"
fi

log_info "Applying ArgoCD manifest with server-side apply..."
log_info "Using --server-side to avoid annotation size errors with ApplicationSet CRD"
if oc_cmd apply -n "${NAMESPACE}" --server-side -f "${MANIFEST_FILE}" 2>&1 | grep -v "^Warning:"; then
    log_success "ArgoCD manifest applied"
else
    log_warning "Some resources may have failed to apply"
    log_info "Checking if core components are being created..."
fi

# Clean up manifest file
rm -f "${MANIFEST_FILE}"

echo ""
echo "============================================================"
echo "Step 3: Populating ArgoCD secrets"
echo "============================================================"
echo ""

# Generate random passwords and tokens
REDIS_PASSWORD=$(openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64)
SERVER_SECRET=$(openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64)

log_info "Creating/updating argocd-redis secret..."
oc_cmd create secret generic argocd-redis \
    --from-literal=auth="${REDIS_PASSWORD}" \
    -n "${NAMESPACE}" \
    --dry-run=client -o yaml | oc_cmd apply -f - || {
    log_error "Failed to create Redis secret"
    exit 1
}
log_success "Redis secret ready"

log_info "Creating/updating argocd-secret..."
oc_cmd create secret generic argocd-secret \
    --from-literal=server.secretkey="${SERVER_SECRET}" \
    -n "${NAMESPACE}" \
    --dry-run=client -o yaml | oc_cmd apply -f - || {
    log_error "Failed to create argocd-secret"
    exit 1
}
log_success "ArgoCD secret ready"

log_info "Waiting for ArgoCD to create argocd-initial-admin-secret..."
INITIAL_ADMIN_SECRET_READY=false
for _ in {1..60}; do
    if oc_cmd get secret argocd-initial-admin-secret -n "${NAMESPACE}" &> /dev/null; then
        INITIAL_ADMIN_SECRET_READY=true
        break
    fi
    sleep 2
done

if [ "${INITIAL_ADMIN_SECRET_READY}" = true ]; then
    log_success "Initial admin secret created by ArgoCD"
else
    log_warning "argocd-initial-admin-secret was not created yet"
    log_info "ArgoCD may still be starting; retrieve the password later once the secret exists"
fi

echo ""
echo "============================================================"
echo "Step 4: Configuring OpenShift Security Context Constraints"
echo "============================================================"
echo ""

# Check if we're on OpenShift by looking for the 'oc' command and OpenShift-specific resources
IS_OPENSHIFT=false
if command -v oc &> /dev/null; then
    if oc_cmd api-resources | grep -q "securitycontextconstraints"; then
        IS_OPENSHIFT=true
    fi
fi

if [ "$IS_OPENSHIFT" = true ]; then
    log_info "OpenShift detected - configuring Security Context Constraints..."
    
    # Grant anyuid SCC to argocd-redis service account
    # This is required because Redis container runs as UID 999, which is outside
    # the default UID range assigned to OpenShift namespaces
    log_info "Granting anyuid SCC to argocd-redis service account..."
    if oc_cmd adm policy add-scc-to-user anyuid -z argocd-redis -n "${NAMESPACE}"; then
        log_success "anyuid SCC granted to argocd-redis"
    else
        log_warning "Failed to grant anyuid SCC - Redis may fail to start"
        log_info "You can manually fix this later with:"
        log_info "  oc adm policy add-scc-to-user anyuid -z argocd-redis -n ${NAMESPACE}"
    fi
    
    # Grant anyuid SCC to argocd-application-controller service account
    # This may be needed for some ArgoCD operations
    log_info "Granting anyuid SCC to argocd-application-controller service account..."
    if oc_cmd adm policy add-scc-to-user anyuid -z argocd-application-controller -n "${NAMESPACE}"; then
        log_success "anyuid SCC granted to argocd-application-controller"
    else
        log_warning "Failed to grant anyuid SCC to application controller"
    fi
    
    log_success "OpenShift SCC configuration complete"
    
    # Additional OpenShift-specific fixes for Redis deployment
    log_info "Applying OpenShift-specific fixes to Redis deployment..."
    
    # Wait a moment for the deployment to be created
    sleep 5
    
    # Remove seccomp profiles and runAsNonRoot from Redis deployment
    # These conflict with OpenShift SCCs and cause pod creation failures
    log_info "Removing seccomp profiles from Redis deployment..."
    
    # Create JSON patch to remove problematic security context settings
    cat > /tmp/redis-openshift-fix.json << 'EOF'
[
  {
    "op": "remove",
    "path": "/spec/template/spec/securityContext/seccompProfile"
  },
  {
    "op": "remove",
    "path": "/spec/template/spec/securityContext/runAsUser"
  },
  {
    "op": "remove",
    "path": "/spec/template/spec/securityContext/runAsNonRoot"
  },
  {
    "op": "remove",
    "path": "/spec/template/spec/initContainers/0/securityContext/seccompProfile"
  }
]
EOF
    
    # Apply the patch (may fail if deployment doesn't exist yet, that's ok)
    if oc_cmd patch deployment argocd-redis -n "${NAMESPACE}" \
        --type=json --patch-file /tmp/redis-openshift-fix.json 2>/dev/null; then
        log_success "Redis deployment patched for OpenShift compatibility"
    else
        log_warning "Could not patch Redis deployment (it may not exist yet)"
        log_info "Redis will be patched automatically when it's created"
    fi
    
    # Clean up temp file
    rm -f /tmp/redis-openshift-fix.json
    
else
    log_info "Not running on OpenShift - skipping SCC configuration"
fi

echo ""
echo "============================================================"
echo "Step 5: Waiting for ArgoCD to be ready"
echo "============================================================"
echo ""

log_info "Waiting for ArgoCD server deployment..."
if oc_cmd wait --for=condition=available --timeout=300s \
    deployment/argocd-server -n "${NAMESPACE}"; then
    log_success "ArgoCD server is ready"
else
    log_warning "Timeout waiting for ArgoCD server"
    log_info "Checking pod status..."
    oc_cmd get pods -n "${NAMESPACE}"
    echo ""
    log_warning "ArgoCD may still be starting. Check pod status above."
fi

echo ""
log_info "Waiting for ArgoCD application controller..."
if oc_cmd wait --for=condition=ready --timeout=300s \
    pod -l app.kubernetes.io/name=argocd-application-controller -n "${NAMESPACE}"; then
    log_success "ArgoCD application controller is ready"
else
    log_warning "Timeout waiting for application controller"
fi

echo ""
log_info "Waiting for ArgoCD repo server..."
if oc_cmd wait --for=condition=ready --timeout=300s \
    pod -l app.kubernetes.io/name=argocd-repo-server -n "${NAMESPACE}"; then
    log_success "ArgoCD repo server is ready"
else
    log_warning "Timeout waiting for repo server"
fi

echo ""
echo "============================================================"
echo "Step 6: Configuring ArgoCD"
echo "============================================================"
echo ""

# Configure insecure mode if requested
if [ "$INSECURE" = true ]; then
    log_warning "Configuring insecure mode (not recommended for production)"
    oc_cmd patch configmap argocd-cmd-params-cm -n "${NAMESPACE}" \
        --type merge -p '{"data":{"server.insecure":"true"}}' || {
        log_warning "Failed to configure insecure mode"
    }
    
    # Restart server to pick up changes
    log_info "Restarting ArgoCD server..."
    oc_cmd rollout restart deployment argocd-server -n "${NAMESPACE}"
    oc_cmd rollout status deployment argocd-server -n "${NAMESPACE}" --timeout=120s || {
        log_warning "Timeout waiting for server restart"
    }
fi

# Configure sync interval
log_info "Configuring sync interval to 30 seconds..."
oc_cmd patch configmap argocd-cm -n "${NAMESPACE}" \
    --type merge -p '{"data":{"timeout.reconciliation":"30s"}}' || {
    log_warning "Failed to configure sync interval"
}

# Restart application controller to pick up changes
log_info "Restarting ArgoCD application controller..."
oc_cmd rollout restart statefulset argocd-application-controller -n "${NAMESPACE}"
oc_cmd rollout status statefulset argocd-application-controller -n "${NAMESPACE}" --timeout=120s || {
    log_warning "Timeout waiting for controller restart"
}

echo ""
echo "============================================================"
echo "Step 7: Creating OpenShift Route"
echo "============================================================"
echo ""

# Check if we're on OpenShift and create a route
if [ "$IS_OPENSHIFT" = true ]; then
    log_info "Creating OpenShift Route for ArgoCD server..."
    
    # Create route with TLS passthrough termination
    if oc_cmd apply -f - <<EOF
apiVersion: route.openshift.io/v1
kind: Route
metadata:
  name: argocd-server
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/name: argocd-server
    app.kubernetes.io/part-of: argocd
    app.kubernetes.io/component: server
spec:
  to:
    kind: Service
    name: argocd-server
    weight: 100
  port:
    targetPort: https
  tls:
    termination: passthrough
    insecureEdgeTerminationPolicy: Redirect
  wildcardPolicy: None
EOF
    then
        log_success "Route created successfully"
        
        # Get the route hostname
        ROUTE_HOST=$(oc_cmd get route argocd-server -n "${NAMESPACE}" \
            -o jsonpath='{.spec.host}' 2>/dev/null || echo "")
        
        if [ -n "$ROUTE_HOST" ]; then
            log_success "ArgoCD is accessible at: https://${ROUTE_HOST}"
        fi
    else
        log_warning "Failed to create route - you may need to create it manually"
    fi
else
    log_info "Not running on OpenShift - skipping route creation"
    log_info "For non-OpenShift clusters, consider creating an Ingress resource"
fi

echo ""
echo "============================================================"
echo "✅ ArgoCD Installation Complete!"
echo "============================================================"
echo ""

# Get admin password if ArgoCD has created the initial secret
log_info "Retrieving admin password..."
ADMIN_PASSWORD=$(oc_cmd -n "${NAMESPACE}" get secret argocd-initial-admin-secret \
    -o jsonpath="{.data.password}" 2>/dev/null | base64 -d 2>/dev/null || echo "")

if [ -n "$ADMIN_PASSWORD" ]; then
    echo "ArgoCD Credentials:"
    echo "  Username: admin"
    echo "  Password: ${ADMIN_PASSWORD}"
    echo ""
else
    log_warning "Could not retrieve admin password from argocd-initial-admin-secret"
    echo "ArgoCD may not have created the initial secret yet."
    echo "To get the password manually once available:"
    echo "  oc -n ${NAMESPACE} get secret argocd-initial-admin-secret -o jsonpath='{.data.password}' | base64 -d"
    echo ""
fi

echo "Access ArgoCD UI:"

# Check if route exists and get hostname (OpenShift)
if [ "$IS_OPENSHIFT" = true ]; then
    ROUTE_HOST=$(oc_cmd get route argocd-server -n "${NAMESPACE}" \
        -o jsonpath='{.spec.host}' 2>/dev/null || echo "")
    
    if [ -n "$ROUTE_HOST" ]; then
        echo "  Via OpenShift Route:"
        echo "     https://${ROUTE_HOST}"
        echo ""
        echo "  Or via port forward:"
        echo "     oc port-forward svc/argocd-server -n ${NAMESPACE} 8080:443"
        echo ""
        if [ "$INSECURE" = true ]; then
            echo "     Then open: http://localhost:8080"
        else
            echo "     Then open: https://localhost:8080"
        fi
    else
        echo "  1. Port forward:"
        echo "     oc port-forward svc/argocd-server -n ${NAMESPACE} 8080:443"
        echo ""
        if [ "$INSECURE" = true ]; then
            echo "  2. Open browser to: http://localhost:8080"
        else
            echo "  2. Open browser to: https://localhost:8080"
        fi
    fi
else
    echo "  1. Port forward:"
    echo "     oc port-forward svc/argocd-server -n ${NAMESPACE} 8080:443"
    echo ""
    if [ "$INSECURE" = true ]; then
        echo "  2. Open browser to: http://localhost:8080"
    else
        echo "  2. Open browser to: https://localhost:8080"
    fi
fi
echo ""

echo "Verify Installation:"
echo "  oc get pods -n ${NAMESPACE}"
echo "  oc get applications -n ${NAMESPACE}"
echo ""

echo "Next Steps:"
echo "  1. Configure Git repository access (required):"
if [ -n "$CONTEXT" ]; then
echo "     # For SSH authentication:"
echo "     ./argocd-configure-repo.sh --context ${CONTEXT} --repo-url git@github.com:org/repo.git --ssh-key-path ~/.ssh/deploy_key"
echo ""
echo "     # For HTTPS authentication:"
echo "     ./argocd-configure-repo.sh --context ${CONTEXT} --repo-url https://github.com/org/repo.git --token <TOKEN>"
else
echo "     # For SSH authentication:"
echo "     ./argocd-configure-repo.sh --repo-url git@github.com:org/repo.git --ssh-key-path ~/.ssh/deploy_key"
echo ""
echo "     # For HTTPS authentication:"
echo "     ./argocd-configure-repo.sh --repo-url https://github.com/org/repo.git --token <TOKEN>"
fi
echo ""
echo "  2. Add spoke clusters (optional):"
echo "     # Not yet implemented - use kubectl to register clusters manually"
echo ""
echo "  3. Deploy applications via ArgoCD Application CRs"
echo ""

log_success "Installation complete!"

# Made with Bob
