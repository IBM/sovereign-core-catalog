# Sovereign Broker Helm Chart

A Helm chart for deploying the Sovereign Broker and Catalog UI to Kubernetes.

## Overview

This chart deploys:
- **Broker**: GitOps-enabled service broker for provisioning services
- **Catalog UI**: Web interface for browsing and provisioning services

## Prerequisites

- Kubernetes 1.19+
- Helm 3.0+
- Image pull secret for Quay registry
- GitHub token for GitOps operations
- SSH key for Git authentication

## Installation

### 1. Create Namespace

```bash
kubectl create namespace byop
```

### 2. Create Image Pull Secret

```bash
kubectl create secret docker-registry quay-pull-secret \
  --docker-server=registry.example.com \
  --docker-username=<username> \
  --docker-password=<password> \
  -n byop
```

### 3. Create Broker Secrets

```bash
kubectl create secret generic byop-broker-secrets \
  --from-literal=github-token="<your-github-token>" \
  --from-file=ssh-private-key=/path/to/id_rsa \
  -n byop
```

### 4. Install Chart

```bash
helm install byop ./chart \
  --namespace byop \
  --set broker.gitops.repoUrl="git@github.com:your-org/your-repo.git"
```

## Configuration

### Global Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `global.imageRegistry` | Image registry URL | `registry.example.com` |
| `global.imageOrganization` | Image organization/namespace | `sovereign-services` |
| `global.imagePullSecrets` | Image pull secrets | `[{name: quay-pull-secret}]` |

### Broker Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `broker.enabled` | Enable broker deployment | `true` |
| `broker.image.repository` | Broker image repository | `broker` |
| `broker.image.tag` | Broker image tag | `latest` |
| `broker.replicaCount` | Number of broker replicas | `1` |
| `broker.service.port` | Broker service port | `8080` |
| `broker.gunicorn.workers` | Gunicorn worker count for the broker | `2` |
| `broker.gitops.repoUrl` | GitOps repository URL | Required |
| `broker.gitops.repoBranch` | GitOps repository branch | `main` |
| `broker.storage.persistent` | Use persistent storage | `true` |
| `broker.storage.size` | Storage size | `1Gi` |
| `broker.clusters` | List of available clusters for provisioning | See below |

#### Gunicorn Workers

The broker now defaults to a conservative `2` Gunicorn workers to reduce memory pressure in small namespace quotas.

Override via Helm when more throughput is needed:

```bash
helm upgrade byop ./chart \
  --namespace byop \
  --reuse-values \
  --set broker.gunicorn.workers=4
```

Or in a values file:

```yaml
broker:
  gunicorn:
    workers: 4
```

`auto` is still supported as an explicit override, but it is no longer the default because it can over-allocate workers in constrained environments.

#### Cluster Configuration

The `broker.clusters` parameter defines the Kubernetes clusters available for service provisioning. By default, only the hub cluster (where the broker is deployed) is configured:

```yaml
broker:
  clusters:
    - name: "hub-cluster"
      server: "https://kubernetes.default.svc"
      type: "hub"
```

**Important: Cluster Names are User-Defined Labels**

The `name` field in cluster configuration is a **user-defined label** used by the broker for:
- Identifying clusters in provisioning requests
- Logging and metadata
- Organizing multi-cluster deployments

**The cluster name does NOT need to match:**
- Kubernetes cluster name
- kubectl context name
- ArgoCD cluster name
- Any system-defined identifier

**What Matters:**
- **`server` URL**: Must be the actual Kubernetes API server URL that ArgoCD can reach
- **Consistency**: Use the same cluster name when provisioning services via the broker API

**Key Points:**
- **Hub cluster**: Always uses `https://kubernetes.default.svc` (in-cluster service URL)
- **Cluster name**: Choose any meaningful name for your organization (e.g., "prod-hub", "dev-cluster", "us-east-1")
- **Spoke clusters**: Add additional clusters for multi-cluster deployments

**Multi-cluster Example:**

```yaml
broker:
  clusters:
    - name: "production-hub"              # User-defined label
      server: "https://kubernetes.default.svc"
      type: "hub"
    - name: "spoke-us-east"               # User-defined label
      server: "https://10.0.1.100:6443"   # Actual API server URL
      type: "spoke"
    - name: "spoke-eu-west"               # User-defined label
      server: "https://10.0.2.100:6443"   # Actual API server URL
      type: "spoke"
```

**Getting Spoke Cluster Server URLs:**

```bash
# From the spoke cluster context
kubectl config view --minify -o jsonpath='{.clusters[0].cluster.server}'

# Or from ArgoCD (if cluster is already registered)
argocd cluster list
```

**Usage in Provisioning Requests:**

When provisioning a service, specify the cluster name in the request:

```bash
curl -X PUT http://broker-url/v2/service_instances/my-instance \
  -H "Content-Type: application/json" \
  -d '{
    "service_id": "mysql",
    "plan_id": "small",
    "parameters": {
      "cluster_name": "spoke-us-east"  # Use the name from your values.yaml
    }
  }'
```

### Catalog App Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `catalogApp.enabled` | Enable catalog app deployment | `true` |
| `catalogApp.image.repository` | Catalog app image repository | `catalog-ui` |
| `catalogApp.image.tag` | Catalog app image tag | `latest` |
| `catalogApp.replicaCount` | Number of catalog app replicas | `2` |
| `catalogApp.service.port` | Catalog app service port | `8080` |
| `catalogApp.route.enabled` | Enable OpenShift route | `true` |
| `catalogApp.route.host` | Route hostname (auto-generated if empty) | `""` |
| `catalogApp.route.tls.enabled` | Enable TLS for route | `true` |
| `catalogApp.route.tls.termination` | TLS termination type | `edge` |
| `catalogApp.ingress.enabled` | Enable ingress (non-OpenShift) | `false` |
| `catalogApp.autoscaling.enabled` | Enable HPA | `true` |
| `catalogApp.autoscaling.minReplicas` | Minimum replicas | `2` |
| `catalogApp.autoscaling.maxReplicas` | Maximum replicas | `10` |

**Note:** OpenShift Route is enabled by default. For non-OpenShift Kubernetes clusters, disable the route and enable ingress instead.

## Examples

### Basic Installation

```bash
helm install byop ./chart \
  --namespace byop \
  --create-namespace
```

### With Custom Values

```bash
helm install byop ./chart \
  --namespace byop \
  --values custom-values.yaml
```

### OpenShift Deployment (Default)

Route is enabled by default for OpenShift:

```bash
helm install byop ./chart \
  --namespace byop \
  --set global.imageRegistry=quay.io \
  --set global.imageOrganization=your-org

# Get the route URL
oc get route byop-catalog-app -n byop
```

### Non-OpenShift Kubernetes Deployment

Disable route and enable ingress:

```bash
helm install byop ./chart \
  --namespace byop \
  --set global.imageRegistry=quay.io \
  --set global.imageOrganization=your-org \
  --set catalogApp.route.enabled=false \
  --set catalogApp.ingress.enabled=true \
  --set catalogApp.ingress.hosts[0].host=catalog.example.com
```

### Use EmptyDir Instead of PVC

```bash
helm install byop ./chart \
  --namespace byop \
  --set broker.storage.persistent=false
```

## Upgrading

```bash
helm upgrade byop ./chart \
  --namespace byop \
  --reuse-values
```

## Uninstalling

```bash
helm uninstall byop --namespace byop
```

## Values File Example

Create a `custom-values.yaml`:

```yaml
global:
  imageRegistry: registry.example.com
  imageOrganization: sovereign-services

broker:
  gitops:
    repoUrl: "git@github.com:my-org/my-gitops-repo.git"
    repoBranch: "main"
  
  resources:
    requests:
      cpu: 200m
      memory: 512Mi
    limits:
      cpu: 1000m
      memory: 1Gi

catalogApp:
  ingress:
    enabled: true
    className: nginx
    hosts:
      - host: catalog.my-domain.com
        paths:
          - path: /
            pathType: Prefix
    tls:
      - secretName: catalog-tls
        hosts:
          - catalog.my-domain.com
  
  autoscaling:
    minReplicas: 3
    maxReplicas: 20
```

## Troubleshooting

### Check Pod Status

```bash
kubectl get pods -n byop
```

### View Logs

```bash
# Broker logs
kubectl logs -n byop deployment/byop-broker -f

# Catalog app logs
kubectl logs -n byop deployment/byop-catalog-app -f
```

### Verify Services

```bash
kubectl get svc -n byop
```

### Test Broker API

```bash
kubectl port-forward -n byop svc/byop-broker 8080:8080
curl http://localhost:8080/v2/catalog
```

### Test Catalog UI

```bash
kubectl port-forward -n byop svc/byop-catalog-app 8081:8080
# Open browser to http://localhost:8081
```

## Architecture

```
┌─────────────────┐
│   Catalog UI    │
│   (Web App)     │
└────────┬────────┘
         │ HTTP
         ▼
┌─────────────────┐
│     Broker      │
│  (Service API)  │
└────────┬────────┘
         │ GitOps
         ▼
┌─────────────────┐
│  Git Repository │
│  (Manifests)    │
└────────┬────────┘
         │ ArgoCD
         ▼
┌─────────────────┐
│   Kubernetes    │
│   (Services)    │
└─────────────────┘
```

## Support

For issues and questions, please open an issue in the repository.

## License

Copyright © 2026 Development Team