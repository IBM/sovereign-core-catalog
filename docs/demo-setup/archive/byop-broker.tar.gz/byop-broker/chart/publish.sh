#!/bin/bash
#
# HELM_PASSWORD=$BYOP_WRITER_PASSWORD ./chart/publish.sh
#
SCRIPT_DIR=$(cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd)
CHART_DIR=$SCRIPT_DIR

HELM_REPO=quay.io
HELM_ORG=your-org
HELM_USER=your-org+byop_writer
HELM_PASSWORD=${HELM_PASSWORD:?}
CHART=byop
VERSION=$(cat "${CHART_DIR}/Chart.yaml" | sed -n 's/^version:\(.*\)$/\1/p' | tr -d ' ')

helm package "${CHART_DIR}"
echo "$HELM_PASSWORD" | helm registry login "$HELM_REPO" --username="$HELM_USER" --password-stdin
helm push "${CHART}-${VERSION}.tgz" "oci://${HELM_REPO}/${HELM_ORG}"
