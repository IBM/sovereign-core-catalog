{{/*
Expand the name of the chart.
*/}}
{{- define "byop.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "byop.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "byop.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "byop.labels" -}}
helm.sh/chart: {{ include "byop.chart" . }}
{{ include "byop.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "byop.selectorLabels" -}}
app.kubernetes.io/name: {{ include "byop.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Broker labels
*/}}
{{- define "byop.broker.labels" -}}
{{ include "byop.labels" . }}
app.kubernetes.io/component: broker
{{- end }}

{{/*
Broker selector labels
*/}}
{{- define "byop.broker.selectorLabels" -}}
{{ include "byop.selectorLabels" . }}
app.kubernetes.io/component: broker
{{- end }}

{{/*
Catalog App labels
*/}}
{{- define "byop.catalogApp.labels" -}}
{{ include "byop.labels" . }}
app.kubernetes.io/component: catalog-app
{{- end }}

{{/*
Catalog App selector labels
*/}}
{{- define "byop.catalogApp.selectorLabels" -}}
{{ include "byop.selectorLabels" . }}
app.kubernetes.io/component: catalog-app
{{- end }}

{{/*
Create the name of the broker service account to use
*/}}
{{- define "byop.broker.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (printf "%s-broker" (include "byop.fullname" .)) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the name of the catalog-app service account to use
*/}}
{{- define "byop.catalogApp.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (printf "%s-catalog-app" (include "byop.fullname" .)) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Broker image
*/}}
{{- define "byop.broker.image" -}}
{{- $registry := .Values.global.imageRegistry }}
{{- $org := .Values.global.imageOrganization }}
{{- $repo := .Values.broker.image.repository }}
{{- $tag := .Values.broker.image.tag | default .Chart.AppVersion }}
{{- if and $registry $org }}
{{- printf "%s/%s/%s:%s" $registry $org $repo $tag }}
{{- else if $registry }}
{{- printf "%s/%s:%s" $registry $repo $tag }}
{{- else }}
{{- printf "%s:%s" $repo $tag }}
{{- end }}
{{- end }}

{{/*
Catalog App image
*/}}
{{- define "byop.catalogApp.image" -}}
{{- $registry := .Values.global.imageRegistry }}
{{- $org := .Values.global.imageOrganization }}
{{- $repo := .Values.catalogApp.image.repository }}
{{- $tag := .Values.catalogApp.image.tag | default .Chart.AppVersion }}
{{- if and $registry $org }}
{{- printf "%s/%s/%s:%s" $registry $org $repo $tag }}
{{- else if $registry }}
{{- printf "%s/%s:%s" $registry $repo $tag }}
{{- else }}
{{- printf "%s:%s" $repo $tag }}
{{- end }}
{{- end }}

{{/*
Broker URL for catalog app
*/}}
{{- define "byop.catalogApp.brokerUrl" -}}
{{- if .Values.catalogApp.brokerUrl }}
{{- .Values.catalogApp.brokerUrl }}
{{- else }}
{{- printf "http://%s-broker.%s.svc.cluster.local:%d" (include "byop.fullname" .) .Release.Namespace (int .Values.broker.service.port) }}
{{- end }}
{{- end }}

{{/*
Validate broker authentication configuration
Fails the deployment if auth is enabled but required configuration is missing
*/}}
{{- define "byop.broker.validateAuth" -}}
{{- if ne (.Values.broker.auth.enabled | toString) "false" }}
  {{- if and (not .Values.broker.auth.jwksUrl) (not .Values.cluster.domain) }}
    {{- fail "\n\n❌ CONFIGURATION ERROR: JWT authentication is enabled but configuration is incomplete.\n\nWhen broker.auth.enabled=true, you must provide EITHER:\n  1. Set broker.auth.enabled=false to disable authentication (not recommended for production)\n  OR\n  2. Provide cluster.domain (e.g., 'cluster.example.com')\n  OR\n  3. Provide explicit broker.auth.jwksUrl\n\nExample:\n  helm install byop . --set cluster.domain=your-cluster.example.com\n  helm install byop . --set broker.auth.enabled=false\n  helm install byop . --set broker.auth.jwksUrl=https://your-idp.example.com/jwks\n" }}
  {{- end }}
{{- end }}
{{- end }}