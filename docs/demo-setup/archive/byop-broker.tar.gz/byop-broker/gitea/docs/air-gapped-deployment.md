# Air-Gapped Deployment Guide for Gitea

Complete guide for deploying Gitea in air-gapped (disconnected) environments using image mirroring.

## Overview

This guide covers deploying Gitea when the target environment has no internet access. The process involves:
1. **Download** images on a connected system
2. **Transfer** images to the air-gapped environment
3. **Publish** images to an accessible registry
4. **Install** Gitea using mirrored images

## Prerequisites

### Connected Environment (Download System)
- macOS with Lima or Linux with native oc-mirror
- Internet access
- Sufficient disk space (~2GB for Gitea images)
- `oc-mirror` installed (see [Installation](#oc-mirror-installation))

### Air-Gapped Environment (Target System)
- OpenShift cluster (CRC, OCP, etc.)
- Container registry accessible from cluster
- `oc` CLI configured
- `helm` CLI installed

## oc-mirror Installation

### macOS ARM64 (Lima-based)

```bash
# Install Lima and oc-mirror
cd gitops/scripts/arm64/lima
./setup-lima-oc-mirror.sh

# Verify installation
oc-mirror-lima version
```

**Advantages:**
- ✅ Native ARM64 binary (no emulation)
- ✅ Full network access
- ✅ Direct file access to macOS home
- ✅ No containerization overhead

### Linux (Native)

```bash
# Download oc-mirror
curl -sL https://mirror.openshift.com/pub/openshift-v4/clients/ocp/stable/oc-mirror.tar.gz | tar -xz
sudo mv oc-mirror /usr/local/bin/
sudo chmod +x /usr/local/bin/oc-mirror

# Verify installation
oc-mirror version
```

## Deployment Workflows

### Workflow 1: External Registry (Recommended)

**Use Case:** Production air-gapped deployments with accessible external registry

**Architecture:**
```
Internet → Download System → Transfer → Air-Gapped Registry → OpenShift Cluster
```

#### Step 1: Download Images (Connected System)

```bash
cd gitea

# Download all required images
./scripts/gitea-mirror-images.sh --download-only

# Verify download
ls -lh mirror-output/
```

**Expected output:**
```
mirror-output/
├── working-dir/
│   ├── v2/
│   │   ├── docker.io/gitea/gitea/
│   │   ├── docker.io/library/postgres/
│   │   └── docker.io/library/redis/
│   ├── isc_pinned_*.yaml
│   └── disc_pinned_*.yaml
```

#### Step 2: Transfer to Air-Gapped Environment

**Option A: Physical Media**
```bash
# Create tarball
tar -czf gitea-images.tar.gz mirror-output/

# Copy to USB drive, DVD, or other media
cp gitea-images.tar.gz /Volumes/USB_DRIVE/

# On air-gapped system
tar -xzf gitea-images.tar.gz
```

**Option B: Network Transfer (if available)**
```bash
# SCP to air-gapped system
scp -r mirror-output/ user@airgapped-system:/path/to/gitea/

# Or rsync
rsync -avz mirror-output/ user@airgapped-system:/path/to/gitea/mirror-output/
```

#### Step 3: Publish to Registry (Air-Gapped System)

```bash
cd gitea

# Login to your registry
podman login registry.example.com

# Publish images
./scripts/gitea-mirror-images.sh \
  --publish-only \
  --mirror-registry registry.example.com/gitea

# Verify images
skopeo list-tags docker://registry.example.com/gitea/gitea
skopeo list-tags docker://registry.example.com/gitea/postgres
skopeo list-tags docker://registry.example.com/gitea/redis
```

#### Step 4: Install Gitea

```bash
# Install with mirrored images
./scripts/gitea-install.sh \
  --use-upstream \
  --mirror-registry registry.example.com/gitea \
  --namespace gitea

# Verify deployment
oc get pods -n gitea
```

### Workflow 2: Direct Mirror (Single Step)

**Use Case:** When download and publish systems are the same

**Architecture:**
```
Internet → System with oc-mirror → Air-Gapped Registry → OpenShift Cluster
```

```bash
cd gitea

# Login to registry
podman login registry.example.com

# Download and publish in one step
./scripts/gitea-mirror-images.sh \
  --mirror-registry registry.example.com/gitea

# Install Gitea
./scripts/gitea-install.sh \
  --use-upstream \
  --mirror-registry registry.example.com/gitea \
  --namespace gitea
```

### Workflow 3: CRC Development (Download-Only)

**Use Case:** Local development with CRC (cannot publish to CRC registry from outside)

**Architecture:**
```
Internet → Download System → CRC Cluster (upstream images)
```

```bash
cd gitea

# Download images for reference
./scripts/gitea-mirror-images.sh --download-only

# Install using upstream images directly
# (CRC can pull from internet if available)
./scripts/gitea-install.sh --use-upstream --namespace gitea
```

**Note:** CRC's internal registry is not accessible from external tools. See [CRC Limitations](#crc-limitations) for details.

## Registry Configuration

### Supported Registries

The mirroring workflow supports any OCI-compliant registry:

#### Quay.io (Public)
```bash
# Login
podman login quay.io

# Mirror
./scripts/gitea-mirror-images.sh \
  --mirror-registry quay.io/your-org/gitea
```

#### Harbor
```bash
# Login
podman login harbor.example.com

# Mirror
./scripts/gitea-mirror-images.sh \
  --mirror-registry harbor.example.com/gitea
```

#### Artifactory
```bash
# Login
podman login artifactory.example.com

# Mirror
./scripts/gitea-mirror-images.sh \
  --mirror-registry artifactory.example.com/docker/gitea
```

#### OpenShift Internal Registry (In-Cluster Only)
```bash
# From within cluster (e.g., in a pod)
./scripts/gitea-mirror-images.sh \
  --mirror-registry image-registry.openshift-image-registry.svc:5000/gitea
```

### Registry Authentication

#### Using Podman/Docker Credentials

```bash
# Login stores credentials in ~/.docker/config.json
podman login registry.example.com

# oc-mirror automatically uses these credentials
./scripts/gitea-mirror-images.sh --mirror-registry registry.example.com/gitea
```

#### Using Pull Secrets

```bash
# Create pull secret in target namespace
oc create secret docker-registry gitea-pull-secret \
  --docker-server=registry.example.com \
  --docker-username=user \
  --docker-password=password \
  -n gitea

# Install with pull secret
./scripts/gitea-install.sh \
  --use-upstream \
  --mirror-registry registry.example.com/gitea \
  --namespace gitea
```

## Image Customization

### Modifying Image List

Edit `gitea/imagesetconfiguration.yaml` to add or change images:

```yaml
kind: ImageSetConfiguration
apiVersion: mirror.openshift.io/v2alpha1

mirror:
  additionalImages:
    - name: docker.io/gitea/gitea:1.26.2
    - name: docker.io/library/postgres:15-alpine
    - name: docker.io/library/redis:7-alpine
    # Add custom images here
    - name: docker.io/your-org/custom-image:tag
```

### Using Different Image Versions

```yaml
mirror:
  additionalImages:
    - name: docker.io/gitea/gitea:1.27.0  # Newer version
    - name: docker.io/library/postgres:16-alpine  # Newer PostgreSQL
    - name: docker.io/library/redis:7-alpine
```

After modifying, re-run the mirror process:

```bash
./scripts/gitea-mirror-images.sh --download-only
```

## Troubleshooting

### Download Issues

#### Slow Download Speed

```bash
# Increase retry attempts and delay
./scripts/gitea-mirror-images.sh \
  --download-only \
  --max-retries 5 \
  --retry-delay 60
```

#### Partial Download

```bash
# Check what was downloaded
ls -lh mirror-output/working-dir/v2/

# Resume download (oc-mirror handles this automatically)
./scripts/gitea-mirror-images.sh --download-only
```

#### Network Timeout

```bash
# Use longer timeout
export OC_MIRROR_TIMEOUT=600  # 10 minutes
./scripts/gitea-mirror-images.sh --download-only
```

### Publish Issues

#### Authentication Failed

```bash
# Verify credentials
podman login registry.example.com

# Check stored credentials
cat ~/.docker/config.json

# Re-login if needed
podman logout registry.example.com
podman login registry.example.com
```

#### TLS Certificate Errors

```bash
# For self-signed certificates
./scripts/gitea-mirror-images.sh \
  --mirror-registry registry.example.com/gitea \
  --dest-tls-verify=false

# Or add certificate to system trust
sudo cp registry-ca.crt /etc/pki/ca-trust/source/anchors/
sudo update-ca-trust
```

#### Registry Storage Full

```bash
# Check registry storage
oc exec -n registry deployment/registry -- df -h /var/lib/registry

# Clean up old images
oc adm prune images --confirm

# Or increase registry storage
oc patch configs.imageregistry.operator.openshift.io cluster \
  --type merge \
  --patch '{"spec":{"storage":{"pvc":{"claim":"larger-pvc"}}}}'
```

### Installation Issues

#### Image Pull Errors

```bash
# Verify images are accessible
skopeo inspect docker://registry.example.com/gitea/gitea:1.26.2

# Check pull secret
oc get secret gitea-pull-secret -n gitea -o yaml

# Verify image references in deployment
oc get deployment -n gitea -o yaml | grep image:
```

#### Wrong Image References

```bash
# Check generated values
./scripts/gitea-install.sh \
  --use-upstream \
  --mirror-registry registry.example.com/gitea \
  --generate-values

# Verify image overrides
cat /tmp/gitea-image-overrides-*.yaml
```

## CRC Limitations

### Issue

CRC's internal registry cannot be accessed from external tools (oc-mirror, containers, VMs) due to networking constraints.

**Error:**
```
dial tcp 127.0.0.1:80: connect: connection refused
```

### Root Cause

- CRC registry route resolves to `127.0.0.1` (localhost)
- External tools cannot access host's localhost
- Internal service name requires cluster network access

### Workarounds

1. **Use download-only mode** (recommended for CRC)
   ```bash
   ./scripts/gitea-mirror-images.sh --download-only
   ./scripts/gitea-install.sh --use-upstream
   ```

2. **Use external registry** (quay.io, Docker Hub)
   ```bash
   ./scripts/gitea-mirror-images.sh --mirror-registry quay.io/your-org/gitea
   ```

3. **Manual push from within cluster**
   ```bash
   # Copy mirror-output to cluster
   oc run -it --rm image-pusher --image=quay.io/skopeo/stable:latest -- bash
   # Inside pod: use skopeo to copy images
   ```

**Detailed documentation:** See `crc/docs/registry.md` and `docs/dev/feat-gitea-install/phase6-crc-registry-limitation.md`

## Best Practices

### 1. Verify Downloads Before Transfer

```bash
# Check all images downloaded
ls -lh mirror-output/working-dir/v2/

# Verify image count
find mirror-output/working-dir/v2 -name "manifest.json" | wc -l
# Should be 3 (gitea, postgres, redis)
```

### 2. Secure Transfer

```bash
# Encrypt tarball for transfer
tar -czf - mirror-output/ | gpg -c > gitea-images.tar.gz.gpg

# Decrypt on air-gapped system
gpg -d gitea-images.tar.gz.gpg | tar -xzf -
```

### 3. Validate Registry Access

```bash
# Before publishing, verify registry is accessible
skopeo inspect docker://registry.example.com/test/image:latest || \
  echo "Registry not accessible"

# Test write access
podman tag alpine:latest registry.example.com/test/alpine:latest
podman push registry.example.com/test/alpine:latest
```

### 4. Document Image Versions

```bash
# Save pinned configuration
cp mirror-output/working-dir/isc_pinned_*.yaml gitea-images-manifest.yaml

# Include in transfer
tar -czf gitea-images.tar.gz mirror-output/ gitea-images-manifest.yaml
```

### 5. Test Installation

```bash
# Test in non-production namespace first
./scripts/gitea-install.sh \
  --use-upstream \
  --mirror-registry registry.example.com/gitea \
  --namespace gitea-test

# Verify all pods running
oc get pods -n gitea-test

# Test Gitea functionality
oc port-forward -n gitea-test svc/gitea 3000:3000
# Access http://localhost:3000
```

## Advanced Scenarios

### Multiple Environments

```bash
# Download once
./scripts/gitea-mirror-images.sh --download-only

# Publish to dev registry
./scripts/gitea-mirror-images.sh \
  --publish-only \
  --mirror-registry dev-registry.example.com/gitea

# Publish to prod registry
./scripts/gitea-mirror-images.sh \
  --publish-only \
  --mirror-registry prod-registry.example.com/gitea
```

### Incremental Updates

```bash
# Update imagesetconfiguration.yaml with new version
# e.g., gitea:1.27.0

# Download only new images
./scripts/gitea-mirror-images.sh --download-only

# Publish updates
./scripts/gitea-mirror-images.sh \
  --publish-only \
  --mirror-registry registry.example.com/gitea

# Upgrade Gitea
helm upgrade gitea chart/ \
  --namespace gitea \
  -f values-with-new-version.yaml
```

### Custom Image Transformations

```bash
# Download images
./scripts/gitea-mirror-images.sh --download-only

# Use skopeo for custom transformations
skopeo copy \
  dir://mirror-output/working-dir/v2/docker.io/gitea/gitea/1.26.2 \
  docker://registry.example.com/custom-org/gitea:v1.26.2-custom

# Install with custom references
./scripts/gitea-install.sh \
  --use-upstream \
  --mirror-registry registry.example.com/custom-org
```

## References

- [oc-mirror Documentation](https://docs.openshift.com/container-platform/latest/installing/disconnected_install/installing-mirroring-disconnected.html)
- [Gitea Helm Chart](https://gitea.com/gitea/helm-chart)
- [OpenShift Image Registry](https://docs.openshift.com/container-platform/latest/registry/index.html)
- [Skopeo Documentation](https://github.com/containers/skopeo)

## Support

For issues or questions:
1. Check [Troubleshooting](#troubleshooting) section
2. Review [CRC Limitations](#crc-limitations) if using CRC
3. Consult `gitea/docs/readme.md` for general Gitea documentation
4. See `docs/dev/feat-gitea-install/` for implementation details

---

*Last Updated: 2026-06-14*  
*Maintained By: BYOP Development Team*