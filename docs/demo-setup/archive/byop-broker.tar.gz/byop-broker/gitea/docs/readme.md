# Gitea Scripts

This directory contains scripts for installing, configuring, and managing Gitea on Kubernetes/OpenShift clusters.

## Overview

These scripts provide a production-ready way to deploy and manage Gitea as part of the BYOP (Bring Your Own Platform) Broker + GitOps system. When installed, Gitea can serve as a drop-in replacement for GitHub in all GitOps workflows.

## Documentation

- **[Air-Gapped Deployment Guide](air-gapped-deployment.md)** - Complete guide for deploying Gitea in disconnected environments using image mirroring

## Available Scripts

### Core Installation Scripts

#### [`gitea-install.sh`](gitea-install.sh)
Install Gitea on Kubernetes/OpenShift using Helm.

**Features:**
- Platform-agnostic (works on any Kubernetes cluster)
- Configurable namespace and release name
- Support for custom values files
- Auto-generated secure passwords
- PostgreSQL or SQLite database options
- Optional Redis cache
- Route/Ingress configuration
- Dry-run mode

**Usage:**
```bash
# Basic installation with auto-generated password
./gitea-install.sh --namespace gitea --admin-email admin@example.com

# Installation with custom password
./gitea-install.sh --namespace gitea \
  --admin-password mySecurePass123 \
  --admin-email admin@example.com

# Dry run to see what would be installed
./gitea-install.sh --namespace gitea \
  --admin-email admin@example.com \
  --dry-run

# Install with custom values file
./gitea-install.sh --namespace gitea \
  --admin-email admin@example.com \
  --values-file custom-values.yaml

# Install with SQLite (no PostgreSQL)
./gitea-install.sh --namespace gitea \
  --admin-email admin@example.com \
  --disable-postgres

# Install with Redis cache
./gitea-install.sh --namespace gitea \
  --admin-email admin@example.com \
  --enable-redis
```

**Options:**
- `--context CONTEXT` - Kubernetes context (optional)
- `--namespace NAMESPACE` - Gitea namespace (default: gitea)
- `--values-file FILE` - Custom values file
- `--admin-user USER` - Admin username (default: gitea-admin)
- `--admin-password PASS` - Admin password (auto-generated if not provided)
- `--admin-email EMAIL` - Admin email (required)
- `--domain DOMAIN` - Gitea domain/hostname
- `--enable-postgres` - Use PostgreSQL (default: true)
- `--disable-postgres` - Use SQLite instead
- `--enable-redis` - Use Redis cache (default: false)
- `--chart-path PATH` - Path to Helm chart (default: ../chart)
- `--release-name NAME` - Helm release name (default: gitea)
- `--dry-run` - Show what would be done
- `-h, --help` - Show help

#### [`gitea-uninstall.sh`](gitea-uninstall.sh)
Cleanly remove Gitea from Kubernetes/OpenShift.

**Features:**
- Safe uninstall with confirmation prompts
- Option to preserve or delete PVCs (data)
- Option to preserve or delete namespace
- Force mode for automation
- Comprehensive cleanup

**Usage:**
```bash
# Uninstall with prompts (keeps namespace and PVCs)
./gitea-uninstall.sh --namespace gitea

# Auto-confirm all steps
./gitea-uninstall.sh --namespace gitea --force

# Delete everything including data
./gitea-uninstall.sh --namespace gitea \
  --delete-namespace \
  --delete-pvcs \
  --force
```

**Options:**
- `--context CONTEXT` - Kubernetes context (optional)
- `--namespace NAMESPACE` - Gitea namespace (default: gitea)
- `--release-name NAME` - Helm release name (default: gitea)
- `--delete-namespace` - Delete namespace after uninstall
- `--delete-pvcs` - Delete PVCs and all data
- `-f, --force` - Skip confirmation prompts
- `-h, --help` - Show help

**Warning:** Using `--delete-pvcs` will permanently delete all Gitea data including repositories, users, issues, and database content.

#### [`gitea-describe.sh`](gitea-describe.sh)
Display information about Gitea installation.

**Features:**
- Show Helm release information
- Display deployment and pod status
- Show access URLs (HTTP, SSH)
- Display storage information
- Show configuration (PostgreSQL, Redis)
- Optional detailed resource information
- Optional log viewing

**Usage:**
```bash
# Show basic information
./gitea-describe.sh --namespace gitea

# Show detailed resource information
./gitea-describe.sh --namespace gitea --resources

# Show recent logs
./gitea-describe.sh --namespace gitea --logs

# Show everything
./gitea-describe.sh --namespace gitea --resources --logs
```

**Options:**
- `--context CONTEXT` - Kubernetes context (optional)
- `--namespace NAMESPACE` - Gitea namespace (default: gitea)
- `--release-name NAME` - Helm release name (default: gitea)
- `--resources` - Show detailed resource information
- `--logs` - Show recent logs
- `-h, --help` - Show help

### Repository Management Scripts

#### [`gitea-repo-create.sh`](../scripts/gitea-repo-create.sh)
Create GitOps repositories in Gitea with SSH deploy keys.

**Features:**
- Create repository via Gitea API
- Generate SSH deploy keys
- Initialize GitOps directory structure
- Support for user accounts and organizations
- Private/public repository options
- Dry-run mode

**Usage:**
```bash
# Create private repo in user account
./gitea-repo-create.sh \
  --gitea-url http://gitea.example.com \
  --gitea-token abc123 \
  --repo-name my-gitops \
  --git-dir ~/git/gitea

# Create repo in organization
./gitea-repo-create.sh \
  --gitea-url http://gitea.example.com \
  --gitea-token abc123 \
  --repo-name my-gitops \
  --git-dir ~/git/gitea \
  --org myorg

# Using environment variables
export GITEA_URL=http://gitea.example.com
export GITEA_TOKEN=abc123
./gitea-repo-create.sh \
  --repo-name my-gitops \
  --git-dir ~/git/gitea
```

**Options:**
- `--gitea-url URL` - Gitea server URL (required)
- `--gitea-token TOKEN` - Gitea API token (required)
- `--repo-name NAME` - Repository name (required)
- `--git-dir DIR` - Local git directory path (required)
- `--org ORG` - Organization name (optional)
- `--public` - Create public repository (default: private)
- `--no-init-structure` - Skip GitOps structure initialization
- `--no-ssh-key` - Skip SSH key generation
- `--ssh-key-path PATH` - Custom SSH key path
- `--dry-run` - Show what would be done
- `-h, --help` - Show help

### Integration Scripts

#### [`gitea-configure-argocd.sh`](../scripts/gitea-configure-argocd.sh)
Configure ArgoCD to access Gitea repositories using SSH authentication.

**Features:**
- Configure SSH known hosts for Gitea
- Create repository credentials secret
- Create default AppProject
- Create application-sets Application
- Restart ArgoCD components
- Works with both community ArgoCD and OpenShift GitOps

**Usage:**
```bash
# Configure community ArgoCD
./gitea-configure-argocd.sh \
  --namespace argocd \
  --gitea-url http://gitea.example.com \
  --repo-url git@gitea.example.com:myorg/gitops.git \
  --ssh-key-path ~/git/gitea/gitops/ssh/gitops

# Configure OpenShift GitOps
./gitea-configure-argocd.sh \
  --namespace openshift-gitops \
  --gitea-url http://gitea.example.com \
  --repo-url git@gitea.example.com:myorg/gitops.git \
  --ssh-key-path ~/git/gitea/gitops/ssh/gitops

# Dry run
./gitea-configure-argocd.sh \
  --namespace argocd \
  --gitea-url http://gitea.example.com \
  --repo-url git@gitea.example.com:myorg/gitops.git \
  --ssh-key-path ~/git/gitea/gitops/ssh/gitops \
  --dry-run
```

**Options:**
- `--context CONTEXT` - Kubernetes context (optional)
- `--namespace NAMESPACE` - ArgoCD namespace (required)
- `--gitea-url URL` - Gitea server URL (required)
- `--repo-url URL` - Git repository URL in SSH format (required)
- `--ssh-key-path PATH` - Path to SSH private key (required)
- `--repo-name NAME` - Repository name (default: derived from URL)
- `--dry-run` - Show what would be done
- `-h, --help` - Show help

**Compatibility:**
- Community ArgoCD (namespace: `argocd`)
- Red Hat OpenShift GitOps (namespace: `openshift-gitops`)

#### [`gitea-configure-broker.sh`](../scripts/gitea-configure-broker.sh)
Configure BYOP Broker to access Gitea repositories for GitOps operations.

**Features:**
- Update broker SSH private key secret
- Update broker GitOps repository URL in ConfigMap
- Optional deployment restart
- Comprehensive validation and error handling
- Dry-run mode

**Usage:**
```bash
# Configure broker with Gitea repository
./gitea-configure-broker.sh \
  --namespace byop \
  --gitea-url http://gitea.example.com \
  --repo-url git@gitea.example.com:myorg/gitops.git \
  --ssh-key-path ~/git/gitea/gitops/ssh/gitops

# Configure and restart broker
./gitea-configure-broker.sh \
  --namespace byop \
  --gitea-url http://gitea.example.com \
  --repo-url git@gitea.example.com:myorg/gitops.git \
  --ssh-key-path ~/git/gitea/gitops/ssh/gitops \
  --restart

# Dry run
./gitea-configure-broker.sh \
  --namespace byop \
  --gitea-url http://gitea.example.com \
  --repo-url git@gitea.example.com:myorg/gitops.git \
  --ssh-key-path ~/git/gitea/gitops/ssh/gitops \
  --dry-run
```

**Options:**
- `--context CONTEXT` - Kubernetes context (optional)
- `--namespace NAMESPACE` - Broker namespace (default: byop)
- `--gitea-url URL` - Gitea server URL (required)
- `--repo-url URL` - Git repository URL in SSH format (required)
- `--ssh-key-path PATH` - Path to SSH private key (required)
- `--restart` - Restart broker deployment after configuration
- `--dry-run` - Show what would be done
- `-h, --help` - Show help

**What it does:**
1. Updates the broker's SSH private key secret for Git authentication
2. Updates the broker's GitOps repository URL in ConfigMap
3. Optionally restarts the broker deployment to apply changes
4. Provides verification steps and next actions

**Prerequisites:**
- Broker deployed in the specified namespace
- SSH private key with write access to Gitea repository
- Gitea repository already created (use `gitea-repo-create.sh`)

### Configuration Scripts (Coming Soon)

#### `gitea-configure.sh`
Post-installation configuration for Gitea.

**Planned Features:**
- Configure SSH access
- Set up webhooks
- Configure OAuth/OIDC
- Set repository defaults
- Configure LFS settings

## Prerequisites

### Required Tools

- `kubectl` or `oc` - Kubernetes/OpenShift CLI
- `helm` - Helm package manager (v3+)
- `openssl` or `/dev/urandom` - For password generation

### Cluster Requirements

- Kubernetes 1.19+ or OpenShift 4.x
- Sufficient resources for Gitea and dependencies:
  - Gitea: ~512Mi memory, 0.5 CPU
  - PostgreSQL (if enabled): ~256Mi memory, 0.25 CPU
  - Redis (if enabled): ~128Mi memory, 0.1 CPU
- Storage class for PVCs (if using persistent storage)

### Permissions

- Namespace admin permissions (create/delete resources in namespace)
- Ability to create Routes (OpenShift) or Ingresses (Kubernetes)

## Quick Start

### 1. Install Gitea

```bash
# Install with auto-generated password
./gitea-install.sh --namespace gitea --admin-email admin@example.com

# Save the generated password shown in the output!
```

### 2. Access Gitea

```bash
# Get access information
./gitea-describe.sh --namespace gitea

# Or use port-forward if no external access
kubectl port-forward -n gitea svc/gitea-http 3000:80
# Then access at http://localhost:3000
```

### 3. Verify Installation

```bash
# Check status
./gitea-describe.sh --namespace gitea

# View logs if needed
./gitea-describe.sh --namespace gitea --logs
```

## Common Workflows

### Development/Testing Installation

```bash
# Install with SQLite (faster, no PostgreSQL)
./gitea-install.sh --namespace gitea-dev \
  --admin-email dev@example.com \
  --disable-postgres

# Access via port-forward
kubectl port-forward -n gitea-dev svc/gitea-http 3000:80
```

### Production Installation

```bash
# Install with PostgreSQL and custom domain
./gitea-install.sh --namespace gitea \
  --admin-email admin@example.com \
  --admin-password "$(openssl rand -base64 32)" \
  --domain gitea.example.com \
  --enable-postgres \
  --enable-redis
```

### Upgrade Gitea

```bash
# Update Helm chart
cd ../chart
helm dependency update

# Upgrade release
helm upgrade gitea . -n gitea -f custom-values.yaml
```

### Backup and Restore

```bash
# Backup PVCs
kubectl get pvc -n gitea
# Use your cluster's backup solution to backup PVCs

# To restore, reinstall without --delete-pvcs
./gitea-uninstall.sh --namespace gitea --force
./gitea-install.sh --namespace gitea --admin-email admin@example.com
```

## Troubleshooting

### Pods Not Starting

```bash
# Check pod status
kubectl get pods -n gitea

# Check pod logs
kubectl logs -n gitea -l app.kubernetes.io/name=gitea

# Check events
kubectl get events -n gitea --sort-by='.lastTimestamp'
```

### Cannot Access Gitea

```bash
# Check service
kubectl get svc -n gitea

# Check route (OpenShift)
kubectl get route -n gitea

# Check ingress (Kubernetes)
kubectl get ingress -n gitea

# Use port-forward as fallback
kubectl port-forward -n gitea svc/gitea-http 3000:80
```

### Database Connection Issues

```bash
# Check PostgreSQL pod
kubectl get pods -n gitea -l app.kubernetes.io/name=postgres

# Check PostgreSQL logs
kubectl logs -n gitea -l app.kubernetes.io/name=postgres

# Check secrets
kubectl get secrets -n gitea
```

### Uninstall Issues

```bash
# Force delete stuck resources
kubectl delete deployment --all -n gitea --force --grace-period=0
kubectl delete pod --all -n gitea --force --grace-period=0

# Delete namespace if stuck
kubectl patch namespace gitea -p '{"metadata":{"finalizers":null}}'
kubectl delete namespace gitea
```

## Integration with BYOP Broker

### Complete Integration Workflow

Follow these steps to integrate Gitea with an **already-installed** BYOP Broker and ArgoCD:

> **Note:** These scripts are **post-install configuration steps** that reconfigure existing broker and ArgoCD deployments to use Gitea instead of GitHub. The broker and ArgoCD must already be installed before running these scripts.

#### 1. Install Gitea

```bash
./gitea-install.sh --namespace gitea --admin-email admin@example.com
```

#### 2. Create GitOps Repository in Gitea

```bash
./gitea-repo-create.sh \
  --gitea-url http://gitea.example.com \
  --gitea-token abc123 \
  --repo-name gitops \
  --git-dir ~/git/gitea
```

#### 3. Configure ArgoCD (Post-Install Reconfiguration)

Reconfigure an existing ArgoCD installation to read from Gitea:

```bash
./gitea-configure-argocd.sh \
  --namespace argocd \
  --gitea-url http://gitea.example.com \
  --repo-url git@gitea.example.com:myorg/gitops.git \
  --ssh-key-path ~/git/gitea/gitops/ssh/gitops
```

#### 4. Configure Broker (Post-Install Reconfiguration)

Reconfigure an existing broker deployment to write to Gitea:

```bash
./gitea-configure-broker.sh \
  --namespace byop \
  --gitea-url http://gitea.example.com \
  --repo-url git@gitea.example.com:myorg/gitops.git \
  --ssh-key-path ~/git/gitea/gitops/ssh/gitops \
  --restart
```

This script updates the broker's:
- SSH private key secret (for Git authentication)
- GitOps repository URL in ConfigMap
- Optionally restarts the deployment to apply changes

#### 5. Verify Integration

```bash
# Check broker logs
kubectl logs -n byop deployment/byop-broker

# Provision a test service via broker API
# Verify commit appears in Gitea repository
# Verify ArgoCD syncs from Gitea
```

### Integration Architecture

```
┌─────────────┐     API      ┌────────────┐
│ Catalog App │─────────────▶│   Broker   │
└─────────────┘              └────────────┘
                                    │
                                    │ Git Push (SSH)
                                    ▼
                             ┌─────────────┐
                             │    Gitea    │
                             │  GitOps Repo│
                             └─────────────┘
                                    │
                                    │ Git Pull (SSH)
                                    ▼
                             ┌─────────────┐
                             │   ArgoCD    │
                             └─────────────┘
                                    │
                                    │ Deploy
                                    ▼
                             ┌─────────────┐
                             │ Kubernetes  │
                             └─────────────┘
```

### Alternative: Configure During Initial Installation

Instead of using the post-install scripts, you can configure the broker to use Gitea during initial Helm installation by providing custom values:

```yaml
# custom-values.yaml
broker:
  gitops:
    repoUrl: "git@gitea.example.com:myorg/gitops.git"
  secrets:
    sshPrivateKey: |
      -----BEGIN OPENSSH PRIVATE KEY-----
      ... your SSH private key ...
      -----END OPENSSH PRIVATE KEY-----
```

```bash
helm install byop chart/ -n byop -f custom-values.yaml
```

## Script Development

### Adding New Scripts

Follow these patterns when creating new scripts:

1. **Use consistent structure:**
   - Colors for output (RED, GREEN, YELLOW, BLUE, NC)
   - Helper functions (log_info, log_success, log_warning, log_error)
   - Context support (--context parameter)
   - Dry-run mode (--dry-run parameter)
   - Help documentation (--help parameter)

2. **Follow naming conventions:**
   - `gitea-<action>.sh` for main scripts
   - Use kebab-case for script names

3. **Include comprehensive help:**
   - Usage examples
   - All parameters documented
   - Prerequisites listed

4. **Make scripts executable:**
   ```bash
   chmod +x gitea-<script>.sh
   ```

5. **Update this README:**
   - Add script to appropriate section
   - Document usage and options
   - Include examples

## Air-Gapped Deployments

For deploying Gitea in air-gapped (disconnected) environments, see the **[Air-Gapped Deployment Guide](air-gapped-deployment.md)**.

The guide covers:
- Image mirroring with oc-mirror
- Download and transfer workflows
- Publishing to external registries
- Complete installation procedures
- Troubleshooting for disconnected environments

**Quick Start (Air-Gapped):**
```bash
# 1. Download images (connected system)
cd gitea
./scripts/gitea-mirror-images.sh --download-only

# 2. Transfer mirror-output/ to air-gapped system

# 3. Publish to registry (air-gapped system)
./scripts/gitea-mirror-images.sh \
  --publish-only \
  --mirror-registry registry.example.com/gitea

# 4. Install Gitea
./scripts/gitea-install.sh \
  --use-upstream \
  --mirror-registry registry.example.com/gitea \
  --namespace gitea
```

## References

- [Gitea Documentation](https://docs.gitea.io/)
- [Gitea API Reference](https://docs.gitea.io/en-us/api-usage/)
- [Gitea Helm Chart](https://github.com/groundhog2k/helm-charts/tree/master/charts/gitea)
- [ArgoCD Repository Credentials](https://argo-cd.readthedocs.io/en/stable/user-guide/private-repositories/)
- [Air-Gapped Deployment Guide](air-gapped-deployment.md)

## Support

For issues or questions:

1. Check the [Troubleshooting](#troubleshooting) section
2. Review script help: `./script-name.sh --help`
3. Check Gitea logs: `./gitea-describe.sh --namespace gitea --logs`
4. Consult the main project documentation

---

**Last Updated:** 2026-06-14
**Status:** Phase 6 In Progress (Upstream Chart with Image Mirroring)

**Completed Phases:**
- ✅ Phase 1: Core Installation Scripts
- ✅ Phase 2: Repository Management Scripts
- ✅ Phase 3: ArgoCD Integration
- ✅ Phase 4: Broker Integration
- ✅ Phase 6 Tasks 1-4: Image mirroring infrastructure and documentation

**In Progress:**
- Phase 6 Task 5: Integration testing and completion summary

**Next Phase:**
- Phase 5: Documentation & Testing (comprehensive integration testing)