# Gitea Configuration Files

This directory contains example configuration files for Gitea deployments.

## Files

### [`values.yaml`](values.yaml)

Example Helm values file for OpenShift deployments with custom registry configuration.

**Key Configuration:**
- OpenShift Route enabled
- PostgreSQL with custom registry
- Redis with custom registry
- OpenShift-compatible security contexts

**Usage:**

```bash
# Use with gitea-install.sh
cd ../scripts
./gitea-install.sh \
  --namespace gitea \
  --admin-email admin@example.com \
  --values-file ../conf/values.yaml
```

**Or directly with Helm:**

```bash
cd ../chart
helm install gitea . \
  --namespace gitea \
  --create-namespace \
  --values ../conf/values.yaml
```

## Creating Custom Values Files

You can create custom values files for different environments:

### Development Environment

```yaml
# conf/values-dev.yaml
postgres:
  enabled: false  # Use SQLite for faster setup

redis:
  enabled: false  # No cache for development

resources:
  limits:
    memory: 512Mi
    cpu: 500m
```

### Production Environment

```yaml
# conf/values-prod.yaml
postgres:
  enabled: true
  settings:
    superuserPassword: "${POSTGRES_PASSWORD}"
  storage:
    size: 50Gi
    className: fast-ssd

redis:
  enabled: true

resources:
  limits:
    memory: 2Gi
    cpu: 2000m
  requests:
    memory: 1Gi
    cpu: 1000m

storage:
  size: 100Gi
  className: fast-ssd
```

### Custom Registry

```yaml
# conf/values-custom-registry.yaml
image:
  registry: "my-registry.example.com"
  repository: "gitea/gitea"

postgres:
  image:
    registry: "my-registry.example.com"
    repository: "postgres/postgres"

redis:
  image:
    registry: "my-registry.example.com"
    repository: "redis/redis"
```

## Configuration Options

See the main chart values file for all available options:
- [`../chart/values.yaml`](../chart/values.yaml) - Complete values with defaults and documentation

## Best Practices

1. **Never commit secrets** - Use environment variables or secret management tools
2. **Use separate files per environment** - dev, staging, production
3. **Document custom settings** - Add comments explaining why settings were changed
4. **Version control** - Track changes to configuration files
5. **Test before production** - Always test configuration changes in non-production first

## Examples

### Minimal Configuration

```yaml
# Just enable Route for OpenShift
route:
  enabled: true
```

### High Availability Configuration

```yaml
# HA setup with PostgreSQL and Redis
postgres:
  enabled: true
  replication:
    enabled: true
    replicas: 2

redis:
  enabled: true
  cluster:
    enabled: true
    nodes: 3

replicas: 3  # Multiple Gitea instances
```

### Resource-Constrained Environment

```yaml
# Minimal resources for small clusters
postgres:
  enabled: false  # Use SQLite

resources:
  limits:
    memory: 256Mi
    cpu: 250m
  requests:
    memory: 128Mi
    cpu: 100m

storage:
  size: 5Gi
```

## See Also

- [Installation Guide](../docs/readme.md) - Complete installation documentation
- [Gitea Chart Documentation](../chart/README.md) - Helm chart details
- [Gitea Official Docs](https://docs.gitea.io/) - Gitea configuration reference

---

**Last Updated:** 2026-06-12