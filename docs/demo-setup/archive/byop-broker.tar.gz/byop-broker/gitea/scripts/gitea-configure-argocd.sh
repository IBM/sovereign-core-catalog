#!/bin/bash
#
# Configure ArgoCD to Access Gitea Repository
# Supports SSH authentication with deploy keys
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE=""  # Required parameter
CONTEXT=""
GITEA_URL=""
REPO_URL=""
SSH_KEY_PATH=""
REPO_NAME=""
DRY_RUN=false

# Build kubectl/oc command with context if specified
k8s_cmd() {
    local cmd="kubectl"
    if command -v oc &> /dev/null; then
        cmd="oc"
    fi
    
    if [ -n "$CONTEXT" ]; then
        $cmd --context="${CONTEXT}" "$@"
    else
        $cmd "$@"
    fi
}

verify_command_example() {
    local args="$1"
    local cmd="kubectl"
    if command -v oc &> /dev/null; then
        cmd="oc"
    fi
    
    if [ -n "$CONTEXT" ]; then
        echo "$cmd --context=${CONTEXT} ${args}"
    else
        echo "$cmd ${args}"
    fi
}

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Configure ArgoCD to access a Gitea repository using SSH authentication.
Works with both community ArgoCD and Red Hat OpenShift GitOps.

Options:
  --context CONTEXT       Kubernetes context (optional; uses current context if omitted)
  --namespace NAMESPACE   ArgoCD namespace (required)
                         Community ArgoCD: typically 'argocd'
                         OpenShift GitOps: typically 'openshift-gitops'
  --gitea-url URL         Gitea server URL (required, e.g., http://gitea.example.com)
  --repo-url URL          Git repository URL (required, SSH format: git@host:org/repo.git)
  --ssh-key-path PATH     Path to SSH private key (required)
  --repo-name NAME        Repository name (default: derived from URL)
  --dry-run              Show what would be done without making changes
  -h, --help             Show this help message

Authentication:
  This script configures SSH authentication for Gitea repositories.
  You must provide:
    - SSH private key (--ssh-key-path)
    - Repository URL in SSH format (git@gitea:org/repo.git)
  
  The SSH key should be the deploy key created by gitea-repo-create.sh

Examples:
  # Configure community ArgoCD for Gitea repository
  $0 --namespace argocd \\
     --gitea-url http://gitea.example.com \\
     --repo-url git@gitea.example.com:myorg/gitops.git \\
     --ssh-key-path ~/git/gitea/gitops/ssh/gitops

  # Configure OpenShift GitOps for Gitea repository
  $0 --namespace openshift-gitops \\
     --gitea-url http://gitea.example.com \\
     --repo-url git@gitea.example.com:myorg/gitops.git \\
     --ssh-key-path ~/git/gitea/gitops/ssh/gitops

  # With custom context
  $0 --context my-cluster \\
     --namespace argocd \\
     --gitea-url http://gitea.example.com \\
     --repo-url git@gitea.example.com:myorg/gitops.git \\
     --ssh-key-path ~/git/gitea/gitops/ssh/gitops

  # Dry run to see what would be configured
  $0 --namespace argocd \\
     --gitea-url http://gitea.example.com \\
     --repo-url git@gitea.example.com:myorg/gitops.git \\
     --ssh-key-path ~/git/gitea/gitops/ssh/gitops \\
     --dry-run

Prerequisites:
  - ArgoCD (community or OpenShift GitOps) must be installed in the specified namespace
  - Gitea repository must exist with deploy key configured
  - SSH private key must be accessible
  - kubectl or oc must be installed and configured

Compatibility:
  This script works with:
  - Community ArgoCD (installed via argocd/scripts/argocd-install.sh)
  - Red Hat OpenShift GitOps (installed via OpenShift GitOps Operator)
  
  Both use the same secret labeling mechanism (argocd.argoproj.io/secret-type=repository)

Related Scripts:
  - gitea-install.sh: Install Gitea
  - gitea-repo-create.sh: Create Gitea repository with SSH keys
  - gitea-configure-broker.sh: Configure broker for Gitea

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --context)
            CONTEXT="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --gitea-url)
            GITEA_URL="$2"
            shift 2
            ;;
        --repo-url)
            REPO_URL="$2"
            shift 2
            ;;
        --ssh-key-path)
            SSH_KEY_PATH="$2"
            shift 2
            ;;
        --repo-name)
            REPO_NAME="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Validate required arguments
if [ -z "$NAMESPACE" ]; then
    log_error "Namespace is required"
    echo ""
    echo "Specify a namespace explicitly:"
    echo "  $0 --namespace YOUR_NAMESPACE --gitea-url URL --repo-url URL --ssh-key-path PATH"
    exit 1
fi

if [ -z "$GITEA_URL" ]; then
    log_error "Gitea URL is required"
    echo ""
    show_help
    exit 1
fi

if [ -z "$REPO_URL" ]; then
    log_error "Repository URL is required"
    echo ""
    show_help
    exit 1
fi

if [ -z "$SSH_KEY_PATH" ]; then
    log_error "SSH key path is required"
    echo ""
    show_help
    exit 1
fi

# Validate SSH URL format
if [[ "$REPO_URL" != git@* ]] && [[ "$REPO_URL" != ssh://* ]]; then
    log_error "Invalid SSH URL format"
    echo "Expected format: git@host:org/repo.git or ssh://git@host/org/repo.git"
    echo "Provided: ${REPO_URL}"
    exit 1
fi

# Derive repository name if not provided
if [ -z "$REPO_NAME" ]; then
    REPO_NAME=$(echo "$REPO_URL" | sed -E 's|.*/([^/]+)\.git$|\1|' | sed 's|[^a-zA-Z0-9-]|-|g')
    if [ -z "$REPO_NAME" ]; then
        REPO_NAME="gitea-repo"
    fi
fi

# Determine and display the actual Kubernetes context being used
if [ -n "$CONTEXT" ]; then
    ACTUAL_CONTEXT="$CONTEXT"
    CONTEXT_SOURCE="specified via --context"
else
    ACTUAL_CONTEXT=$(kubectl config current-context 2>/dev/null || echo "unknown")
    CONTEXT_SOURCE="using current context"
fi

echo "============================================================"
echo "Configure ArgoCD for Gitea Repository"
echo "============================================================"
echo ""
echo "⚠️  KUBERNETES CONTEXT: ${ACTUAL_CONTEXT}"
echo "    (${CONTEXT_SOURCE})"
echo ""
echo "Configuration:"
if [ -n "$CONTEXT" ]; then
    echo "  Context:        ${CONTEXT}"
else
    echo "  Context:        current context"
fi
echo "  Namespace:      ${NAMESPACE}"
echo "  Gitea URL:      ${GITEA_URL}"
echo "  Repository URL: ${REPO_URL}"
echo "  Repository Name: ${REPO_NAME}"
echo "  SSH Key:        ${SSH_KEY_PATH}"
echo "  Dry Run:        ${DRY_RUN}"
echo ""

if [ "$DRY_RUN" = true ]; then
    log_info "DRY RUN MODE - No changes will be made"
    echo ""
fi

# Check prerequisites
log_info "Checking prerequisites..."

# Check kubectl/oc
if command -v oc &> /dev/null; then
    log_success "oc is installed"
elif command -v kubectl &> /dev/null; then
    log_success "kubectl is installed"
else
    log_error "Neither kubectl nor oc is installed"
    exit 1
fi

# Check if context exists
if [ -n "$CONTEXT" ]; then
    if ! kubectl config get-contexts "${CONTEXT}" &> /dev/null; then
        log_error "Kubernetes context '${CONTEXT}' not found"
        exit 1
    fi
    log_success "Context '${CONTEXT}' found"
else
    log_info "Using current context"
fi

# Check if ArgoCD is installed
if ! k8s_cmd get namespace "${NAMESPACE}" &> /dev/null; then
    log_error "ArgoCD namespace '${NAMESPACE}' not found"
    echo ""
    echo "Please install ArgoCD first:"
    echo "  Community ArgoCD: See argocd/scripts/argocd-install.sh"
    echo "  OpenShift GitOps: Install OpenShift GitOps Operator"
    exit 1
fi
log_success "ArgoCD namespace '${NAMESPACE}' exists"

# Check for ArgoCD installation (works for both community and OpenShift GitOps)
if k8s_cmd -n "${NAMESPACE}" get deployment argocd-repo-server &> /dev/null; then
    log_success "ArgoCD repo-server deployment found"
elif k8s_cmd -n "${NAMESPACE}" get argocd &> /dev/null; then
    log_success "OpenShift GitOps ArgoCD custom resource found"
else
    log_warning "Could not verify ArgoCD installation"
    log_info "Continuing - secret labeling works for both ArgoCD variants"
fi

# Validate SSH key
# Expand tilde in path
SSH_KEY_PATH="${SSH_KEY_PATH/#\~/$HOME}"

if [ ! -f "$SSH_KEY_PATH" ]; then
    log_error "SSH key not found: ${SSH_KEY_PATH}"
    exit 1
fi
log_success "SSH key found: ${SSH_KEY_PATH}"

# Check key permissions
KEY_PERMS=$(stat -f "%OLp" "$SSH_KEY_PATH" 2>/dev/null || stat -c "%a" "$SSH_KEY_PATH" 2>/dev/null)
if [ "$KEY_PERMS" != "600" ] && [ "$KEY_PERMS" != "400" ]; then
    log_warning "SSH key has insecure permissions: ${KEY_PERMS}"
    log_info "Recommended: chmod 600 ${SSH_KEY_PATH}"
fi

echo ""
log_success "All prerequisites met"
echo ""

# Extract Git host from URL
GIT_HOST=$(echo "$REPO_URL" | sed -E 's|git@([^:]+):.*|\1|')
if [ -z "$GIT_HOST" ]; then
    # Try ssh:// format
    GIT_HOST=$(echo "$REPO_URL" | sed -E 's|ssh://git@([^/]+)/.*|\1|')
fi

if [ "$DRY_RUN" = true ]; then
    echo "============================================================"
    echo "DRY RUN - Configuration Steps"
    echo "============================================================"
    echo ""
    echo "The following actions would be performed:"
    echo ""
    echo "Step 1: Configure SSH known hosts for ${GIT_HOST}"
    echo "        - Fetch SSH host keys from Gitea"
    echo "        - Update argocd-ssh-known-hosts-cm ConfigMap"
    echo ""
    echo "Step 2: Create repository credentials"
    echo "        - Create secret 'repo-${REPO_NAME}' with SSH private key"
    echo "        - Label secret for ArgoCD recognition"
    echo ""
    echo "Step 3: Restart ArgoCD components"
    echo "        - Restart argocd-repo-server deployment"
    echo ""
    echo "Step 4: Create default AppProject"
    echo "        - Create default AppProject in namespace"
    echo ""
    echo "Step 5: Create application-sets Application"
    echo "        - Create Application to manage ApplicationSets"
    echo ""
    log_success "Dry run complete - no changes made"
    exit 0
fi

echo ""
echo "============================================================"
echo "Step 1: Configuring SSH known hosts"
echo "============================================================"
echo ""

log_info "Git host: ${GIT_HOST}"

# Get SSH host key
log_info "Fetching SSH host key for ${GIT_HOST}..."
SSH_KNOWN_HOSTS=$(ssh-keyscan -t rsa,ecdsa,ed25519 "${GIT_HOST}" 2>/dev/null || true)

if [ -z "$SSH_KNOWN_HOSTS" ]; then
    log_warning "Could not fetch SSH host key automatically"
    log_info "Attempting to extract from Gitea service..."
    
    # Try to get SSH host key from Gitea pod if running in same cluster
    GITEA_POD=$(k8s_cmd get pods -l app.kubernetes.io/name=gitea -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)
    if [ -n "$GITEA_POD" ]; then
        log_info "Found Gitea pod: ${GITEA_POD}"
        SSH_KNOWN_HOSTS=$(k8s_cmd exec "${GITEA_POD}" -- cat /data/ssh/ssh_host_rsa_key.pub 2>/dev/null | awk '{print "gitea " $1 " " $2}' || true)
    fi
    
    if [ -z "$SSH_KNOWN_HOSTS" ]; then
        log_warning "Could not fetch SSH host key"
        log_info "You may need to configure it manually later"
        log_info "Run: ssh-keyscan ${GIT_HOST}"
    fi
else
    log_success "SSH host key retrieved"
fi

if [ -n "$SSH_KNOWN_HOSTS" ]; then
    # Update ArgoCD SSH known hosts ConfigMap
    log_info "Updating ArgoCD SSH known hosts..."
    
    # Create or update ConfigMap
    k8s_cmd -n "${NAMESPACE}" create configmap argocd-ssh-known-hosts-cm \
        --from-literal="ssh_known_hosts=${SSH_KNOWN_HOSTS}" \
        --dry-run=client -o yaml | \
        k8s_cmd apply -f -
    
    log_success "SSH known hosts configured"
fi

echo ""
echo "============================================================"
echo "Step 2: Creating repository credentials"
echo "============================================================"
echo ""

log_info "Creating SSH credentials secret..."

# Read SSH private key
SSH_KEY_CONTENT=$(cat "$SSH_KEY_PATH")

# Create repository credentials secret
k8s_cmd -n "${NAMESPACE}" create secret generic "repo-${REPO_NAME}" \
    --from-literal=type=git \
    --from-literal=url="${REPO_URL}" \
    --from-literal=sshPrivateKey="${SSH_KEY_CONTENT}" \
    --dry-run=client -o yaml | \
    k8s_cmd apply -f -

# Label the secret so ArgoCD recognizes it
k8s_cmd -n "${NAMESPACE}" label secret "repo-${REPO_NAME}" \
    argocd.argoproj.io/secret-type=repository --overwrite

log_success "SSH credentials configured"

echo ""
echo "============================================================"
echo "Step 3: Restarting ArgoCD components"
echo "============================================================"
echo ""

log_info "Restarting ArgoCD repo server to pick up new credentials..."
k8s_cmd -n "${NAMESPACE}" rollout restart deployment argocd-repo-server
k8s_cmd -n "${NAMESPACE}" rollout status deployment argocd-repo-server --timeout=120s || {
    log_warning "Timeout waiting for repo server restart"
}
log_success "ArgoCD repo server restarted"

echo ""
echo "============================================================"
echo "Step 4: Creating Default AppProject"
echo "============================================================"
echo ""

# Always apply default AppProject to ensure it has correct spec
log_info "Configuring default AppProject..."

# Create/update default AppProject
cat <<EOF | k8s_cmd apply -f -
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: default
  namespace: ${NAMESPACE}
spec:
  description: Default project
  sourceRepos:
  - '*'
  destinations:
  - namespace: '*'
    server: '*'
  clusterResourceWhitelist:
  - group: '*'
    kind: '*'
  namespaceResourceWhitelist:
  - group: '*'
    kind: '*'
EOF
log_success "Default AppProject configured"

echo ""
echo "============================================================"
echo "Step 5: Creating ApplicationSets Application"
echo "============================================================"
echo ""

# Check if application-sets application already exists
if k8s_cmd -n "${NAMESPACE}" get application application-sets &> /dev/null; then
    log_info "Application-sets application already exists"
    
    # Check if it's configured for the correct repository
    EXISTING_REPO=$(k8s_cmd -n "${NAMESPACE}" get application application-sets -o jsonpath='{.spec.source.repoURL}' 2>/dev/null || echo "")
    
    if [ "$EXISTING_REPO" = "$REPO_URL" ]; then
        log_info "Deleting existing application-sets application to recreate with updated configuration..."
        k8s_cmd -n "${NAMESPACE}" delete application application-sets
        log_success "Existing application deleted"
    else
        log_warning "Application-sets application points to different repository: ${EXISTING_REPO}"
        log_info "Deleting and recreating application-sets application to use: ${REPO_URL}"
        k8s_cmd -n "${NAMESPACE}" delete application application-sets
        log_success "Existing application deleted"
    fi
fi

# Create the application-sets application
log_info "Creating application-sets application to auto-manage service instances..."

cat <<EOF | k8s_cmd apply -f -
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: application-sets
  namespace: ${NAMESPACE}
spec:
  destination:
    namespace: ${NAMESPACE}
    server: https://kubernetes.default.svc
  source:
    path: application-sets
    repoURL: ${REPO_URL}
    targetRevision: HEAD
    directory:
      recurse: true
  project: default
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
EOF

log_success "Application-sets application created"
log_info "The application-sets application will automatically create Applications from application-sets/ directory"

echo ""
echo "============================================================"
echo "✅ Gitea Repository Configuration Complete!"
echo "============================================================"
echo ""
echo "Repository Details:"
echo "  Name:       ${REPO_NAME}"
echo "  URL:        ${REPO_URL}"
echo "  Gitea:      ${GITEA_URL}"
echo "  Auth:       SSH"
echo ""
echo "Verify Configuration:"
echo "  $(verify_command_example "-n ${NAMESPACE} get secret repo-${REPO_NAME}")"
echo ""

# Display application-sets application status
echo "Application-Sets Application Status:"
APP_STATUS=$(k8s_cmd -n "${NAMESPACE}" get application application-sets -o jsonpath='{.status.sync.status}' 2>/dev/null || echo "Unknown")
APP_HEALTH=$(k8s_cmd -n "${NAMESPACE}" get application application-sets -o jsonpath='{.status.health.status}' 2>/dev/null || echo "Unknown")
echo "  Name:   application-sets"
echo "  Sync:   ${APP_STATUS}"
echo "  Health: ${APP_HEALTH}"
echo ""
echo "The application-sets application will automatically:"
echo "  - Monitor application-sets/ directory in the GitOps repository"
echo "  - Create ArgoCD ApplicationSets for dynamic service provisioning"
echo "  - Keep ApplicationSets in sync with Git"
echo ""
echo "Note: The application-sets/ directory will be created when the broker"
echo "      provisions the first service instance."
echo ""

log_success "Configuration complete!"
echo ""
echo "Next Steps:"
echo "  1. Configure broker to use Gitea repository:"
echo "     ./gitea-configure-broker.sh --gitea-url ${GITEA_URL} --repo-url ${REPO_URL}"
echo ""
echo "  2. Verify ArgoCD can access the repository:"
echo "     $(verify_command_example "-n ${NAMESPACE} get application application-sets")"
echo ""

# Made with Bob