# Legacy Gitea Scripts (v1)

This directory contains the original basic scripts that were used before the production-ready scripts were created.

## Files

### `create`
Original basic installation command:
```bash
helm install gitea . --values cust.yaml -n gitea --create-namespace
```

**Replaced by:** [`../gitea-install.sh`](../gitea-install.sh)

### `delete`
Original basic cleanup commands:
```bash
helm delete gitea -n gitea
kubectl delete ns gitea
kubectl describe ns gitea
```

**Replaced by:** [`../gitea-uninstall.sh`](../gitea-uninstall.sh)

## Why These Were Replaced

The original scripts lacked:
- Parameter handling and validation
- Error handling and logging
- Dry-run mode
- Context selection
- Secure credential management
- Status checking and verification
- Help documentation

## Migration

If you were using these scripts, migrate to the new production-ready scripts:

**Old:**
```bash
cd gitea/chart
./create
```

**New:**
```bash
cd gitea/scripts
./gitea-install.sh --namespace gitea --admin-email admin@example.com
```

See [`../gitea-install.sh --help`](../gitea-install.sh) for all available options.

## Status

These scripts are kept for reference only and should not be used for new installations.

---

**Superseded:** 2026-06-12  
**Replaced by:** Production-ready scripts in [`gitea/scripts/`](../)