#!/bin/bash
#
# Gitea Installation Script
# Installs Gitea on Kubernetes/OpenShift using Helm
#

set -e

# Get script directory (works regardless of CWD)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GITEA_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE="gitea"
CONTEXT=""
DRY_RUN=false
VALUES_FILE=""
ADMIN_USER="gitea-admin"
ADMIN_PASSWORD=""
ADMIN_EMAIL=""
DOMAIN=""
ENABLE_POSTGRES=true
ENABLE_REDIS=false
CHART_PATH="${GITEA_ROOT}/chart"
RELEASE_NAME="gitea"
USE_UPSTREAM=false
UPSTREAM_REPO="https://groundhog2k.github.io/helm-charts"
UPSTREAM_VERSION="0.15.2"
MIRROR_REGISTRY=""
GENERATE_VALUES=false

# Build kubectl/oc command with context if specified
k8s_cmd() {
    local cmd="kubectl"
    if command -v oc &> /dev/null; then
        cmd="oc"
    fi
    
    if [ -n "$CONTEXT" ]; then
        $cmd --context="${CONTEXT}" "$@"
    else
        $cmd "$@"
    fi
}

# Build helm command with context if specified
helm_cmd() {
    if [ -n "$CONTEXT" ]; then
        helm --kube-context="${CONTEXT}" "$@"
    else
        helm "$@"
    fi
}

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1" >&2
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1" >&2
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1" >&2
}

log_error() {
    echo -e "${RED}[✗]${NC} $1" >&2
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Install Gitea on Kubernetes/OpenShift cluster using Helm.

Options:
  --context CONTEXT          Kubernetes context (optional; uses current context if omitted)
  --namespace NAMESPACE      Gitea namespace (default: gitea)
  --values-file FILE         Custom values file (optional)
  --admin-user USER          Admin username (default: gitea-admin)
  --admin-password PASS      Admin password (required; will be generated if not provided)
  --admin-email EMAIL        Admin email (required)
  --domain DOMAIN            Gitea domain/hostname (optional; auto-detected if not provided)
  --enable-postgres          Use PostgreSQL database (default: true)
  --disable-postgres         Use SQLite database instead of PostgreSQL
  --enable-redis             Use Redis cache (default: false)
  --chart-path PATH          Path to Gitea Helm chart (default: ../chart)
  --release-name NAME        Helm release name (default: gitea)
  --dry-run                  Show what would be done without making changes
  -h, --help                 Show this help message

Upstream Chart Options:
  --use-upstream             Use upstream Helm chart instead of local copy
  --upstream-repo URL        Upstream Helm repository URL
                             (default: https://groundhog2k.github.io/helm-charts)
  --upstream-version VERSION Chart version to install (default: 0.15.2)
  --mirror-registry HOST/ORG Mirror registry prefix for air-gapped deployments
                             (e.g., registry.example.com/gitea)
  --generate-values          Generate values file and exit (for inspection)

Mirror Registry:
  The --mirror-registry option automatically transforms image references to use
  a mirror registry prefix. This is useful for air-gapped deployments.

  Example transformation with --mirror-registry registry.example.com/gitea:
    docker.io/gitea/gitea:1.26.2          → registry.example.com/gitea/gitea:1.26.2
    docker.io/library/postgres:15-alpine  → registry.example.com/gitea/postgres:15-alpine
    docker.io/library/redis:7-alpine      → registry.example.com/gitea/redis:7-alpine

  Use gitea-mirror-images.sh to mirror images before installation.

Examples:
  # Install from local chart (default behavior)
  $0 --namespace gitea --admin-email admin@example.com

  # Install from upstream chart
  $0 --use-upstream --namespace gitea --admin-email admin@example.com

  # Install from upstream with specific version
  $0 --use-upstream --upstream-version 0.15.2 --namespace gitea --admin-email admin@example.com

  # Air-gapped deployment with mirror registry
  $0 --use-upstream --mirror-registry registry.example.com/gitea --namespace gitea --admin-email admin@example.com

  # Generate values file for inspection
  $0 --use-upstream --generate-values --namespace gitea --admin-email admin@example.com

  # Install with custom password and domain
  $0 --namespace gitea --admin-password mySecurePass123 --admin-email admin@example.com --domain gitea.example.com

  # Install with custom values file
  $0 --namespace gitea --admin-email admin@example.com --values-file custom-values.yaml

  # Install with SQLite (no PostgreSQL)
  $0 --namespace gitea --admin-email admin@example.com --disable-postgres

  # Install with Redis cache
  $0 --namespace gitea --admin-email admin@example.com --enable-redis

EOF
}

# Generate secure random password
generate_password() {
    if command -v openssl &> /dev/null; then
        openssl rand -base64 32 | tr -d "=+/" | cut -c1-25
    else
        head -c 32 /dev/urandom | base64 | tr -d "=+/" | cut -c1-25
    fi
}

# Apply mirror registry transformation to images
# Transforms image registry and repository paths for mirrored images
# Example: docker.io/gitea/gitea → registry.example.com/org/gitea/gitea
# Note: oc-mirror preserves the source path structure (gitea/gitea, library/postgres, library/redis)
# Image tags are determined by the Helm chart's values (appVersion and subchart dependencies)
apply_mirror_registry() {
    local values_file="$1"
    local mirror_registry="$2"
    
    log_info "Applying mirror registry transformation: $mirror_registry" >&2
    
    # Transform Gitea image (preserves gitea/gitea path)
    sed -i.bak "/^image:/,/pullPolicy:/ s|registry: docker.io|registry: ${mirror_registry%%/*}|" "$values_file"
    sed -i.bak "/^image:/,/pullPolicy:/ s|repository: gitea/gitea|repository: ${mirror_registry#*/}/gitea/gitea|" "$values_file"
    log_info "  Gitea image: ${mirror_registry}/gitea/gitea" >&2
    
    # Transform PostgreSQL image (library/postgres path)
    sed -i.bak "/^postgres:/,/^[^ ]/ s|registry: docker.io|registry: ${mirror_registry%%/*}|" "$values_file"
    sed -i.bak "/^postgres:/,/^[^ ]/ s|repository: library/postgres|repository: ${mirror_registry#*/}/library/postgres|" "$values_file"
    log_info "  PostgreSQL image: ${mirror_registry}/library/postgres" >&2
    
    # Transform Redis image (library/redis path)
    sed -i.bak "/^redis:/,/^[^ ]/ s|registry: docker.io|registry: ${mirror_registry%%/*}|" "$values_file"
    sed -i.bak "/^redis:/,/^[^ ]/ s|repository: library/redis|repository: ${mirror_registry#*/}/library/redis|" "$values_file"
    log_info "  Redis image: ${mirror_registry}/library/redis" >&2
    
    # Clean up backup files
    rm -f "${values_file}.bak"
    log_success "Mirror registry transformation applied" >&2
}

# Generate values file for Helm installation
generate_values_file() {
    local temp_values
    temp_values=$(mktemp)
    
    log_info "Generating Helm values..." >&2
    
    # Generate passwords if needed
    local postgres_password=""
    local postgres_user_password=""
    if [ "$ENABLE_POSTGRES" = true ]; then
        postgres_password=$(generate_password)
        postgres_user_password=$(generate_password)
    fi
    
    # Start with base values
    cat > "$temp_values" << EOF
# Gitea Helm values (generated by gitea-install.sh)

# Namespace configuration
namespaceOverride: ${NAMESPACE}

# Image configuration
image:
  registry: docker.io
  repository: gitea/gitea
  tag: ""  # Use chart's appVersion
  pullPolicy: IfNotPresent

# PostgreSQL dependency
postgres:
  enabled: ${ENABLE_POSTGRES}
EOF

    if [ "$ENABLE_POSTGRES" = true ]; then
        cat >> "$temp_values" << EOF
  image:
    registry: docker.io
    repository: library/postgres
    tag: ""  # Use subchart's appVersion (13.12)
  settings:
    superuserPassword: "${postgres_password}"
  userDatabase:
    name: gitea
    user: gitea
    password: "${postgres_user_password}"
  storage:
    requestedSize: 10Gi
  # OpenShift-compatible security context
  podSecurityContext:
    fsGroup: null
  securityContext:
    runAsUser: null
    runAsGroup: null
EOF
    fi

    cat >> "$temp_values" << EOF

# Redis dependency
redis:
  enabled: ${ENABLE_REDIS}
EOF

    if [ "$ENABLE_REDIS" = true ]; then
        cat >> "$temp_values" << EOF
  image:
    registry: docker.io
    repository: library/redis
    tag: ""  # Use subchart's appVersion (7.0.12)
  # OpenShift-compatible security context
  podSecurityContext:
    fsGroup: null
  securityContext:
    runAsUser: null
    runAsGroup: null
EOF
    fi

    cat >> "$temp_values" << EOF

# OpenShift-compatible security context for Gitea
podSecurityContext:
  fsGroup: null
securityContext:
  runAsUser: null
  runAsGroup: null

# Gitea configuration
gitea:
  admin:
    username: "${ADMIN_USER}"
    password: "${ADMIN_PASSWORD}"
    email: "${ADMIN_EMAIL}"
  config:
    server:
      DOMAIN: "${DOMAIN}"
      ROOT_URL: "https://${DOMAIN}"

# Ingress configuration
ingress:
  enabled: false

# Route configuration (OpenShift)
route:
  enabled: true
  host: "${DOMAIN}"
EOF

    # Apply mirror registry transformation if provided
    if [[ -n "$MIRROR_REGISTRY" ]]; then
        apply_mirror_registry "$temp_values" "$MIRROR_REGISTRY"
    fi
    
    echo "$temp_values"
}

# Install Gitea from upstream Helm repository
install_from_upstream() {
    log_info "Installing Gitea from upstream chart"
    log_info "  Repository: $UPSTREAM_REPO"
    log_info "  Version: $UPSTREAM_VERSION"
    
    # Add Helm repository
    log_info "Adding Helm repository..."
    if helm_cmd repo add groundhog2k "$UPSTREAM_REPO" 2>/dev/null; then
        log_success "Helm repository added"
    else
        log_info "Helm repository already exists, updating..."
    fi
    
    log_info "Updating Helm repositories..."
    helm_cmd repo update
    log_success "Helm repositories updated"
    
    # Generate values file
    local values_file
    values_file=$(generate_values_file)
    
    # If generate-values mode, just output the file and exit
    if [ "$GENERATE_VALUES" = true ]; then
        log_success "Generated values file:"
        echo ""
        cat "$values_file"
        echo ""
        log_info "Values file saved to: $values_file"
        log_info "You can use this file with: helm install --values $values_file"
        exit 0
    fi
    
    # Install from upstream
    log_info "Installing Gitea from upstream chart..."
    
    HELM_ARGS=(
        "upgrade"
        "--install"
        "${RELEASE_NAME}"
        "groundhog2k/gitea"
        "--version" "${UPSTREAM_VERSION}"
        "--namespace" "${NAMESPACE}"
        "--create-namespace"
        "--values" "${values_file}"
    )
    
    # Add custom values file if provided
    if [ -n "$VALUES_FILE" ]; then
        if [ ! -f "$VALUES_FILE" ]; then
            log_error "Values file not found: $VALUES_FILE"
            rm -f "$values_file"
            exit 1
        fi
        HELM_ARGS+=("--values" "${VALUES_FILE}")
        log_info "Using custom values file: ${VALUES_FILE}"
    fi
    
    # Execute helm upgrade --install
    if helm_cmd "${HELM_ARGS[@]}"; then
        log_success "Gitea installed from upstream chart"
    else
        log_error "Failed to install Gitea from upstream chart"
        rm -f "$values_file"
        exit 1
    fi
    
    # Clean up temporary values file
    rm -f "$values_file"
}

# Install Gitea from local chart
install_from_local_chart() {
    log_info "Installing Gitea from local chart: $CHART_PATH"
    
    # Create temporary values file
    TEMP_VALUES="/tmp/gitea-install-values-$$.yaml"
    
    log_info "Generating Helm values..."
    
    cat > "$TEMP_VALUES" << EOF
# Gitea installation values
# Generated by gitea-install.sh

postgres:
  enabled: ${ENABLE_POSTGRES}
EOF
    
    if [ "$ENABLE_POSTGRES" = true ]; then
        POSTGRES_PASSWORD=$(generate_password)
        cat >> "$TEMP_VALUES" << EOF
  settings:
    superuserPassword: "${POSTGRES_PASSWORD}"
  userDatabase:
    name: "gitea"
    user: "gitea"
    password: "${POSTGRES_PASSWORD}"
EOF
    fi
    
    cat >> "$TEMP_VALUES" << EOF

redis:
  enabled: ${ENABLE_REDIS}

# Domain configuration
gitea:
  config:
    server:
      DOMAIN: "${DOMAIN}"

ingress:
  enabled: false

route:
  enabled: true
  host: "${DOMAIN}"
EOF
    
    log_success "Helm values prepared"
    
    log_info "Installing/upgrading Gitea Helm chart..."
    
    HELM_ARGS=(
        "upgrade"
        "--install"
        "${RELEASE_NAME}"
        "${CHART_PATH}"
        "--namespace" "${NAMESPACE}"
        "--create-namespace"
        "--values" "${TEMP_VALUES}"
    )
    
    # Add custom values file if provided
    if [ -n "$VALUES_FILE" ]; then
        if [ ! -f "$VALUES_FILE" ]; then
            log_error "Values file not found: $VALUES_FILE"
            rm -f "$TEMP_VALUES"
            exit 1
        fi
        HELM_ARGS+=("--values" "${VALUES_FILE}")
        log_info "Using custom values file: ${VALUES_FILE}"
    fi
    
    # Execute helm upgrade --install
    if helm_cmd "${HELM_ARGS[@]}"; then
        log_success "Gitea Helm chart installed/upgraded"
    else
        log_error "Failed to install Gitea Helm chart"
        rm -f "$TEMP_VALUES"
        exit 1
    fi
    
    # Clean up temporary values file
    rm -f "$TEMP_VALUES"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --context)
            CONTEXT="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --values-file)
            VALUES_FILE="$2"
            shift 2
            ;;
        --admin-user)
            ADMIN_USER="$2"
            shift 2
            ;;
        --admin-password)
            ADMIN_PASSWORD="$2"
            shift 2
            ;;
        --admin-email)
            ADMIN_EMAIL="$2"
            shift 2
            ;;
        --domain)
            DOMAIN="$2"
            shift 2
            ;;
        --enable-postgres)
            ENABLE_POSTGRES=true
            shift
            ;;
        --disable-postgres)
            ENABLE_POSTGRES=false
            shift
            ;;
        --enable-redis)
            ENABLE_REDIS=true
            shift
            ;;
        --chart-path)
            CHART_PATH="$2"
            shift 2
            ;;
        --release-name)
            RELEASE_NAME="$2"
            shift 2
            ;;
        --use-upstream)
            USE_UPSTREAM=true
            shift
            ;;
        --upstream-repo)
            UPSTREAM_REPO="$2"
            shift 2
            ;;
        --upstream-version)
            UPSTREAM_VERSION="$2"
            shift 2
            ;;
        --mirror-registry)
            MIRROR_REGISTRY="$2"
            shift 2
            ;;
        --generate-values)
            GENERATE_VALUES=true
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Determine actual context
if [ -n "$CONTEXT" ]; then
    ACTUAL_CONTEXT="$CONTEXT"
    CONTEXT_SOURCE="specified via --context"
else
    ACTUAL_CONTEXT=$(kubectl config current-context 2>/dev/null || echo "unknown")
    CONTEXT_SOURCE="using current context"
fi

# Validate required parameters
if [ -z "$ADMIN_EMAIL" ]; then
    log_error "Admin email is required"
    echo ""
    echo "Specify admin email:"
    echo "  $0 --admin-email admin@example.com"
    exit 1
fi

# Generate admin password if not provided
if [ -z "$ADMIN_PASSWORD" ]; then
    log_info "Generating secure admin password..."
    ADMIN_PASSWORD=$(generate_password)
    PASSWORD_GENERATED=true
else
    PASSWORD_GENERATED=false
fi

# Validate chart path exists (only for local chart mode)
if [ "$USE_UPSTREAM" = false ]; then
    if [ ! -d "$CHART_PATH" ]; then
        log_error "Chart path does not exist: $CHART_PATH"
        exit 1
    fi

    if [ ! -f "$CHART_PATH/Chart.yaml" ]; then
        log_error "Invalid chart path (Chart.yaml not found): $CHART_PATH"
        exit 1
    fi
fi

echo "============================================================"
echo "Gitea Installation"
echo "============================================================"
echo ""
echo "⚠️  KUBERNETES CONTEXT: ${ACTUAL_CONTEXT}"
echo "    (${CONTEXT_SOURCE})"
echo ""
echo "Configuration:"
echo "  Namespace:        ${NAMESPACE}"
echo "  Release Name:     ${RELEASE_NAME}"
if [ "$USE_UPSTREAM" = true ]; then
    echo "  Chart Source:     Upstream (${UPSTREAM_REPO})"
    echo "  Chart Version:    ${UPSTREAM_VERSION}"
    if [ -n "$MIRROR_REGISTRY" ]; then
        echo "  Mirror Registry:  ${MIRROR_REGISTRY}"
    fi
else
    echo "  Chart Source:     Local (${CHART_PATH})"
fi
echo "  Admin User:       ${ADMIN_USER}"
echo "  Admin Email:      ${ADMIN_EMAIL}"
echo "  Domain:           ${DOMAIN:-auto-detect}"
echo "  PostgreSQL:       ${ENABLE_POSTGRES}"
echo "  Redis:            ${ENABLE_REDIS}"
echo "  Values File:      ${VALUES_FILE:-none}"
echo "  Dry Run:          ${DRY_RUN}"
if [ "$GENERATE_VALUES" = true ]; then
    echo "  Generate Values:  true (will exit after generation)"
fi
echo ""

if [ "$DRY_RUN" = true ]; then
    log_info "DRY RUN MODE - No changes will be made"
    echo ""
fi

# Check prerequisites
log_info "Checking prerequisites..."

# Check kubectl/oc
if ! command -v kubectl &> /dev/null && ! command -v oc &> /dev/null; then
    log_error "kubectl or oc is not installed"
    exit 1
fi
log_success "kubectl/oc is installed"

# Check helm
if ! command -v helm &> /dev/null; then
    log_error "helm is not installed"
    exit 1
fi
log_success "helm is installed"

# Check cluster connectivity
if ! k8s_cmd cluster-info &> /dev/null; then
    log_error "Cannot connect to cluster"
    exit 1
fi
log_success "Cluster is accessible"

log_success "All prerequisites met"
echo ""

if [ "$DRY_RUN" = true ]; then
    echo "============================================================"
    echo "DRY RUN - Installation Steps"
    echo "============================================================"
    echo ""
    echo "The following would be installed:"
    echo ""
    echo "1. Create namespace '${NAMESPACE}' (if not exists)"
    echo "2. Install Gitea Helm chart"
    echo "   - Gitea application"
    if [ "$ENABLE_POSTGRES" = true ]; then
        echo "   - PostgreSQL database"
    else
        echo "   - SQLite database (embedded)"
    fi
    if [ "$ENABLE_REDIS" = true ]; then
        echo "   - Redis cache"
    fi
    echo "3. Create admin user: ${ADMIN_USER}"
    echo "4. Configure access (Route/Ingress)"
    echo ""
    log_success "Dry run complete - no changes made"
    exit 0
fi

echo ""
echo "============================================================"
echo "Step 1: Creating namespace"
echo "============================================================"
echo ""

log_info "Checking namespace '${NAMESPACE}'..."
if k8s_cmd get namespace "${NAMESPACE}" &> /dev/null; then
    log_success "Namespace '${NAMESPACE}' already exists"
else
    log_info "Creating namespace '${NAMESPACE}'..."
    if k8s_cmd create namespace "${NAMESPACE}"; then
        log_success "Namespace '${NAMESPACE}' created"
    else
        log_error "Failed to create namespace '${NAMESPACE}'"
        exit 1
    fi
fi

echo ""
echo "============================================================"
echo "Step 2: Preparing configuration"
echo "============================================================"
echo ""

# Auto-detect domain from Route if not provided
if [ -z "$DOMAIN" ]; then
    log_info "Auto-detecting domain from Route..."
    # Try to get existing route hostname
    EXISTING_ROUTE=$(k8s_cmd get route "${RELEASE_NAME}" -n "${NAMESPACE}" -o jsonpath='{.spec.host}' 2>/dev/null || echo "")
    if [ -n "$EXISTING_ROUTE" ]; then
        DOMAIN="$EXISTING_ROUTE"
        log_info "Using existing route domain: ${DOMAIN}"
    else
        # Generate expected route hostname based on OpenShift pattern
        ROUTE_BASE=$(k8s_cmd get route -n openshift-console console -o jsonpath='{.spec.host}' 2>/dev/null | sed 's/^console-openshift-console\.//' || echo "")
        if [ -n "$ROUTE_BASE" ]; then
            DOMAIN="${RELEASE_NAME}-${NAMESPACE}.${ROUTE_BASE}"
            log_info "Generated domain from cluster: ${DOMAIN}"
        else
            log_warning "Could not auto-detect domain - using localhost"
            DOMAIN="localhost"
        fi
    fi
fi

log_success "Configuration prepared"

echo ""
echo "============================================================"
echo "Step 3: Installing Gitea via Helm"
echo "============================================================"
echo ""

# Install from upstream or local chart
if [ "$USE_UPSTREAM" = true ]; then
    install_from_upstream
else
    install_from_local_chart
fi

echo ""
echo "============================================================"
echo "Step 4: Waiting for Gitea to be ready"
echo "============================================================"
echo ""

log_info "Waiting for Gitea deployment to be ready..."
if k8s_cmd wait --for=condition=available --timeout=300s deployment/"${RELEASE_NAME}" -n "${NAMESPACE}" 2>/dev/null; then
    log_success "Gitea deployment is ready"
else
    log_warning "Timeout waiting for deployment (this may be normal)"
    log_info "Check status with: kubectl get pods -n ${NAMESPACE}"
fi

echo ""
echo "============================================================"
echo "Step 5: Configuring admin user"
echo "============================================================"
echo ""

log_info "Waiting for Gitea to be fully initialized..."
sleep 10

# Get Gitea pod name
GITEA_POD=$(k8s_cmd get pods -n "${NAMESPACE}" -l "app.kubernetes.io/name=gitea" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")

if [ -n "$GITEA_POD" ]; then
    log_info "Creating admin user via Gitea CLI..."
    
    # Create admin user using gitea admin command
    if k8s_cmd exec -n "${NAMESPACE}" "${GITEA_POD}" -- \
        gitea admin user create \
        --username "${ADMIN_USER}" \
        --password "${ADMIN_PASSWORD}" \
        --email "${ADMIN_EMAIL}" \
        --admin \
        --must-change-password=false 2>/dev/null; then
        log_success "Admin user created: ${ADMIN_USER}"
    else
        log_warning "Admin user may already exist or will be created on first login"
    fi
else
    log_warning "Could not find Gitea pod to create admin user"
    log_info "You can create the admin user manually after installation"
fi

echo ""
echo "============================================================"
echo "Installation Complete!"
echo "============================================================"
echo ""

# Get access information
log_info "Retrieving access information..."

# Try to get Route (OpenShift)
ROUTE_HOST=$(k8s_cmd get route -n "${NAMESPACE}" "${RELEASE_NAME}" -o jsonpath='{.spec.host}' 2>/dev/null || echo "")

if [ -n "$ROUTE_HOST" ]; then
    GITEA_URL="https://${ROUTE_HOST}"
    log_success "Gitea URL (Route): ${GITEA_URL}"
else
    # Try to get Ingress
    INGRESS_HOST=$(k8s_cmd get ingress -n "${NAMESPACE}" "${RELEASE_NAME}" -o jsonpath='{.spec.rules[0].host}' 2>/dev/null || echo "")
    
    if [ -n "$INGRESS_HOST" ]; then
        GITEA_URL="http://${INGRESS_HOST}"
        log_success "Gitea URL (Ingress): ${GITEA_URL}"
    else
        # Fallback to service
        SERVICE_IP=$(k8s_cmd get svc -n "${NAMESPACE}" "${RELEASE_NAME}-http" -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")
        
        if [ -n "$SERVICE_IP" ]; then
            GITEA_URL="http://${SERVICE_IP}"
            log_success "Gitea URL (LoadBalancer): ${GITEA_URL}"
        else
            log_info "Gitea URL: Use port-forward to access"
            log_info "  kubectl port-forward -n ${NAMESPACE} svc/${RELEASE_NAME}-http 3000:80"
            GITEA_URL="http://localhost:3000"
        fi
    fi
fi

echo ""
echo "Access Information:"
echo "  URL:            ${GITEA_URL}"
echo "  Admin User:     ${ADMIN_USER}"
if [ "$PASSWORD_GENERATED" = true ]; then
    echo "  Admin Password: ${ADMIN_PASSWORD} (SAVE THIS - it won't be shown again)"
else
    echo "  Admin Password: <provided by user>"
fi
echo "  Admin Email:    ${ADMIN_EMAIL}"
echo ""

# SSH access information
SSH_PORT=$(k8s_cmd get svc -n "${NAMESPACE}" "${RELEASE_NAME}-ssh" -o jsonpath='{.spec.ports[0].nodePort}' 2>/dev/null || echo "")
if [ -n "$SSH_PORT" ]; then
    log_info "SSH Access (NodePort): Port ${SSH_PORT}"
    echo "  Use: git clone ssh://git@<node-ip>:${SSH_PORT}/user/repo.git"
fi

echo ""
log_info "Next steps:"
echo "  1. Access Gitea at: ${GITEA_URL}"
echo "  2. Log in with admin credentials"
echo "  3. Configure additional settings as needed"
echo "  4. Create repositories and users"
echo ""
log_info "To configure ArgoCD integration, run:"
echo "  ./gitea-configure-argocd.sh --gitea-url ${GITEA_URL}"
echo ""
log_info "To configure broker integration, run:"
echo "  ./gitea-configure-broker.sh --gitea-url ${GITEA_URL}"
echo ""

log_success "Gitea installation completed successfully!"

# Made with Bob
