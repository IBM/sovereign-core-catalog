#!/bin/bash
#
# Gitea Repository Creation Script
# Creates a GitOps repository in Gitea with SSH deploy keys
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
GITEA_URL=""
GITEA_TOKEN=""
REPO_NAME=""
GIT_DIR=""
ORG_NAME=""
PRIVATE=true
INIT_STRUCTURE=true
GENERATE_SSH_KEY=true
SSH_KEY_PATH=""
DRY_RUN=false

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Create a GitOps repository in Gitea with SSH deploy keys.

Required Options:
  --gitea-url URL            Gitea server URL (e.g., http://gitea.example.com)
  --gitea-token TOKEN        Gitea API token (required for authentication)
  --repo-name NAME           Repository name (required)
  --git-dir DIR              Local git directory path (required)

Optional Options:
  --org ORG                  Organization name (default: user's account)
  --public                   Create public repository (default: private)
  --no-init-structure        Skip GitOps structure initialization
  --no-ssh-key               Skip SSH key generation
  --ssh-key-path PATH        Custom path for SSH key (default: <repo>/ssh/gitops)
  --dry-run                  Show what would be done without making changes
  -h, --help                 Show this help message

Examples:
  # Create private repo in user account
  $0 --gitea-url http://gitea.example.com \\
     --gitea-token abc123 \\
     --repo-name my-gitops \\
     --git-dir ~/git/gitea

  # Create repo in organization
  $0 --gitea-url http://gitea.example.com \\
     --gitea-token abc123 \\
     --repo-name my-gitops \\
     --git-dir ~/git/gitea \\
     --org myorg

  # Create public repo without SSH key
  $0 --gitea-url http://gitea.example.com \\
     --gitea-token abc123 \\
     --repo-name my-gitops \\
     --git-dir ~/git/gitea \\
     --public \\
     --no-ssh-key

Environment Variables:
  GITEA_URL                  Gitea server URL (alternative to --gitea-url)
  GITEA_TOKEN                Gitea API token (alternative to --gitea-token)

Notes:
  - API token can be created in Gitea: User Settings > Applications > Generate New Token
  - Token needs 'repo' scope for repository creation and deploy key management
  - SSH keys are stored in <repo>/ssh/ directory (added to .gitignore)

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --gitea-url)
            GITEA_URL="$2"
            shift 2
            ;;
        --gitea-token)
            GITEA_TOKEN="$2"
            shift 2
            ;;
        --repo-name)
            REPO_NAME="$2"
            shift 2
            ;;
        --git-dir)
            GIT_DIR="$2"
            shift 2
            ;;
        --org)
            ORG_NAME="$2"
            shift 2
            ;;
        --public)
            PRIVATE=false
            shift
            ;;
        --no-init-structure)
            INIT_STRUCTURE=false
            shift
            ;;
        --no-ssh-key)
            GENERATE_SSH_KEY=false
            shift
            ;;
        --ssh-key-path)
            SSH_KEY_PATH="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Check for environment variables if not provided
if [ -z "$GITEA_URL" ] && [ -n "$GITEA_URL" ]; then
    GITEA_URL="$GITEA_URL"
fi

if [ -z "$GITEA_TOKEN" ] && [ -n "$GITEA_TOKEN" ]; then
    GITEA_TOKEN="$GITEA_TOKEN"
fi

# Validate required parameters
if [ -z "$GITEA_URL" ]; then
    log_error "Gitea URL is required"
    echo ""
    echo "Specify Gitea URL:"
    echo "  $0 --gitea-url http://gitea.example.com ..."
    echo "Or set environment variable: export GITEA_URL=http://gitea.example.com"
    exit 1
fi

if [ -z "$GITEA_TOKEN" ]; then
    log_error "Gitea API token is required"
    echo ""
    echo "Specify Gitea token:"
    echo "  $0 --gitea-token YOUR_TOKEN ..."
    echo "Or set environment variable: export GITEA_TOKEN=YOUR_TOKEN"
    echo ""
    echo "Create token in Gitea: User Settings > Applications > Generate New Token"
    exit 1
fi

if [ -z "$REPO_NAME" ]; then
    log_error "Repository name is required"
    echo ""
    echo "Specify repository name:"
    echo "  $0 --repo-name my-gitops ..."
    exit 1
fi

if [ -z "$GIT_DIR" ]; then
    log_error "Git directory is required"
    echo ""
    echo "Specify git directory:"
    echo "  $0 --git-dir ~/git/gitea ..."
    exit 1
fi

# Expand tilde in GIT_DIR
GIT_DIR="${GIT_DIR/#\~/$HOME}"

# Set default SSH key path if not provided
if [ -z "$SSH_KEY_PATH" ]; then
    SSH_KEY_PATH="${GIT_DIR}/${REPO_NAME}/ssh/gitops"
fi

# Remove trailing slash from Gitea URL
GITEA_URL="${GITEA_URL%/}"

echo "============================================================"
echo "Gitea Repository Creation"
echo "============================================================"
echo ""
echo "Configuration:"
echo "  Gitea URL:      ${GITEA_URL}"
echo "  Repository:     ${REPO_NAME}"
echo "  Organization:   ${ORG_NAME:-<user account>}"
echo "  Private:        ${PRIVATE}"
echo "  Git Directory:  ${GIT_DIR}"
echo "  Init Structure: ${INIT_STRUCTURE}"
echo "  Generate SSH:   ${GENERATE_SSH_KEY}"
if [ "$GENERATE_SSH_KEY" = true ]; then
    echo "  SSH Key Path:   ${SSH_KEY_PATH}"
fi
echo "  Dry Run:        ${DRY_RUN}"
echo ""

if [ "$DRY_RUN" = true ]; then
    log_info "DRY RUN MODE - No changes will be made"
    echo ""
fi

# Check prerequisites
log_info "Checking prerequisites..."

# Check curl
if ! command -v curl &> /dev/null; then
    log_error "curl is not installed"
    exit 1
fi
log_success "curl is installed"

# Check git
if ! command -v git &> /dev/null; then
    log_error "git is not installed"
    exit 1
fi
log_success "git is installed"

# Check ssh-keygen if needed
if [ "$GENERATE_SSH_KEY" = true ]; then
    if ! command -v ssh-keygen &> /dev/null; then
        log_error "ssh-keygen is not installed"
        exit 1
    fi
    log_success "ssh-keygen is installed"
fi

# Check jq for JSON parsing
if ! command -v jq &> /dev/null; then
    log_error "jq is not installed (required for JSON parsing)"
    exit 1
fi
log_success "jq is installed"

log_success "All prerequisites met"
echo ""

if [ "$DRY_RUN" = true ]; then
    echo "============================================================"
    echo "DRY RUN - Repository Creation Steps"
    echo "============================================================"
    echo ""
    echo "The following would be created:"
    echo ""
    echo "1. Local git repository: ${GIT_DIR}/${REPO_NAME}"
    echo "2. Gitea repository: ${GITEA_URL}/${ORG_NAME:-<user>}/${REPO_NAME}"
    if [ "$GENERATE_SSH_KEY" = true ]; then
        echo "3. SSH key pair: ${SSH_KEY_PATH}"
        echo "4. Deploy key in Gitea (write access)"
    fi
    if [ "$INIT_STRUCTURE" = true ]; then
        echo "5. GitOps directory structure"
    fi
    echo ""
    log_success "Dry run complete - no changes made"
    exit 0
fi

# Check if repository already exists locally
REPO_PATH="${GIT_DIR}/${REPO_NAME}"
if [ -d "${REPO_PATH}/.git" ]; then
    log_error "Repository already exists locally: ${REPO_PATH}"
    log_info "Remove it first or use a different name"
    exit 1
fi

echo ""
echo "============================================================"
echo "Step 1: Getting Gitea user information"
echo "============================================================"
echo ""

log_info "Authenticating with Gitea..."

# Get current user info
USER_INFO=$(curl -s -H "Authorization: token ${GITEA_TOKEN}" \
    "${GITEA_URL}/api/v1/user" || echo "")

if [ -z "$USER_INFO" ] || echo "$USER_INFO" | grep -q "error"; then
    log_error "Failed to authenticate with Gitea"
    log_error "Check your Gitea URL and token"
    exit 1
fi

GITEA_USER=$(echo "$USER_INFO" | jq -r '.login')
log_success "Authenticated as: ${GITEA_USER}"

# Determine owner (org or user)
if [ -n "$ORG_NAME" ]; then
    OWNER="$ORG_NAME"
    OWNER_TYPE="organization"
    
    # Verify org exists
    log_info "Verifying organization: ${ORG_NAME}"
    ORG_INFO=$(curl -s -H "Authorization: token ${GITEA_TOKEN}" \
        "${GITEA_URL}/api/v1/orgs/${ORG_NAME}" || echo "")
    
    if [ -z "$ORG_INFO" ] || echo "$ORG_INFO" | grep -q "error"; then
        log_error "Organization '${ORG_NAME}' not found or not accessible"
        exit 1
    fi
    log_success "Organization verified"
else
    OWNER="$GITEA_USER"
    OWNER_TYPE="user"
fi

echo ""
echo "============================================================"
echo "Step 2: Creating local git repository"
echo "============================================================"
echo ""

log_info "Creating directory: ${REPO_PATH}"
mkdir -p "${REPO_PATH}"
cd "${REPO_PATH}"

log_info "Initializing git repository..."
git init
git branch -M main

# Create README
log_info "Creating README.md..."
cat > README.md << EOF
# ${REPO_NAME}

GitOps repository for cluster configuration and service deployments.

## Structure

- \`services/\` - Service definitions and configurations
- \`clusters/\` - Cluster-specific configurations
- \`argocd/\` - ArgoCD ApplicationSets and configurations

## Usage

This repository is managed by the BYOP Broker and ArgoCD.

EOF

# Create .gitignore
log_info "Creating .gitignore..."
cat > .gitignore << EOF
# SSH keys (never commit)
ssh/

# Temporary files
*.tmp
*.swp
*~

# OS files
.DS_Store
Thumbs.db

EOF

# Create GitOps structure if requested
if [ "$INIT_STRUCTURE" = true ]; then
    log_info "Creating GitOps directory structure..."
    mkdir -p services
    mkdir -p clusters
    mkdir -p argocd
    
    # Create placeholder files
    echo "# Services" > services/README.md
    echo "# Clusters" > clusters/README.md
    echo "# ArgoCD" > argocd/README.md
    
    log_success "GitOps structure created"
fi

# Generate SSH key if requested
if [ "$GENERATE_SSH_KEY" = true ]; then
    log_info "Generating SSH key pair..."
    mkdir -p "$(dirname "${SSH_KEY_PATH}")"
    ssh-keygen -C "gitops-${REPO_NAME}" -f "${SSH_KEY_PATH}" -q -N ""
    log_success "SSH key generated: ${SSH_KEY_PATH}"
fi

# Commit initial structure
log_info "Committing initial structure..."
git add .
git commit -m "Initial commit: GitOps repository structure"

log_success "Local repository created"

echo ""
echo "============================================================"
echo "Step 3: Creating Gitea repository"
echo "============================================================"
echo ""

log_info "Creating repository in Gitea..."

# Prepare repository creation payload
REPO_PAYLOAD=$(cat <<EOF
{
  "name": "${REPO_NAME}",
  "description": "GitOps repository for cluster configuration",
  "private": ${PRIVATE},
  "auto_init": false,
  "default_branch": "main"
}
EOF
)

# Create repository (org or user)
if [ "$OWNER_TYPE" = "organization" ]; then
    API_ENDPOINT="${GITEA_URL}/api/v1/orgs/${OWNER}/repos"
else
    API_ENDPOINT="${GITEA_URL}/api/v1/user/repos"
fi

REPO_RESPONSE=$(curl -s -X POST \
    -H "Authorization: token ${GITEA_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "${REPO_PAYLOAD}" \
    "${API_ENDPOINT}")

# Check if repository was created
if echo "$REPO_RESPONSE" | jq -e '.id' > /dev/null 2>&1; then
    REPO_ID=$(echo "$REPO_RESPONSE" | jq -r '.id')
    REPO_URL=$(echo "$REPO_RESPONSE" | jq -r '.clone_url')
    REPO_SSH_URL=$(echo "$REPO_RESPONSE" | jq -r '.ssh_url')
    log_success "Repository created: ${REPO_URL}"
else
    log_error "Failed to create repository"
    echo "$REPO_RESPONSE" | jq -r '.message // .error // "Unknown error"'
    exit 1
fi

echo ""
echo "============================================================"
echo "Step 4: Configuring git remote"
echo "============================================================"
echo ""

log_info "Adding remote origin..."
git remote add origin "${REPO_SSH_URL}"
log_success "Remote added: ${REPO_SSH_URL}"

log_info "Pushing to Gitea..."
if git push -u origin main; then
    log_success "Repository pushed to Gitea"
else
    log_error "Failed to push to Gitea"
    log_warning "You may need to configure SSH access first"
    exit 1
fi

# Add deploy key if SSH key was generated
if [ "$GENERATE_SSH_KEY" = true ]; then
    echo ""
    echo "============================================================"
    echo "Step 5: Adding deploy key"
    echo "============================================================"
    echo ""
    
    log_info "Reading SSH public key..."
    SSH_PUBLIC_KEY=$(cat "${SSH_KEY_PATH}.pub")
    
    log_info "Adding deploy key to repository..."
    
    DEPLOY_KEY_PAYLOAD=$(cat <<EOF
{
  "title": "GitOps Deploy Key",
  "key": "${SSH_PUBLIC_KEY}",
  "read_only": false
}
EOF
)
    
    DEPLOY_KEY_RESPONSE=$(curl -s -X POST \
        -H "Authorization: token ${GITEA_TOKEN}" \
        -H "Content-Type: application/json" \
        -d "${DEPLOY_KEY_PAYLOAD}" \
        "${GITEA_URL}/api/v1/repos/${OWNER}/${REPO_NAME}/keys")
    
    if echo "$DEPLOY_KEY_RESPONSE" | jq -e '.id' > /dev/null 2>&1; then
        log_success "Deploy key added with write access"
    else
        log_error "Failed to add deploy key"
        echo "$DEPLOY_KEY_RESPONSE" | jq -r '.message // .error // "Unknown error"'
        log_warning "You can add the deploy key manually in Gitea"
    fi
fi

echo ""
echo "============================================================"
echo "Repository Creation Complete!"
echo "============================================================"
echo ""

log_success "GitOps repository created successfully!"
echo ""
echo "Repository Information:"
echo "  Name:           ${REPO_NAME}"
echo "  Owner:          ${OWNER} (${OWNER_TYPE})"
echo "  URL:            ${REPO_URL}"
echo "  SSH URL:        ${REPO_SSH_URL}"
echo "  Local Path:     ${REPO_PATH}"
if [ "$GENERATE_SSH_KEY" = true ]; then
    echo "  SSH Key:        ${SSH_KEY_PATH}"
    echo "  SSH Public Key: ${SSH_KEY_PATH}.pub"
fi
echo ""

log_info "Next steps:"
echo "  1. Configure ArgoCD to use this repository:"
echo "     ./gitea-configure-argocd.sh --gitea-url ${GITEA_URL} --repo ${OWNER}/${REPO_NAME}"
echo ""
echo "  2. Configure broker to use this repository:"
echo "     ./gitea-configure-broker.sh --gitea-url ${GITEA_URL} --repo ${OWNER}/${REPO_NAME}"
echo ""
if [ "$GENERATE_SSH_KEY" = true ]; then
    echo "  3. Use the SSH private key for authentication:"
    echo "     ${SSH_KEY_PATH}"
    echo ""
fi

# Made with Bob