#!/bin/bash
#
# Configure BYOP Broker to use Gitea Repository
# Configures SSH authentication and GitOps repository URL
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE="byop"
CONTEXT=""
GITEA_URL=""
REPO_URL=""
SSH_KEY_PATH=""
RESTART_DEPLOYMENT=false
DRY_RUN=false

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# Build kubectl/oc command with context if specified
k8s_cmd() {
    local cmd="kubectl"
    if command -v oc &> /dev/null; then
        cmd="oc"
    fi
    
    if [ -n "$CONTEXT" ]; then
        $cmd --context="${CONTEXT}" "$@"
    else
        $cmd "$@"
    fi
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Configure BYOP Broker to access a Gitea repository for GitOps operations.

This script:
  1. Updates the broker's SSH private key secret
  2. Updates the broker's GitOps repository URL in ConfigMap
  3. Optionally restarts the broker deployment to apply changes
  4. Verifies the broker can access the repository

Options:
  --context CONTEXT       Kubernetes context (optional; uses current context if omitted)
  --namespace NAMESPACE   Broker namespace (default: byop)
  --gitea-url URL         Gitea server URL (required)
                         Example: http://gitea.example.com or https://gitea-gitea.apps.example.com
  --repo-url URL          Git repository URL in SSH format (required)
                         Example: git@gitea.example.com:myorg/gitops.git
  --ssh-key-path PATH     Path to SSH private key (required)
                         The private key used for Git authentication
  --restart              Restart broker deployment after configuration (default: false)
  --dry-run              Show what would be done without making changes
  -h, --help             Show this help message

Prerequisites:
  - kubectl or oc CLI installed
  - Broker deployed in the specified namespace
  - SSH private key with access to Gitea repository
  - Gitea repository already created (use gitea-repo-create.sh)

Examples:
  # Configure broker with Gitea repository
  $0 \\
    --namespace byop \\
    --gitea-url http://gitea.example.com \\
    --repo-url git@gitea.example.com:myorg/gitops.git \\
    --ssh-key-path ~/git/gitea/gitops/ssh/gitops

  # Configure and restart broker
  $0 \\
    --namespace byop \\
    --gitea-url http://gitea.example.com \\
    --repo-url git@gitea.example.com:myorg/gitops.git \\
    --ssh-key-path ~/git/gitea/gitops/ssh/gitops \\
    --restart

  # Dry run to see what would be done
  $0 \\
    --namespace byop \\
    --gitea-url http://gitea.example.com \\
    --repo-url git@gitea.example.com:myorg/gitops.git \\
    --ssh-key-path ~/git/gitea/gitops/ssh/gitops \\
    --dry-run

  # Use specific Kubernetes context
  $0 \\
    --context my-cluster \\
    --namespace byop \\
    --gitea-url http://gitea.example.com \\
    --repo-url git@gitea.example.com:myorg/gitops.git \\
    --ssh-key-path ~/git/gitea/gitops/ssh/gitops

Integration Workflow:
  1. Install Gitea: ./gitea-install.sh
  2. Create GitOps repo: ./gitea-repo-create.sh
  3. Configure ArgoCD: ./gitea-configure-argocd.sh
  4. Configure Broker: ./gitea-configure-broker.sh (this script)
  5. Provision services via broker API

Notes:
  - The broker expects SSH authentication for Git operations
  - The SSH key must have write access to the repository
  - The broker will use the repository URL from the ConfigMap
  - Restart is optional but recommended to ensure changes take effect
  - The broker's GitOps cache will be cleared on restart

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --context)
            CONTEXT="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --gitea-url)
            GITEA_URL="$2"
            shift 2
            ;;
        --repo-url)
            REPO_URL="$2"
            shift 2
            ;;
        --ssh-key-path)
            SSH_KEY_PATH="$2"
            shift 2
            ;;
        --restart)
            RESTART_DEPLOYMENT=true
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Validate required parameters
if [ -z "$GITEA_URL" ]; then
    log_error "Missing required parameter: --gitea-url"
    echo ""
    show_help
    exit 1
fi

if [ -z "$REPO_URL" ]; then
    log_error "Missing required parameter: --repo-url"
    echo ""
    show_help
    exit 1
fi

if [ -z "$SSH_KEY_PATH" ]; then
    log_error "Missing required parameter: --ssh-key-path"
    echo ""
    show_help
    exit 1
fi

# Validate SSH URL format
if [[ ! "$REPO_URL" =~ ^git@ ]]; then
    log_error "Repository URL must be in SSH format (git@host:org/repo.git)"
    log_error "Got: $REPO_URL"
    exit 1
fi

# Expand tilde in SSH key path
SSH_KEY_PATH="${SSH_KEY_PATH/#\~/$HOME}"

# Validate SSH key exists
if [ ! -f "$SSH_KEY_PATH" ]; then
    log_error "SSH private key not found: $SSH_KEY_PATH"
    exit 1
fi

# Check SSH key permissions
KEY_PERMS=$(stat -f "%OLp" "$SSH_KEY_PATH" 2>/dev/null || stat -c "%a" "$SSH_KEY_PATH" 2>/dev/null)
if [ "$KEY_PERMS" != "600" ] && [ "$KEY_PERMS" != "400" ]; then
    log_warning "SSH key permissions are $KEY_PERMS (should be 600 or 400)"
    log_warning "Consider running: chmod 600 $SSH_KEY_PATH"
fi

log_info "Starting broker configuration for Gitea..."
echo ""
log_info "Configuration:"
log_info "  Namespace: $NAMESPACE"
log_info "  Gitea URL: $GITEA_URL"
log_info "  Repository URL: $REPO_URL"
log_info "  SSH Key: $SSH_KEY_PATH"
log_info "  Restart Deployment: $RESTART_DEPLOYMENT"
if [ "$DRY_RUN" = true ]; then
    log_warning "DRY RUN MODE - No changes will be made"
fi
echo ""

# Check prerequisites
log_info "Checking prerequisites..."

# Check for kubectl/oc
if ! command -v kubectl &> /dev/null && ! command -v oc &> /dev/null; then
    log_error "Neither kubectl nor oc found in PATH"
    exit 1
fi

if command -v oc &> /dev/null; then
    log_success "Found oc CLI"
else
    log_success "Found kubectl CLI"
fi

# Check namespace exists
if ! k8s_cmd get namespace "$NAMESPACE" &> /dev/null; then
    log_error "Namespace '$NAMESPACE' does not exist"
    exit 1
fi
log_success "Namespace '$NAMESPACE' exists"

# Check broker deployment exists
DEPLOYMENT_NAME=$(k8s_cmd get deployment -n "$NAMESPACE" -l app.kubernetes.io/component=broker -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
if [ -z "$DEPLOYMENT_NAME" ]; then
    log_error "Broker deployment not found in namespace '$NAMESPACE'"
    log_error "Expected deployment with label: app.kubernetes.io/component=broker"
    exit 1
fi
log_success "Found broker deployment: $DEPLOYMENT_NAME"

# Get secret name
SECRET_NAME=$(k8s_cmd get secret -n "$NAMESPACE" -l app.kubernetes.io/component=broker -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
if [ -z "$SECRET_NAME" ]; then
    log_error "Broker secret not found in namespace '$NAMESPACE'"
    log_error "Expected secret with label: app.kubernetes.io/component=broker"
    exit 1
fi
log_success "Found broker secret: $SECRET_NAME"

# Get configmap name
CONFIGMAP_NAME=$(k8s_cmd get configmap -n "$NAMESPACE" -l app.kubernetes.io/component=broker -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
if [ -z "$CONFIGMAP_NAME" ]; then
    log_error "Broker ConfigMap not found in namespace '$NAMESPACE'"
    log_error "Expected ConfigMap with label: app.kubernetes.io/component=broker"
    exit 1
fi
log_success "Found broker ConfigMap: $CONFIGMAP_NAME"

echo ""

# Step 1: Update SSH private key secret
log_info "Step 1: Updating SSH private key secret..."

if [ "$DRY_RUN" = true ]; then
    log_info "[DRY RUN] Would update secret '$SECRET_NAME' with SSH private key"
else
    # Read SSH private key
    SSH_KEY_CONTENT=$(cat "$SSH_KEY_PATH")
    
    # Update secret
    k8s_cmd patch secret "$SECRET_NAME" -n "$NAMESPACE" \
        --type='json' \
        -p="[{\"op\": \"replace\", \"path\": \"/data/ssh-private-key\", \"value\": \"$(echo -n "$SSH_KEY_CONTENT" | base64 | tr -d '\n')\"}]"
    
    log_success "Updated SSH private key in secret '$SECRET_NAME'"
fi

echo ""

# Step 2: Update GitOps repository URL in ConfigMap
log_info "Step 2: Updating GitOps repository URL in ConfigMap..."

if [ "$DRY_RUN" = true ]; then
    log_info "[DRY RUN] Would update ConfigMap '$CONFIGMAP_NAME' with repository URL: $REPO_URL"
else
    # Get current ConfigMap data
    CURRENT_CONFIG=$(k8s_cmd get configmap "$CONFIGMAP_NAME" -n "$NAMESPACE" -o jsonpath='{.data.config\.gitops\.json}')
    
    # Update repo_url in the JSON config
    UPDATED_CONFIG=$(echo "$CURRENT_CONFIG" | jq --arg url "$REPO_URL" '.gitops.repo_url = $url')
    
    # Create temporary file for the updated config
    TEMP_CONFIG=$(mktemp)
    echo "$UPDATED_CONFIG" > "$TEMP_CONFIG"
    
    # Update ConfigMap
    k8s_cmd create configmap "$CONFIGMAP_NAME" \
        --from-file=config.gitops.json="$TEMP_CONFIG" \
        --dry-run=client -o yaml | \
        k8s_cmd apply -n "$NAMESPACE" -f -
    
    # Clean up
    rm -f "$TEMP_CONFIG"
    
    log_success "Updated repository URL in ConfigMap '$CONFIGMAP_NAME'"
fi

echo ""

# Step 3: Restart broker deployment (optional)
if [ "$RESTART_DEPLOYMENT" = true ]; then
    log_info "Step 3: Restarting broker deployment..."
    
    if [ "$DRY_RUN" = true ]; then
        log_info "[DRY RUN] Would restart deployment '$DEPLOYMENT_NAME'"
    else
        k8s_cmd rollout restart deployment "$DEPLOYMENT_NAME" -n "$NAMESPACE"
        log_success "Initiated rollout restart of deployment '$DEPLOYMENT_NAME'"
        
        log_info "Waiting for deployment to be ready..."
        if k8s_cmd rollout status deployment "$DEPLOYMENT_NAME" -n "$NAMESPACE" --timeout=120s; then
            log_success "Deployment is ready"
        else
            log_warning "Deployment rollout timed out or failed"
            log_warning "Check deployment status with: kubectl get pods -n $NAMESPACE"
        fi
    fi
else
    log_info "Step 3: Skipping deployment restart (use --restart to enable)"
    log_warning "Changes will take effect when broker pods are restarted"
fi

echo ""

# Step 4: Display configuration summary
log_info "Configuration Summary:"
echo ""
log_info "Broker Configuration:"
log_info "  Namespace: $NAMESPACE"
log_info "  Deployment: $DEPLOYMENT_NAME"
log_info "  Secret: $SECRET_NAME"
log_info "  ConfigMap: $CONFIGMAP_NAME"
echo ""
log_info "GitOps Configuration:"
log_info "  Repository URL: $REPO_URL"
log_info "  SSH Key: Updated in secret"
log_info "  Gitea URL: $GITEA_URL"
echo ""

if [ "$DRY_RUN" = false ]; then
    log_success "Broker configuration complete!"
    echo ""
    log_info "Next Steps:"
    log_info "  1. Verify broker can access repository:"
    log_info "     kubectl logs -n $NAMESPACE deployment/$DEPLOYMENT_NAME"
    log_info "  2. Test service provisioning via broker API"
    log_info "  3. Verify commits appear in Gitea repository"
    log_info "  4. Verify ArgoCD syncs from Gitea repository"
    echo ""
    
    if [ "$RESTART_DEPLOYMENT" = false ]; then
        log_warning "Reminder: Restart broker deployment to apply changes:"
        log_warning "  kubectl rollout restart deployment $DEPLOYMENT_NAME -n $NAMESPACE"
    fi
else
    log_info "Dry run complete - no changes were made"
fi

# Made with Bob
