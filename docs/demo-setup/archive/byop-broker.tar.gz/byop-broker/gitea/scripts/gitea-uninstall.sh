#!/bin/bash
#
# Gitea Uninstall Script
# Cleanly removes Gitea from Kubernetes/OpenShift
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
NAMESPACE="gitea"
CONTEXT=""
FORCE=false
DELETE_NAMESPACE=false
DELETE_PVCS=false
RELEASE_NAME="gitea"

# Build kubectl/oc command with context if specified
k8s_cmd() {
    local cmd="kubectl"
    if command -v oc &> /dev/null; then
        cmd="oc"
    fi
    
    if [ -n "$CONTEXT" ]; then
        $cmd --context="${CONTEXT}" "$@"
    else
        $cmd "$@"
    fi
}

# Build helm command with context if specified
helm_cmd() {
    if [ -n "$CONTEXT" ]; then
        helm --kube-context="${CONTEXT}" "$@"
    else
        helm "$@"
    fi
}

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Uninstall Gitea from Kubernetes/OpenShift cluster.

This script performs cleanup in the following order:
  1. Uninstall Gitea Helm release
  2. Optionally delete PVCs (persistent data)
  3. Optionally delete namespace

Options:
  --context CONTEXT       Kubernetes context (optional; uses current context if omitted)
  --namespace NAMESPACE   Gitea namespace (default: gitea)
  --release-name NAME     Helm release name (default: gitea)
  --delete-namespace      Delete the namespace after uninstall (default: keep namespace)
  --delete-pvcs           Delete PVCs and all data (default: keep PVCs for potential reinstall)
  -f, --force            Skip all confirmation prompts
  -h, --help             Show this help message

Examples:
  # Uninstall with prompts (keeps namespace and PVCs)
  $0 --namespace gitea

  # Auto-confirm all steps
  $0 --namespace gitea --force

  # Short form
  $0 --namespace gitea -f

  # Delete everything including data
  $0 --namespace gitea --delete-namespace --delete-pvcs --force

  # Uninstall specific release
  $0 --namespace gitea --release-name my-gitea

Warning:
  Using --delete-pvcs will permanently delete all Gitea data including:
  - Git repositories
  - User accounts
  - Issues and pull requests
  - Database content

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --context)
            CONTEXT="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --release-name)
            RELEASE_NAME="$2"
            shift 2
            ;;
        --delete-namespace)
            DELETE_NAMESPACE=true
            shift
            ;;
        --delete-pvcs)
            DELETE_PVCS=true
            shift
            ;;
        -f|--force)
            FORCE=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Determine actual context
if [ -n "$CONTEXT" ]; then
    ACTUAL_CONTEXT="$CONTEXT"
    CONTEXT_SOURCE="specified via --context"
else
    ACTUAL_CONTEXT=$(kubectl config current-context 2>/dev/null || echo "unknown")
    CONTEXT_SOURCE="using current context"
fi

echo "============================================================"
echo "Gitea Uninstall"
echo "============================================================"
echo ""
echo "⚠️  KUBERNETES CONTEXT: ${ACTUAL_CONTEXT}"
echo "    (${CONTEXT_SOURCE})"
echo ""
echo "Configuration:"
echo "  Namespace:        ${NAMESPACE}"
echo "  Release Name:     ${RELEASE_NAME}"
echo "  Delete Namespace: ${DELETE_NAMESPACE}"
echo "  Delete PVCs:      ${DELETE_PVCS}"
echo "  Force:            ${FORCE}"
echo ""

# Check prerequisites
log_info "Checking prerequisites..."

# Check kubectl/oc
if ! command -v kubectl &> /dev/null && ! command -v oc &> /dev/null; then
    log_error "kubectl or oc is not installed"
    exit 1
fi
log_success "kubectl/oc is installed"

# Check helm
if ! command -v helm &> /dev/null; then
    log_error "helm is not installed"
    exit 1
fi
log_success "helm is installed"

# Check cluster connectivity
if ! k8s_cmd cluster-info &> /dev/null; then
    log_error "Cannot connect to cluster"
    exit 1
fi
log_success "Cluster is accessible"

# Check if namespace exists
if ! k8s_cmd get namespace "${NAMESPACE}" &> /dev/null; then
    log_warning "Namespace '${NAMESPACE}' does not exist"
    log_info "Nothing to uninstall"
    exit 0
fi

# Check if Helm release exists
if ! helm_cmd list -n "${NAMESPACE}" | grep -q "^${RELEASE_NAME}"; then
    log_warning "Helm release '${RELEASE_NAME}' not found in namespace '${NAMESPACE}'"
    
    if [ "$FORCE" = false ]; then
        read -p "Continue with cleanup anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log_info "Uninstall cancelled"
            exit 0
        fi
    fi
fi

log_success "All prerequisites met"
echo ""

# Confirmation prompt
if [ "$FORCE" = false ]; then
    echo "============================================================"
    echo "⚠️  WARNING: This will uninstall Gitea"
    echo "============================================================"
    echo ""
    echo "The following will be removed:"
    echo "  - Gitea Helm release: ${RELEASE_NAME}"
    echo "  - Gitea application and services"
    echo "  - PostgreSQL database (if enabled)"
    echo "  - Redis cache (if enabled)"
    
    if [ "$DELETE_PVCS" = true ]; then
        echo ""
        echo "⚠️  DANGER: PVCs will be DELETED"
        echo "  - All Git repositories will be LOST"
        echo "  - All user data will be LOST"
        echo "  - All database content will be LOST"
    else
        echo ""
        echo "PVCs will be KEPT (data preserved for potential reinstall)"
    fi
    
    if [ "$DELETE_NAMESPACE" = true ]; then
        echo ""
        echo "Namespace '${NAMESPACE}' will be DELETED"
    else
        echo ""
        echo "Namespace '${NAMESPACE}' will be KEPT"
    fi
    
    echo ""
    read -p "Are you sure you want to proceed? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log_info "Uninstall cancelled"
        exit 0
    fi
    
    if [ "$DELETE_PVCS" = true ]; then
        echo ""
        log_warning "FINAL WARNING: All data will be permanently deleted!"
        read -p "Type 'DELETE' to confirm data deletion: " -r
        echo
        if [[ ! $REPLY == "DELETE" ]]; then
            log_info "Uninstall cancelled"
            exit 0
        fi
    fi
fi

echo ""
echo "============================================================"
echo "Step 1: Uninstalling Gitea Helm release"
echo "============================================================"
echo ""

log_info "Uninstalling Helm release '${RELEASE_NAME}'..."

if helm_cmd uninstall "${RELEASE_NAME}" -n "${NAMESPACE}" 2>&1; then
    log_success "Helm release uninstalled"
else
    log_warning "Helm release may not exist or already uninstalled"
fi

# Wait for pods to terminate
log_info "Waiting for pods to terminate..."
sleep 5

# Check if any pods remain
REMAINING_PODS=$(k8s_cmd get pods -n "${NAMESPACE}" --no-headers 2>/dev/null | wc -l || echo "0")
if [ "$REMAINING_PODS" -gt 0 ]; then
    log_info "Waiting for ${REMAINING_PODS} pod(s) to terminate..."
    k8s_cmd wait --for=delete pod --all -n "${NAMESPACE}" --timeout=60s 2>/dev/null || log_warning "Some pods may still be terminating"
fi

log_success "Gitea uninstalled"

echo ""
echo "============================================================"
echo "Step 2: Cleaning up resources"
echo "============================================================"
echo ""

# Delete PVCs if requested
if [ "$DELETE_PVCS" = true ]; then
    log_info "Deleting PVCs (this will delete all data)..."
    
    PVCS=$(k8s_cmd get pvc -n "${NAMESPACE}" --no-headers 2>/dev/null | awk '{print $1}' || echo "")
    
    if [ -n "$PVCS" ]; then
        for pvc in $PVCS; do
            log_info "Deleting PVC: ${pvc}"
            if k8s_cmd delete pvc "${pvc}" -n "${NAMESPACE}" --timeout=60s 2>&1; then
                log_success "PVC deleted: ${pvc}"
            else
                log_warning "Failed to delete PVC: ${pvc}"
            fi
        done
    else
        log_info "No PVCs found"
    fi
else
    PVCS=$(k8s_cmd get pvc -n "${NAMESPACE}" --no-headers 2>/dev/null | awk '{print $1}' || echo "")
    if [ -n "$PVCS" ]; then
        log_info "PVCs preserved (data retained):"
        for pvc in $PVCS; do
            echo "  - ${pvc}"
        done
        echo ""
        log_info "To delete PVCs later, run:"
        echo "  kubectl delete pvc --all -n ${NAMESPACE}"
    fi
fi

# Delete secrets
log_info "Cleaning up secrets..."
SECRETS=$(k8s_cmd get secrets -n "${NAMESPACE}" --no-headers 2>/dev/null | grep -E "gitea|postgres|redis" | awk '{print $1}' || echo "")
if [ -n "$SECRETS" ]; then
    for secret in $SECRETS; do
        k8s_cmd delete secret "${secret}" -n "${NAMESPACE}" 2>/dev/null || true
    done
    log_success "Secrets cleaned up"
else
    log_info "No secrets to clean up"
fi

# Delete configmaps
log_info "Cleaning up configmaps..."
CONFIGMAPS=$(k8s_cmd get configmaps -n "${NAMESPACE}" --no-headers 2>/dev/null | grep -E "gitea|postgres|redis" | awk '{print $1}' || echo "")
if [ -n "$CONFIGMAPS" ]; then
    for cm in $CONFIGMAPS; do
        k8s_cmd delete configmap "${cm}" -n "${NAMESPACE}" 2>/dev/null || true
    done
    log_success "ConfigMaps cleaned up"
else
    log_info "No configmaps to clean up"
fi

echo ""
echo "============================================================"
echo "Step 3: Namespace cleanup"
echo "============================================================"
echo ""

if [ "$DELETE_NAMESPACE" = true ]; then
    log_info "Deleting namespace '${NAMESPACE}'..."
    
    if k8s_cmd delete namespace "${NAMESPACE}" --timeout=120s 2>&1; then
        log_success "Namespace deleted"
    else
        log_warning "Failed to delete namespace (may require manual cleanup)"
        log_info "Check namespace status with: kubectl get namespace ${NAMESPACE}"
    fi
else
    log_info "Namespace '${NAMESPACE}' preserved"
    log_info "To delete namespace later, run:"
    echo "  kubectl delete namespace ${NAMESPACE}"
fi

echo ""
echo "============================================================"
echo "Uninstall Complete!"
echo "============================================================"
echo ""

log_success "Gitea has been uninstalled from namespace '${NAMESPACE}'"

if [ "$DELETE_PVCS" = false ]; then
    echo ""
    log_info "Data has been preserved in PVCs"
    log_info "To reinstall Gitea with existing data:"
    echo "  ./gitea-install.sh --namespace ${NAMESPACE}"
fi

if [ "$DELETE_NAMESPACE" = false ]; then
    echo ""
    log_info "Namespace '${NAMESPACE}' has been preserved"
    log_info "To completely remove everything:"
    echo "  kubectl delete namespace ${NAMESPACE}"
fi

echo ""
log_success "Uninstall completed successfully!"

# Made with Bob
