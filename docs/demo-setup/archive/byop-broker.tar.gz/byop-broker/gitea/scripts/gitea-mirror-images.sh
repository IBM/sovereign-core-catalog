#!/bin/bash
#
# Gitea Image Mirroring Script
# Mirrors Gitea container images to a private registry for air-gapped deployments
#

set -e

# Get script directory (works regardless of CWD)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GITEA_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
MIRROR_REGISTRY=""
IMAGESET_CONFIG="${GITEA_ROOT}/imagesetconfiguration.yaml"
OUTPUT_DIR="./mirror-output"
ACTION=""
MAX_RETRIES=3
RETRY_DELAY=30

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

show_help() {
    cat << EOF
Usage: $0 --mirror-registry HOST/ORG [OPTIONS]

Mirror Gitea container images to a private registry for air-gapped deployments.

Required Options:
  --mirror-registry HOST/ORG  Target mirror registry (e.g., registry.example.com/gitea)

Optional Options:
  --imageset-config FILE      Path to ImageSetConfiguration YAML
                              (default: ${GITEA_ROOT}/imagesetconfiguration.yaml)
  --output-dir DIR            Output directory for mirrored images
                              (default: ./mirror-output)
  --max-retries N             Maximum number of retry attempts (default: 3)
  --retry-delay N             Delay between retries in seconds (default: 30)
  --download-only             Only download images (don't publish)
  --publish-only              Only publish images (skip download)
  -h, --help                  Show this help message

Workflow:
  This script wraps oc-mirror commands to simplify the image mirroring workflow:

  1. Download images from source registries (docker.io)
  2. Package images for transfer (optional: create tarball)
  3. Publish images to target mirror registry

  For air-gapped environments:
    # On internet-connected machine:
    $0 --mirror-registry registry.example.com/gitea --download-only
    tar -czf mirror-output.tar.gz mirror-output/

    # Transfer mirror-output.tar.gz to air-gapped environment

    # On air-gapped machine:
    tar -xzf mirror-output.tar.gz
    $0 --mirror-registry registry.example.com/gitea --publish-only

  For connected environments:
    # Download and publish in one step:
    $0 --mirror-registry registry.example.com/gitea

Image Transformations:
  The script mirrors these images with the following transformations:
    docker.io/gitea/gitea:1.26.2          → registry.example.com/gitea/gitea:1.26.2
    docker.io/library/postgres:15-alpine  → registry.example.com/gitea/postgres:15-alpine
    docker.io/library/redis:7-alpine      → registry.example.com/gitea/redis:7-alpine

Prerequisites:
  - oc-mirror CLI tool installed
  - Podman or Docker installed
  - Authentication configured for target registry

Examples:
  # Download and publish images (connected environment)
  $0 --mirror-registry registry.example.com/gitea

  # Download only (for air-gapped transfer)
  $0 --mirror-registry registry.example.com/gitea --download-only

  # Publish only (after air-gapped transfer)
  $0 --mirror-registry registry.example.com/gitea --publish-only

  # Use custom ImageSetConfiguration
  $0 --mirror-registry registry.example.com/gitea --imageset-config custom-imageset.yaml

After Mirroring:
  Install Gitea with mirrored images:
    ./gitea-install.sh --use-upstream --mirror-registry registry.example.com/gitea

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --mirror-registry)
            MIRROR_REGISTRY="$2"
            shift 2
            ;;
        --imageset-config)
            IMAGESET_CONFIG="$2"
            shift 2
            ;;
        --output-dir)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        --max-retries)
            MAX_RETRIES="$2"
            shift 2
            ;;
        --retry-delay)
            RETRY_DELAY="$2"
            shift 2
            ;;
        --download-only)
            ACTION="download"
            shift
            ;;
        --publish-only)
            ACTION="publish"
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Validate required parameters
if [ -z "$MIRROR_REGISTRY" ]; then
    log_error "Mirror registry is required"
    echo ""
    echo "Specify mirror registry:"
    echo "  $0 --mirror-registry registry.example.com/gitea"
    exit 1
fi

# Validate ImageSetConfiguration file exists
if [ ! -f "$IMAGESET_CONFIG" ]; then
    log_error "ImageSetConfiguration file not found: $IMAGESET_CONFIG"
    exit 1
fi

# Check prerequisites
log_info "Checking prerequisites..."

# Check oc-mirror
if ! command -v oc-mirror &> /dev/null; then
    log_error "oc-mirror is not installed"
    echo ""
    echo "Install oc-mirror:"
    echo "  https://docs.openshift.com/container-platform/latest/installing/disconnected_install/installing-mirroring-installation-images.html"
    exit 1
fi
log_success "oc-mirror is installed"

# Check podman or docker
if ! command -v podman &> /dev/null && ! command -v docker &> /dev/null; then
    log_error "podman or docker is not installed"
    exit 1
fi
log_success "Container runtime is available"

log_success "All prerequisites met"
echo ""

echo "============================================================"
echo "Gitea Image Mirroring"
echo "============================================================"
echo ""
echo "Configuration:"
echo "  Mirror Registry:  ${MIRROR_REGISTRY}"
echo "  ImageSet Config:  ${IMAGESET_CONFIG}"
echo "  Output Directory: ${OUTPUT_DIR}"
if [ -n "$ACTION" ]; then
    echo "  Action:           ${ACTION}"
else
    echo "  Action:           download and publish"
fi
echo ""

# Extract registry host and organization from mirror registry
REGISTRY_HOST="${MIRROR_REGISTRY%%/*}"
if [[ "$MIRROR_REGISTRY" == *"/"* ]]; then
    REGISTRY_ORG="${MIRROR_REGISTRY#*/}"
    DESTINATION="docker://${REGISTRY_HOST}/${REGISTRY_ORG}"
    log_info "Target registry: ${REGISTRY_HOST}"
    log_info "Target organization: ${REGISTRY_ORG}"
else
    REGISTRY_ORG=""
    DESTINATION="docker://${REGISTRY_HOST}"
    log_info "Target registry: ${REGISTRY_HOST}"
    log_info "Target organization: (none - using registry root)"
fi
echo ""

# Download images
if [ "$ACTION" != "publish" ]; then
    echo "============================================================"
    echo "Step 1: Downloading images from source registries"
    echo "============================================================"
    echo ""
    
    log_info "Downloading images using oc-mirror..."
    log_info "This may take several minutes depending on network speed..."
    echo ""
    
    # Change to gitea root directory so containerized oc-mirror can access files
    # The containerized wrapper mounts $(pwd) as /workspace in the container
    cd "${GITEA_ROOT}"
    
    # Use relative path for ImageSetConfiguration (relative to gitea root)
    RELATIVE_IMAGESET_CONFIG="./imagesetconfiguration.yaml"
    
    # Retry loop for download
    ATTEMPT=1
    SUCCESS=false
    
    while [ $ATTEMPT -le $MAX_RETRIES ]; do
        if [ $ATTEMPT -gt 1 ]; then
            log_info "Retry attempt ${ATTEMPT}/${MAX_RETRIES} after ${RETRY_DELAY}s delay..."
            sleep $RETRY_DELAY
        fi
        
        if oc-mirror --config="${RELATIVE_IMAGESET_CONFIG}" file://"${OUTPUT_DIR}" --v2; then
            log_success "Images downloaded successfully"
            SUCCESS=true
            break
        else
            EXIT_CODE=$?
            
            if [ $ATTEMPT -eq $MAX_RETRIES ]; then
                log_error "Failed to download images after ${MAX_RETRIES} attempts"
                
                # Check if error log exists
                ERROR_LOG=$(find "${OUTPUT_DIR}/working-dir/logs" -name "mirroring_errors_*.txt" 2>/dev/null | head -n 1)
                if [ -n "$ERROR_LOG" ] && [ -f "$ERROR_LOG" ]; then
                    echo ""
                    log_error "Error details:"
                    cat "$ERROR_LOG"
                    echo ""
                fi
                
                log_info "Troubleshooting:"
                echo "  - Check network connectivity"
                echo "  - Verify Docker Hub is accessible"
                echo "  - Try again later (transient errors)"
                echo "  - Increase --max-retries or --retry-delay"
                exit 1
            else
                log_warning "Attempt ${ATTEMPT}/${MAX_RETRIES} failed (exit code: ${EXIT_CODE})"
            fi
        fi
        
        ATTEMPT=$((ATTEMPT + 1))
    done
    
    echo ""
    log_info "Downloaded images are stored in: ${OUTPUT_DIR}"
    
    if [ "$ACTION" = "download" ]; then
        echo ""
        log_success "Download complete!"
        echo ""
        log_info "Next steps for air-gapped transfer:"
        echo "  1. Create tarball: tar -czf mirror-output.tar.gz ${OUTPUT_DIR}/"
        echo "  2. Transfer tarball to air-gapped environment"
        echo "  3. Extract: tar -xzf mirror-output.tar.gz"
        echo "  4. Publish: $0 --mirror-registry ${MIRROR_REGISTRY} --publish-only"
        exit 0
    fi
fi

# Publish images
if [ "$ACTION" != "download" ]; then
    echo ""
    echo "============================================================"
    echo "Step 2: Publishing images to mirror registry"
    echo "============================================================"
    echo ""
    
    # Verify output directory exists for publish-only mode
    if [ "$ACTION" = "publish" ] && [ ! -d "$OUTPUT_DIR" ]; then
        log_error "Output directory not found: ${OUTPUT_DIR}"
        log_info "Run with --download-only first or extract the mirror tarball"
        exit 1
    fi
    
    log_info "Publishing images to ${MIRROR_REGISTRY}..."
    log_info "This may take several minutes depending on network speed..."
    echo ""
    
    # Change to gitea root directory so containerized oc-mirror can access files
    # The containerized wrapper mounts $(pwd) as /workspace in the container
    cd "${GITEA_ROOT}"
    
    # Retry loop for publish
    ATTEMPT=1
    SUCCESS=false
    
    while [ $ATTEMPT -le $MAX_RETRIES ]; do
        if [ $ATTEMPT -gt 1 ]; then
            log_info "Retry attempt ${ATTEMPT}/${MAX_RETRIES} after ${RETRY_DELAY}s delay..."
            sleep $RETRY_DELAY
        fi
        
        # Use relative path for ImageSetConfiguration (relative to gitea root)
        RELATIVE_IMAGESET_CONFIG="./imagesetconfiguration.yaml"
        
        # Use --dest-tls-verify=false for registries with self-signed certs (like Quay)
        # Explicitly specify authfile location for Podman compatibility
        if oc-mirror --config="${RELATIVE_IMAGESET_CONFIG}" --from=file://"${OUTPUT_DIR}" "${DESTINATION}" --dest-tls-verify=false --authfile="${HOME}/.docker/config.json" --v2; then
            log_success "Images published successfully"
            SUCCESS=true
            break
        else
            EXIT_CODE=$?
            
            if [ $ATTEMPT -eq $MAX_RETRIES ]; then
                log_error "Failed to publish images after ${MAX_RETRIES} attempts"
                
                # Check if error log exists
                ERROR_LOG=$(find "${OUTPUT_DIR}/working-dir/logs" -name "mirroring_errors_*.txt" 2>/dev/null | head -n 1)
                if [ -n "$ERROR_LOG" ] && [ -f "$ERROR_LOG" ]; then
                    echo ""
                    log_error "Error details:"
                    cat "$ERROR_LOG"
                    echo ""
                fi
                
                log_info "Troubleshooting:"
                echo "  - Verify registry authentication"
                echo "  - Check registry connectivity"
                echo "  - Verify registry has sufficient storage"
                echo "  - Increase --max-retries or --retry-delay"
                exit 1
            else
                log_warning "Attempt ${ATTEMPT}/${MAX_RETRIES} failed (exit code: ${EXIT_CODE})"
            fi
        fi
        
        ATTEMPT=$((ATTEMPT + 1))
    done
fi

echo ""
echo "============================================================"
echo "Mirroring Complete!"
echo "============================================================"
echo ""

log_success "Images have been mirrored to: ${MIRROR_REGISTRY}"
echo ""
echo "Mirrored images:"
echo "  ${MIRROR_REGISTRY}/gitea:1.26.2"
echo "  ${MIRROR_REGISTRY}/postgres:15-alpine"
echo "  ${MIRROR_REGISTRY}/redis:7-alpine"
echo ""
log_info "Next steps:"
echo "  1. Verify images in registry:"
echo "     podman search ${REGISTRY_HOST}/${REGISTRY_ORG}/gitea"
echo ""
echo "  2. Install Gitea with mirrored images:"
echo "     ./gitea-install.sh --use-upstream --mirror-registry ${MIRROR_REGISTRY}"
echo ""

log_success "Image mirroring completed successfully!"

# Made with Bob