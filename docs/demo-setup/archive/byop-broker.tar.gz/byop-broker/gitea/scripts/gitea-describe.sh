#!/bin/bash
#
# Gitea Describe Script
# Display information about Gitea installation
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Default values
NAMESPACE="gitea"
CONTEXT=""
RELEASE_NAME="gitea"
SHOW_RESOURCES=false
SHOW_LOGS=false

# Build kubectl/oc command with context if specified
k8s_cmd() {
    local cmd="kubectl"
    if command -v oc &> /dev/null; then
        cmd="oc"
    fi
    
    if [ -n "$CONTEXT" ]; then
        $cmd --context="${CONTEXT}" "$@"
    else
        $cmd "$@"
    fi
}

# Build helm command with context if specified
helm_cmd() {
    if [ -n "$CONTEXT" ]; then
        helm --kube-context="${CONTEXT}" "$@"
    else
        helm "$@"
    fi
}

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

section_header() {
    echo ""
    echo -e "${CYAN}============================================================${NC}"
    echo -e "${CYAN}$1${NC}"
    echo -e "${CYAN}============================================================${NC}"
    echo ""
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Display information about Gitea installation.

Options:
  --context CONTEXT       Kubernetes context (optional; uses current context if omitted)
  --namespace NAMESPACE   Gitea namespace (default: gitea)
  --release-name NAME     Helm release name (default: gitea)
  --resources             Show detailed resource information
  --logs                  Show recent logs from Gitea pod
  -h, --help             Show this help message

Examples:
  # Show basic information
  $0 --namespace gitea

  # Show detailed resource information
  $0 --namespace gitea --resources

  # Show logs
  $0 --namespace gitea --logs

  # Show everything
  $0 --namespace gitea --resources --logs

EOF
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --context)
            CONTEXT="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --release-name)
            RELEASE_NAME="$2"
            shift 2
            ;;
        --resources)
            SHOW_RESOURCES=true
            shift
            ;;
        --logs)
            SHOW_LOGS=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            echo ""
            show_help
            exit 1
            ;;
    esac
done

# Determine actual context
if [ -n "$CONTEXT" ]; then
    ACTUAL_CONTEXT="$CONTEXT"
else
    ACTUAL_CONTEXT=$(kubectl config current-context 2>/dev/null || echo "unknown")
fi

section_header "Gitea Installation Information"

echo "Cluster Context: ${ACTUAL_CONTEXT}"
echo "Namespace:       ${NAMESPACE}"
echo "Release Name:    ${RELEASE_NAME}"
echo ""

# Check if namespace exists
if ! k8s_cmd get namespace "${NAMESPACE}" &> /dev/null; then
    log_error "Namespace '${NAMESPACE}' does not exist"
    exit 1
fi

# Check if Helm release exists
if ! helm_cmd list -n "${NAMESPACE}" 2>/dev/null | grep -q "^${RELEASE_NAME}"; then
    log_warning "Helm release '${RELEASE_NAME}' not found in namespace '${NAMESPACE}'"
    echo ""
    log_info "Gitea may not be installed or may have been installed manually"
    exit 0
fi

section_header "Helm Release Information"

# Get Helm release info
RELEASE_INFO=$(helm_cmd list -n "${NAMESPACE}" | grep "^${RELEASE_NAME}" || echo "")
if [ -n "$RELEASE_INFO" ]; then
    echo "$RELEASE_INFO" | awk 'NR==1 {print "NAME\t\tNAMESPACE\tREVISION\tUPDATED\t\t\t\tSTATUS\t\tCHART\t\tAPP VERSION"} NR>1'
    echo ""
    
    # Get release status
    RELEASE_STATUS=$(helm_cmd status "${RELEASE_NAME}" -n "${NAMESPACE}" 2>/dev/null || echo "")
    if [ -n "$RELEASE_STATUS" ]; then
        echo "Release Status:"
        echo "$RELEASE_STATUS" | grep -A 5 "STATUS:"
    fi
else
    log_warning "Could not retrieve Helm release information"
fi

section_header "Deployment Status"

# Get deployment status
DEPLOYMENT=$(k8s_cmd get deployment -n "${NAMESPACE}" -l "app.kubernetes.io/name=gitea" -o wide 2>/dev/null || echo "")
if [ -n "$DEPLOYMENT" ]; then
    echo "$DEPLOYMENT"
else
    log_warning "No Gitea deployment found"
fi

section_header "Pod Status"

# Get pod status
PODS=$(k8s_cmd get pods -n "${NAMESPACE}" -o wide 2>/dev/null || echo "")
if [ -n "$PODS" ]; then
    echo "$PODS"
else
    log_warning "No pods found in namespace"
fi

section_header "Service Information"

# Get services
SERVICES=$(k8s_cmd get svc -n "${NAMESPACE}" 2>/dev/null || echo "")
if [ -n "$SERVICES" ]; then
    echo "$SERVICES"
else
    log_warning "No services found"
fi

section_header "Access Information"

# Get Route (OpenShift)
ROUTE_HOST=$(k8s_cmd get route -n "${NAMESPACE}" "${RELEASE_NAME}" -o jsonpath='{.spec.host}' 2>/dev/null || echo "")
if [ -n "$ROUTE_HOST" ]; then
    GITEA_URL="https://${ROUTE_HOST}"
    log_success "Gitea URL (Route): ${GITEA_URL}"
else
    # Try Ingress
    INGRESS_HOST=$(k8s_cmd get ingress -n "${NAMESPACE}" "${RELEASE_NAME}" -o jsonpath='{.spec.rules[0].host}' 2>/dev/null || echo "")
    if [ -n "$INGRESS_HOST" ]; then
        GITEA_URL="http://${INGRESS_HOST}"
        log_success "Gitea URL (Ingress): ${GITEA_URL}"
    else
        # Try LoadBalancer
        SERVICE_IP=$(k8s_cmd get svc -n "${NAMESPACE}" "${RELEASE_NAME}-http" -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")
        if [ -n "$SERVICE_IP" ]; then
            GITEA_URL="http://${SERVICE_IP}"
            log_success "Gitea URL (LoadBalancer): ${GITEA_URL}"
        else
            log_info "No external access configured"
            log_info "Use port-forward: kubectl port-forward -n ${NAMESPACE} svc/${RELEASE_NAME}-http 3000:80"
            GITEA_URL="http://localhost:3000 (via port-forward)"
        fi
    fi
fi

# SSH access
SSH_PORT=$(k8s_cmd get svc -n "${NAMESPACE}" "${RELEASE_NAME}-ssh" -o jsonpath='{.spec.ports[0].nodePort}' 2>/dev/null || echo "")
if [ -n "$SSH_PORT" ]; then
    log_info "SSH Access (NodePort): Port ${SSH_PORT}"
    echo "  Git clone: git clone ssh://git@<node-ip>:${SSH_PORT}/user/repo.git"
else
    SSH_TYPE=$(k8s_cmd get svc -n "${NAMESPACE}" "${RELEASE_NAME}-ssh" -o jsonpath='{.spec.type}' 2>/dev/null || echo "")
    if [ "$SSH_TYPE" = "ClusterIP" ]; then
        log_info "SSH Access: ClusterIP only (internal)"
    fi
fi

section_header "Storage Information"

# Get PVCs
PVCS=$(k8s_cmd get pvc -n "${NAMESPACE}" 2>/dev/null || echo "")
if [ -n "$PVCS" ]; then
    echo "$PVCS"
else
    log_info "No PVCs found (may be using emptyDir or hostPath)"
fi

section_header "Configuration"

# Check for PostgreSQL
POSTGRES_ENABLED=$(k8s_cmd get deployment -n "${NAMESPACE}" -l "app.kubernetes.io/name=postgres" 2>/dev/null | grep -c "postgres" || echo "0")
if [ "$POSTGRES_ENABLED" -gt 0 ]; then
    log_success "Database: PostgreSQL (deployed)"
else
    log_info "Database: SQLite (embedded)"
fi

# Check for Redis
REDIS_ENABLED=$(k8s_cmd get deployment -n "${NAMESPACE}" -l "app.kubernetes.io/name=redis" 2>/dev/null | grep -c "redis" || echo "0")
if [ "$REDIS_ENABLED" -gt 0 ]; then
    log_success "Cache: Redis (deployed)"
else
    log_info "Cache: None (Redis not deployed)"
fi

# Show detailed resources if requested
if [ "$SHOW_RESOURCES" = true ]; then
    section_header "Detailed Resource Information"
    
    log_info "Deployments:"
    k8s_cmd get deployments -n "${NAMESPACE}" -o wide 2>/dev/null || log_warning "No deployments found"
    
    echo ""
    log_info "StatefulSets:"
    k8s_cmd get statefulsets -n "${NAMESPACE}" -o wide 2>/dev/null || log_info "No statefulsets found"
    
    echo ""
    log_info "ConfigMaps:"
    k8s_cmd get configmaps -n "${NAMESPACE}" 2>/dev/null || log_info "No configmaps found"
    
    echo ""
    log_info "Secrets:"
    k8s_cmd get secrets -n "${NAMESPACE}" 2>/dev/null || log_info "No secrets found"
    
    echo ""
    log_info "Routes (OpenShift):"
    k8s_cmd get routes -n "${NAMESPACE}" 2>/dev/null || log_info "No routes found (not OpenShift or routes not configured)"
    
    echo ""
    log_info "Ingresses:"
    k8s_cmd get ingresses -n "${NAMESPACE}" 2>/dev/null || log_info "No ingresses found"
fi

# Show logs if requested
if [ "$SHOW_LOGS" = true ]; then
    section_header "Recent Logs"
    
    GITEA_POD=$(k8s_cmd get pods -n "${NAMESPACE}" -l "app.kubernetes.io/name=gitea" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    
    if [ -n "$GITEA_POD" ]; then
        log_info "Logs from pod: ${GITEA_POD}"
        echo ""
        k8s_cmd logs -n "${NAMESPACE}" "${GITEA_POD}" --tail=50 2>/dev/null || log_warning "Could not retrieve logs"
    else
        log_warning "No Gitea pod found"
    fi
fi

section_header "Summary"

# Get Gitea version
GITEA_VERSION=$(k8s_cmd get deployment -n "${NAMESPACE}" -l "app.kubernetes.io/name=gitea" -o jsonpath='{.items[0].spec.template.spec.containers[0].image}' 2>/dev/null | cut -d: -f2 || echo "unknown")

echo "Gitea Version:    ${GITEA_VERSION}"
echo "Access URL:       ${GITEA_URL}"
echo "Namespace:        ${NAMESPACE}"
echo "Release:          ${RELEASE_NAME}"
echo ""

# Health check
READY_PODS=$(k8s_cmd get pods -n "${NAMESPACE}" -l "app.kubernetes.io/name=gitea" -o jsonpath='{.items[*].status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || echo "")
if [[ "$READY_PODS" == *"True"* ]]; then
    log_success "Status: Healthy (pods are ready)"
else
    log_warning "Status: Not ready (check pod status above)"
fi

echo ""
log_info "For more details, use:"
echo "  kubectl describe deployment ${RELEASE_NAME} -n ${NAMESPACE}"
echo "  kubectl logs -n ${NAMESPACE} -l app.kubernetes.io/name=gitea"
echo ""

# Made with Bob
