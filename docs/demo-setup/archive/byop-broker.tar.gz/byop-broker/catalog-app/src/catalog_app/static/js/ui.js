/**
 * UI Module - Handles all UI rendering and display logic
 */
const UI = {
    /**
     * Escape HTML special characters to prevent XSS
     * @param {*} value - Value to escape
     * @returns {string} Escaped HTML string
     */
    escapeHtml(value) {
        const text = String(value ?? "");
        const map = {
            '&': '&',
            '<': '<',
            '>': '>',
            '"': '"',
            "'": '&#39'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    },

    renderDashboardLink(dashboardUrl) {
        if (!dashboardUrl) {
            return "";
        }

        const escapedUrl = this.escapeHtml(dashboardUrl);
        return `
            <div class="detail-item detail-item-full">
                <span class="detail-label">Dashboard:</span>
                <a
                    class="dashboard-link"
                    href="${escapedUrl}"
                    target="_blank"
                    rel="noopener noreferrer"
                >Open dashboard</a>
            </div>
        `;
    },

    /**
     * Display services in the services grid
     * @param {Array} services - Array of service objects
     */
    displayServices(services) {
        const container = document.getElementById("services-container");

        if (services.length === 0) {
            container.className = "";
            container.innerHTML = '<p class="empty-message">No services available</p>';
            return;
        }

        container.innerHTML = "";
        container.className = "services-grid";

        services.forEach((service) => {
            const card = document.createElement("div");
            card.className = "service-card";

            const plans = service.plans || [];
            const planButtons = plans.map((plan) => {
                const escapedPlanName = this.escapeHtml(plan.name || "Unnamed plan");
                const serviceId = encodeURIComponent(JSON.stringify(service.id));
                const serviceName = encodeURIComponent(JSON.stringify(service.name));
                const planId = encodeURIComponent(JSON.stringify(plan.id));
                const planName = encodeURIComponent(JSON.stringify(plan.name));

                return `<button class="plan-btn" type="button" data-service-id="${serviceId}" data-service-name="${serviceName}" data-plan-id="${planId}" data-plan-name="${planName}" onclick="Modal.openFromButton(this)">${escapedPlanName}</button>`;
            }).join("");

            card.innerHTML = `
                <div class="service-name">${this.escapeHtml(service.name)}</div>
                <div class="service-description">${this.escapeHtml(service.description || "No description")}</div>
                <div class="plans">
                    <div class="plan-label">Available Plans:</div>
                    <div class="plan-buttons">
                        ${planButtons || '<span class="empty-message">No plans available</span>'}
                    </div>
                </div>
            `;

            container.appendChild(card);
        });
    },

    /**
     * Display instances in the instances list
     * @param {Array} instances - Array of instance objects
     */
    displayInstances(instances) {
        const container = document.getElementById("instances-container");

        if (instances.length === 0) {
            container.innerHTML = '<p class="empty-message">No instances provisioned</p>';
            container.className = "";
            return;
        }

        container.innerHTML = "";
        container.className = "instances-list";

        instances.forEach((instance) => {
            const card = document.createElement("div");
            const state = instance.state || "unknown";
            card.className = `instance-card ${state}`;
            card.id = `instance-${instance.instance_id}`;

            const errorDetails = state === "failed"
                ? `<div class="error-details">${this.escapeHtml(instance.description || "Provision failed")}</div>`
                : "";

            const deleteButton = document.createElement("button");
            deleteButton.className = "btn btn-danger";
            deleteButton.type = "button";

            if (state !== "in_progress") {
                deleteButton.textContent = "Delete";
                deleteButton.addEventListener("click", () => {
                    App.deprovisionInstance(instance.instance_id, instance.service_id, instance.plan_id);
                });
            } else {
                deleteButton.textContent = "Delete (in progress)";
                deleteButton.disabled = true;
            }

            const clusterName = instance.parameters?.cluster_name || "k3s-cluster-1 (default)";
            const createdAt = instance.created_at ? new Date(instance.created_at).toLocaleString() : "N/A";
            const updatedAt = instance.updated_at ? new Date(instance.updated_at).toLocaleString() : "N/A";

            card.innerHTML = `
                <div class="instance-header">
                    <div class="instance-id">${this.escapeHtml(instance.instance_id)}</div>
                    <div class="instance-state state-${this.escapeHtml(state)}">${this.escapeHtml(state)}</div>
                </div>
                <div class="instance-details">
                    <div class="detail-item">
                        <span class="detail-label">Service:</span> ${this.escapeHtml(instance.service_id)}
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Plan:</span> ${this.escapeHtml(instance.plan_id)}
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Cluster:</span> ${this.escapeHtml(clusterName)}
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Created:</span> ${this.escapeHtml(createdAt)}
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Updated:</span> ${this.escapeHtml(updatedAt)}
                    </div>
                    ${this.renderDashboardLink(instance.dashboard_url)}
                </div>
                ${errorDetails}
                <div class="instance-actions"></div>
            `;

            const actionsContainer = card.querySelector(".instance-actions");
            actionsContainer.appendChild(deleteButton);

            const statusButton = document.createElement("button");
            statusButton.className = "btn btn-secondary";
            statusButton.type = "button";
            statusButton.textContent = "Check Status";
            statusButton.addEventListener("click", () => {
                App.checkStatus(instance.instance_id);
            });
            actionsContainer.appendChild(statusButton);

            container.appendChild(card);
        });
    },
};
