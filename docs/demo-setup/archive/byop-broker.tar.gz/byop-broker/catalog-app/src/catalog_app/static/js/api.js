/**
 * API Module - Handles all broker API interactions
 */
const API = {
    /**
     * Load available clusters from broker
     * @returns {Promise<Array>} Array of cluster objects
     */
    async loadClusters() {
        try {
            const response = await fetch("/api/clusters");
            const data = await response.json();
            return data.clusters || [];
        } catch (error) {
            console.error("Error loading clusters:", error);
            return [];
        }
    },

    /**
     * Load available services from broker catalog
     * @returns {Promise<Array>} Array of service objects
     */
    async loadServices() {
        const response = await fetch("/api/broker/catalog");
        const data = await response.json();
        return data.services || [];
    },

    /**
     * Load all provisioned service instances
     * @returns {Promise<Array>} Array of instance objects
     */
    async loadInstances() {
        const response = await fetch("/api/broker/service_instances");
        
        if (!response.ok) {
            throw new Error(`Failed to load instances (${response.status})`);
        }
        
        const data = await response.json();
        return data.instances || [];
    },

    /**
     * Provision a new service instance
     * @param {string} instanceId - Unique instance identifier
     * @param {string} serviceId - Service ID to provision
     * @param {string} planId - Plan ID to use
     * @param {string} clusterName - Target cluster name
     * @returns {Promise<Response>} Fetch response object
     */
    async provisionInstance(instanceId, serviceId, planId, clusterName, parameters) {
        // Get the cluster's server URL from the select element's data attribute
        const clusterSelect = document.getElementById("cluster-select");
        const selectedOption = clusterSelect.options[clusterSelect.selectedIndex];
        const clusterUrl = selectedOption.dataset.server || clusterName;

        const requestBody = {
            service_id: serviceId,
            plan_id: planId,
            parameters: {
                cluster_url: clusterUrl,  // Use cluster server URL, not name
                ...parameters
            },
        };

        return await fetch(
            `/api/broker/service_instances/${encodeURIComponent(instanceId)}?accepts_incomplete=true`,
            {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    "X-Broker-API-Version": "2.16",
                },
                body: JSON.stringify(requestBody),
            }
        );
    },

    /**
     * Deprovision (delete) a service instance
     * @param {string} instanceId - Instance ID to delete
     * @param {string} serviceId - Service ID
     * @param {string} planId - Plan ID
     * @returns {Promise<Response>} Fetch response object
     */
    async deprovisionInstance(instanceId, serviceId, planId) {
        return await fetch(
            `/api/broker/service_instances/${encodeURIComponent(instanceId)}?accepts_incomplete=true&service_id=${encodeURIComponent(serviceId)}&plan_id=${encodeURIComponent(planId)}`,
            {
                method: "DELETE",
                headers: {
                    "X-Broker-API-Version": "2.16",
                },
            }
        );
    },

    /**
     * Check the status of a service instance operation
     * @param {string} instanceId - Instance ID to check
     * @returns {Promise<Object>} Status object with state and description
     */
    async checkStatus(instanceId) {
        const response = await fetch(
            `/api/broker/service_instances/${encodeURIComponent(instanceId)}/last_operation`
        );
        
        if (!response.ok) {
            throw new Error("Failed to check status");
        }
        
        return await response.json();
    },
};

// Made with Bob
