"""
Structured logging configuration using Python standard logging library.

This module provides JSON-formatted logging for production observability
and text-formatted logging for development.

Usage:
    from catalog_app.logging_config import get_logger

    logger = get_logger(__name__)
    logger.info("Request received", path="/catalog", method="GET")
    logger.error("Broker connection failed", error=str(e), broker_url=url)

Configuration:
    LOG_LEVEL: Set logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    LOG_FORMAT: Set format (json, text) - default: json
"""

import logging
import os
import sys
from typing import Any

from pythonjsonlogger import jsonlogger


class CustomJsonFormatter(jsonlogger.JsonFormatter):
    """
    Custom JSON formatter that adds standard fields to all log records.

    Adds:
    - timestamp: ISO 8601 UTC timestamp
    - level: Log level name (INFO, ERROR, etc.)
    - logger: Logger name (module path)
    - message: Log message
    - Any extra fields passed via logger.info("msg", field=value)
    """

    def add_fields(
        self,
        log_record: dict[str, Any],
        record: logging.LogRecord,
        message_dict: dict[str, Any],
    ) -> None:
        """Add custom fields to log record."""
        super().add_fields(log_record, record, message_dict)

        # Ensure timestamp is always present
        if not log_record.get("timestamp"):
            log_record["timestamp"] = self.formatTime(record, self.datefmt)

        # Ensure level is always present
        if not log_record.get("level"):
            log_record["level"] = record.levelname

        # Ensure logger name is present
        if not log_record.get("logger"):
            log_record["logger"] = record.name


def configure_logging(
    level: str | None = None,
    format_type: str | None = None,
) -> None:
    """
    Configure logging for the application.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
               Defaults to LOG_LEVEL env var or INFO
        format_type: Format type (json, text)
                    Defaults to LOG_FORMAT env var or json

    This should be called once at application startup.
    """
    # Get configuration from environment or parameters
    log_level = level or os.getenv("LOG_LEVEL", "INFO").upper()
    log_format = format_type or os.getenv("LOG_FORMAT", "json").lower()

    # Validate log level
    numeric_level = getattr(logging, log_level, None)
    if not isinstance(numeric_level, int):
        print(
            f"Invalid log level: {log_level}, using INFO",
            file=sys.stderr,
        )
        numeric_level = logging.INFO

    # Create handler (stderr for container compatibility)
    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(numeric_level)

    # Configure formatter based on format type
    if log_format == "json":
        # JSON formatter for production
        formatter: logging.Formatter = CustomJsonFormatter(
            "%(timestamp)s %(level)s %(logger)s %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S.%fZ",
        )
    else:
        # Text formatter for development
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

    handler.setFormatter(formatter)

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)

    # Remove existing handlers to avoid duplicates
    root_logger.handlers.clear()

    # Add our handler
    root_logger.addHandler(handler)

    # Suppress noisy third-party loggers
    logging.getLogger("werkzeug").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for the given name.

    Args:
        name: Logger name (typically __name__)

    Returns:
        Logger instance configured with structured logging

    Example:
        logger = get_logger(__name__)
        logger.info("Processing request", request_id="123", path="/catalog")
    """
    return logging.getLogger(name)


# Made with Bob
