/**
 * Validation Module - Basic JSON Schema validation for service parameters
 * MVP version: Simple validation without dynamic form generation
 */
const Validation = {
    currentSchema: null,
    ajvValidator: null,

    /**
     * Fetch and compile schema for a service
     * IMPORTANT: Always fetches fresh schema from broker to ensure up-to-date validation
     * NOTE: Ajv validation is optional - schema is still loaded for UI hints even without Ajv
     * @param {string} serviceId - Service ID to fetch schema for
     * @returns {Promise<boolean>} True if schema loaded successfully
     */
    async fetchAndCompileSchema(serviceId) {
        try {
            // Clear any existing cached schema to force fresh fetch
            this.clear();
            console.log('Fetching fresh schema for service:', serviceId);
            
            // Fetch schema from proxy endpoint (broker pulls latest from Git)
            const response = await fetch(`/api/services/${encodeURIComponent(serviceId)}/schema`);
            
            if (!response.ok) {
                console.warn(`No schema available for service ${serviceId}`);
                this.currentSchema = null;
                this.ajvValidator = null;
                return false;
            }

            const schema = await response.json();
            this.currentSchema = schema;
            console.log('Schema loaded successfully:', schema);

            // Try to compile with Ajv if available (optional - for validation)
            if (typeof window.ajv7 !== 'undefined' && typeof window.ajvFormats !== 'undefined') {
                try {
                    const ajv = new window.ajv7({
                        allErrors: true,
                        verbose: true,
                        $data: true
                    });
                    
                    // Add format validators
                    window.ajvFormats(ajv);

                    // Compile schema
                    this.ajvValidator = ajv.compile(schema);
                    console.log('Schema compiled with Ajv for validation');
                } catch (ajvError) {
                    console.warn('Ajv compilation failed, validation will be skipped:', ajvError);
                    this.ajvValidator = null;
                }
            } else {
                console.info('Ajv not available, schema validation will be skipped (schema still loaded for UI hints)');
                this.ajvValidator = null;
            }
            
            return true;
            
        } catch (error) {
            console.error('Error fetching schema:', error);
            this.currentSchema = null;
            this.ajvValidator = null;
            return false;
        }
    },

    /**
     * Validate form parameters against schema
     * @param {Object} parameters - Parameters object to validate
     * @returns {Object} Validation result {valid: boolean, errors: Array}
     */
    validateParameters(parameters) {
        if (!this.ajvValidator || !this.currentSchema) {
            // No schema available - skip validation
            return { valid: true, errors: [] };
        }

        const valid = this.ajvValidator(parameters);

        if (valid) {
            return { valid: true, errors: [] };
        }

        // Format errors for display
        const errors = this.ajvValidator.errors.map(err => ({
            field: err.instancePath.replace(/^\//, '') || err.params.missingProperty,
            message: this.formatErrorMessage(err)
        }));

        return { valid: false, errors };
    },

    /**
     * Format Ajv error message for user display
     * @param {Object} error - Ajv error object
     * @returns {string} Formatted error message
     */
    formatErrorMessage(error) {
        const field = error.instancePath.replace(/^\//, '') || error.params.missingProperty || 'field';
        
        switch (error.keyword) {
            case 'required':
                return `${error.params.missingProperty} is required`;
            case 'type':
                return `${field} must be of type ${error.params.type}`;
            case 'minLength':
                return `${field} must be at least ${error.params.limit} characters`;
            case 'maxLength':
                return `${field} must be at most ${error.params.limit} characters`;
            case 'pattern':
                return `${field} format is invalid`;
            case 'minimum':
                return `${field} must be at least ${error.params.limit}`;
            case 'maximum':
                return `${field} must be at most ${error.params.limit}`;
            case 'format':
                return `${field} must be a valid ${error.params.format}`;
            case 'enum':
                return `${field} must be one of: ${error.params.allowedValues.join(', ')}`;
            default:
                return error.message || `${field} is invalid`;
        }
    },

    /**
     * Show validation errors in the UI
     * @param {Array} errors - Array of error objects {field, message}
     */
    showValidationErrors(errors) {
        if (errors.length === 0) {
            return;
        }

        // Show first error as toast
        const firstError = errors[0];
        Toast.show(`Validation error: ${firstError.message}`, 'error');

        // Log all errors to console for debugging
        console.error('Validation errors:', errors);
    },

    /**
     * Clear validation state
     */
    clear() {
        this.currentSchema = null;
        this.ajvValidator = null;
    }
};
