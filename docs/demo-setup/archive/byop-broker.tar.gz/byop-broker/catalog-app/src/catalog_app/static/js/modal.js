/**
 * Modal Module - Handles provision modal management
 */
const Modal = {
    availableClusters: [],

    /**
     * Open provision modal from button click
     * @param {HTMLElement} button - Button element with data attributes
     */
    openFromButton(button) {
        const serviceId = JSON.parse(decodeURIComponent(button.dataset.serviceId));
        const serviceName = JSON.parse(decodeURIComponent(button.dataset.serviceName));
        const planId = JSON.parse(decodeURIComponent(button.dataset.planId));
        const planName = JSON.parse(decodeURIComponent(button.dataset.planName));

        this.open(serviceId, serviceName, planId, planName);
    },

    /**
     * Open provision modal with service details
     * @param {string} serviceId - Service ID
     * @param {string} serviceName - Service name
     * @param {string} planId - Plan ID
     * @param {string} planName - Plan name
     */
    async open(serviceId, serviceName, planId, planName) {
        document.getElementById("service-id").value = serviceId;
        document.getElementById("service-name").value = serviceName;
        document.getElementById("plan-id").value = planId;
        document.getElementById("plan-name").value = planName;
        document.getElementById("instance-id").value = "";

        // Fetch and compile schema for validation
        const schemaLoaded = await Validation.fetchAndCompileSchema(serviceId);

        // Update placeholder and hint based on schema
        this.updateParametersFieldFromSchema(schemaLoaded);

        const clusterSelect = document.getElementById("cluster-select");
        clusterSelect.innerHTML = "";

        if (this.availableClusters.length === 0) {
            clusterSelect.innerHTML = '<option value="">No clusters available</option>';
        } else {
            this.availableClusters.forEach((cluster) => {
                const option = document.createElement("option");
                option.value = cluster.name;
                option.textContent = cluster.name + (cluster.type === "hub" ? " (Hub)" : "");
                option.dataset.server = cluster.server;
                clusterSelect.appendChild(option);
            });
            clusterSelect.value = this.availableClusters[0].name;
        }

        document.getElementById("provision-modal").style.display = "block";
    },

    /**
     * Generate example value for a property based on its schema
     * @param {Object} prop - Property schema
     * @param {string} key - Property key name
     * @returns {*} Example value
     */
    generateExampleValue(prop, key) {
        // Use example value from schema if available
        if (prop.examples !== undefined && Array.isArray(prop.examples) && prop.examples.length > 0) {
            return prop.examples[0];
        } else if (prop.example !== undefined) {
            return prop.example;
        } else if (prop.default !== undefined) {
            return prop.default;
        }

        // Handle nested objects recursively
        if (prop.type === 'object' && prop.properties) {
            return this.buildExampleFromProperties(prop.properties, prop.required || []);
        }

        // Handle arrays
        if (prop.type === 'array' && prop.items) {
            if (prop.items.type === 'object' && prop.items.properties) {
                return [this.buildExampleFromProperties(prop.items.properties, prop.items.required || [])];
            }
            return [this.generateExampleValue(prop.items, 'item')];
        }

        // Generate example based on type
        switch (prop.type) {
            case 'string':
                if (prop.enum && prop.enum.length > 0) {
                    return prop.enum[0];
                }
                return prop.description ? `my${key}` : 'value';
            case 'number':
            case 'integer':
                return prop.minimum !== undefined ? prop.minimum : 1;
            case 'boolean':
                return false;
            default:
                return 'value';
        }
    },

    /**
     * Build example object from schema properties (supports nested objects)
     * @param {Object} properties - Schema properties object
     * @param {Array} required - Array of required field names
     * @returns {Object} Example object
     */
    buildExampleFromProperties(properties, required = []) {
        const example = {};
        
        for (const [key, prop] of Object.entries(properties)) {
            // Skip cluster_url as it's automatically added
            if (key === 'cluster_url') continue;

            example[key] = this.generateExampleValue(prop, key);
        }

        return example;
    },

    /**
     * Update parameters field placeholder and hint based on loaded schema
     * @param {boolean} schemaLoaded - Whether schema was successfully loaded
     */
    updateParametersFieldFromSchema(schemaLoaded) {
        const parametersField = document.getElementById("parameters-json");
        const hintElement = parametersField.nextElementSibling;

        console.log('updateParametersFieldFromSchema called:', {
            schemaLoaded,
            hasCurrentSchema: !!Validation.currentSchema,
            currentSchema: Validation.currentSchema
        });

        if (!schemaLoaded || !Validation.currentSchema) {
            // No schema available - use generic placeholder
            console.warn('No schema available, using generic placeholder');
            parametersField.placeholder = '{"parameter_name": "value"}';
            if (hintElement && hintElement.classList.contains('form-hint')) {
                hintElement.textContent = 'Enter service parameters in JSON format.';
            }
            return;
        }

        const schema = Validation.currentSchema;
        const properties = schema.properties || {};
        const required = schema.required || [];

        console.log('Schema loaded successfully:', {
            propertiesCount: Object.keys(properties).length,
            requiredCount: required.length,
            properties: Object.keys(properties),
            required
        });

        // Build example JSON from schema (supports nested objects)
        const example = this.buildExampleFromProperties(properties, required);

        // If the schema has a top-level 'plan' property, override it with the
        // currently-selected plan so the placeholder matches the clicked button.
        const planId = document.getElementById("plan-id")?.value;
        if (planId && 'plan' in example) {
            example.plan = planId;
        }

        // Set placeholder with formatted JSON
        parametersField.placeholder = JSON.stringify(example, null, 2);

        // Update hint text with required fields
        if (hintElement && hintElement.classList.contains('form-hint')) {
            let hintText = 'Enter service parameters in JSON format.';
            if (required.length > 0) {
                const requiredFields = required.filter(f => f !== 'cluster_url').join(', ');
                if (requiredFields) {
                    hintText += ` Required: ${requiredFields}.`;
                }
            }
            
            // Add info about auto-generated fields (check nested properties too)
            const autoGenFields = this.findAutoGenerateFields(properties);
            
            if (autoGenFields.length > 0) {
                hintText += ` Optional fields will be auto-generated if not provided.`;
            }
            
            hintElement.textContent = hintText;
        }
    },

    /**
     * Find fields with x-auto-generate or x-generate flags (supports nested objects)
     * @param {Object} properties - Schema properties object
     * @returns {Array} Array of field names with auto-generate flags
     */
    findAutoGenerateFields(properties) {
        const fields = [];
        
        for (const [key, prop] of Object.entries(properties)) {
            if (prop['x-auto-generate'] === true || prop['x-generate']) {
                fields.push(key);
            }
            
            // Check nested objects
            if (prop.type === 'object' && prop.properties) {
                const nestedFields = this.findAutoGenerateFields(prop.properties);
                fields.push(...nestedFields.map(f => `${key}.${f}`));
            }
        }
        
        return fields;
    },

    /**
     * Fill the parameters field with example JSON from schema
     */
    fillExampleParameters() {
        const parametersField = document.getElementById("parameters-json");
        
        // Use the placeholder as the example (it's already formatted from the schema,
        // with plan already overridden to match the selected plan button).
        const exampleJson = parametersField.placeholder;
        
        if (exampleJson && exampleJson !== '{"parameter_name": "value"}') {
            parametersField.value = exampleJson;
            console.log('Filled parameters field with example from schema');
        } else {
            // Fallback: generate from schema if available
            if (Validation.currentSchema && Validation.currentSchema.properties) {
                const schema = Validation.currentSchema;
                const properties = schema.properties || {};
                const required = schema.required || [];
                
                // Use the new recursive method to build example (supports nested objects)
                const example = this.buildExampleFromProperties(properties, required);

                // Override plan with the currently-selected plan button value
                const planId = document.getElementById("plan-id")?.value;
                if (planId && 'plan' in example) {
                    example.plan = planId;
                }
                
                parametersField.value = JSON.stringify(example, null, 2);
                console.log('Filled parameters field with generated example (supports nested objects)');
            } else {
                console.warn('No schema available to generate example');
            }
        }
    },

    /**
     * Close provision modal
     */
    close() {
        document.getElementById("provision-modal").style.display = "none";
    },

    /**
     * Set available clusters for modal
     * @param {Array} clusters - Array of cluster objects
     */
    setClusters(clusters) {
        this.availableClusters = clusters;
    },
};
