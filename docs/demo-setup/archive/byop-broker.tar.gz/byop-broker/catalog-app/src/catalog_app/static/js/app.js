/**
 * App Module - Main application logic and initialization
 */
const App = {
    /**
     * Initialize the application
     */
    async init() {
        // Load initial data
        await this.refreshAll();

        // Set up form submission handler
        document.getElementById("provision-form").addEventListener("submit", async (event) => {
            event.preventDefault();
            await this.handleProvisionSubmit();
        });

        // Set up modal close on background click
        window.onclick = function(event) {
            const modal = document.getElementById("provision-modal");
            if (event.target === modal) {
                Modal.close();
            }
        };
    },

    /**
     * Refresh all data (clusters, services, instances)
     */
    async refreshAll() {
        const button = document.querySelector(".refresh-btn");
        button.classList.add("spinning");

        try {
            // Load clusters and update modal
            const clusters = await API.loadClusters();
            Modal.setClusters(clusters);
            console.log("Loaded clusters:", clusters);

            // Load and display services
            const services = await API.loadServices();
            UI.displayServices(services);

            // Load and display instances
            const instances = await API.loadInstances();
            UI.displayInstances(instances);
        } catch (error) {
            console.error("Error refreshing data:", error);
            Toast.show(`Error loading data: ${error.message}`, "error");
        } finally {
            window.setTimeout(() => button.classList.remove("spinning"), 500);
        }
    },

    /**
     * Handle provision form submission
     */
    async handleProvisionSubmit() {
        console.log("=== Provision Submit Started ===");
        
        const serviceId = document.getElementById("service-id").value;
        const planId = document.getElementById("plan-id").value;
        const instanceId = document.getElementById("instance-id").value;
        const clusterName = document.getElementById("cluster-select").value;
        const parametersJson = document.getElementById("parameters-json").value.trim();

        console.log("Form values:", { serviceId, planId, instanceId, clusterName, parametersJson });

        if (!clusterName) {
            console.error("No cluster selected");
            Toast.show("Please select a target cluster", "error");
            return;
        }

        // Parse user-provided parameters
        let parameters = {};
        if (parametersJson) {
            try {
                parameters = JSON.parse(parametersJson);
                console.log("Parsed parameters:", parameters);
            } catch (error) {
                console.error("JSON parse error:", error);
                Toast.show(`Invalid JSON in parameters: ${error.message}`, "error");
                return;
            }
        }

        // Validate parameters against schema
        console.log("Validating parameters...");
        const validationResult = Validation.validateParameters(parameters);
        console.log("Validation result:", validationResult);
        
        if (!validationResult.valid) {
            console.error("Validation failed:", validationResult.errors);
            Validation.showValidationErrors(validationResult.errors);
            return;
        }

        try {
            console.log("Calling API.provisionInstance...");
            const response = await API.provisionInstance(instanceId, serviceId, planId, clusterName, parameters);
            console.log("API response:", response);

            if (response.ok) {
                console.log("Provision successful");
                Modal.close();
                Toast.show(`Provisioning started for instance: ${instanceId} on cluster: ${clusterName}`, "success");
                await API.loadInstances().then(instances => UI.displayInstances(instances));
                await this.refreshInstancesAfterProvision(instanceId);
            } else {
                const error = await response.json();
                console.error("Provision failed:", error);
                Toast.show(`Error: ${error.description || error.error || "Failed to provision"}`, "error");
            }
        } catch (error) {
            console.error("Exception during provision:", error);
            Toast.show(`Error: ${error.message}`, "error");
        }
        
        console.log("=== Provision Submit Ended ===");
    },

    /**
     * Deprovision (delete) an instance
     * @param {string} instanceId - Instance ID to delete
     * @param {string} serviceId - Service ID
     * @param {string} planId - Plan ID
     */
    async deprovisionInstance(instanceId, serviceId, planId) {
        try {
            const response = await API.deprovisionInstance(instanceId, serviceId, planId);

            if (response.ok) {
                Toast.show(`Deprovisioning started for instance: ${instanceId}`, "success");
                await API.loadInstances().then(instances => UI.displayInstances(instances));
                await this.refreshInstancesAfterDelete(instanceId);
            } else {
                const error = await response.json();
                Toast.show(`Error: ${error.description || error.error || "Failed to deprovision"}`, "error");
            }
        } catch (error) {
            Toast.show(`Error: ${error.message}`, "error");
        }
    },

    /**
     * Check status of an instance
     * @param {string} instanceId - Instance ID to check
     */
    async checkStatus(instanceId) {
        try {
            const data = await API.checkStatus(instanceId);
            const instances = await API.loadInstances();
            const enrichedInstances = instances.map((instance) => {
                if (instance.instance_id !== instanceId) {
                    return instance;
                }

                return {
                    ...instance,
                    dashboard_url: data.dashboard_url || instance.dashboard_url,
                    description: data.description || instance.description,
                    state: data.state || instance.state,
                };
            });

            UI.displayInstances(enrichedInstances);

            const escapedInstanceId = UI.escapeHtml(instanceId);
            const escapedState = UI.escapeHtml(data.state || "unknown");
            const escapedDescription = UI.escapeHtml(data.description || "N/A");
            const dashboardMessage = data.dashboard_url
                ? ` <span class="toast-dashboard-label">Dashboard:</span> ` +
                  `<a class="toast-link" href="${UI.escapeHtml(data.dashboard_url)}" ` +
                  `target="_blank" rel="noopener noreferrer">Open dashboard</a>`
                : "";
            Toast.show(
                `Instance: ${escapedInstanceId} - State: ${escapedState} - ${escapedDescription}${dashboardMessage}`,
                "info",
                { allowHtml: true }
            );
        } catch (error) {
            Toast.show("Failed to check status", "error");
        }
    },

    /**
     * Refresh instances after provision until visible
     * @param {string} instanceId - Instance ID to wait for
     */
    async refreshInstancesAfterProvision(instanceId) {
        const attempts = 20;

        Toast.showBanner(`Provisioning ${instanceId}… waiting for instance to appear in the catalog`);

        try {
            for (let attempt = 0; attempt < attempts; attempt += 1) {
                try {
                    const instances = await API.loadInstances();
                    const instance = instances.find((item) => item.instance_id === instanceId);

                    if (instance) {
                        const status = await API.checkStatus(instanceId);
                        const enrichedInstance = {
                            ...instance,
                            dashboard_url: status.dashboard_url || instance.dashboard_url,
                            description: status.description || instance.description,
                            state: status.state || instance.state,
                        };
                        const enrichedInstances = instances.map((item) =>
                            item.instance_id === instanceId ? enrichedInstance : item
                        );

                        UI.displayInstances(enrichedInstances);
                        Toast.show(`Instance ${instanceId} is now visible in the catalog`, "success");
                        return;
                    }

                    UI.displayInstances(instances);
                } catch (error) {
                    console.error("Error refreshing instances after provision:", error);
                }

                Toast.showBanner(
                    `Provisioning ${instanceId}… waiting for catalog refresh ` +
                    `(${attempt + 1}/${attempts})`
                );

                await new Promise((resolve) => {
                    window.setTimeout(resolve, 1000);
                });
            }

            try {
                const instances = await API.loadInstances();
                UI.displayInstances(instances);
            } catch (error) {
                console.error("Final instance refresh failed:", error);
            }

            Toast.show(
                `Provision succeeded but instance ${instanceId} is not visible yet. Use refresh to re-check.`,
                "info"
            );
        } finally {
            Toast.hideBanner();
        }
    },

    /**
     * Refresh instances after delete until removed
     * @param {string} instanceId - Instance ID to wait for removal
     */
    async refreshInstancesAfterDelete(instanceId) {
        const attempts = 20;

        Toast.showBanner(`Deleting ${instanceId}… waiting for instance to disappear from the catalog`);

        try {
            for (let attempt = 0; attempt < attempts; attempt += 1) {
                try {
                    const instances = await API.loadInstances();
                    UI.displayInstances(instances);
                    const instanceVisible = instances.some((instance) => instance.instance_id === instanceId);

                    if (!instanceVisible) {
                        Toast.show(`Instance ${instanceId} has been removed from the catalog`, "success");
                        return;
                    }
                } catch (error) {
                    console.error("Error refreshing instances after delete:", error);
                }

                Toast.showBanner(
                    `Deleting ${instanceId}… waiting for catalog refresh ` +
                    `(${attempt + 1}/${attempts})`
                );

                await new Promise((resolve) => {
                    window.setTimeout(resolve, 1000);
                });
            }

            try {
                const instances = await API.loadInstances();
                UI.displayInstances(instances);
            } catch (error) {
                console.error("Final delete refresh failed:", error);
            }

            Toast.show(
                `Delete succeeded but instance ${instanceId} is still visible. Use refresh to re-check.`,
                "info"
            );
        } finally {
            Toast.hideBanner();
        }
    },
};

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});
