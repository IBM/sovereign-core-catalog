"""
Catalog Web UI - Simple web interface for GitOps CSB Broker

This application provides a web UI to interact with the gitops-csb broker:
- View available services
- Provision service instances with cluster targeting
- Monitor provisioning status
- Deprovision service instances
"""

import json
import os

import requests
from flask import Flask, Response, jsonify, render_template, request
from flask_cors import CORS

from catalog_app.logging_config import configure_logging, get_logger


# Configure structured logging
configure_logging()
logger = get_logger(__name__)

app = Flask(__name__)
CORS(app)  # Enable CORS for API calls

# Configuration
BROKER_URL = os.getenv("BROKER_URL", "http://localhost:7329")


# Middleware to log requests (excluding health checks)
@app.before_request
def log_request() -> None:
    """Log incoming requests, excluding health check endpoints to reduce noise."""
    # Skip logging for health check endpoints
    if request.path == "/health":
        return

    logger.info(
        f"Request: {request.method} {request.path}",
        extra={
            "method": request.method,
            "path": request.path,
            "remote_addr": request.remote_addr,
        },
    )


@app.after_request
def log_response(response: Response) -> Response:
    """Log outgoing responses, excluding health check endpoints to reduce noise."""
    # Skip logging for health check endpoints
    if request.path == "/health":
        return response

    logger.info(
        f"Response: {request.method} {request.path} - {response.status_code}",
        extra={
            "method": request.method,
            "path": request.path,
            "status_code": response.status_code,
        },
    )
    return response


@app.route("/")
def index() -> str:
    """Serve the main UI page."""
    # Pass empty string so JavaScript uses relative URLs
    return render_template("index.html", broker_url="")


@app.route("/api/config")
def get_config() -> Response:
    """Get UI configuration."""
    return jsonify({"broker_url": ""})  # Use relative URLs


@app.route("/api/broker/catalog")
def proxy_catalog() -> Response | tuple[Response, int]:
    """Proxy request to broker's catalog endpoint."""
    try:
        response = requests.get(f"{BROKER_URL}/v2/catalog", timeout=10)
        return Response(
            response.content,
            status=response.status_code,
            content_type=response.headers.get("Content-Type", "application/json"),
        )
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to broker: {str(e)}"}), 503


@app.route("/api/broker/service_instances")
def proxy_service_instances() -> Response | tuple[Response, int]:
    """Proxy request to broker's service instances list endpoint.

    This proxies to the broker's /service_instances endpoint (GitOps-sourced extension).
    Note: This is NOT part of the OSB v2 API - it's a custom extension.
    """
    try:
        response = requests.get(f"{BROKER_URL}/service_instances", timeout=10)
        return Response(
            response.content,
            status=response.status_code,
            content_type=response.headers.get("Content-Type", "application/json"),
        )
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to broker: {str(e)}"}), 503


@app.route(
    "/api/broker/service_instances/<instance_id>",
    defaults={"subpath": ""},
    methods=["PUT", "DELETE", "GET", "PATCH"],
)
@app.route(
    "/api/broker/service_instances/<instance_id>/<path:subpath>",
    methods=["GET"],
)
def proxy_service_instance(instance_id: str, subpath: str) -> Response | tuple[Response, int]:
    """Proxy requests to broker service instance endpoints."""
    try:
        url = f"{BROKER_URL}/v2/service_instances/{instance_id}"
        if subpath:
            url = f"{url}/{subpath}"

        if request.query_string:
            url += f"?{request.query_string.decode('utf-8')}"

        logger.info(f"Proxying {request.method} request to broker: {url}")
        logger.info(
            f"Request body: {request.get_data().decode('utf-8') if request.get_data() else 'None'}"
        )

        response = requests.request(
            method=request.method,
            url=url,
            headers={k: v for k, v in request.headers if k.lower() != "host"},
            data=request.get_data(),
            timeout=30,
        )

        logger.info(f"Broker response: {response.status_code}")

        return Response(
            response.content,
            status=response.status_code,
            content_type=response.headers.get("Content-Type", "application/json"),
        )
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to proxy to broker: {str(e)}")
        return jsonify({"error": f"Failed to connect to broker: {str(e)}"}), 503


@app.route("/api/services/<service_id>/schema")
def proxy_service_schema(service_id: str) -> Response | tuple[Response, int]:
    """Proxy request to broker's service schema endpoint.

    This endpoint retrieves the JSON schema for a service's parameters,
    which is used for client-side validation in the UI.

    NOTE: This proxies to a custom broker endpoint (not part of OSB/CSB API).

    Args:
        service_id: Service identifier (e.g., "mariadb-service")

    Returns:
        JSON schema for the service parameters

    Example response:
        {
            "type": "object",
            "properties": {
                "database_name": {
                    "type": "string",
                    "description": "Name of the database",
                    "minLength": 1,
                    "maxLength": 63
                },
                "database_password": {
                    "type": "string",
                    "description": "Database password (auto-generated if not provided)",
                    "x-auto-generate": true
                }
            },
            "required": ["database_name"]
        }
    """
    try:
        response = requests.get(f"{BROKER_URL}/services/{service_id}/schema", timeout=10)
        return Response(
            response.content,
            status=response.status_code,
            content_type=response.headers.get("Content-Type", "application/json"),
        )
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to fetch schema for service {service_id}: {e}")
        return jsonify({"error": f"Failed to connect to broker: {str(e)}"}), 503


@app.route("/api/clusters")
def get_clusters() -> Response | tuple[Response, int]:
    """Get available Kubernetes clusters from configuration.

    Reads cluster configuration from AVAILABLE_CLUSTERS environment variable.
    This endpoint is now owned by catalog-app (moved from broker).

    Returns:
        JSON response with clusters list and count

    Example response:
        {
            "clusters": [
                {
                    "name": "k3s-cluster-1",
                    "server": "https://kubernetes.default.svc",
                    "type": "hub"
                },
                {
                    "name": "k3s-cluster-2",
                    "server": "https://192.168.2.86:6443",
                    "type": "spoke"
                }
            ],
            "count": 2
        }
    """
    try:
        # Read cluster configuration from environment variable
        clusters_json = os.getenv("AVAILABLE_CLUSTERS", "[]")
        logger.info("Reading cluster configuration from environment")

        # Parse JSON configuration
        clusters = json.loads(clusters_json)

        if not isinstance(clusters, list):
            logger.error(f"AVAILABLE_CLUSTERS must be a JSON array, got {type(clusters).__name__}")
            return jsonify(
                {"clusters": [], "count": 0, "error": "Invalid cluster configuration format"}
            ), 500

        # Validate cluster objects
        valid_clusters = []
        for cluster in clusters:
            if not isinstance(cluster, dict):
                logger.warning(f"Skipping invalid cluster object: {cluster}")
                continue

            if "name" not in cluster or "server" not in cluster:
                logger.warning(f"Skipping cluster missing required fields: {cluster}")
                continue

            # Add type if not specified (default to spoke)
            if "type" not in cluster:
                cluster["type"] = "spoke"

            valid_clusters.append(cluster)
            logger.debug(f"Found cluster: {cluster['name']} ({cluster['type']})")

        logger.info(f"Cluster discovery complete: {len(valid_clusters)} clusters found")

        return jsonify({"clusters": valid_clusters, "count": len(valid_clusters)})

    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse AVAILABLE_CLUSTERS JSON: {e}")
        return jsonify(
            {
                "clusters": [],
                "count": 0,
                "error": f"Invalid JSON in cluster configuration: {str(e)}",
            }
        ), 500

    except Exception as e:
        logger.error(f"Unexpected error during cluster discovery: {e}")
        return jsonify(
            {"clusters": [], "count": 0, "error": f"Cluster discovery failed: {str(e)}"}
        ), 500


@app.route("/health")
def health() -> tuple[Response, int]:
    """Health check endpoint."""
    return jsonify({"status": "healthy"}), 200


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    # Bind to all interfaces for container deployment - safe in Kubernetes with network policies
    host = os.getenv("HOST", "0.0.0.0")  # nosec B104
    # Debug mode controlled by environment variable - defaults to False for production
    debug = os.getenv("FLASK_DEBUG", "false").lower() in ("true", "1", "yes")

    logger.info(
        "Starting Catalog UI",
        extra={"host": host, "port": port, "broker_url": BROKER_URL, "debug": debug},
    )

    app.run(host=host, port=port, debug=debug)  # nosec B201

# Made with Bob
