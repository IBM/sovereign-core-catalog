/**
 * Toast Module - Handles toast notifications and status banners
 */
const Toast = {
    /**
     * Show a toast notification
     * @param {string} message - Message to display
     * @param {string} type - Toast type: 'success', 'error', or 'info'
     * @param {Object} options - Toast rendering options
     * @param {boolean} options.allowHtml - Whether message should be rendered as trusted HTML
     */
    show(message, type = "info", options = {}) {
        const container = document.getElementById("toast-container");
        const toast = document.createElement("div");
        toast.className = `toast ${type}`;

        const iconByType = {
            success: "✅",
            error: "❌",
            info: "ℹ️",
        };

        toast.innerHTML = `
            <div class="toast-icon">${iconByType[type] || "ℹ️"}</div>
            <div class="toast-message"></div>
            <button class="toast-close" type="button" aria-label="Close">×</button>
        `;

        const messageElement = toast.querySelector(".toast-message");
        if (options.allowHtml) {
            messageElement.innerHTML = message;
        } else {
            messageElement.textContent = message;
        }

        toast.querySelector(".toast-close").addEventListener("click", () => {
            toast.remove();
        });

        container.appendChild(toast);

        window.setTimeout(() => {
            toast.remove();
        }, 5000);
    },

    /**
     * Show status banner with message
     * @param {string} message - Status message to display
     */
    showBanner(message) {
        document.getElementById("status-banner-message").textContent = message;
        document.getElementById("status-banner").classList.add("visible");
    },

    /**
     * Hide status banner
     */
    hideBanner() {
        document.getElementById("status-banner").classList.remove("visible");
    },
};
