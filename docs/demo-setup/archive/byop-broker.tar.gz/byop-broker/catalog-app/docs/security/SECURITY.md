# Security Policy - Catalog UI

## Supported Versions

We release patches for security vulnerabilities in the following versions:

| Version | Supported          |
| ------- | ------------------ |
| 1.x.x   | :white_check_mark: |
| < 1.0   | :x:                |

## Reporting a Vulnerability

We take the security of the Catalog UI seriously. If you believe you have found a security vulnerability, please report it to us as described below.

### Where to Report

**Please do NOT report security vulnerabilities through public GitHub issues.**

Instead, please report them via email to:
- **Security Team**: security@example.com
- **Project Maintainer**: maintainer@example.com

### What to Include

Please include the following information in your report:

1. **Description**: A clear description of the vulnerability
2. **Impact**: The potential impact of the vulnerability
3. **Steps to Reproduce**: Detailed steps to reproduce the issue
4. **Proof of Concept**: Code or commands demonstrating the vulnerability (if applicable)
5. **Affected Versions**: Which versions are affected
6. **Suggested Fix**: Any suggestions for fixing the vulnerability (optional)
7. **Your Contact Information**: How we can reach you for follow-up

### Response Timeline

- **Initial Response**: Within 48 hours of receiving your report
- **Status Updates**: Weekly updates on the progress of addressing the vulnerability
- **Resolution**: We aim to resolve critical vulnerabilities within 30 days
- **Disclosure**: Coordinated disclosure after a fix is available

### What to Expect

1. **Acknowledgment**: We will acknowledge receipt of your vulnerability report
2. **Investigation**: We will investigate and validate the vulnerability
3. **Fix Development**: We will develop and test a fix
4. **Disclosure**: We will coordinate disclosure with you
5. **Credit**: We will credit you in the security advisory (unless you prefer to remain anonymous)

## Security Best Practices for Users

### Deployment Security

#### 1. Secure Credential Storage
- **Never hardcode broker API key** in configuration files or code
- Store API key in Kubernetes secrets or environment variables
- Use secret management solutions (Vault, Sealed Secrets)
- Rotate API key regularly

```yaml
# Example: Kubernetes secret for broker API key
apiVersion: v1
kind: Secret
metadata:
  name: catalog-ui-broker-key
type: Opaque
stringData:
  broker-api-key: <your-secure-api-key>
```

```yaml
# Example: Deployment with secret
apiVersion: apps/v1
kind: Deployment
metadata:
  name: catalog-ui
spec:
  template:
    spec:
      containers:
      - name: catalog-ui
        env:
        - name: BROKER_API_KEY
          valueFrom:
            secretKeyRef:
              name: catalog-ui-broker-key
              key: broker-api-key
```

#### 2. HTTPS Configuration
- **Always use HTTPS in production**
- Configure TLS certificates properly
- Use HSTS headers
- Redirect HTTP to HTTPS

```yaml
# Example: Ingress with TLS
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: catalog-ui-ingress
  annotations:
    nginx.ingress.kubernetes.io/force-ssl-redirect: "true"
    nginx.ingress.kubernetes.io/ssl-protocols: "TLSv1.2 TLSv1.3"
spec:
  tls:
  - hosts:
    - catalog.example.com
    secretName: catalog-ui-tls
  rules:
  - host: catalog.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: catalog-ui
            port:
              number: 5000
```

#### 3. Security Headers
Configure security headers in your web server or application:

```python
# Example: Flask security headers
from flask import Flask, make_response

@app.after_request
def set_security_headers(response):
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'"
    return response
```

#### 4. Container Security
- Run as non-root user
- Use read-only root filesystem
- Drop all capabilities
- Apply pod security policies/standards
- Scan container images regularly

```yaml
# Example: Security context
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop:
    - ALL
```

#### 5. Network Security
- Deploy UI in a private network segment
- Use network policies to restrict traffic
- Only allow ingress from load balancer
- Only allow egress to broker

```yaml
# Example: Network policy
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: catalog-ui-network-policy
spec:
  podSelector:
    matchLabels:
      app: catalog-ui
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: ingress-nginx
    ports:
    - protocol: TCP
      port: 5000
  egress:
  - to:
    - podSelector:
        matchLabels:
          app: broker
    ports:
    - protocol: TCP
      port: 5000
  - to:
    - namespaceSelector: {}
    ports:
    - protocol: TCP
      port: 53  # DNS
```

### Application Security

#### 1. Input Validation
Always validate user input on both client and server side:

```python
# Example: Server-side validation
from flask import request, abort

@app.route('/provision', methods=['POST'])
def provision_service():
    # Validate required fields
    if not request.form.get('service_id'):
        abort(400, 'Service ID is required')
    
    # Validate format
    service_id = request.form.get('service_id')
    if not re.match(r'^[a-zA-Z0-9-]+$', service_id):
        abort(400, 'Invalid service ID format')
    
    # Validate length
    if len(service_id) > 100:
        abort(400, 'Service ID too long')
    
    # Sanitize input
    service_id = service_id.strip()
    
    # Continue with provisioning...
```

#### 2. CSRF Protection
Enable CSRF protection for all forms:

```python
# Example: Flask-WTF CSRF protection
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
csrf = CSRFProtect(app)

# In templates
# <form method="POST">
#   {{ csrf_token() }}
#   <!-- form fields -->
# </form>
```

#### 3. XSS Prevention
- Use template auto-escaping (enabled by default in Jinja2)
- Sanitize user input
- Implement Content Security Policy
- Never use `|safe` filter on user input

```python
# Example: Safe template rendering
# Jinja2 auto-escapes by default
{{ user_input }}  # Safe - auto-escaped

# Only use |safe for trusted content
{{ trusted_html|safe }}  # Only for content you control
```

#### 4. Session Security
Configure secure session settings:

```python
# Example: Secure session configuration
app.config['SESSION_COOKIE_SECURE'] = True  # HTTPS only
app.config['SESSION_COOKIE_HTTPONLY'] = True  # No JavaScript access
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'  # CSRF protection
app.config['PERMANENT_SESSION_LIFETIME'] = 3600  # 1 hour timeout
```

### Monitoring and Logging

#### 1. Enable Comprehensive Logging
Log all security-relevant events:

```python
# Example: Security event logging
import logging

logger = logging.getLogger(__name__)

@app.route('/provision', methods=['POST'])
def provision_service():
    logger.info('Provision request', extra={
        'user_ip': request.remote_addr,
        'service_id': request.form.get('service_id'),
        'timestamp': datetime.utcnow().isoformat()
    })
    # Continue with provisioning...
```

#### 2. Security Event Monitoring
Monitor for:
- Failed authentication attempts (if auth enabled)
- Unusual request patterns
- Input validation failures
- CSRF token failures
- Rate limit violations
- Error spikes

#### 3. Log Security
- Forward logs to centralized logging system
- Never log sensitive data (API keys, passwords, tokens)
- Sanitize parameters before logging
- Implement log integrity verification

```python
# Example: Safe logging
def safe_log_params(params):
    """Sanitize parameters before logging."""
    safe_params = params.copy()
    sensitive_keys = ['password', 'api_key', 'token', 'secret']
    for key in sensitive_keys:
        if key in safe_params:
            safe_params[key] = '***REDACTED***'
    return safe_params

logger.info('Request parameters', extra={'params': safe_log_params(request.form)})
```

### Rate Limiting

Implement rate limiting to prevent abuse:

```python
# Example: Flask-Limiter
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

@app.route('/provision', methods=['POST'])
@limiter.limit("10 per minute")
def provision_service():
    # Provisioning logic...
    pass
```

### Incident Response

#### 1. Preparation
- Document incident response procedures
- Identify incident response team
- Maintain contact information
- Test incident response plan

#### 2. Detection and Analysis
- Monitor security alerts
- Investigate suspicious activity
- Determine scope and impact
- Preserve evidence

#### 3. Containment and Recovery
- Isolate affected systems
- Rotate compromised credentials
- Apply security patches
- Restore from known good state
- Verify system integrity

#### 4. Post-Incident
- Document lessons learned
- Update security controls
- Update threat model
- Communicate with stakeholders

## Security Features

### Authentication and Authorization
- API key authentication for broker access (server-side only)
- Session management (if user auth enabled)
- CSRF protection for all forms
- Secure cookie configuration

### Data Protection
- HTTPS for all communications
- Secure cookie flags
- API key never exposed to client
- Input sanitization
- Output encoding

### Input Validation
- Client-side validation (JavaScript)
- Server-side validation (Python)
- Schema validation
- Length limits
- Format validation
- Sanitization

### XSS Prevention
- Template auto-escaping (Jinja2)
- Content Security Policy
- No inline JavaScript
- Input sanitization
- Output encoding

### CSRF Prevention
- CSRF tokens for all forms
- SameSite cookie attribute
- Origin/Referer validation
- Double-submit cookie pattern

### Security Scanning
- Static analysis with Bandit
- Dependency scanning with pip-audit
- Secret scanning with detect-secrets
- Container image scanning
- Regular security audits

## Compliance

### Standards and Frameworks
- OWASP Top 10 compliance
- OWASP ASVS (Application Security Verification Standard)
- CIS Kubernetes Benchmark
- NIST Cybersecurity Framework

### Data Privacy
- GDPR compliance (if applicable)
- Data minimization
- Right to erasure
- Data portability

## Security Updates

### Update Policy
- Security patches released as soon as possible
- Critical vulnerabilities patched within 7 days
- High severity vulnerabilities patched within 30 days
- Medium/Low severity vulnerabilities in next release

### Notification
- Security advisories published on GitHub
- Email notification to registered users
- CVE assignment for significant vulnerabilities

### Upgrade Recommendations
- Always use the latest stable version
- Subscribe to security advisories
- Test updates in non-production first
- Have rollback plan ready

## Security Checklist

### Pre-Deployment
- [ ] Configure HTTPS with valid certificates
- [ ] Set secure cookie flags
- [ ] Enable CSRF protection
- [ ] Configure Content Security Policy
- [ ] Set security headers (HSTS, X-Frame-Options, etc.)
- [ ] Configure rate limiting
- [ ] Set up audit logging
- [ ] Configure network policies
- [ ] Scan container images
- [ ] Review and test security controls

### Post-Deployment
- [ ] Verify HTTPS configuration
- [ ] Test CSRF protection
- [ ] Verify security headers
- [ ] Test rate limiting
- [ ] Review audit logs
- [ ] Scan for vulnerabilities
- [ ] Verify network policies
- [ ] Test input validation
- [ ] Verify API key is not exposed

### Ongoing
- [ ] Monitor security alerts
- [ ] Review audit logs regularly
- [ ] Rotate API key quarterly
- [ ] Update dependencies monthly
- [ ] Scan for vulnerabilities weekly
- [ ] Review security headers quarterly
- [ ] Test security controls quarterly
- [ ] Update threat model annually

## Common Vulnerabilities and Mitigations

### XSS (Cross-Site Scripting)
**Risk**: High  
**Mitigations**:
- Template auto-escaping
- Content Security Policy
- Input sanitization
- Output encoding

### CSRF (Cross-Site Request Forgery)
**Risk**: High  
**Mitigations**:
- CSRF tokens
- SameSite cookies
- Origin/Referer validation

### SQL Injection (if database added)
**Risk**: Critical  
**Mitigations**:
- Parameterized queries
- ORM usage
- Input validation
- Least privilege database user

### Session Hijacking
**Risk**: Medium  
**Mitigations**:
- Secure cookie flags
- HTTPS only
- Session timeout
- Session regeneration

### Information Disclosure
**Risk**: High  
**Mitigations**:
- Generic error messages
- No stack traces in responses
- Sanitize logs
- API key server-side only

## Resources

### Documentation
- [Threat Model](threat-model.md) - Detailed threat analysis
- [Architecture Documentation](../architecture/README.md) - System architecture
- [Configuration Guide](../configuration-guide.md) - Configuration reference

### External Resources
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [OWASP ASVS](https://owasp.org/www-project-application-security-verification-standard/)
- [Flask Security Best Practices](https://flask.palletsprojects.com/en/latest/security/)
- [Content Security Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP)

## Contact

For security-related questions or concerns:
- **Security Team**: security@example.com
- **Project Maintainer**: maintainer@example.com
- **GitHub Issues**: For non-security bugs only

---

*Last Updated: 2026-04-14*  
*Next Review: 2026-07-14*