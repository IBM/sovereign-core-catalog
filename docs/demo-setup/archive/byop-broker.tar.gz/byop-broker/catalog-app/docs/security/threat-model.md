# Threat Model - Catalog UI

## System Overview

The Catalog UI is a web-based user interface that provides a user-friendly way to interact with the GitOps CSB Broker. It allows users to browse the service catalog, provision services, and manage service instances through a web browser.

## Assets

### Critical Assets
1. **Broker API Key**: Used for broker API authentication
2. **User Session Data**: Session tokens and user information (if authentication enabled)
3. **Service Parameters**: User-provided provisioning parameters
4. **Application Code**: Source code and configuration
5. **User Data**: Form inputs and user preferences

### Data Classification
- **Highly Sensitive**: Broker API key, session tokens
- **Sensitive**: Service parameters, user data
- **Internal**: Application configuration
- **Public**: Service catalog information

## Trust Boundaries

### External Boundaries
1. **User → Catalog UI**: HTTPS web interface
2. **Catalog UI → Broker**: HTTPS REST API

### Internal Boundaries
1. **Route Handlers → Broker Client**: Function calls
2. **Route Handlers → Template Renderer**: Function calls

## Threat Analysis (STRIDE)

### Spoofing Identity

#### Threat: Session Hijacking
**Description**: Attacker steals user session token to impersonate user.

**Impact**: Medium - Unauthorized access to user's services

**Likelihood**: Medium - Common web attack

**Mitigations**:
- ✅ Secure cookie flags (HttpOnly, Secure, SameSite)
- ✅ Session timeout
- ✅ Session regeneration after login
- ✅ HTTPS only
- ⚠️ Consider: User authentication and authorization
- ⚠️ Consider: Multi-factor authentication

#### Threat: CSRF Attack
**Description**: Attacker tricks user into performing unwanted actions.

**Impact**: High - Unauthorized service provisioning/deprovisioning

**Likelihood**: High - Common web attack

**Mitigations**:
- ✅ CSRF tokens for all state-changing operations
- ✅ SameSite cookie attribute
- ✅ Verify Origin/Referer headers
- ✅ Double-submit cookie pattern

### Tampering with Data

#### Threat: Form Input Manipulation
**Description**: Attacker modifies form inputs to inject malicious data.

**Impact**: High - Malicious service provisioning

**Likelihood**: High - Easy to execute

**Mitigations**:
- ✅ Client-side validation (JavaScript)
- ✅ Server-side validation (Python)
- ✅ Input sanitization
- ✅ Schema validation against service definitions
- ✅ Parameter whitelisting
- ✅ Length limits on all inputs

#### Threat: API Request Tampering
**Description**: Attacker intercepts and modifies requests to broker.

**Impact**: High - Unauthorized service configuration

**Likelihood**: Low - Requires network access

**Mitigations**:
- ✅ HTTPS/TLS for all communications
- ✅ Request validation before sending to broker
- ✅ Broker API key never exposed to client
- ✅ All broker calls proxied through backend

#### Threat: XSS via User Input
**Description**: Attacker injects malicious scripts through form inputs.

**Impact**: High - Session theft, data theft

**Likelihood**: High - Common web vulnerability

**Mitigations**:
- ✅ Template auto-escaping (Jinja2)
- ✅ Content Security Policy headers
- ✅ Input sanitization
- ✅ Output encoding
- ✅ No inline JavaScript
- ✅ Validate all user inputs

### Repudiation

#### Threat: Denial of Actions
**Description**: User denies performing provisioning or deprovisioning.

**Impact**: Low - Accountability issues

**Likelihood**: Low - Internal users

**Mitigations**:
- ✅ Comprehensive audit logging
- ✅ Log all user actions
- ✅ Session tracking
- ✅ IP address logging
- ✅ Timestamp all events
- ⚠️ Consider: User authentication for non-repudiation

### Information Disclosure

#### Threat: Broker API Key Exposure
**Description**: API key leaked through client-side code or errors.

**Impact**: Critical - Unauthorized broker access

**Likelihood**: Medium - Common misconfiguration

**Mitigations**:
- ✅ API key stored server-side only (environment variable)
- ✅ Never send API key to client
- ✅ All broker calls proxied through backend
- ✅ Sanitize error messages
- ✅ No API key in logs
- ✅ No API key in source code

#### Threat: Sensitive Data in Logs
**Description**: User parameters or credentials logged.

**Impact**: High - Data exposure

**Likelihood**: Medium - Easy to accidentally log

**Mitigations**:
- ✅ Sanitize parameters before logging
- ✅ Never log passwords or secrets
- ✅ Redact sensitive fields
- ✅ Structured logging with field filtering

#### Threat: Information Leakage via Error Messages
**Description**: Detailed error messages reveal system internals.

**Impact**: Medium - Aids attacker reconnaissance

**Likelihood**: High - Common in development

**Mitigations**:
- ✅ Generic error messages to users
- ✅ Detailed errors only in logs
- ✅ No stack traces in responses
- ✅ No file paths in error messages
- ✅ Custom error pages

#### Threat: Directory Traversal
**Description**: Attacker accesses files outside web root.

**Impact**: High - Source code disclosure

**Likelihood**: Low - Framework protects against this

**Mitigations**:
- ✅ Flask framework protection
- ✅ No user-controlled file paths
- ✅ Validate all file access
- ✅ Whitelist allowed paths

### Denial of Service

#### Threat: Request Flooding
**Description**: Attacker floods UI with requests.

**Impact**: High - Service unavailable

**Likelihood**: High - Easy to execute

**Mitigations**:
- ✅ Rate limiting per IP
- ✅ Request throttling
- ✅ Connection limits
- ✅ Timeout configuration
- ✅ Resource quotas (CPU, memory)
- ✅ Horizontal pod autoscaling
- ⚠️ Consider: DDoS protection service
- ⚠️ Consider: CAPTCHA for public endpoints

#### Threat: Large File Upload
**Description**: Attacker uploads large files to exhaust resources.

**Impact**: Medium - Resource exhaustion

**Likelihood**: Low - No file upload in current design

**Mitigations**:
- ✅ File size limits (if file upload added)
- ✅ File type validation
- ✅ Virus scanning
- ✅ Temporary file cleanup

#### Threat: Slowloris Attack
**Description**: Attacker keeps connections open to exhaust resources.

**Impact**: Medium - Service degradation

**Likelihood**: Medium - Known attack pattern

**Mitigations**:
- ✅ Connection timeout
- ✅ Request timeout
- ✅ Maximum connections per IP
- ✅ Load balancer protection

### Elevation of Privilege

#### Threat: Container Escape
**Description**: Attacker escapes container to access host.

**Impact**: Critical - Full system compromise

**Likelihood**: Low - Requires vulnerability

**Mitigations**:
- ✅ Non-root container user
- ✅ Read-only root filesystem
- ✅ Drop all capabilities
- ✅ Security context constraints
- ✅ Pod security policies/standards
- ✅ Regular security updates
- ✅ Container image scanning

#### Threat: Privilege Escalation via Broker API
**Description**: Attacker uses UI to gain elevated broker access.

**Impact**: High - Unauthorized broker operations

**Likelihood**: Low - Requires broker vulnerability

**Mitigations**:
- ✅ Minimal broker API permissions
- ✅ Input validation before broker calls
- ✅ No direct user control of API parameters
- ✅ Broker-side authorization

## Attack Scenarios

### Scenario 1: XSS Attack via Service Parameters
**Attack Path**:
1. Attacker enters malicious JavaScript in service parameter
2. Parameter stored without sanitization
3. Parameter displayed to other users
4. Malicious script executes in victim's browser
5. Attacker steals session token

**Risk**: High  
**Impact**: High - Session hijacking

**Mitigations**:
- Template auto-escaping
- Input sanitization
- Content Security Policy
- Output encoding
- No user-generated HTML

### Scenario 2: CSRF Attack for Service Deprovisioning
**Attack Path**:
1. Attacker crafts malicious page with hidden form
2. Victim visits attacker's page while logged in
3. Form auto-submits to deprovision service
4. Service deleted without user consent

**Risk**: High  
**Impact**: High - Data loss

**Mitigations**:
- CSRF tokens on all forms
- SameSite cookie attribute
- Verify Origin/Referer headers
- Require confirmation for destructive actions

### Scenario 3: Broker API Key Exposure
**Attack Path**:
1. Developer accidentally includes API key in client-side code
2. Attacker views page source
3. Attacker extracts API key
4. Attacker directly calls broker API
5. Unauthorized service provisioning

**Risk**: Critical  
**Impact**: Critical - Full broker access

**Mitigations**:
- API key server-side only
- Secret scanning (detect-secrets)
- Code review process
- Never send API key to client
- Proxy all broker calls

### Scenario 4: SQL Injection (if database added)
**Attack Path**:
1. Attacker enters SQL code in form field
2. Input not properly sanitized
3. SQL code executed against database
4. Attacker gains database access

**Risk**: High (if database added)  
**Impact**: Critical - Data breach

**Mitigations**:
- Parameterized queries
- ORM usage (SQLAlchemy)
- Input validation
- Least privilege database user
- Database activity monitoring

## Security Controls

### Preventive Controls
- ✅ Input validation (client and server)
- ✅ Output encoding
- ✅ CSRF protection
- ✅ XSS prevention (template escaping, CSP)
- ✅ HTTPS only
- ✅ Secure cookie flags
- ✅ Rate limiting
- ✅ Container security (non-root, read-only FS)

### Detective Controls
- ✅ Comprehensive audit logging
- ✅ Security scanning (bandit, pip-audit)
- ✅ Secret scanning (detect-secrets)
- ✅ Container image scanning
- ✅ Request logging
- ⚠️ Consider: Web application firewall (WAF)
- ⚠️ Consider: Intrusion detection system (IDS)

### Corrective Controls
- ✅ Incident response plan
- ✅ Session revocation
- ✅ API key rotation
- ✅ Backup and restore procedures
- ✅ Disaster recovery plan

## Review Schedule

- **Architecture Changes**: Review threat model when architecture changes
- **Quarterly Review**: Reassess threats and controls every quarter
- **Post-Incident**: Review after any security incident
- **Feature Additions**: Review when adding new features

## Assumptions and Dependencies

### Assumptions
- Broker API is properly secured
- Network is segmented and monitored
- Users access UI over HTTPS
- Container platform is secure
- Secrets management follows best practices

### Dependencies
- Broker API availability and security
- Network security infrastructure
- Certificate authority for TLS
- Container platform security

## Open Issues and Future Work

### High Priority
- [ ] Implement user authentication and authorization
- [ ] Add Web Application Firewall (WAF)
- [ ] Implement rate limiting per user
- [ ] Add CAPTCHA for public endpoints

### Medium Priority
- [ ] Implement Content Security Policy reporting
- [ ] Add security headers (HSTS, X-Frame-Options, etc.)
- [ ] Implement session management improvements
- [ ] Add security metrics dashboard

### Low Priority
- [ ] Implement OAuth 2.0 integration
- [ ] Add support for SAML authentication
- [ ] Implement audit log viewer in UI
- [ ] Add security event notifications

---

*Last Updated: 2026-04-14*  
*Next Review: 2026-07-14*