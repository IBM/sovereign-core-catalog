# Catalog UI Documentation

Welcome to the Catalog UI documentation. This directory contains comprehensive documentation for understanding, deploying, and maintaining the web interface for the GitOps CSB Broker.

## Documentation Structure

### Architecture Documentation
Detailed architecture documentation following the C4 model:

- **[Architecture Overview](architecture/README.md)** - Introduction to architecture documentation
- **[System Overview](architecture/system-overview.md)** - C4 Context diagram showing the UI in its ecosystem
- **[Container Diagram](architecture/container-diagram.md)** - Major components and their responsibilities
- **[Component Design](architecture/component-design.md)** - Detailed design of the web application

### Security Documentation
Comprehensive security documentation and policies:

- **[Threat Model](security/threat-model.md)** - STRIDE threat analysis and attack scenarios
- **[Security Policy](security/SECURITY.md)** - Security best practices and vulnerability reporting

## Quick Links

### Getting Started
- [Installation Guide](#installation) - How to deploy the UI
- [Configuration Guide](#configuration) - Configuration options and examples
- [Quick Start](#quick-start) - Get up and running quickly

### Development
- [Development Setup](#development-setup) - Set up development environment
- [Testing Guide](#testing) - How to run tests
- [Contributing](#contributing) - How to contribute to the project

### Operations
- [Deployment Guide](#deployment) - Production deployment guidelines
- [Monitoring](#monitoring) - Monitoring and observability
- [Troubleshooting](#troubleshooting) - Common issues and solutions

## What is the Catalog UI?

The Catalog UI is a web-based user interface that provides a user-friendly way to interact with the GitOps CSB Broker. It allows users to:

- **Browse Service Catalog**: View available services and their plans
- **Provision Services**: Request new service instances with custom parameters
- **Manage Instances**: View, update, and deprovision existing services
- **Monitor Status**: Track provisioning and deployment status

### Key Features

- ✅ **User-Friendly**: Intuitive web interface, no CLI required
- ✅ **Responsive Design**: Works on desktop and mobile devices
- ✅ **Real-Time Updates**: Live status updates for operations
- ✅ **Secure**: HTTPS, CSRF protection, XSS prevention
- ✅ **Accessible**: Keyboard navigation and screen reader support
- ✅ **Lightweight**: Minimal dependencies, fast loading

## Installation

### Prerequisites

- Kubernetes cluster (1.20+)
- GitOps CSB Broker deployed and accessible
- Broker API key

### Quick Install

```bash
# Clone the repository
git clone https://github.com/example/catalog-app.git
cd catalog-app

# Create namespace
kubectl create namespace catalog-ui

# Create secret for broker API key
kubectl create secret generic catalog-ui-broker-key \
  --from-literal=broker-api-key=your-api-key \
  -n catalog-ui

# Deploy UI
kubectl apply -f kubernetes/deployment.yaml -n catalog-ui
```

### Helm Install

```bash
# Add Helm repository
helm repo add catalog-ui https://charts.example.com/catalog-ui
helm repo update

# Install UI
helm install catalog-ui catalog-ui/catalog-ui \
  --namespace catalog-ui \
  --create-namespace \
  --set broker.url=http://broker:5000 \
  --set broker.apiKeySecret=catalog-ui-broker-key
```

### Docker Run (Development)

```bash
# Build image
docker build -t catalog-ui:latest .

# Run container
docker run -d \
  -p 5000:5000 \
  -e BROKER_URL=http://broker:5000 \
  -e BROKER_API_KEY=your-api-key \
  catalog-ui:latest
```

## Configuration

### Environment Variables

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| `BROKER_URL` | Broker API URL | Yes | - |
| `BROKER_API_KEY` | API key for broker | Yes | - |
| `SECRET_KEY` | Flask secret key | Yes | - |
| `SESSION_TIMEOUT` | Session timeout (seconds) | No | `3600` |
| `LOG_LEVEL` | Logging level | No | `INFO` |
| `PORT` | Server port | No | `5000` |

### Configuration File

Create a `config.yaml` file:

```yaml
broker:
  url: http://broker:5000
  api_key: your-secure-api-key
  timeout: 30
  
app:
  secret_key: your-secret-key
  session_timeout: 3600
  port: 5000
  
security:
  csrf_enabled: true
  secure_cookies: true
  https_only: true
  
logging:
  level: INFO
  format: json
```

## Quick Start

### 1. Verify Installation

```bash
# Check UI pod is running
kubectl get pods -n catalog-ui

# Check UI logs
kubectl logs -n catalog-ui deployment/catalog-ui

# Test UI health
curl http://catalog-ui.example.com/health
```

### 2. Access the UI

Open your browser and navigate to:
```
https://catalog-ui.example.com
```

### 3. Browse Services

1. The home page displays the service catalog
2. Click on a service to view details
3. Select a plan to see pricing and features

### 4. Provision a Service

1. Click "Provision" on a service
2. Fill in the provisioning form
3. Review parameters
4. Click "Submit"
5. Monitor provisioning status

### 5. Manage Instances

1. Navigate to "My Services"
2. View list of service instances
3. Click on an instance for details
4. Use actions menu to manage instance

## Development Setup

### Prerequisites

- Python 3.10+
- Node.js 16+ (for frontend development)
- Git
- Docker (for containerized testing)

### Local Development

```bash
# Clone repository
git clone https://github.com/example/catalog-app.git
cd catalog-app

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt

# Install pre-commit hooks (configured at project root)
cd ..
pre-commit install

# Set environment variables
cd catalog-app
export BROKER_URL=http://localhost:5000
export BROKER_API_KEY=dev-api-key
export SECRET_KEY=dev-secret-key

# Run UI locally
python app.py

# Access at http://localhost:5000
```

### Frontend Development

```bash
# Install frontend dependencies (if using npm)
npm install

# Watch for changes and rebuild
npm run watch

# Build for production
npm run build
```

## Testing

### Run All Tests

```bash
make test
```

### Run Specific Test Types

```bash
# Unit tests only
make test-unit

# Integration tests only
make test-integration

# With coverage
make coverage
```

### Test Coverage

```bash
# Generate coverage report
make coverage

# View HTML coverage report
make coverage-report
```

### Manual Testing

```bash
# Run UI with test broker
docker-compose up

# Access UI at http://localhost:5000
# Test broker at http://localhost:5001
```

## Deployment

### Production Deployment

See [Deployment Guide](deployment-guide.md) for detailed production deployment instructions.

Key considerations:
- Use HTTPS with valid certificates
- Store API key in Kubernetes secrets
- Enable CSRF protection
- Configure security headers
- Set resource limits
- Enable monitoring and logging
- Configure rate limiting

### Kubernetes Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: catalog-ui
  namespace: catalog-ui
spec:
  replicas: 3
  selector:
    matchLabels:
      app: catalog-ui
  template:
    metadata:
      labels:
        app: catalog-ui
    spec:
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
      containers:
      - name: catalog-ui
        image: catalog-ui:1.0.0
        ports:
        - containerPort: 5000
        env:
        - name: BROKER_URL
          value: http://broker:5000
        - name: BROKER_API_KEY
          valueFrom:
            secretKeyRef:
              name: catalog-ui-broker-key
              key: broker-api-key
        - name: SECRET_KEY
          valueFrom:
            secretKeyRef:
              name: catalog-ui-secret
              key: secret-key
        resources:
          requests:
            cpu: 250m
            memory: 256Mi
          limits:
            cpu: 500m
            memory: 512Mi
        livenessProbe:
          httpGet:
            path: /health/live
            port: 5000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 5000
          initialDelaySeconds: 5
          periodSeconds: 5
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities:
            drop:
            - ALL
```

### Ingress Configuration

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: catalog-ui-ingress
  namespace: catalog-ui
  annotations:
    nginx.ingress.kubernetes.io/force-ssl-redirect: "true"
    nginx.ingress.kubernetes.io/ssl-protocols: "TLSv1.2 TLSv1.3"
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
spec:
  tls:
  - hosts:
    - catalog.example.com
    secretName: catalog-ui-tls
  rules:
  - host: catalog.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: catalog-ui
            port:
              number: 5000
```

## Monitoring

### Metrics

The UI exposes Prometheus metrics at `/metrics`:

- `ui_requests_total` - Total HTTP requests
- `ui_request_duration_seconds` - Request duration
- `ui_broker_calls_total` - Total broker API calls
- `ui_broker_call_duration_seconds` - Broker call duration
- `ui_errors_total` - Total errors by type

### Logging

Structured JSON logging includes:
- Request ID for correlation
- Timestamp
- Log level
- Component name
- User IP address
- Message
- Context data

### Health Checks

- **Liveness**: `GET /health/live` - UI process is running
- **Readiness**: `GET /health/ready` - Can connect to broker
- **Startup**: `GET /health/startup` - Initial catalog load complete

## Security

### Security Features

- ✅ **HTTPS Only**: All traffic over TLS
- ✅ **CSRF Protection**: Tokens for all forms
- ✅ **XSS Prevention**: Template escaping, CSP
- ✅ **Secure Cookies**: HttpOnly, Secure, SameSite
- ✅ **Input Validation**: Client and server side
- ✅ **Rate Limiting**: Prevent abuse
- ✅ **Security Headers**: HSTS, X-Frame-Options, etc.

### Security Best Practices

1. **Always use HTTPS in production**
2. **Store API key in secrets, never in code**
3. **Enable CSRF protection**
4. **Configure Content Security Policy**
5. **Set secure cookie flags**
6. **Implement rate limiting**
7. **Monitor security logs**
8. **Keep dependencies updated**

See [Security Policy](security/SECURITY.md) for detailed security guidelines.

## Troubleshooting

### Common Issues

#### UI Not Loading

```bash
# Check pod status
kubectl describe pod -n catalog-ui -l app=catalog-ui

# Check logs
kubectl logs -n catalog-ui -l app=catalog-ui

# Common causes:
# - Missing secrets
# - Invalid broker URL
# - Network connectivity issues
```

#### Cannot Connect to Broker

```bash
# Test broker connectivity
kubectl exec -n catalog-ui deployment/catalog-ui -- \
  curl http://broker:5000/v2/catalog

# Check network policies
kubectl get networkpolicy -n catalog-ui

# Common causes:
# - Broker not running
# - Invalid broker URL
# - Network policies blocking access
# - Invalid API key
```

#### CSRF Token Errors

```bash
# Check secret key configuration
kubectl get secret catalog-ui-secret -n catalog-ui -o yaml

# Verify CSRF is enabled
kubectl exec -n catalog-ui deployment/catalog-ui -- \
  env | grep CSRF

# Common causes:
# - Missing or invalid secret key
# - CSRF disabled in config
# - Session expired
# - Cookie issues
```

#### Slow Performance

```bash
# Check resource usage
kubectl top pod -n catalog-ui

# Check broker response time
kubectl logs -n catalog-ui -l app=catalog-ui | grep broker_call_duration

# Common causes:
# - Insufficient resources
# - Slow broker responses
# - Network latency
# - Too many concurrent requests
```

## Contributing

We welcome contributions! Please see our [Contributing Guide](../CONTRIBUTING.md) for details.

### Development Workflow

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests and linting
5. Commit with clear messages
6. Push to your fork
7. Create a pull request

### Code Standards

- Follow PEP 8 style guide
- Use type hints (Python 3.10+ style)
- Write tests for new features
- Update documentation
- Run `make lint` before committing
- Ensure `make ci` passes

## Support

### Getting Help

- **Documentation**: Start here!
- **GitHub Issues**: Report bugs and request features
- **Discussions**: Ask questions and share ideas
- **Email**: support@example.com

### Reporting Issues

When reporting issues, please include:
- UI version
- Browser and version
- Error messages and logs
- Steps to reproduce
- Expected vs actual behavior
- Screenshots (if applicable)

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](../LICENSE) file for details.

## Related Projects

- [GitOps CSB Broker](../../broker/docs/README.md) - Backend service broker
- [ArgoCD](https://argoproj.github.io/cd/) - GitOps continuous delivery
- [Open Service Broker API](https://www.openservicebrokerapi.org/) - Service broker specification

---

*Last Updated: 2026-04-14*