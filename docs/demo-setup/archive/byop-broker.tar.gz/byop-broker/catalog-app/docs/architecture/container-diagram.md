# Container Diagram - Catalog UI

## C4 Container Diagram

This diagram shows the major containers (applications/services) that make up the Catalog UI system.

```mermaid
C4Container
    title Container Diagram - Catalog UI
    
    Person(user, "User", "Web browser user")
    
    Container_Boundary(ui_system, "Catalog UI") {
        Container(web_app, "Web Application", "Flask/Python", "Serves UI and proxies API calls")
        Container(static, "Static Assets", "HTML/CSS/JS", "Frontend interface")
        Container(templates, "Templates", "Jinja2", "HTML templates")
    }
    
    System_Ext(broker, "GitOps CSB Broker", "Service broker API")
    
    Rel(user, web_app, "Accesses UI", "HTTPS")
    Rel(web_app, static, "Serves", "HTTP")
    Rel(web_app, templates, "Renders", "Function calls")
    Rel(web_app, broker, "API calls", "HTTPS/JSON")
```

## Container Descriptions

### Web Application (`app.py`)
**Technology**: Flask (Python)  
**Purpose**: Serve web interface and proxy broker API calls

**Responsibilities**:
- Serve HTML pages
- Handle user requests
- Proxy API calls to broker
- Session management (if authentication enabled)
- Error handling and user feedback
- Request/response transformation

**Key Routes**:
- `GET /` - Home page with catalog
- `GET /services` - List all services
- `GET /services/:id` - Service details
- `POST /provision` - Provision service
- `GET /instances` - List service instances
- `DELETE /instances/:id` - Deprovision service

**Configuration**:
```python
# Environment variables
BROKER_URL = os.getenv('BROKER_URL', 'http://broker:5000')
BROKER_API_KEY = os.getenv('BROKER_API_KEY')
SESSION_SECRET = os.getenv('SESSION_SECRET')
```

### Static Assets
**Technology**: HTML, CSS, JavaScript  
**Purpose**: Frontend user interface

**Components**:
- **HTML**: Page structure and content
- **CSS**: Styling and layout (Bootstrap or custom)
- **JavaScript**: Client-side interactivity and AJAX calls

**Key Features**:
- Responsive design for mobile and desktop
- Form validation
- AJAX for asynchronous operations
- Progress indicators
- Error handling

**File Structure**:
```
static/
├── css/
│   ├── main.css
│   └── bootstrap.min.css
├── js/
│   ├── app.js
│   ├── catalog.js
│   └── provisioning.js
└── images/
    └── logo.png
```

### Templates (`templates/`)
**Technology**: Jinja2  
**Purpose**: Server-side HTML rendering

**Template Files**:
- `base.html` - Base layout template
- `index.html` - Home page / catalog view
- `service_detail.html` - Service details page
- `provision_form.html` - Provisioning form
- `instances.html` - Service instances list
- `error.html` - Error page

**Template Features**:
- Template inheritance (extends base.html)
- Template includes for reusable components
- Context variables from Flask
- Filters for data formatting
- Conditional rendering

**Example Template Structure**:
```html
{% extends "base.html" %}

{% block title %}Service Catalog{% endblock %}

{% block content %}
<div class="catalog">
  {% for service in services %}
    <div class="service-card">
      <h3>{{ service.name }}</h3>
      <p>{{ service.description }}</p>
      <a href="/services/{{ service.id }}">Details</a>
    </div>
  {% endfor %}
</div>
{% endblock %}
```

## Data Flow

### Page Load Flow
```
1. User → Web App (GET /)
2. Web App → Broker (GET /v2/catalog)
3. Broker → Web App (catalog JSON)
4. Web App → Templates (render with catalog data)
5. Templates → Web App (HTML)
6. Web App → User (HTML page)
```

### Provisioning Flow
```
1. User fills form → Web App (POST /provision)
2. Web App validates input
3. Web App → Broker (PUT /v2/service_instances/:id)
4. Broker → Web App (202 Accepted)
5. Web App → User (success message)
6. JavaScript polls for status
7. Web App → Broker (GET /v2/service_instances/:id)
8. Broker → Web App (status JSON)
9. Web App → User (status update)
```

### Error Handling Flow
```
1. User action → Web App
2. Web App → Broker (API call)
3. Broker → Web App (error response)
4. Web App logs error
5. Web App → Templates (render error page)
6. Templates → Web App (error HTML)
7. Web App → User (user-friendly error message)
```

## API Integration

### Broker API Client
The web application includes a broker API client module:

```python
class BrokerClient:
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({
            'X-Broker-API-Version': '2.16',
            'Authorization': f'Bearer {api_key}'
        })
    
    def get_catalog(self) -> dict[str, Any]:
        """Fetch service catalog from broker."""
        
    def provision_service(
        self,
        instance_id: str,
        service_id: str,
        plan_id: str,
        parameters: dict[str, Any]
    ) -> dict[str, Any]:
        """Provision a service instance."""
        
    def deprovision_service(
        self,
        instance_id: str,
        service_id: str,
        plan_id: str
    ) -> dict[str, Any]:
        """Deprovision a service instance."""
```

## Configuration

### Environment Variables
```bash
# Broker connection
BROKER_URL=http://broker:5000
BROKER_API_KEY=your-api-key

# Application settings
FLASK_ENV=production
SECRET_KEY=your-secret-key
SESSION_TIMEOUT=3600

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json
```

### Configuration File
```python
# config.py
class Config:
    BROKER_URL = os.getenv('BROKER_URL', 'http://localhost:5000')
    BROKER_API_KEY = os.getenv('BROKER_API_KEY')
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key')
    SESSION_TIMEOUT = int(os.getenv('SESSION_TIMEOUT', '3600'))
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
```

## Deployment

### Container Requirements
- Python 3.10+
- Flask and dependencies
- Network access to broker

### Resource Requirements
- CPU: 0.25-0.5 core
- Memory: 256MB-512MB
- Storage: 100MB (for application code)

### Scaling Considerations
- Stateless design allows horizontal scaling
- Session storage in Redis for multi-instance deployments
- Load balancer for distributing traffic

## Security

### Input Validation
- Client-side validation with JavaScript
- Server-side validation in Flask
- Sanitize all user inputs
- Validate against service schemas

### XSS Prevention
- Template auto-escaping enabled
- Content Security Policy headers
- Sanitize user-generated content

### CSRF Protection
- CSRF tokens for all forms
- Validate tokens on submission
- SameSite cookie attribute

### Secure Communication
- HTTPS only in production
- Secure cookie flags
- HSTS headers

### API Security
- API key stored securely (environment variable)
- Never expose API key to client
- Proxy all broker calls through backend

---

*Last Updated: 2026-04-14*