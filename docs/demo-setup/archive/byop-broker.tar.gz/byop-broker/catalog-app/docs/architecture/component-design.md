# Component Design - Catalog UI

## C4 Component Diagram

This diagram shows the internal components of the Web Application, which is the main container in the system.

```mermaid
C4Component
    title Component Diagram - Web Application
    
    Container_Boundary(web_app, "Web Application") {
        Component(routes, "Route Handlers", "Flask", "HTTP request handlers")
        Component(broker_client, "Broker Client", "Python", "Broker API client")
        Component(validator, "Input Validator", "Python", "Form validation")
        Component(renderer, "Template Renderer", "Jinja2", "HTML rendering")
        Component(error_handler, "Error Handler", "Python", "Error processing")
        Component(logger, "Logger", "Python", "Structured logging")
    }
    
    Container_Ext(templates, "Templates", "Jinja2 templates")
    System_Ext(broker, "GitOps CSB Broker", "Service broker API")
    
    Rel(routes, validator, "Validates input", "Function calls")
    Rel(routes, broker_client, "Calls broker", "Function calls")
    Rel(routes, renderer, "Renders pages", "Function calls")
    Rel(routes, error_handler, "Handles errors", "Function calls")
    Rel(routes, logger, "Logs events", "Function calls")
    Rel(renderer, templates, "Uses", "Template engine")
    Rel(broker_client, broker, "API calls", "HTTPS/REST")
    Rel(error_handler, logger, "Logs errors", "Function calls")
```

## Component Descriptions

### Route Handlers (`app.py`)
**Purpose**: Handle HTTP requests and coordinate responses

**Key Responsibilities**:
- Define URL routes
- Parse request parameters
- Coordinate component interactions
- Return HTTP responses
- Handle sessions (if enabled)

**Key Routes**:
```python
@app.route('/')
def index() -> str:
    """Display service catalog home page."""
    
@app.route('/services/<service_id>')
def service_detail(service_id: str) -> str:
    """Display service details page."""
    
@app.route('/provision', methods=['POST'])
def provision_service() -> dict[str, Any]:
    """Handle service provisioning request."""
    
@app.route('/instances')
def list_instances() -> str:
    """Display service instances list."""
    
@app.route('/instances/<instance_id>', methods=['DELETE'])
def deprovision_service(instance_id: str) -> dict[str, Any]:
    """Handle service deprovisioning request."""
```

**Request Flow**:
1. Receive HTTP request
2. Validate input via validator
3. Call broker client for data
4. Render response via template renderer
5. Handle errors via error handler
6. Log operation via logger
7. Return HTTP response

### Broker Client
**Purpose**: Interact with GitOps CSB Broker API

**Key Responsibilities**:
- Authenticate with broker
- Make HTTP requests to broker
- Parse broker responses
- Handle API errors
- Retry failed requests
- Cache responses (optional)

**Key Methods**:
```python
class BrokerClient:
    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: int = 30
    ):
        """Initialize broker client."""
        
    def get_catalog(self) -> dict[str, Any]:
        """Fetch service catalog.
        
        Returns:
            Catalog with services and plans
            
        Raises:
            BrokerAPIError: If API call fails
        """
        
    def provision_service(
        self,
        instance_id: str,
        service_id: str,
        plan_id: str,
        parameters: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Provision a service instance.
        
        Args:
            instance_id: Unique instance identifier
            service_id: Service to provision
            plan_id: Service plan
            parameters: Provisioning parameters
            
        Returns:
            Provisioning response with operation status
            
        Raises:
            BrokerAPIError: If provisioning fails
        """
        
    def get_instance_status(
        self,
        instance_id: str
    ) -> dict[str, Any]:
        """Get service instance status.
        
        Args:
            instance_id: Instance identifier
            
        Returns:
            Instance status and details
            
        Raises:
            BrokerAPIError: If status check fails
        """
        
    def deprovision_service(
        self,
        instance_id: str,
        service_id: str,
        plan_id: str
    ) -> dict[str, Any]:
        """Deprovision a service instance.
        
        Args:
            instance_id: Instance to deprovision
            service_id: Service type
            plan_id: Service plan
            
        Returns:
            Deprovisioning response
            
        Raises:
            BrokerAPIError: If deprovisioning fails
        """
```

**Error Handling**:
- Retry transient failures (3 attempts)
- Exponential backoff between retries
- Classify errors (client vs server)
- Log all API interactions
- Provide user-friendly error messages

### Input Validator
**Purpose**: Validate user input and form data

**Key Responsibilities**:
- Validate form submissions
- Check required fields
- Validate data types
- Enforce constraints (min/max, patterns)
- Sanitize input
- Return validation errors

**Key Functions**:
```python
def validate_provision_request(
    data: dict[str, Any]
) -> tuple[bool, list[str]]:
    """Validate provisioning request.
    
    Args:
        data: Form data to validate
        
    Returns:
        Tuple of (is_valid, error_messages)
    """
    
def validate_service_id(
    service_id: str
) -> bool:
    """Validate service ID format.
    
    Args:
        service_id: Service identifier
        
    Returns:
        True if valid, False otherwise
    """
    
def sanitize_input(
    value: str
) -> str:
    """Sanitize user input.
    
    Args:
        value: Raw input value
        
    Returns:
        Sanitized value
    """
```

**Validation Rules**:
- Required fields must be present
- Service ID must match UUID format
- Parameters must match service schema
- String lengths within limits
- No SQL injection patterns
- No XSS patterns

### Template Renderer
**Purpose**: Render HTML templates with data

**Key Responsibilities**:
- Load Jinja2 templates
- Pass context data to templates
- Render HTML output
- Handle template errors
- Apply template filters
- Cache compiled templates

**Key Functions**:
```python
def render_catalog(
    services: list[dict[str, Any]]
) -> str:
    """Render catalog page.
    
    Args:
        services: List of services to display
        
    Returns:
        Rendered HTML
    """
    
def render_service_detail(
    service: dict[str, Any]
) -> str:
    """Render service detail page.
    
    Args:
        service: Service details
        
    Returns:
        Rendered HTML
    """
    
def render_error(
    error_code: int,
    message: str
) -> str:
    """Render error page.
    
    Args:
        error_code: HTTP error code
        message: Error message
        
    Returns:
        Rendered error page
    """
```

**Template Context**:
- Service data from broker
- User session data (if enabled)
- Flash messages
- CSRF tokens
- Configuration values

### Error Handler
**Purpose**: Process and format errors for users

**Key Responsibilities**:
- Catch exceptions
- Log error details
- Format user-friendly messages
- Determine HTTP status codes
- Render error pages
- Track error metrics

**Key Functions**:
```python
def handle_broker_error(
    error: BrokerAPIError
) -> tuple[str, int]:
    """Handle broker API errors.
    
    Args:
        error: Broker API exception
        
    Returns:
        Tuple of (error_message, http_status_code)
    """
    
def handle_validation_error(
    errors: list[str]
) -> tuple[str, int]:
    """Handle validation errors.
    
    Args:
        errors: List of validation error messages
        
    Returns:
        Tuple of (error_message, http_status_code)
    """
    
@app.errorhandler(404)
def not_found(error: Exception) -> tuple[str, int]:
    """Handle 404 errors."""
    
@app.errorhandler(500)
def internal_error(error: Exception) -> tuple[str, int]:
    """Handle 500 errors."""
```

**Error Categories**:
- **Client Errors (4xx)**: Invalid input, not found, unauthorized
- **Server Errors (5xx)**: Broker unavailable, internal errors
- **Network Errors**: Timeout, connection refused
- **Validation Errors**: Form validation failures

### Logger
**Purpose**: Structured logging for application events

**Key Responsibilities**:
- Log HTTP requests
- Log broker API calls
- Log errors and exceptions
- Log performance metrics
- Structured JSON logging
- No sensitive data in logs

**Key Functions**:
```python
def log_request(
    method: str,
    path: str,
    status_code: int,
    duration_ms: float
) -> None:
    """Log HTTP request.
    
    Args:
        method: HTTP method
        path: Request path
        status_code: Response status code
        duration_ms: Request duration in milliseconds
    """
    
def log_broker_call(
    endpoint: str,
    method: str,
    status_code: int,
    duration_ms: float
) -> None:
    """Log broker API call.
    
    Args:
        endpoint: Broker API endpoint
        method: HTTP method
        status_code: Response status code
        duration_ms: Call duration in milliseconds
    """
    
def log_error(
    error: Exception,
    context: dict[str, Any]
) -> None:
    """Log error with context.
    
    Args:
        error: Exception that occurred
        context: Additional context information
    """
```

**Log Levels**:
- **DEBUG**: Detailed diagnostic information
- **INFO**: General informational messages
- **WARNING**: Warning messages
- **ERROR**: Error messages
- **CRITICAL**: Critical errors

## Component Interactions

### Catalog Display Flow
```
1. User requests / → Route Handler
2. Route Handler → Broker Client (get_catalog())
3. Broker Client → Broker API
4. Broker API → Broker Client (catalog JSON)
5. Broker Client → Route Handler (parsed catalog)
6. Route Handler → Template Renderer (render_catalog())
7. Template Renderer → Templates (load and render)
8. Templates → Template Renderer (HTML)
9. Template Renderer → Route Handler (HTML)
10. Route Handler → Logger (log request)
11. Route Handler → User (HTML response)
```

### Provisioning Flow
```
1. User submits form → Route Handler
2. Route Handler → Validator (validate_provision_request())
3. Validator → Route Handler (validation result)
4. If invalid: Route Handler → Error Handler → User
5. If valid: Route Handler → Broker Client (provision_service())
6. Broker Client → Broker API
7. Broker API → Broker Client (202 Accepted)
8. Broker Client → Route Handler (operation response)
9. Route Handler → Logger (log operation)
10. Route Handler → User (success response)
```

## Design Patterns

### Dependency Injection
Components receive dependencies through constructor injection:
```python
class CatalogApp:
    def __init__(
        self,
        broker_client: BrokerClient,
        validator: InputValidator,
        logger: Logger
    ):
        self.broker = broker_client
        self.validator = validator
        self.logger = logger
```

### Error Handling Strategy
- Use specific exception types
- Provide context in error messages
- Log errors with structured logging
- Return user-friendly messages
- Track error metrics

### Logging Strategy
- Structured JSON logging
- Include correlation IDs
- Log all API interactions
- No sensitive data in logs
- Performance metrics

## Testing Strategy

### Unit Tests
- Mock broker client
- Test route handlers in isolation
- Test validation logic
- Test error handling
- Test template rendering

### Integration Tests
- Test with test broker instance
- Test end-to-end workflows
- Test error scenarios
- Test performance

### Test Coverage Goals
- Overall: > 80%
- Route handlers: > 85%
- Validation: > 90%
- Error handling: > 85%

---

*Last Updated: 2026-04-14*