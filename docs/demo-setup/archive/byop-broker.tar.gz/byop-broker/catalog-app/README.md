# Service Catalog Web UI

A simple web interface for interacting with the GitOps CSB (Common Service Broker) server.

## Features

- **📦 Service Catalog**: Browse available services and plans
- **🚀 Provision Services**: Create new service instances with automatic status polling
- **🔧 Manage Instances**: View all provisioned instances with real-time status updates
- **❌ Deprovision Services**: Delete service instances with status tracking
- **⚠️ Error Display**: View detailed error messages for failed operations
- **🔄 Auto-Refresh**: Automatic polling of instance status every 5 seconds

## Prerequisites

- Python 3.10+
- GitOps CSB broker running (default: http://localhost:7329)

## Installation

1. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure broker URL** (optional):
   ```bash
   export CSB_BROKER_URL=http://localhost:7329
   ```

## Usage

### Start the Web UI

```bash
python app.py
```

The web interface will be available at: **http://localhost:5000**

### Configuration

Configure via environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `CSB_BROKER_URL` | `http://localhost:7329` | URL of the GitOps CSB broker |
| `CATALOG_PORT` | `5000` | Port for the web UI server |
| `CATALOG_HOST` | `0.0.0.0` | Host interface to bind to |

Example:
```bash
export CSB_BROKER_URL=http://localhost:8080
export CATALOG_PORT=3000
python app.py
```

## Using the Web Interface

### 1. Browse Services

The main page displays all available services from the broker's catalog. Each service card shows:
- Service name and description
- Available plans
- Provision buttons for each plan

### 2. Provision a Service

1. Click on a plan button (e.g., "Standard", "Premium")
2. Enter an instance ID (e.g., `dev-001`, `prod-mysql-001`)
3. Click "Provision"
4. The instance will appear in the "Provisioned Instances" section with status "in_progress"
5. Status automatically updates to "succeeded" or "failed"

### 3. Monitor Instances

The "Provisioned Instances" section shows:
- **Instance ID**: Unique identifier
- **Status Badge**: Color-coded status (in_progress/succeeded/failed)
- **Service Details**: Service type, plan, timestamps
- **Error Details**: Displayed automatically for failed operations
- **Actions**: Delete and Check Status buttons

Status colors:
- 🟠 **Orange**: Operation in progress
- 🟢 **Green**: Operation succeeded
- 🔴 **Red**: Operation failed

### 4. Deprovision a Service

1. Click the "Delete" button on an instance card
2. Confirm the deletion
3. Status updates to "in_progress" during deprovisioning
4. Instance is removed when deprovisioning completes

### 5. Check Status Manually

Click the "Check Status" button to view the current operation status in a popup dialog.

### 6. Refresh Data

- **Auto-refresh**: Instances refresh automatically every 5 seconds
- **Manual refresh**: Click the circular refresh button (↻) in the bottom-right corner

## Architecture

```
┌─────────────────┐
│   Web Browser   │
│  (JavaScript)   │
└────────┬────────┘
         │ HTTP
         ↓
┌─────────────────┐
│  Catalog UI     │
│  (Flask)        │
│  Port 5000      │
└────────┬────────┘
         │ HTTP API
         ↓
┌─────────────────┐
│  GitOps CSB     │
│  Broker         │
│  Port 7329      │
└─────────────────┘
```

The catalog UI is a thin client that:
1. Serves the HTML/JavaScript interface
2. Proxies API calls to the CSB broker
3. Enables CORS for cross-origin requests

## API Endpoints Used

The UI interacts with these CSB broker endpoints:

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/v2/catalog` | GET | List available services and plans |
| `/v2/service_instances` | GET | List all provisioned instances (custom extension) |
| `/v2/service_instances/:id` | PUT | Provision a new service instance |
| `/v2/service_instances/:id` | DELETE | Deprovision a service instance |
| `/v2/service_instances/:id/last_operation` | GET | Check operation status |

## Development

### Project Structure

```
catalog/
├── app.py                  # Flask application
├── templates/
│   └── index.html         # Web UI (HTML + JavaScript)
├── requirements.txt       # Python dependencies
├── requirements-dev.txt   # Development dependencies
├── Makefile               # Development automation
├── pyproject.toml         # Project configuration
├── pytest.ini             # Test configuration
├── .python-version        # Python version (3.10)
├── tests/                 # Test suite
│   ├── __init__.py
│   ├── conftest.py        # Test fixtures
│   └── unit/
│       └── test_app.py    # Unit tests
└── README.md             # This file
```

### Setup Development Environment

```bash
# Install development dependencies
make install-dev

# Or manually
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

### Running in Development Mode

```bash
# Enable Flask debug mode
export FLASK_ENV=development
export FLASK_DEBUG=1
python app.py

# Or use Makefile
make run-dev
```

### Development Workflow

**Run tests**:
```bash
make test              # Run all tests
make test-unit         # Run unit tests only
make coverage          # Run tests with coverage report
```

**Code quality**:
```bash
make lint              # Run linting checks (ruff, mypy)
make format            # Format code with ruff
make format-check      # Check formatting without changes
make complexity        # Check code complexity with radon
```

**Security**:
```bash
make security          # Run security checks (bandit, pip-audit, detect-secrets)
```

**All checks**:
```bash
make all               # Run format, lint, complexity, and tests
make ci                # Run CI pipeline checks
```

### Code Standards

This project follows the Bob development standards:

- **Python 3.10+** with modern type hints (`dict`, `list`, `X | None`)
- **Ruff** for linting and formatting
- **Mypy** for static type checking
- **Pytest** for testing (target: 80%+ coverage)
- **Radon** for complexity analysis (target: grade B or better)
- **Bandit** for security scanning
- **detect-secrets** for secret detection (IBM fork)

### Pre-commit Checks

Before committing code, run:
```bash
make all
```

This ensures:
- ✅ Code is formatted correctly
- ✅ No linting errors
- ✅ Complexity is within acceptable ranges
- ✅ All tests pass
- ✅ No security issues
- ✅ No secrets in code
```

### Customization

**Change UI colors**: Edit the CSS in `templates/index.html`:
```css
/* Primary color */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* Button colors */
.btn-primary {
    background: #667eea;
}
```

**Change polling interval**: Edit JavaScript in `templates/index.html`:
```javascript
// Auto-refresh instances every 5 seconds
setInterval(loadInstances, 5000);  // Change 5000 to desired milliseconds
```

## Troubleshooting

### Cannot connect to broker

**Problem**: "Error loading services: Failed to fetch"

**Solution**:
```bash
# Verify broker is running
curl http://localhost:7329/health

# Check broker URL configuration
echo $CSB_BROKER_URL

# Ensure broker allows CORS (already configured in gitops-csb)
```

### Port already in use

**Problem**: "Address already in use"

**Solution**:
```bash
# Use a different port
export CATALOG_PORT=5001
python app.py

# Or kill the process using port 5000
lsof -ti:5000 | xargs kill -9
```

### Instances not updating

**Problem**: Status stuck on "in_progress"

**Solution**:
1. Check the CSB broker logs for errors
2. Manually check status: Click "Check Status" button
3. Verify GitOps operations are completing (check ArgoCD)
4. Refresh the page to force reload

### CORS errors in browser console

**Problem**: "Access-Control-Allow-Origin" errors

**Solution**: Ensure flask-cors is installed and the broker has CORS enabled (already configured).

## Integration with GitOps CSB

This UI is designed to work with the GitOps CSB broker. The broker must be running and accessible.

**Start the broker**:
```bash
cd gitops-csb
python app.py
```

**Start the catalog UI**:
```bash
cd catalog
python app.py
```


## Architecture Documentation

For detailed architecture information, see:

- **[Architecture Overview](docs/architecture/README.md)** - Complete architecture documentation
- **[System Context](docs/architecture/system-overview.md)** - C4 Context diagram showing system landscape
- **[Container Diagram](docs/architecture/container-diagram.md)** - C4 Container diagram showing major components
- **[Component Design](docs/architecture/component-design.md)** - C4 Component diagram showing internal structure

**Access the UI**: http://localhost:5000

## Security Considerations

⚠️ **This is a development tool** - not intended for production use without additional security measures:

- No authentication or authorization
- No input validation beyond basic checks
- No rate limiting
- No audit logging
- CORS enabled for all origins

For production use, add:
- User authentication (OAuth, SAML, etc.)
- Role-based access control (RBAC)
- Input validation and sanitization
- Rate limiting and throttling
- Audit logging
- Restricted CORS origins
- HTTPS/TLS encryption

For detailed security information, see:

- **[Security Policy](docs/security/SECURITY.md)** - Security policy and vulnerability reporting
- **[Threat Model](docs/security/threat-model.md)** - STRIDE threat analysis and mitigations

## Contributing

### How to Contribute

1. **Fork the repository**
2. **Create a feature branch**: `git checkout -b feature/my-feature`
3. **Make your changes** following the code standards
4. **Run all checks**: `make ci`
5. **Commit your changes**: `git commit -m "feat: add new feature"`
6. **Push to your fork**: `git push origin feature/my-feature`
7. **Create a Pull Request**

### Commit Message Format

Follow conventional commits:
- `feat:` New feature
- `fix:` Bug fix
- `docs:` Documentation changes
- `refactor:` Code refactoring
- `test:` Test changes
- `chore:` Build/tooling changes

### Pull Request Checklist

- [ ] Code follows project standards
- [ ] All tests pass (`make test`)
- [ ] Linting passes (`make lint`)
- [ ] Complexity is acceptable (`make complexity`)
- [ ] Security checks pass (`make security`)
- [ ] Documentation updated
- [ ] Commit messages follow convention

### Development Standards

This project follows the Bob development standards:

- **Python 3.10+** with modern type hints (`dict`, `list`, `X | None`)
- **Ruff** for linting and formatting (line length: 120)
- **Mypy** for static type checking
- **Pytest** for testing (target: 80%+ coverage)
- **Radon** for complexity analysis (target: grade B or better, complexity < 10)
- **Bandit** for security scanning
- **detect-secrets** for secret detection (IBM fork)


## License

This is a prototype for demonstration purposes.

---

**Status**: ✅ Fully Functional Web UI

The catalog UI provides a complete interface for:
- Browsing available services
- Provisioning service instances
- Monitoring operation status
- Deprovisioning instances
- Viewing error details

*Last Updated: 2026-03-31*