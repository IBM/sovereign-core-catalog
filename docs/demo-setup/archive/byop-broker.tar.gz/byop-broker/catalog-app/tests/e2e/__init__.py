"""End-to-end tests for deployed catalog-app and broker."""

# Made with Bob
