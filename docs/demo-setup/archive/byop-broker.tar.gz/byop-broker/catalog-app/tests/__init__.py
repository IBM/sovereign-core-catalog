"""Tests for catalog web UI."""

# Made with Bob
