"""Pytest configuration and fixtures for catalog UI tests."""

import pytest
import requests_mock as rm

from catalog_app.app import app as flask_app


@pytest.fixture
def app():
    """Create Flask application for testing."""
    flask_app.config.update(
        {
            "TESTING": True,
        }
    )
    yield flask_app


@pytest.fixture
def client(app):
    """Create test client."""
    return app.test_client()


@pytest.fixture
def runner(app):
    """Create test CLI runner."""
    return app.test_cli_runner()


@pytest.fixture
def requests_mock():
    """Create requests mock fixture."""
    with rm.Mocker() as m:
        yield m


# Made with Bob
