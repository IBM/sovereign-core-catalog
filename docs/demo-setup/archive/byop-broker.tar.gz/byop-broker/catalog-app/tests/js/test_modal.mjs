/**
 * Unit tests for modal.js — Modal module
 *
 * Uses Node.js built-in test runner (node:test, available since Node 18).
 * No npm install required.
 *
 * Run:  node --test tests/js/test_modal.mjs
 *   or: make test-js
 */

import { test, describe } from "node:test";
import assert from "node:assert/strict";

// ---------------------------------------------------------------------------
// Minimal DOM stub — only the getElementById surface that modal.js touches
// ---------------------------------------------------------------------------
const domStore = {};

global.document = {
    getElementById(id) {
        if (!(id in domStore)) {
            domStore[id] = { value: "", placeholder: "" };
        }
        return domStore[id];
    },
};

function resetDom(overrides = {}) {
    for (const key of Object.keys(domStore)) delete domStore[key];
    for (const [id, attrs] of Object.entries(overrides)) {
        domStore[id] = { value: "", placeholder: "", ...attrs };
    }
}

// ---------------------------------------------------------------------------
// Load the module under test.
// modal.js is written as a plain script that assigns to `const Modal = {...}`.
// We import it as a CJS-style side-effect and re-export Modal via globalThis.
// ---------------------------------------------------------------------------
// modal.js uses `const Modal = { ... };` — not exported.  We append a
// globalThis assignment and evaluate it so Modal is accessible here.
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const modalSrc = readFileSync(
    resolve(__dirname, "../../src/catalog_app/static/js/modal.js"),
    "utf8"
);

// Stub out Validation (only the shape modal.js reads)
global.Validation = { currentSchema: null };

// Evaluate the source, then expose the module-scoped `Modal` onto globalThis.
// Using indirect eval so `const` declarations are visible to the assignment.
// eslint-disable-next-line no-eval
(0, eval)(modalSrc + "\nglobalThis.Modal = Modal;");
const Modal = global.Modal;

// ---------------------------------------------------------------------------
// generateExampleValue
// ---------------------------------------------------------------------------
describe("generateExampleValue", () => {
    test("returns first element of examples array", () => {
        const result = Modal.generateExampleValue(
            { type: "string", examples: ["hello", "world"] },
            "key"
        );
        assert.equal(result, "hello");
    });

    test("prefers examples over default", () => {
        const result = Modal.generateExampleValue(
            { type: "string", examples: ["from-examples"], default: "from-default" },
            "key"
        );
        assert.equal(result, "from-examples");
    });

    test("falls back to default when no examples", () => {
        const result = Modal.generateExampleValue(
            { type: "string", default: "my-default" },
            "key"
        );
        assert.equal(result, "my-default");
    });

    test("falls back to first enum value when no examples or default", () => {
        const result = Modal.generateExampleValue(
            { type: "string", enum: ["tiny", "small", "medium"] },
            "plan"
        );
        assert.equal(result, "tiny");
    });

    test("handles nested object recursively", () => {
        const result = Modal.generateExampleValue(
            {
                type: "object",
                properties: {
                    name: { type: "string", examples: ["alice"] },
                },
            },
            "instance"
        );
        assert.deepEqual(result, { name: "alice" });
    });

    test("handles boolean type", () => {
        assert.equal(Modal.generateExampleValue({ type: "boolean" }, "flag"), false);
    });

    test("handles integer type with minimum", () => {
        assert.equal(
            Modal.generateExampleValue({ type: "integer", minimum: 5 }, "count"),
            5
        );
    });

    test("handles integer type without minimum", () => {
        assert.equal(Modal.generateExampleValue({ type: "integer" }, "count"), 1);
    });
});

// ---------------------------------------------------------------------------
// buildExampleFromProperties
// ---------------------------------------------------------------------------
describe("buildExampleFromProperties", () => {
    test("builds flat example from schema properties", () => {
        const properties = {
            plan: { type: "string", examples: ["medium"] },
            timeout: { type: "integer", minimum: 10 },
        };
        const result = Modal.buildExampleFromProperties(properties, ["plan"]);
        assert.deepEqual(result, { plan: "medium", timeout: 10 });
    });

    test("skips cluster_url", () => {
        const properties = {
            cluster_url: { type: "string" },
            name: { type: "string", examples: ["my-instance"] },
        };
        const result = Modal.buildExampleFromProperties(properties);
        assert.ok(!("cluster_url" in result));
        assert.equal(result.name, "my-instance");
    });

    test("builds nested example", () => {
        const properties = {
            instance: {
                type: "object",
                properties: {
                    name: { type: "string", examples: ["qradar-dev-01"] },
                },
            },
        };
        const result = Modal.buildExampleFromProperties(properties);
        assert.deepEqual(result, { instance: { name: "qradar-dev-01" } });
    });
});

// ---------------------------------------------------------------------------
// Plan override in updateParametersFieldFromSchema
// ---------------------------------------------------------------------------
describe("updateParametersFieldFromSchema — plan override", () => {
    const qradarSchema = {
        properties: {
            plan: {
                type: "string",
                enum: ["tiny", "small", "medium", "large", "small-ha", "medium-ha", "large-ha"],
                examples: ["medium"],
            },
            instance: {
                type: "object",
                properties: {
                    name: { type: "string", examples: ["qradar-dev-01"] },
                },
            },
        },
        required: ["plan", "instance"],
    };

    test("placeholder plan matches the selected plan button (standalone)", () => {
        resetDom({
            "plan-id": { value: "small" },
            "parameters-json": { value: "", placeholder: "" },
        });
        global.Validation.currentSchema = qradarSchema;

        Modal.updateParametersFieldFromSchema(true);

        const placeholder = JSON.parse(domStore["parameters-json"].placeholder);
        assert.equal(
            placeholder.plan,
            "small",
            "placeholder.plan should match plan-id, not schema examples[0]"
        );
    });

    test("placeholder plan matches the selected plan button (HA)", () => {
        resetDom({
            "plan-id": { value: "medium-ha" },
            "parameters-json": { value: "", placeholder: "" },
        });
        global.Validation.currentSchema = qradarSchema;

        Modal.updateParametersFieldFromSchema(true);

        const placeholder = JSON.parse(domStore["parameters-json"].placeholder);
        assert.equal(placeholder.plan, "medium-ha");
    });

    test("placeholder plan matches large-ha button", () => {
        resetDom({
            "plan-id": { value: "large-ha" },
            "parameters-json": { value: "", placeholder: "" },
        });
        global.Validation.currentSchema = qradarSchema;

        Modal.updateParametersFieldFromSchema(true);

        const placeholder = JSON.parse(domStore["parameters-json"].placeholder);
        assert.equal(placeholder.plan, "large-ha");
    });

    test("does not override when plan-id is empty (no plan selected)", () => {
        resetDom({
            "plan-id": { value: "" },
            "parameters-json": { value: "", placeholder: "" },
        });
        global.Validation.currentSchema = qradarSchema;

        Modal.updateParametersFieldFromSchema(true);

        const placeholder = JSON.parse(domStore["parameters-json"].placeholder);
        // Falls back to schema examples[0] = "medium"
        assert.equal(placeholder.plan, "medium");
    });

    test("leaves schema unchanged when schema has no plan property", () => {
        resetDom({
            "plan-id": { value: "small" },
            "parameters-json": { value: "", placeholder: "" },
        });
        global.Validation.currentSchema = {
            properties: { database_name: { type: "string", examples: ["mydb"] } },
            required: ["database_name"],
        };

        Modal.updateParametersFieldFromSchema(true);

        const placeholder = JSON.parse(domStore["parameters-json"].placeholder);
        assert.ok(!("plan" in placeholder), "no plan key should be injected");
        assert.equal(placeholder.database_name, "mydb");
    });

    test("sets generic placeholder when schema is unavailable", () => {
        resetDom({ "parameters-json": { value: "", placeholder: "" } });
        global.Validation.currentSchema = null;

        Modal.updateParametersFieldFromSchema(false);

        assert.equal(
            domStore["parameters-json"].placeholder,
            '{"parameter_name": "value"}'
        );
    });
});

// ---------------------------------------------------------------------------
// fillExampleParameters — plan override in fallback path
// ---------------------------------------------------------------------------
describe("fillExampleParameters — plan override", () => {
    const qradarSchema = {
        properties: {
            plan: {
                type: "string",
                enum: ["tiny", "small", "medium", "large", "small-ha", "medium-ha", "large-ha"],
                examples: ["medium"],
            },
        },
        required: ["plan"],
    };

    test("copies placeholder (already plan-corrected) into field value", () => {
        resetDom({
            "plan-id": { value: "small-ha" },
            "parameters-json": { value: "", placeholder: '{"plan":"small-ha"}' },
        });

        Modal.fillExampleParameters();

        assert.equal(domStore["parameters-json"].value, '{"plan":"small-ha"}');
    });

    test("fallback path overrides plan from plan-id when placeholder is generic", () => {
        resetDom({
            "plan-id": { value: "large-ha" },
            "parameters-json": { value: "", placeholder: '{"parameter_name": "value"}' },
        });
        global.Validation.currentSchema = qradarSchema;

        Modal.fillExampleParameters();

        const filled = JSON.parse(domStore["parameters-json"].value);
        assert.equal(filled.plan, "large-ha");
    });

    test("fallback path leaves plan as schema example when plan-id is empty", () => {
        resetDom({
            "plan-id": { value: "" },
            "parameters-json": { value: "", placeholder: '{"parameter_name": "value"}' },
        });
        global.Validation.currentSchema = qradarSchema;

        Modal.fillExampleParameters();

        const filled = JSON.parse(domStore["parameters-json"].value);
        assert.equal(filled.plan, "medium"); // schema examples[0]
    });
});
