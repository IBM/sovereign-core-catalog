"""Unit tests for catalog UI Flask application."""

import pytest


@pytest.mark.unit
def test_index_route(client):
    """Test that index route returns HTML."""
    response = client.get("/")
    assert response.status_code == 200
    assert b"Service Catalog" in response.data


@pytest.mark.unit
def test_health_check(client):
    """Test health check endpoint."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.get_json()
    assert data["status"] == "healthy"


@pytest.mark.unit
def test_config_endpoint(client):
    """Test configuration endpoint."""
    response = client.get("/api/config")
    assert response.status_code == 200
    data = response.get_json()
    assert "broker_url" in data
    assert isinstance(data["broker_url"], str)


@pytest.mark.unit
def test_schema_proxy_endpoint_success(client, requests_mock):
    """Test schema proxy endpoint with successful broker response."""
    service_id = "mariadb-service"
    mock_schema = {
        "type": "object",
        "properties": {
            "database_name": {"type": "string"},
            "database_password": {"type": "string", "x-auto-generate": True},
        },
        "required": ["database_name"],
    }

    # Mock the broker's schema endpoint
    requests_mock.get(
        f"http://localhost:7329/services/{service_id}/schema",
        json=mock_schema,
        status_code=200,
    )

    response = client.get(f"/api/services/{service_id}/schema")
    assert response.status_code == 200
    data = response.get_json()
    assert data == mock_schema
    assert "properties" in data
    assert "database_name" in data["properties"]


@pytest.mark.unit
def test_schema_proxy_endpoint_not_found(client, requests_mock):
    """Test schema proxy endpoint when service not found."""
    service_id = "nonexistent-service"

    # Mock the broker returning 404
    requests_mock.get(
        f"http://localhost:7329/services/{service_id}/schema",
        json={
            "error": "not_found",
            "description": "No schema found for service 'nonexistent-service'",
        },
        status_code=404,
    )

    response = client.get(f"/api/services/{service_id}/schema")
    assert response.status_code == 404
    data = response.get_json()
    assert "error" in data
    assert data["error"] == "not_found"


@pytest.mark.unit
def test_schema_proxy_endpoint_broker_unavailable(client, requests_mock):
    """Test schema proxy endpoint when broker is unavailable."""
    import requests.exceptions

    service_id = "mariadb-service"

    # Mock connection error
    requests_mock.get(
        f"http://localhost:7329/services/{service_id}/schema",
        exc=requests.exceptions.ConnectionError("Connection refused"),
    )

    response = client.get(f"/api/services/{service_id}/schema")
    assert response.status_code == 503
    data = response.get_json()
    assert "error" in data
    assert "Failed to connect to broker" in data["error"]


# Made with Bob
