#!/usr/bin/env python3
"""Check if all required dependencies are installed."""

import sys
from importlib import import_module


REQUIRED_PACKAGES = [
    "flask",
    "flask_cors",
    "requests",
]

DEV_PACKAGES = [
    "pytest",
    "pytest_cov",
    "pytest_flask",
    "ruff",
    "mypy",
    "radon",
    "bandit",
]


def check_packages(packages: list[str], package_type: str = "required") -> bool:
    """Check if packages are installed.
    
    Args:
        packages: List of package names to check
        package_type: Type of packages (for display)
        
    Returns:
        True if all packages are installed, False otherwise
    """
    missing = []
    for package in packages:
        try:
            import_module(package)
        except ImportError:
            missing.append(package)
    
    if missing:
        print(f"✗ Missing {package_type} packages: {', '.join(missing)}")
        return False
    
    print(f"✓ All {package_type} packages installed")
    return True


def main() -> int:
    """Main function.
    
    Returns:
        Exit code (0 for success, 1 for failure)
    """
    print("Checking catalog-app dependencies...\n")
    
    required_ok = check_packages(REQUIRED_PACKAGES, "required")
    dev_ok = check_packages(DEV_PACKAGES, "development")
    
    print()
    if required_ok and dev_ok:
        print("✓ All dependencies installed")
        return 0
    elif required_ok:
        print("⚠ Required dependencies installed, but some dev dependencies missing")
        print("  Run: pip install -r requirements-dev.txt")
        return 0
    else:
        print("✗ Missing required dependencies")
        print("  Run: pip install -r requirements.txt")
        return 1


if __name__ == "__main__":
    sys.exit(main())

# Made with Bob
