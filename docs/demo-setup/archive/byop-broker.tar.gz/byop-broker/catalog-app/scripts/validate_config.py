#!/usr/bin/env python3
"""Validate configuration and environment variables for catalog-app."""

import os
import sys


REQUIRED_ENV_VARS = {
    "BROKER_URL": "URL of the GitOps CSB Broker",
}

OPTIONAL_ENV_VARS = {
    "PORT": "Port to run the application on (default: 8080)",
    "FLASK_ENV": "Flask environment (development/production)",
    "FLASK_DEBUG": "Enable Flask debug mode (0/1)",
}


def validate_env_vars() -> tuple[bool, list[str]]:
    """Validate environment variables.
    
    Returns:
        Tuple of (all_valid, missing_vars)
    """
    missing = []
    
    for var, description in REQUIRED_ENV_VARS.items():
        value = os.getenv(var)
        if not value:
            missing.append(f"{var}: {description}")
        else:
            print(f"✓ {var}={value}")
    
    return len(missing) == 0, missing


def show_optional_vars() -> None:
    """Show optional environment variables and their current values."""
    print("\nOptional environment variables:")
    for var, description in OPTIONAL_ENV_VARS.items():
        value = os.getenv(var)
        if value:
            print(f"  {var}={value} - {description}")
        else:
            print(f"  {var}=(not set) - {description}")


def validate_broker_url() -> bool:
    """Validate broker URL format.
    
    Returns:
        True if valid, False otherwise
    """
    broker_url = os.getenv("BROKER_URL")
    if not broker_url:
        return True  # Will be caught by required vars check
    
    if not (broker_url.startswith("http://") or broker_url.startswith("https://")):
        print(f"⚠ BROKER_URL should start with http:// or https://: {broker_url}")
        return False
    
    return True


def main() -> int:
    """Main function.
    
    Returns:
        Exit code (0 for success, 1 for failure)
    """
    print("Validating catalog-app configuration...\n")
    print("Required environment variables:")
    
    all_valid, missing = validate_env_vars()
    
    if missing:
        print("\n✗ Missing required environment variables:")
        for var in missing:
            print(f"  - {var}")
        print("\nSet them in your environment or .env file")
        return 1
    
    if not validate_broker_url():
        print("\n✗ Invalid BROKER_URL format")
        return 1
    
    show_optional_vars()
    
    print("\n✓ Configuration is valid")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Made with Bob
