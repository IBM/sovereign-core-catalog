# Helper Scripts

This directory contains helper scripts for development and testing of the Catalog UI.

## Available Scripts

### check_dependencies.py
Verify that all required dependencies are installed.

**Usage:**
```bash
python scripts/check_dependencies.py
```

### validate_config.py
Validate configuration and environment variables.

**Usage:**
```bash
python scripts/validate_config.py
```

## Running Scripts

All scripts can be run from the catalog-app root directory:

```bash
# Check dependencies
python scripts/check_dependencies.py

# Validate configuration
python scripts/validate_config.py
```

## Adding New Scripts

When adding new helper scripts:
1. Create the script in this directory
2. Add a shebang line: `#!/usr/bin/env python3`
3. Make it executable: `chmod +x scripts/your_script.py`
4. Document it in this README
5. Follow the project's Python coding standards

---

*Last Updated: 2026-04-14*